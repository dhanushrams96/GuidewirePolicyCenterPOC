@personal_auto @submission
Feature: Notes

  As an agent, I want to add or edit notes on a policy so I can capture additional information relevant to the policy in the system.

  Background:
    Given I am a user with the "Producer" role
    And an in-force Personal Auto policy

  @DesignatedFunction
  Scenario: Create a note on the policy
    When I create a note with the following:
      | Topic          | Pre-renewal direction                    |
      | Subject        | My Subject                               |
      | Security Level | Unrestricted                            |
      | Text           | Refer to customer service representative |
    Then the policy should have the following note:
      | Topic          | Pre-renewal direction                    |
      | Subject        | My Subject                               |
      | Security Level | Unrestricted                            |
      | Text           | Refer to customer service representative |