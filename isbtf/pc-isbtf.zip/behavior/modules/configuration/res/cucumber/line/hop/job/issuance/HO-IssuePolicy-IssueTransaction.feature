@homeowners @issuance @HO-IssuePolicy-IssueTransaction
Feature: Issuance of bound policy

  As an agent,
  I want to make changes to a bound but not issued policy,
  so that policy gets issued and accompanying forms are inferred.

  Background:
    Given I am a user with the "Producer" role

  @11560-GW @DesignatedFunction
  Scenario: Issue a bound policy
    Given a bound but not issued Homeowners submission
    When I begin an issuance
    And I quote the issuance
    And I issue the issuance
    Then the issuance status should be "Bound"
    And policy should be issued

  @11560-GW @DesignatedFunction
  Scenario: Bind Quoted Submission
    Given a Homeowners submission
    And the job status is "Quoted"
    When I bind the policy
    Then the submission status should be "Bound"

  @11560-GW @DesignatedFunction
  Scenario: Issue a bound policy
    Given a Homeowners submission
    And the job status is "Quoted"
    When I issue the policy
    Then the submission status should be "Bound"
    And policy should be issued
