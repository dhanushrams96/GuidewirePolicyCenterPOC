@personal_auto @policy_change
Feature: Policy Change

  As an agent, I want to modify a policy that is in-force. The change can start anytime during the policy contractual
  period and is effective for the rest of the contractual period.

  Background:
    Given I am a user with the "Producer" role
    And today's date is "07/01/2018"
    And an in-force Personal Auto policy

  Scenario: Begin a mid-term Policy Change from the actions menu and use the Policy Change Wizard. When a new vehicle
  is added, the premium of the quoted policy is increased.
    When I begin a new policy change
    # Effective 3 months into the term
    And I set the policy change effective date to "10/01/2018"
    And I add the following vehicle:
      | Make       | Ford   |
      | Model      | Fusion |
      | Model Year | 2018   |
      | Cost New   | 22000  |
    And I quote the policy change
    Then the policy change status should be "Quoted"
    And the change in cost should be "433.00 USD"
    When I issue the policy change
    Then the policy change status should be "Bound"

  Scenario: Add a driver and a vehicle in a Policy Change
    When I begin a new policy change
    And I add the following driver:
      | First name          | Dave         |
      | Last name           | Davidson     |
      | Date of Birth       | 01/01/1970   |
      | Address 1           | 123 Lake St. |
      | Year First Licensed | 2000         |
    And I add the following vehicle:
      | Make       | Ford          |
      | Model      | Fusion        |
      | Model Year | 2018          |
      | Cost New   | 22000         |
      | Driver     | Dave Davidson |
    And I quote the policy change
    Then the policy change status should be "Quoted"

  Scenario: Onset and offset transactions are created on a mid-term policy change
    Given a Personal Auto submission
    And the job status is "Draft"
    And I add the following vehicle:
      | Make       | Ford   |
      | Model      | Fusion |
      | Model Year | 2018   |
      | Cost New   | 22000  |
    And I quote the submission
    And I issue the policy
    When I begin a new policy change
    # Effective 3 months into the term
    And I set the policy change effective date to "10/01/2018"
    And I revise vehicle "2018 Ford Fusion" with the following fields:
      | Cost New   | 61000  |
    And I quote the policy change
    Then the policy change status should be "Quoted"
    Then the following onset and offset transactions for vehicle "2018 Ford Fusion" should exist:
      | Comprehensive Coverage                                 | -31.00 USD |
      | Comprehensive Coverage                                 | 51.00 USD  |
      | Collision Coverage                                     | -50.00 USD |
      | Collision Coverage                                     | 83.00 USD  |
      | CA Tax                                                 | 111.00 USD |
      | CA Tax                                                 | -107.00 USD|

  Scenario: Handle a policy change preemption
    When I begin a new policy change
    And I store the current job as "PREEMPTED:12345"
    And I add the following vehicle:
      | Make            | Acura        |
      | Model           | Foo1         |
      | Model Year      | 2010         |
      | Body Type       | Pickup truck |
      | color           | Red          |
      | Cost New        | 22000        |
    And I quote the policy change
    And I begin another new policy change
    And I store the current job as "PREEMPTING:54321"
    And I add the following vehicle:
      | Make            | Acura        |
      | Model           | Foo2         |
      | Model Year      | 2010         |
      | Body Type       | Convertible  |
      | Cost New        | 34000        |
    And I quote the policy change
    And I issue the policy change
    And I recall "PREEMPTED:12345" as the current job
    Then the policy change should be preempted
    And I apply the preemption forward
    And the following vehicle should exist:
      | Make          | Acura        |
      | Model         | Foo2         |
      | Model Year    | 2010         |
      | Body Type     | Convertible  |
      | Cost New      | 34000 USD    |

  Scenario: When I quote a conflicting out-of-sequence policy change, the conflicts are shown on the quote screen
    When I begin a new policy change
    # Effective 2 months into the term
    And I set the transaction effective date to "09/01/2018"
    And I add the "Medical Payments" line-level coverage:
      | Medical Limit | 10,000 |
    And I quote the policy change
    And I issue the policy change
    When I begin a new policy change
    # Effective 1 month into the term
    And I set the transaction effective date to "08/01/2018"
    And I add the "Medical Payments" line-level coverage:
      | Medical Limit | 15,000 |
    And I quote the policy change
    Then the policy change status should remain "Draft"
    And there should be the following conflicts:
      | Item          | Policy Change  | Conflict  |
      | Medical Limit | 15,000         | 10,000    |

  Scenario: Resolve out-of-sequence conflict and issue
    When I begin a new policy change
    # Effective 2 months into the term
    And I set the transaction effective date to "09/01/2018"
    And I add the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 100/200/50 |
    And I quote the policy change
    And I issue the policy change
    And I begin a new policy change
    # Effective 1 month into the term
    And I set the transaction effective date to "08/01/2018"
    And I add the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 500K CSL |
    And I quote the policy change
    Then the policy change status should remain "Draft"
    When I resolve all conflicts as "Override None"
    And I quote the policy change
    And I issue the policy change
    Then the policy change status should be "Bound"
    And I view the policy as of "0" days into the term
    #submission slice
    And the "Liability - Bodily Injury and Property Damage" line-level coverage on Policy File should exist:
      | Auto Liability Package | 250/500/100 |
    And I view the policy as of "31" days into the term
    # out-of-sequence slice
    And the "Liability - Bodily Injury and Property Damage" line-level coverage on Policy File should exist:
      | Auto Liability Package | 500K CSL |
    And I view the policy as of "62" days into the term
    And the "Liability - Bodily Injury and Property Damage" line-level coverage on Policy File should exist:
      | Auto Liability Package | 100/200/50 |

  Scenario: Policy Change with holds
    When I create a hold with a new Hold Rule:
      | Hold Type        | Regulatory Hold        |
      | Code             | Code:55555             |
      | Description      | Sandy Hurricane        |
      # the Hold Start date is 2 months prior to today
      | Hold Start Date  | 05/01/2018       |
      # the Hold End date is 2 months after today
      | Hold End Date    | 09/01/2018 |
      | UW Issue Type    | Regulatory Policy Hold |
      | Long Description | Sandy Hurricane        |
      # Hold Rule
      | Line of Business        | Personal Auto    |
      | Policy Transaction Type | Policy Change    |
      | Transaction Date Type   | Reference Date  |
      # go to a popup to search for the coverage
      | Coverage                | Towing and Labor |
    And I begin a new policy change
    # Effective from day one
    And I set the policy change effective date to "07/01/2018"
    And I set the "Towing and Labor" vehicle-level coverage:
      | Towing and Labor Limit | 100 |
    And I quote the policy change
    Then the following UW issues should exist
      | Section Title  | Short Description |
      | Blocking Quote | Sandy Hurricane   |
    # Complete Policy change after holds are removed
    And I remove the Hold having code "Code:55555"
    And the "Policy Hold Job Evaluation" batch process is executed
    And I quote the policy change
    Then the policy change status should be "Quoted"