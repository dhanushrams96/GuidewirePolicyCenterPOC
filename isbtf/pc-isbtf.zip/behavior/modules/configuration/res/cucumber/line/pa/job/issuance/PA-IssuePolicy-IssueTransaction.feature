@personal_auto @issuance @PA-IssuePolicy-IssueTransaction

Feature: Issuance of bound policy

  As an agent,
  I want to create a submission and issue the policy,
  so that policy gets officially issued.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |

  @11010-GW
  Scenario: Issue a quoted Personal Auto submission
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I issue the policy
    Then the submission status should be "Bound"
