@personal_auto @submission
Feature: Contingencies

  As an agent, I want to view and manage contingencies on a policy such as adding, removing, waiving or resolving existing
  contingencies on a policy and ensure the necessary actions are executed on policies with unresolved overdue contingencies.

  Background:
    Given I am a user with the "Underwriter" role
    Given today's date is "07/01/2018"

  Scenario: Issue a policy with added contingency to the policy
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I add the following contingency:
      | Title       | Proof of Title              |
      | Description | Missing Title               |
      | Action      | Change policy retroactively |
      | Due Date    | 07/15/2018                  |
    And I issue the policy
    Then the submission status should be "Bound"
    And the status of the contingency is "Pending"
    And the policy with following contingency should exist:
      | Title            | Proof of Title              |
      | Potential Action | Change policy retroactively |
      | Due Date         | 07/15/2018                  |

  Scenario: Resolve a contingency on an in-force policy
    Given a Personal Auto submission
    And the submission has an effective date of "05/01/2018"
    And the job status is "Quoted"
    And I add the following contingency:
      | Title       | Proof of Title              |
      | Description | Missing Title               |
      | Action      | Change policy retroactively |
      | Due Date    | 07/01/2018                  |
    And I issue the policy
    When I resolve the following contingency:
      | Title    | Proof of Title |
      | Due Date | 07/01/2018     |
      | Status   | Pending        |
    Then the policy with following contingency should exist:
      | Title           | Proof of Title |
      | Due Date        | 07/01/2018     |
      | Status          | Resolved       |
      | Completion Date | 07/01/2018     |

  Scenario: Triggering potential action for unresolved contingencies that are over due
    Given a Personal Auto submission
    And the submission has an effective date of "05/01/2018"
    And the job status is "Quoted"
    And I add the following contingency:
      | Title       | Proof of Title              |
      | Description | Missing Title               |
      | Action      | Change policy retroactively |
      | Due Date    | 07/01/2018                  |
    And I issue the policy
    And the status of the contingency should be "Pending"
    When the "Handle Unresolved Contingency" batch process is executed
    Then the following policy transactions should exist:
      | Type          | Effective Date | Transaction Status |
      | Submission    | 05/01/2018     | Bound              |
      | Policy Change | 05/01/2018     | Draft              |