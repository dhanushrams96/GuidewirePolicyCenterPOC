@personal_auto @submission
Feature: Submission

  As an agent, I want to create a submission for a new policy, quote the submission so that I can give the policyholder
  a quote for their new policy request.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  Scenario Outline: Edit coverages with terms on a submission
    Given a Personal Auto submission
    And the submission has base state "New Jersey"
    And the job status is "Draft"
    When I set the "<coverage>" line-level coverage:
      | <term> | <value> |
    Then the "<coverage>" line-level coverage should exist:
      | <term> | <value> |

    Examples:
      | coverage                                      | term                                       | value    |
      | Liability - Bodily Injury and Property Damage | Auto Liability Package                     | 100K CSL |
      | Medical Payments                              | Medical Limit                              | 25,000   |
      | Uninsured Motorist - Bodily Injury            | Uninsured Motorist - BI Limits             | 250K CSL |
      | Uninsured Motorist - Property Damage          | Uninsured Motorist - Property Damage Limit | 50,000   |
      | PIP - New Jersey                              | Med Only option                            | true     |

  Scenario Outline: Add coverages without terms to a submission
    Given a Personal Auto submission
    And the job status is "Draft"
    When I add the "<coverage>" line-level coverage
    Then the "<coverage>" line-level coverage should exist

    Examples:
      | coverage                                |
      | Medical Payments                        |
      | Underinsured Motorist - Property Damage |
      | Mexico Coverage - Limited               |

  Scenario: Add coverage with multiple terms to a submission
    Given a Personal Auto submission
    And the submission has base state "New Jersey"
    And the job status is "Draft"
    And I create "PIP - New Jersey Table" as the following named DataTable:
      | Medical                       | 25,000                              |
      | Medical Deductible            | 500                                 |
      | Medical Deductible applies to | Insured                             |
      | Med Only option               | true                                |
      | PIP Med is secondary          | true                                |
      | Medical Copay Option          | true                                |
      | NON-Medical Benefits          | 175/18200 \| 20/14600 \| 15200/2000 |
    When I set the "PIP - New Jersey" line-level coverage:
      | NamedDataTable | PIP - New Jersey Table |
    Then the "PIP - New Jersey" line-level coverage should exist:
      | NamedDataTable | PIP - New Jersey Table |

  Scenario Outline: Remove coverages from a submission
    Given a Personal Auto submission
    And the job status is "Draft"
    When I remove the "<coverage>" line-level coverage
    Then the "<coverage>" line-level coverage shouldn't exist

    Examples:
      | coverage                                |
      | Medical Payments                        |
      | Uninsured Motorist - Bodily Injury      |
      | Uninsured Motorist - Property Damage    |
      | Underinsured Motorist - Property Damage |
      | Mexico Coverage - Limited               |

  Scenario: Closing a quoted Personal Auto submission using "Not-Taken" and "Insured's request - N.O.C"
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I close the quote using the "Not-Taken" option having closing reason "Insured's request - N.O.C"
    Then the submission status should be "Not-Taken"
    And the selected reason code should be "Insured's request - N.O.C"

  Scenario: Closing a quoted Personal Auto submission using "Decline" and "Loss history"
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I close the quote using the "Decline" option having closing reason "Loss history"
    Then the submission status should be "Declined"
    And the selected reason code should be "Loss history"

  Scenario: Closing a quoted Personal Auto submission using "Withdraw Transaction"
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I close the quote using the "Withdraw Transaction"
    Then the submission status should be "Withdrawn"

