@personal_auto @submission @PA-AssessRisk-QuoteTransaction

Feature: Submission

  As an agent,
  I want to create a submission for a new policy, quote the submission,
  so that correct UW issues are raised.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  @10990-GW.2
  Scenario: Quote a Personal Auto submission that generates a bind-blocking UW issue
    Given a Personal Auto submission
    And the job status is "Draft"
    And the submission has a driver who is age "20"
    When I quote the submission
    Then the submission status should be "Quoted"
    And the following UW issues should exist
      | Section Title | Short Description       |
      | Blocking Bind | Primary Driver under 25 |

  @10990-GW.2
  Scenario: Fail to bind a quoted submission which has one or more bind-blocking UW issues
    Given a Personal Auto submission
    And the submission has a "Blocks Bind" UW issue
    And the job status is "Quoted"
    When I attempt to issue the policy
    Then the submission status should remain "Quoted"

  @10990-GW.2
  Scenario: Approve bind-blocking UW issues on a quoted personal auto submission by an underwriter with appropriate authority
    Given a Personal Auto submission
    And the job status is "Quoted"
    And the submission has a driver who is age "20"
    And the submission has a vehicle that costs "101000"
    When an Underwriter approves "Primary Driver under 25" UW issue
    Then the following UW issues should exist
      | Section Title    | Short Description       |
      | Already Approved | Primary Driver under 25 |
      | Blocking Bind    | High-value vehicle      |

  Scenario: Issue a quoted personal auto submission with approved UW issues
    Given a Personal Auto submission
    And the job status is "Quoted"
    And the submission has a "Blocks Bind" UW issue
    And the UW issue has been approved
    When I issue the policy
    Then the submission status should be "Bound"
    And "all" UW issues should be approved