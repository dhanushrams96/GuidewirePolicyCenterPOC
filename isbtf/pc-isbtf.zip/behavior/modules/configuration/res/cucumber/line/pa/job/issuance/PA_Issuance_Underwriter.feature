@personal_auto @issuance
Feature: Issuance of bound policy

  As an agent, I want to make changes to a bound policy and issue the policy so policy gets officially issued and accompanying
  forms are sent out to the policyholder.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And a bound but not issued Personal Auto policy

  @DesignatedFunction
  Scenario: Issue a bound Personal Auto policy
    When I begin an issuance
    And I set the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 100K CSL  |
    And I quote the issuance
    And I issue the issuance
    Then the issuance status should be "Bound"
