@personal_auto @cancellation
Feature: Cancellation and Reinstatement

  As an agent, I want to either cancel the entire policy (flat cancel) or cancel a policy anytime during the term (midterm cancelation).
  As an agent, I also want to reinstate a canceled policy so I can make the canceled policy active.

  Background:
    Given I am a user with the "Producer" role
    And today's date is "07/01/2018"
    And an in-force Personal Auto policy

  Scenario: Prorata cancellation - Cancel Now
    When I start a Cancellation with the following
      | Source     | Insured              |
      | Reason     | Out of business/sold |
      | CancelDate | 07/14/2018           |
    Then the change in cost should be "735.00 USD"
    And I bind the cancellation with "Cancel Now"
    Then the cancellation status should be "Bound"

  Scenario: Prorata cancellation - Schedule Cancellation
    When I start a Cancellation with the following
      | Source     | Insurer     |
      | Reason     | Non-payment |
      | CancelDate | 07/24/2018  |
    Then the change in cost should be "691.00 USD"
    And I bind the cancellation with "Schedule Cancellation"
    Then the cancellation status should be "Canceling"

  Scenario: Rescind a scheduled cancellation
    When I start a Cancellation with the following
      | Source     | Insurer     |
      | Reason     | Non-payment |
      | CancelDate | 08/01/2018  |
    And I bind the cancellation with "Schedule Cancellation"
    And the cancellation status should be "Canceling"
    When I rescind the cancellation
    Then the cancellation status should be "Rescinded"

  Scenario: Flat cancellation
    When I start a Cancellation with the following
      | Source | Insured          |
      | Reason | Policy not-taken |
    And I bind the cancellation with "Cancel Now"
    Then the cancellation status should be "Bound"
    And the following Personal Auto costs should exist:
      | Total Premium      | 0 USD |
      | Taxes & Surcharges | 0 USD |
      | Total Cost         | 0 USD |

  Scenario: Reinstate a pro-rated cancellation
    Given I start a Cancellation with the following
      | Source                      | Insurer     |
      | Reason                      | Non-payment |
      | CancelDate                  | 08/01/2018  |
    And I bind the cancellation with "Cancel Now"
    And the cancellation status should be "Bound"
    When I reinstate the policy
    Then the reinstatement status should be "Bound"