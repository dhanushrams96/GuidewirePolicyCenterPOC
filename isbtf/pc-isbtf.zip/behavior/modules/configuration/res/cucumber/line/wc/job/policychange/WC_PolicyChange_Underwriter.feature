@workers_compensation @policychange
Feature: Workers Compensation

  As an underwriter, I want to make changes to a workers compensation policy that is effective for the entire term (contractual period)
  irrespective of the policy change effective date.

  Background:
    Given I am a user with the "Underwriter" role
    And today's date is "06/01/2019"
    And an account of type "Company"
      | Company Name | Jim O'Brien and Sons |
    And a Workers Compensation submission
    And the policy effective date is "07/01/2018"
    And the policy has the following covered employees:
      | Governing Law  | Location         | Class Code | # Employees | Basis |
      | Voluntary Comp | 1: San Francisco | 0035       | 75          | 10000 |
      | Voluntary Comp | 1: San Francisco | 0005       | 25          | 2000  |
    And I quote the submission
    # note: the plan type can be either installments or premium reporting, "Payment Plan" indicates installments
    And the payment schedule plan type is "Payment Plan"
    And the policy requires a final audit
    And I issue the policy

  # In window mode,  a mid-term policy change for covered employees is effective for the full term.
  # The scenario below verifies this by doing another policy change starting the beginning of the term
  # and checking if the previous mid term change is effective for the entire term.
  Scenario: A mid-term policy change for covered employees is effective for the full term
    When I begin a new policy change
    And I set the policy change effective date to "08/01/2018"
    And I set the following covered employees:
      | Governing Law  | Location         | Class Code | # Employees | Basis |
      | Voluntary Comp | 1: San Francisco | 0035       | 100         | 15000 |
      | Voluntary Comp | 1: San Francisco | 0005       | 55          | 20000 |
    And I quote the policy change
    And I issue the policy change
    When I begin another new policy change
    And I set the policy change effective date to "07/01/2018"
    Then the following covered employees should exist on WC Coverages Step
      | Governing Law  | Location         | Class Code | # Employees | Basis |
      | Voluntary Comp | 1: San Francisco | 0035       | 100         | 15000 |
      | Voluntary Comp | 1: San Francisco | 0005       | 55          | 20000 |

  Scenario: An Agent changes an experience modifier using split period
    When I begin a new policy change
    And I set the policy change effective date to "08/01/2018"
    And I split the period effective "09/01/2018" with Type "Forced Rerating"
    Then the following periods should exist:
      | Period   | Effective Date Range    |
      | Period 1 | 07/01/2018 - 09/01/2018 |
      | Period 2 | 09/01/2018 - 07/01/2019 |
    When I enter experience modifiers:
      | Period   | Experience Modifier |
      | Period 1 | 1.1                 |
      | Period 2 | 0.98                |
    And I quote the policy change
    # UI note: on the Quote screen on the Policy Premium tab there will be two Standard Premium sections
    Then policy premiums should be calculated for each period of the split
      | Standard Premium Header                     |
      | Standard Premium ( 07/01/2018 - 09/01/2018) |
      | Standard Premium ( 09/01/2018 - 06/30/2019) |
    And the following Workers Compensation costs should exist in specified period:
      | Period   | Code | Description         | Rate   |
      | Period 1 | 9903 | Experience modifier | 1.1000 |
      | Period 2 | 9903 | Experience modifier | 0.9800 |