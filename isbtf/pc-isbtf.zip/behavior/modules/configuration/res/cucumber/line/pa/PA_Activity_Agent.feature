@personal_auto @submission
Feature: Activity

  As an agent, I want to create a new activity or manage an activity assigned to me on the policy.

  Background:
    Given I am a user with the "Producer" role
    And today's date is "07/01/2018"
    And an in-force Personal Auto policy

  @DesignatedFunction
  Scenario: Create an activity on the policy
    When I create a "Request", "Get Motor Vehicle Reports" activity with the following data:
      | Due Date        | 07/15/2018 |
      | Escalation Date | 07/20/2018 |
      | Priority        | High       |
    Then the following activity should exist:
      | Subject                   | Status |
      | Get Motor Vehicle Reports | Open   |