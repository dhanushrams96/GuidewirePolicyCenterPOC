@homeowners @rewrite @PC-COM-Re-Price-QuoteTransaction
Feature: Cancellation and Rewrite

  As an agent,
  I want to rewrite a canceled policy,
  so that I can make the canceled policy active.

  Background:
    Given I am a user with the "Producer" role

  @201706-GW.22
  Scenario: On rewrite validate the correct forms are inferred
    Given a Homeowners submission
    And of type "dwelling" and coverage form "HO2"
    And the submission has base state "California"
    And the job status is "Quoted"
    And I issue the policy
    And I cancel the policy for rewrite
    And I rewrite the policy as "Rewrite Remainder of Term"
    When I quote the rewrite
    Then the rewrite status should be "Quoted"
    And the total premium exist
    And the following forms should be inferred
      | HO DP 00  |
      | HOP 02 00 |
      | HOP 08 CA |