@personal_auto @submission @PA-QuickQuote-QuickQuote
Feature: Submission

  As an agent,
  I want to create Quick Quote submission for a new policy, quote the submission,
  so that I can give the policyholder a quote for their new policy request.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  Scenario: Quoting a new Personal Auto submission using quick quote application
    When I create a new submission
    And I select "Quick Quote" quote application
    And I select "Personal Auto" as the product
    And I enter the following policy info:
      | Term Type  | 6 months   |
      | Base State | California |
    And I add the following driver:
      | First name           | John       |
      | Last name            | Doe        |
      | Date of Birth        | 01/04/1980 |
      | Marital Status       | Married    |
      | Year First Licensed  | 1996       |
      | Number of Accidents  | 0          |
      | Number of Violations | 0          |
    And I add the following vehicle:
      | Model Year     | 2018   |
      | Make           | Ford   |
      | Model          | Fusion |
      | Cost New       | 22000  |
      | Primary Driver | 1      |
    And I quote the submission
    Then the total cost should be "683.00 USD"