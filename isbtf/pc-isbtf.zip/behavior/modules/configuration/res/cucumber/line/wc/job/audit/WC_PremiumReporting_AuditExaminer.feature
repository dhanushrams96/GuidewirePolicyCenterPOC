@workers_compensation @submission
Feature: Premium Reporting

  As an audit examiner, I want to process the audit information received on a policy with premium reporting payment plan.

  Background:
    Given I am a user with the "Underwriter" role
    And today's date is "10/01/2018"
    And an account of type "Company"
      | Company Name | Greg Savas & Co. |
    And a Workers Compensation policy
    And the policy effective date is "07/01/2018"
    And the policy has the following covered employees:
      | Governing Law  | Location         | Class Code | # Employees | Basis |
      | Voluntary Comp | 1: San Francisco | 0035       | 75          | 10000 |
    And I quote the submission
    And the payment schedule plan type is "Reporting Plan"
    And the policy requires a final audit
    And the Premium Reporting Plan is "Quarterly Reports by calendar quarter, exclude last quarter"
    And I issue the policy

  Scenario: As an audit examiner, I would like to process the premium reporting information received.
    When the "AuditTask" batch process is executed
    And I switch to a user with the "Audit Examiner" role
    Then the following audit schedule should exist:
      | Type           | Status      | Period Start | End Date   |
      | Premium Report | In Progress | 07/01/2018   | 10/01/2018 |
      | Premium Report | Scheduled   | 10/01/2018   | 01/01/2019 |
      | Premium Report | Scheduled   | 01/01/2019   | 04/01/2019 |
      | Final Audit    | Scheduled   | 07/01/2018   | 07/01/2019 |
    When I enter the following audit information for the report starting on "07/01/2018"
      | Received Date    | 10/04/2018 |
      | Payment Received | 1000 USD   |
    Then I enter the following audit details:
      | Location | Class Code | Estimated Payroll | Audited Payroll |
      | 1        | 0035       | 2521              | 16000           |
    And I calculate the premiums
    And I submit the audit
    Then the following policy transactions should exist:
      | Type           | Effective Date | Transaction Status |
      | Premium Report | 07/01/2018     | Completed          |