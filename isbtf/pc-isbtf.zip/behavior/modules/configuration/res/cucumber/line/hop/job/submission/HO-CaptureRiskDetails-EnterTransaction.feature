@homeowners @submission @HO-CaptureRiskDetails-EnterTransaction
Feature: Entered information in Submission

  As an agent,
  I want to enter information during a submission,
  so submission can store relevant information.

  Background:
    Given I am a user with the "Producer" role

  @11490-GW.3
  Scenario: Additional Interests on Submission
    Given a Homeowners submission
    And of type "Dwelling" and coverage form "HO2"
    And the job status is "Draft"
    When I add the following company as an additional interest
      | Name                    | Chase Mortgages  |
      | Interest Type           | First Mortgagee  |
      | Effective Date          | 11/01/2018       |
      | Expiration Date         | 11/08/2024       |
      | Description of Interest | Mortgage Company |
      | Certificate Required    | Yes              |
      | Contract Number         | 11211            |
      | Address 1               | 123 A Random St. |
      | City                    | San Mateo        |
      | State                   | California       |
      | ZIP Code                | 94404            |
      | Address Type            | Business         |
    Then "Chase Mortgages" should exist as an additional interest on the submission

  @11490-GW.10
  Scenario: Add optional coverage to a Submission
    Given a Homeowners submission
    And the job status is "Draft"
    When I add the Scheduled Personal Property coverage
      | Description       | Diamond Ring      |
      | Serial No         | SR1102            |
      | Appraiser         | Smiths Jewellers  |
      | Date Of Appraisal | 10/14/2019        |
      | Type              | Jewelry           |
      | Limit             | 2000              |
      | Deductible        | $500              |
      | Valuation Method  | Actual cash value |
      | Appraised Value   | 5000              |
    And I quote the submission
    Then the submission status should be "Quoted"
    And a premium exists for the scheduled item
    And the policy should have the "Scheduled Personal Property Coverage" optional coverage
    And the following forms should be inferred
      | HOP SPP 1 |

  @11490-GW.1
  Scenario: Edit risks to a submission
    Given a Homeowners submission
    When I set the dwelling with the information provided in the table:
      | Location                           | 2: 121 Main St, Foster City, CA |
      | Territory Code for Homeowners Line | 30                              |
      | Location Type                      | In City Limits                  |
      | Residence                          | 1 Family Residence              |
      | Estimated Replacement Cost         | 700000.00                       |
      | Number of Units Between Firewall   | 1                               |
      | Number of Insured Units            | 1                               |
      | Usage                              | Primary                         |
      | Occupancy                          | Owner Occupied                  |
      | Number of Roomers/Boarders         | 0                               |
      | Burglar Alarm                      | Central Station                 |
      | All Doors Have Deadbolts           | true                            |
      | Distance to Fire Hydrant (ft)      | 20                              |
      | Distance to Fire Station (mi)      | 1                               |
      | Fire Protection Class              | Superior                        |
      | Fire Alarm                         | Alarm - Local                   |
      | Number of Fire Extinguishers       | 0                               |
      | Smoke Alarms                       | All Floors                      |
      | Sprinkler System                   | None                            |
      | Residence Visible to Neighbors     | true                            |
      | Specific Hazard                    | Flood Zone                      |
      | Hazard Type                        | Property                        |
      | Hazard Additional Information      | Lives close to the bay          |
      | Animal Type                        | Dog                             |
      | Breed                              | German Shepherds                |
      | Bite History                       | false                           |
      | Is there a swimming pool?          | true                            |
      | Type                               | Above Ground                    |
      | Approved Fence                     | true                            |
      | Diving Board                       | false                           |
      | Slide                              | false                           |
    Then the dwelling should exist
      | Location                           | 2: 121 Main St, Foster City, CA |
      | Territory Code for Homeowners Line | 30                              |
      | Location Type                      | In City Limits                  |
      | Residence                          | 1 Family Residence              |
      | Estimated Replacement Cost         | 700000.00                       |
      | Number of Units Between Firewall   | 1                               |
      | Number of Insured Units            | 1                               |
      | Usage                              | Primary                         |
      | Occupancy                          | Owner Occupied                  |
      | Number of Roomers/Boarders         | 0                               |
      | Burglar Alarm                      | Central Station                 |
      | All Doors Have Deadbolts           | true                            |
      | Distance to Fire Hydrant (ft)      | 20                              |
      | Distance to Fire Station (mi)      | 1                               |
      | Fire Protection Class              | Superior                        |
      | Fire Alarm                         | Alarm - Local                   |
      | Number of Fire Extinguishers       | 0                               |
      | Smoke Alarms                       | All Floors                      |
      | Sprinkler System                   | None                            |
      | Residence Visible to Neighbors     | true                            |
      | Specific Hazard                    | Flood Zone                      |
      | Hazard Type                        | Property                        |
      | Hazard Additional Information      | Lives close to the bay          |
      | Animal Type                        | Dog                             |
      | Breed                              | German Shepherds                |
      | Bite History                       | false                           |
      | Is there a swimming pool?          | true                            |
      | Type                               | Above Ground                    |
      | Approved Fence                     | true                            |
      | Diving Board                       | false                           |
      | Slide                              | false                           |
    And the submission status should be "Draft"

  @11490-GW.8
  Scenario: Territory Code - Address in NV
    Given a Homeowners submission
    And the submission has base state "California"
    And the job status is "Draft"
    When I set the new policy location without save
      | Address 1    | 121 Main St. |
      | City         | Las Vegas    |
      | County       | Clark        |
      | State        | Nevada       |
      | ZIP Code     | 88901        |
    Then I should get homeowners territory code "240"

  @11490-GW.8
  Scenario: Territory Code - Any Address in NV
    Given a Homeowners submission
    And the submission has base state "California"
    And the job status is "Draft"
    When I set the new policy location without save
      | Address 1    | 234 hope  |
      | City         | The Lakes |
      | County       | Clark     |
      | State        | Nevada    |
      | ZIP Code     | 88000     |
    Then I should get homeowners territory code "230"

  @11490-GW.5
  Scenario: I want to validate that a distance away from both fire hydrant and a fire station will result in Limited protection class for dwelling
    Given a Homeowners submission
    When I set the distance to fire hydrant and fire station as
      | Distance to Fire Hydrant (ft) | 300 |
      | Distance to Fire Station (mi) | 30  |
    And I infer the protection class code for the risk
    Then I should see a fire protection class code of "Limited"

  @11490-GW.5
  Scenario: I want to validate that a distance away from both fire hydrant and a fire station will result in Superior protection class for dwelling
    Given a Homeowners submission
    When I set the distance to fire hydrant and fire station as
      | Distance to Fire Hydrant (ft) | 10 |
      | Distance to Fire Station (mi) | 1  |
    And I infer the protection class code for the risk
    Then I should see a fire protection class code of "Superior"

  @11490-GW.6
  Scenario: Dwelling Hazards to a submission
    Given a Homeowners submission
    When I add dwelling hazards as
      | Specific Hazard | Type      | Additional Information           |
      | Woodstove       | Property  | Woodstove located in living area |
      | Woodstove       | Liability | Woodstove located in living area |
    Then the dwelling hazards should exist
      | Specific Hazard | Type      | Additional Information           |
      | Woodstove       | Property  | Woodstove located in living area |
      | Woodstove       | Liability | Woodstove located in living area |

  @11500-GW.1
  Scenario: Construction field on Dwelling Construction to a submission
    Given a Homeowners submission
    When I set construction type as Other
    Then the Construction Type Description field should be provided

  @11500-GW.1
  Scenario: Roof field on Dwelling Construction to a submission
    Given a Homeowners submission
    When I set roof type as Other
    Then the Roof Type Description field should be provided

  @11500-GW.1
  Scenario: Primary Heating field on Dwelling Construction to a submission
    Given a Homeowners submission
    When I set primary heating as Oil
    Then the Fuel Storage Tank and Fuel Line fields should be provided

  @11500-GW.1
  Scenario: Dwelling Construction to a submission
    Given a Homeowners submission
    When I set construction as
      | Year Built        | 2000                    |
      | Construction      | Concrete                |
      | Number of Stories | 2                       |
      | Garage            | Attached Garage - 2 Car |
      | Foundation        | Full Basement           |
      | Roof              | Asphalt Shingle         |
      | Primary Heating   | Gas                     |
      | Secondary Heating | Electricity             |
      | Plumbing          | Copper                  |
      | Wiring            | Copper                  |
      | Electrical System | Circuit Breaker         |
      | Roof - Year       | 2015                    |
    And the transaction is saved successfully
    Then the dwelling construction should exist
      | Year Built        | 2000                    |
      | Construction      | Concrete                |
      | Number of Stories | 2                       |
      | Garage            | Attached Garage - 2 Car |
      | Foundation        | Full Basement           |
      | Roof              | Asphalt Shingle         |
      | Primary Heating   | Gas                     |
      | Secondary Heating | Electricity             |
      | Plumbing          | Copper                  |
      | Wiring            | Copper                  |
      | Electrical System | Circuit Breaker         |
      | Roof - Year       | 2015                    |