@homeowners @policychange @PC-COM-PriceRisk-QuoteTransaction
Feature: Policy Change Issuance

  As an agent,
  I want to create a policy change on existing policy,
  so that I can verify I can bind/issue the policy change.

  Background:
    Given I am a user with the "Producer" role
    And an in-force Homeowners policy

  @201706-GW.43
  Scenario: Issue a Policy Change
    Given I begin a new policy change
    And I quote the policy change
    When I issue the policy change
    Then the policy change status should be "Bound"