@personal_auto @submission @PA-DefineProductForms-FormsInference(SRS)

Feature: Submission

  As an agent,
  I want to create a submission for a new policy, quote the submission,
  so that correct forms are inferred related to the base state.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  @10850-GW.1-SRS
  Scenario: Forms Inference based on jurisdiction for Personal Auto submission
    Given a Personal Auto submission
    And the job status is "Draft"
    And the submission has a vehicle garaged in "California"
    When I quote the submission
    Then the following forms should be inferred
      | PA 00DS |
      | PA 0208 |
      | PA 0272 |
      | PF 01   |
