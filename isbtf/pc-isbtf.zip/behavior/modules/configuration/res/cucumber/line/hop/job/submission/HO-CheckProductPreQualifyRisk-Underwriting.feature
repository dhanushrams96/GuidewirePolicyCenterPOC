@homeowners @submission @HO-CheckProductPreQualifyRisk-Underwriting
Feature: Underwriting validations on submission

  As an agent,
  I require underwriting validations,
  so that I can't quote an invalid submission.

  Background:
    Given I am a user with the "Producer" role

  @11470-GW
  Scenario: Can not quote a dwelling submission occupied by a tenant
    Given a Homeowners submission
    And of type "Dwelling" and coverage form "HO2"
    And a "Tenant" occupies this dwelling
    Then the job cannot be quoted because the "Dwelling must be owner occupied"
