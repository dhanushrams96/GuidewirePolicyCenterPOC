@personal_auto @submission
Feature: Rating

  As an underwriter, I want to use the rating worksheet to see how the premiums were calculated on a given policy.

  Background:
    Given Rating Plugin is PCRatingPlugin

  Scenario: Rating worksheet generation for Personal Auto submission
    Given a Personal Auto submission
    And the job status is "Quoted"

#  The next steps are commented out because it needs the rating module to be enabled, which OOTB is disabled by default.
#  To run this scenario first enable to rating module and then uncomment the steps below.

#    When I view rating worksheet
#    Then rating worksheet should be available for review