@homeowners @cancellation @reinstatement @HO-AssessCancellationRisks-CancelReinstateRewriteTransaction
Feature: Cancellation and Reinstatement

  As an underwriter,
  I want to either cancel the entire policy (flat cancel) or cancel a policy anytime during the term (midterm cancellation)
  so that I can have a policy cancelled.

  Background:
    Given I am a user with the "Underwriter" role
    And today's date is "02/01/2020"

  @14690-GW.480
  Scenario: Trigger a validation error when the Cancellation Effective Date set earlier than the default date
    Given an in-force Homeowners policy
    When an "Insurer" starts a Cancellation because of "Fraud" effective on "02/11/2020"
    Then the following error messages should occur
      | Cancellation Effective Date : The date 02/11/2020 12:01:00 AM is before the earliest valid effective date of 02/12/2020 12:01:00 AM. |
    And the cancellation status should be "Draft"