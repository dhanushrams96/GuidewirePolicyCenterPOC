@homeowners @reinstatement @PC-COM-ConfirmOfferReinstatement-QuoteTransaction
Feature: Cancellation and Reinstatement

  As an agent,
  I also want to reinstate a canceled policy,
  so that I can make the canceled policy active.

  Background:
    Given I am a user with the "Producer" role

  @201706-GW.21
  Scenario: On Reinstatement, validate Total Cost exist after Quote
    Given a cancelled Homeowners policy
    And I start a Reinstatement
    When I quote the Reinstatement
    Then the reinstatement status should be "Quoted"
    And the total premium exist