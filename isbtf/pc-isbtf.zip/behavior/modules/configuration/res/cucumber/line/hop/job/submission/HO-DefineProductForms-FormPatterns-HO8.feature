@homeowners @submission @HO-DefineProductForms-FormPatterns-HO8
Feature: Forms and Form Patterns

  As an agent,
  I want to quote a submission,
  so that I can infer correct forms.

  Background:
    Given I am a user with the "Producer" role

  @11440-GW.2.2.HO8
  Scenario: Forms Inference based on California
    Given a Homeowners submission
    And the submission has base state "California"
    When I quote the submission
    Then the following forms should be inferred
      | HO DP 00  |
      | HOP 08 CA |


  @11440-GW.2.2.HO8
  Scenario Outline: Forms Inference based on policy type and coverage form
    Given a Homeowners submission
    And of type "<policy type>" and coverage form "<coverage form>"
    When I quote the submission
    Then the following forms should be inferred
      | HO DP 00 |
      | <form>   |

    Examples:
      | policy type | coverage form | form      |
      | Dwelling    | HO2           | HOP 02 00 |
      | Dwelling    | HO3           | HOP 03 00 |
      | Dwelling    | HO5           | HOP 05 00 |
      | Rental      | HO4           | HOP 04 00 |
      | Condominium | HO6           | HOP 06 00 |