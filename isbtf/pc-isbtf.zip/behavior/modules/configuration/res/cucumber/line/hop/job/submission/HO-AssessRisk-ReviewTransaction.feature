@homeowners @submission @HO-AssessRisk-ReviewTransaction
Feature: Submission

  As an agent,
  I want to create a submission for a new policy, quote the submission
  so that I can give the policyholder a quote for their new policy request.

  Background:
    Given I am a user with the "Producer" role

  @11530-GW
  Scenario: Quote a Homeowners submission and review the policy with the insured
    Given a Homeowners submission
    When I review the policy with the insured
    Then I should have the following product information available
      | Product              |
      | Address              |
      | Effective Date       |
      | Expiration Date      |
      | Policy Type          |
      | Coverage Form        |
      | Section I Coverages  |
      | Additional Coverages |
      | Optional Coverages   |
      | Policy Conditions    |