@personal_auto @submission
Feature: Submission

  As an agent, I want to create new submissions, generate a quote and take the submissions through approval and issuance.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  Scenario: Quote a new Submission w/blocking bind UW issues using the Submission Wizard
    When I create a new submission
    And I select the following product offering:
      | Quote Type       | Default Base State | Default Effective Date |
      | Full Application | California         | 01/15/2019             |
    And I select "Personal Auto" as the product
    And I enter the following qualification information:
      | Prequalification Questions                                                                                   | Responses |
      | Is the applicant currently insured?                                                                          | Yes       |
      | Is the applicant's license currently suspended, canceled, or revoked?                                        | No        |
      | Has the applicant's license ever been canceled, suspended or revoked?                                        | No        |
      | Any drivers with convictions for moving traffic violations within the past 3 years? If 'Yes' please explain. | No        |
      | Has any policy or coverage been declined, canceled, or non-renewed during the prior 3 years?                 | No        |
    And I enter the following policy info:
      | Term Type | 6 months |
    And I add the following driver:
      | First name           | John         |
      | Last name            | Doe          |
      | Date of Birth        | 01/04/1980   |
      | Year First Licensed  | 1996         |
      | Number of Accidents  | 0            |
      | Number of Violations | 0            |
      | Address 1            | 123 Fake St. |
    And I add the following vehicle:
      | Model Year     | 2018     |
      | Make           | Ford     |
      | Model          | F-150    |
      | Cost New       | 200000   |
      | Primary Driver | John Doe |
    And I add the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 250/500/100 |
    And I add the "Medical Payments" line-level coverage:
      | Medical Limit | 5,000 |
    And I add the "Uninsured Motorist - Bodily Injury" line-level coverage:
      | Uninsured Motorist - BI Limits | 20/50 |
    And I add the "Comprehensive" vehicle-level coverage:
      | Comprehensive Deductible | 1,000 |
    And I add the "Collision" vehicle-level coverage:
      | Collision Deductible | 1,000 |
    And I quote the submission
    Then the following Personal Auto costs should exist:
      | Total Cost | 1175.00 USD |
    # take this through approval and to issuance
    Then the following forms should be inferred
      | PA 00DS |
      | PA 0208 |
      | PA 0272 |
      | PF 01   |
    And the following UW issues should exist
      | Section Title | Short Description  |
      | Blocking Bind | High-value vehicle |
    When an Underwriter approves "High-value vehicle" UW issue
    And I select payment plan "6 Payments Demo"
    And I issue the policy
    Then the submission status should be "Bound"

  Scenario: Quote a new Quick Quote Submission w/blocking bind UW issues using the Submission Wizard
    When I create a new submission
    And I select the following product offering:
      | Quote Type  | Default Base State | Default Effective Date |
      | Quick Quote | California         | 01/15/2019             |
    And I select "Personal Auto" as the product
    And I enter the following policy info:
      | Term Type  | 6 months   |
      | Base State | California |
    And I add the following driver:
      | First name           | John       |
      | Last name            | Doe        |
      | Date of Birth        | 01/04/1980 |
      | Marital Status       | Married    |
      | Year First Licensed  | 1996       |
      | Number of Accidents  | 0          |
      | Number of Violations | 0          |
    And I add the following vehicle:
      | Model Year     | 2018   |
      | Make           | Ford   |
      | Model          | Fusion |
      | Cost New       | 200000 |
      | Primary Driver | 1      |
    And I quote the submission
    # take this through approval and to issuance
    Then the following UW issues should exist
      | Section Title | Short Description  |
      | Blocking Bind | High-value vehicle |
    When an Underwriter approves "High-value vehicle" UW issue
    Then "all" UW issues should be approved