@personal_auto @submission @PA-MultipleQuoteVersions-SidebySide

Feature: Submission

  As an agent,
  I want to create side by side submission for a new policy, quote the submission,
  so that I can give the policyholder a quote for their new policy request.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  @11340-GW
  Scenario: Begin side by side quoting
    Given a Personal Auto submission
    And the job status is "Draft"
    When I start side by side quoting
    Then there should be "3" versions available
    And the submission status should be "Rated"

  @11350-GW
  Scenario Outline: Select one version of the side by side quotes
    Given a Personal Auto submission
    And the job status is "Draft"
    And I start side by side quoting
    When I select side by side version number "<selected>"
    Then the submission status should be "Quoted"
    And the following versions should exist:
      | Version #<selected>     | Quoted | Selected   |
      | Version #<unselected 1> | Rated  | Deselected |
      | Version #<unselected 2> | Rated  | Deselected |

    Examples:
      | selected | unselected 1 | unselected 2 |
      | 1        | 2            | 3            |
      | 2        | 1            | 3            |
      | 3        | 1            | 2            |

  @11370-GW
  Scenario Outline: Side by Side Quoting Issuance
    Given a Personal Auto submission
    And the job status is "Quoted"
    And I start side by side quoting
    And I select side by side version number "<selected>"
    When I issue the policy
    Then the submission status should be "Bound"
    And the following versions should exist:
      | Version #<selected>     | Bound     | Selected   |
      | Version #<unselected 1> | Withdrawn | Deselected |
      | Version #<unselected 2> | Withdrawn | Deselected |

    Examples:
      | selected | unselected 1 | unselected 2 |
      | 1        | 2            | 3            |
      | 2        | 1            | 3            |
      | 3        | 1            | 2            |

  @11380-GW
  Scenario Outline: Change a version-specific coverage for a side by side version
    Given a Personal Auto submission
    And the job status is "Draft"
    When I set the "<coverage>" line-level coverage:
      | <term> | <value 1> |
    And I start side by side quoting
    And I edit the submission
    And I select version number "1"
    And the "<coverage>" line-level coverage should exist:
      | <term> | <value 1> |
    And I select version number "2"
    And I edit the submission
    And the "<coverage>" line-level coverage should exist:
      | <term> | <value 2 old> |
    And I set the "<coverage>" line-level coverage:
      | <term> | <value 2 new> |
    Then I select version number "1"
    And the "<coverage>" line-level coverage should exist:
      | <term> | <value 1> |
    Then I select version number "2"
    And the "<coverage>" line-level coverage should exist:
      | <term> | <value 2 new> |

    Examples:
      | coverage                                      | term                   | value 1 | value 2 old | value 2 new |
      | Liability - Bodily Injury and Property Damage | Auto Liability Package | 15/30/5 | 100/200/50  | 100K CSL    |
      | Medical Payments                              | Medical Limit          | 5,000   | 5,000       | 10,000      |

  @11380-GW
  Scenario Outline: Change data by adding a new person that is shared among side by side versions
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I start side by side quoting
    And I select version number "<version>"
    And I edit the submission
    And I create "John Smith Table" as the following named DataTable:
      | First name                            | John             |
      | Last name                             | Smith            |
      | Date of Birth                         | 01/01/1970       |
      | Relationship to Primary Named Insured | Business Partner |
      | Address 1                             | 123 Fake St.     |
    And I add a new additional named insured of type person:
      | NamedDataTable | John Smith Table |
    Then I select version number "1"
    And the additional named insured of type person should exist:
      | NamedDataTable | John Smith Table |
    And I select version number "2"
    And the additional named insured of type person should exist:
      | NamedDataTable | John Smith Table |
    And I select version number "3"
    And the additional named insured of type person should exist:
      | NamedDataTable | John Smith Table |

    Examples:
      | version |
      | 1       |
      | 2       |
      | 3       |

  @11330-GW
  Scenario: Using the multiple versioning capability, begin a new version and set coverages and quote it
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I create a new version
    And I select version number "2"
    And I set the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 100K CSL |
    And I set the "Medical Payments" line-level coverage:
      | Medical Limit | 5,000 |
    And I add the "Uninsured Motorist - Property Damage" line-level coverage
    And I quote the submission
    Then the submission status should be "Quoted"
    And the following versions should exist:
      | Version #1 | Quoted | Deselected |
      | Version #2 | Quoted | Selected   |
    #Edit the submission to verify the coverage and their covTerm existence
    And I edit the submission
    And the "Liability - Bodily Injury and Property Damage" line-level coverage should exist:
      | Auto Liability Package | 100K CSL |
    And the "Medical Payments" line-level coverage should exist:
      | Medical Limit | 5,000 |
    And the "Uninsured Motorist - Property Damage" line-level coverage should exist