@workers_compensation @submission
Feature: Workers Compensation Rating Override

  As an underwriter, I want to override base rate, adjusted rate or the amount used for cost
  so that I can make adjustments to the premium calculated by the automated rating engine.

  Background:
    Given I am a user with the "Underwriter" role

  Scenario: An underwriter overrides the base rate to adjust cost for a specific class of covered class on a workerscompensation policy.
    Given a Workers Compensation submission
    And the policy has the following covered employees:
      | Governing Law  | Location         | Class Code | Basis |
      | Voluntary Comp | 1: San Francisco | 0050       | 10000 |
    When I quote the submission
    Then the following Workers Compensation cost should exist:
      | Loc. | Code | Basis     | Rate    | Amount  |
      | 1    | 0050 | 10,000.00 | 10.0080 | 1001.00 |
    # This step includes overriding the rate and rerating the policy using the overridden rate
    When I override the rate for a class of covered employees with the following:
      | Loc. | Code | Base Rate |
      | 1    | 0050 | 13.1180   |
    Then the following Workers Compensation cost should exist:
      | Loc. | Code | Basis     | Rate    | Amount  |
      | 1    | 0050 | 10,000.00 | 13.1180 | 1312.00 |