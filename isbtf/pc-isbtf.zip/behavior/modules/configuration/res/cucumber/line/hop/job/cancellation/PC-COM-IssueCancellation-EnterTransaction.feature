@homeowners @cancellation @PC-COM-IssueCancellation-EnterTransaction
Feature: Cancellation

  As an agent,
  I want to either cancel the entire policy (flat cancel) or cancel a policy anytime during the term (midterm cancellation),
  so that the cancellation is successful.
  While as an underwriter,
  I want to start a cancellation,
  so that I can check the cancellation lead time.

  Background:
    Given today's date is "10/22/2019"

    @201706-GW.18
    Scenario: Prorata cancellation - Cancel Now
      Given I am a user with the "Producer" role
      And an in-force Homeowners policy
      When I start a Cancellation with the following
        | Source                      | Insured              |
        | Reason                      | Out of business/sold |
        | Cancellation Effective Date | 10/30/2019           |
      And I bind the cancellation with "Cancel Now"
      Then the cancellation status should be "Bound"

  @201706-GW.18
  Scenario Outline: Cancellation Effective date based on System Config interval
    Given I am a user with the "Underwriter" role
    And an in-force Homeowners policy with a base state of "<State>"
    When I start a Cancellation with the following
      | Source | Insurer     |
      | Reason | Non-payment |
    Then the cancellation effective date should be today plus "<Lead Time>" days

    Examples:
      | State         | Lead Time |
      | Arizona       | 1         |
      | West Virginia | 11        |