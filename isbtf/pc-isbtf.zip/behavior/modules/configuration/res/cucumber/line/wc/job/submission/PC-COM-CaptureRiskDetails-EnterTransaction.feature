@workers_compensation @submission @PC-COM-CaptureRiskDetails-EnterTransaction
Feature: Submission

  As an agent,
  I want to enter information during a submission,
  so that the risk is correctly accessed and the correct UW company is assigned depending on the state.

  Background:
    Given I am a user with the "Producer" role
    And today's date is "01/15/2019"

  @10900-GW.1
  Scenario: Starting a new Workers' Compensation submission for a Colorado account the UW company should default correctly
    Given I create the following account of type Person:
      | First name     | Liz            |
      | Last name      | Jennings       |
      | Address 1      | 111 Main St.   |
      | Address 2      | Floor 1        |
      | Address 3      | Unit #0001     |
      | City           | Arvada         |
      | State          | CO             |
      | ZIP Code       | 80001          |
    When I create a new submission
    And I select the following product offering:
      | Quote Type       | Default Base State | Default Effective Date |
      | Full Application | Colorado           | 01/15/2019             |
    And I select "Workers' Compensation" as the product
    Then the UW company should be defaulted to "Acme Low Hazard Insurance"

  @10900-GW.1
  Scenario: Starting a new Workers' Compensation submission for a Hawaiian account the UW company should default correctly
    Given I create the following account of type Person:
      | First name     | Liz            |
      | Last name      | Jennings       |
      | Address 1      | 111 Main St.   |
      | Address 2      | Floor 1        |
      | Address 3      | Unit #0001     |
      | City           | Aiea           |
      | State          | HI             |
      | ZIP Code       | 96701          |
    When I create a new submission
    And I select the following product offering:
      | Quote Type       | Default Base State | Default Effective Date |
      | Full Application | Hawaii             | 01/15/2019             |
    And I select "Workers' Compensation" as the product
    Then the UW company should be defaulted to "Acme High Hazard Insurance"