@homeowners @submission @HO-AssessRisk-QuoteTransaction
Feature: Submission

  As an agent,
  I want to create a submission for a new policy, quote the submission,
  so that I can give the policyholder a quote for their new policy request.

  Background:
    Given I am a user with the "Producer" role

  @11540-GW.3 @DesignatedFunction
  Scenario: Quote a Homeowners submission
    Given a Homeowners submission
    And of type "Dwelling" and coverage form "HO2"
    And the submission has base state "California"
    And the job status is "Draft"
    When I quote the submission
    Then the submission status should be "Quoted"
    And the total premium exist
    And the following forms should be inferred
      | HO DP 00  |
      | HOP 02 00 |
      | HOP 08 CA |

  @11540-GW.3
  Scenario: Non-copper wiring uw issue after quoting a new homeowners submission
    Given a Homeowners submission
    And the job status is "Draft"
    And I set construction as
      | Year Built        | 1980                    |
      | Construction      | Frame                   |
      | Number of Stories | 2                       |
      | Garage            | Attached Garage - 2 Car |
      | Foundation        | Full Basement           |
      | Roof              | Asphalt Shingle         |
      | Primary Heating   | Gas                     |
      | Secondary Heating | Electricity             |
      | Plumbing          | Copper                  |
      | Wiring            | Knob & Tube             |
      | Electrical System | Circuit Breaker         |
      | Roof - Year       | 2015                    |
    When I quote the submission
    Then the submission status should be "Quoted"
    And the following UW issues should exist
      | Section Title | Short Description |
      | Blocking Bind | Non-copper wiring |

  @11540-GW.3
  Scenario: Fail to bind a quoted homeowners submission which has one or more bind-blocking UW issues
    Given a Homeowners submission
    And the submission has a "Blocks Bind" UW issue
    And the job status is "Quoted"
    When I attempt to issue the policy
    Then the submission status should remain "Quoted"

  @11540-GW.3
  Scenario: Approve bind-blocking UW issues on a quoted homeowners submission by an underwriter with appropriate authority
    Given a Homeowners submission
    And the submission has a Non-copper wiring UW issue
    And the job status is "Quoted"
    When an Underwriter Manager approves "Non-copper wiring" UW issue
    Then the following UW issues should exist
      | Section Title    | Short Description |
      | Already Approved | Non-copper wiring |

  @11540-GW.2
  Scenario: Quote a Homeowners submission when scheduled item limit exceeds Coverage C limit value
    Given a Homeowners submission
    And the job status is "Draft"
    And I add the "Coverage A - Dwelling" line-level coverage:
      | CovA Limit | 5000 |
    And I add the "Coverage C - Personal Property" line-level coverage:
      | CovC Limit Pct | 75% |
    And I add the following Scheduled Personal Property:
      | Description           | Serial No | Appraiser               | Date Of Appraisal | Type                | Limit | Deductible | Valuation Method  | Appraised Value |
      | Steinway & Sons Piano | A3312     | John's Fine Instruments | 11/10/2019        | Musical Instruments | 3760  | $1,000     | Actual cash value | 4000            |
    When I quote the submission
    Then the following error messages should occur
      | Scheduled personal property scheduled item limit exceeds Coverage C limit value |
    And the submission status should remain "Draft"