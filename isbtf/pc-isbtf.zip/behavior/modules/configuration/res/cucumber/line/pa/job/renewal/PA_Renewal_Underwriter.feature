@personal_auto @renewal
Feature: Renewal

  As an underwriter, I want to manually initiate the renewal process on an existing policy before its scheduled time
  so that I can make changes to the renewal.

  Background:
    Given I am a user with the "Underwriter" role
    And today's date is "07/01/2018"

  @DesignatedFunction
  Scenario: Automatic Policy Renewal
    # within the renewal lead time
    Given a Personal Auto submission
    And the submission has an expiration date of "07/15/2018"
    And the submission is bound
    When the "Policy Renewal Start" batch process is executed
    Then the following policy transactions should exist:
      | Type    | Effective Date | Transaction Status |
      | Renewal | 07/15/2018     | Bound              |
    And I view the "Renewal" transaction with effective date "07/15/2018"
    And the Renewal status should be "Bound"

  Scenario: Create a new policy term using manual renewal
    # after the effective date but not within the renewal lead time
    Given a Personal Auto submission
    And the submission has an expiration date of "09/01/2018"
    And the submission is bound
    When I renew the policy
    And I view the "Renewal" transaction with effective date "09/01/2018"
    Then the Renewal status should be "Renewing"
    When I edit the Renewal
    Then the Renewal status should be "Draft"
    And I quote the Renewal
    And I issue the Renewal with "Issue Now"
    Then the following policy transactions should exist:
      | Type    | Effective Date | Transaction Status |
      | Renewal | 09/01/2018     | Bound              |

  Scenario: Policy Change cross-term
    Given an in-force Personal Auto policy
    And I store the current job as "Original term"
    When I renew the policy
    Then the Renewal status should be "Renewing"
    And I store the current job as "Renewal term"
    And I recall "Original term" as the current job
    Then I begin a new policy change
    And I add the following vehicle:
      | Make       | Ford    |
      | Model      | Mustang |
      | Model Year | 2018    |
      | Cost New   | 22000   |
    And I quote the policy change
    And I issue the policy change
    When I apply the pending changes to the unbound renewal
    And I recall "Renewal term" as the current job
    Then the following vehicle should exist:
      | Make       | Ford      |
      | Model      | Mustang   |
      | Model Year | 2018      |
      | Cost New   | 22000 USD |