@personal_auto @submission @PA-PriceRisk-QuoteTransaction

Feature: Submission

  As an agent,
  I want to create a submission for a new policy, quote the submission,
  so that correct costs are generated.

  Background:
    Given I am a user with the "Producer" role
    And an account of type "Person"
      | First name | Jack  |
      | Last name  | Clark |
    And today's date is "01/15/2019"

  Scenario: Quoting generates the vehicle-level costs, line-level costs, and total costs
    Given a Personal Auto submission
    And the job status is "Draft"
    And I add the "Liability - Bodily Injury and Property Damage" line-level coverage:
      | Auto Liability Package | 100K CSL |
    And I add the "Medical Payments" line-level coverage:
      | Medical Limit | 10,000 |
    And I add the "Comprehensive" vehicle-level coverage:
      | Comprehensive Deductible | 1,000 |
    And I add the "Collision" vehicle-level coverage:
      | Collision Deductible | 1,000 |
    When I quote the submission
    Then the following Personal Auto costs should exist:
      | Total Premium                                          | 384.00 USD |
      | Taxes & Surcharges                                     | 28.00 USD  |
      | Total Cost                                             | 412.00 USD |
      | Comprehensive Coverage                                 | 16.00 USD  |
      | Collision Coverage                                     | 26.00 USD  |
      | Liability - Bodily Injury and Property Damage Coverage | 248.00 USD |
      | Medical Payments Coverage                              | 45.00 USD  |

  Scenario: Verify generation of financial transactions based on costs
    Given a Personal Auto submission
    And the job status is "Quoted"
    When I issue the policy
    Then the following financial transactions should exist:
      | Collision coverage                                     | 30.00 USD  |
      | Comprehensive coverage                                 | 18.00 USD  |
      | Uninsured Motorist - Bodily Injury coverage            | 37.00 USD  |
      | Uninsured Motorist - Property Damage coverage          | 12.00 USD  |
      | CA Tax                                                 | 50.00 USD  |
      | Liability - Bodily Injury and Property Damage coverage | 588.00 USD |