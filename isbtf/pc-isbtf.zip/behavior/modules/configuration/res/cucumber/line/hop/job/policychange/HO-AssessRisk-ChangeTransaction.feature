@homeowners @policychange @HO-AssessRisk-ChangeTransaction
Feature: Policy change transactions

  As an agent,
  I want to create a policy change on existing policy,
  so that policy change transaction could be created successfully.

  Background:
    Given I am a user with the "Producer" role

  @11540-GW.33
  Scenario: UW Issues due to addition of a dog with bite history
    Given an in-force Homeowners policy of policy type "Dwelling" and coverage form "HO2"
    And the following UW rules are loaded
      | HOP: Animal bite history |
    When I begin a new policy change
    And I add the following animal information
      | Animal Type  | Dog       |
      | Breed        | Pit Bulls |
      | Bite History | Yes       |
    And I quote the policy change
    Then the policy change status should be "Quoted"
    And the following UW issues should exist
      | Section Title | Short Description   |
      | Blocking Bind | Animal bite history |

  @11540-GW.33
  Scenario: Verification of an approved UW issue
    Given an in-force Homeowners policy of policy type "Dwelling" and coverage form "HO2"
    And the following UW rules are loaded
      | HOP: Animal bite history |
    And I begin a new policy change
    And with the following animal information
      | Animal Type  | Dog       |
      | Breed        | Pit Bulls |
      | Bite History | Yes       |
    And I quote the policy change
    When an Underwriter approves "Animal bite history" UW issue
    Then the following UW issues should exist
      | Section Title    | Short Description   |
      | Already Approved | Animal bite history |

  @11540-GW.33
  Scenario: Change successfully bound after UW issue is approved
    Given an in-force Homeowners policy of policy type "Dwelling" and coverage form "HO2"
    And the following UW rules are loaded
      | HOP: Animal bite history |
    And I begin a new policy change
    And with the following animal information
      | Animal Type  | Dog       |
      | Breed        | Pit Bulls |
      | Bite History | Yes       |
    And I quote the policy change
    And an Underwriter approves "Animal bite history" UW issue
    When I issue the policy change
    Then the policy change status should be "Bound"

  @11540-GW.23
  Scenario: A policy change can not modify the dwelling location
    Given an account of type "Person"
      | First name | Jack           |
      | Last name  | Clark          |
      | Address 1  | 321 Topsail Ct |
      | City       | Foster City    |
      | County     | San Mateo      |
      | State      | CA             |
      | Zip Code   | 94404          |
    And an in-force Homeowners policy of policy type "Dwelling" and coverage form "HO2"
    And I update the Account's primary location data with the following
      | Address 1  | 311 Topsail Ct |
    When I begin a new policy change
    And I quote the policy change
    Then the following error messages should occur
      | The dwelling location can only be changed in a submission, issuance, rewrite or rewrite new account transaction |
    And the policy change status should be "Draft"
