@homeowners @renewal @HO-AssessRiskandClaimsExperience-RenewTransaction
Feature: Renewal

  As an agent,
  I want to create a renewal on an existing policy
  so that I can give the policyholder a renewal.

  Background:
    Given I am a user with the "Producer" role
    And today's date is "10/01/2018"
    And a Homeowners submission

  @11540-GW.32
  Scenario: Upon Renewal Previously Approved UW issue will require approval again
    Given an approved Non-copper wiring UW issue which is valid until "EndOfTerm"
    And I issue the policy
    When today's date is "09/01/2019"
    And I renew the policy
    And I view the "Renewal" transaction with effective date "10/01/2019"
    Then the Non-copper wiring UW issue should exist
#    And the Renewal status should be "New"

  @11540-GW.32
  Scenario: Upon Renewal once approving the blocking UW issue renewal transaction can be bound
    Given an approved Non-copper wiring UW issue which is valid until "EndOfTerm"
    And I issue the policy
    When today's date is "09/01/2019"
    And I renew the policy
    And I view the "Renewal" transaction with effective date "10/01/2019"
    Then the Non-copper wiring UW issue should exist
    When an Underwriter Manager approves "Non-copper wiring" UW issue
    And I am a user with the "Underwriter" role
    And I issue the Renewal with "Issue Now"
    Then the Renewal status should be "Bound"