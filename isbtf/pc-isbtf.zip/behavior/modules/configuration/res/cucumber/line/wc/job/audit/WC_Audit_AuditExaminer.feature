@workers_compensation @audit
Feature: Workers Compensation

  As an audit examiner, I want to process an audit that I have received from either an auditor or a policyholder.

  Background:
    Given I am a user with the "Underwriter" role
    And today's date is "06/01/2019"
    And an account of type "Company"
      | Company Name | Jim O'Brien and Sons |
    And a Workers Compensation submission
    And the policy effective date is "07/01/2018"
    And the policy has the following covered employees:
      | Governing Law  | Location         | Class Code | # Employees | Basis |
      | Voluntary Comp | 1: San Francisco | 0035       | 75          | 10000 |
      | Voluntary Comp | 1: San Francisco | 0005       | 25          | 2000  |
    And I quote the submission
    # note: the plan type can be either installments or premium reporting, "Payment Plan" indicates installments
    And the payment schedule plan type is "Payment Plan"
    And the policy requires a final audit
    And I issue the policy

  Scenario: An Audit examiner performs a final audit
    When I switch to a user with the "Auditor" role
    And audit is scheduled to "05/31/2019"
    And the "AuditTask" batch process is executed
    Then I should be assigned the following activities:
      | Subject                       | Account Holder       | Due Date   | Status |
      | A new audit has been assigned | Jim O'Brien and Sons | 06/04/2019 | Open   |
    And I switch to a user with the "Audit Examiner" role
    And I enter the following audit summary information:
      | Received Date | 06/08/2019 |
      | Audit Fee     | 75 USD     |
    Then I enter the following audit details:
      | Location | Class Code | Estimated Payroll | Audited Payroll |
      | 1        | 0035       | 10000             | 16000           |
    And I calculate the premiums
    And I submit the final audit
    Then the following policy transactions should exist:
      | Type        | Effective Date | Transaction Status |
      | Final Audit | 07/01/2018     | Completed          |