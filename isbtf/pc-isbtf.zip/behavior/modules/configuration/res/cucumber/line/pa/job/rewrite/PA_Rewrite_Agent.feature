@personal_auto @rewrite
Feature: Rewrite

  As an agent, I want to rewrite canceled policies for their full term, remainder of the term, or a completely new term,
  as the canceled policies may have been entered in error or may be eligible for new terms.

  Background:
    Given today's date is "07/01/2018"

  Scenario: Rewrite full term, user journey
    Given an in-force Personal Auto policy
    When I start a Cancellation with the following
      | Source | Insurer                                    |
      | Reason | Policy rewritten or replaced (flat cancel) |
    And I bind the cancellation with "Cancel Now"
    When I rewrite the policy as "Rewrite Full Term"
    And I add the following vehicle:
      | Model Year | 2018   |
      | Make       | Ford   |
      | Model      | Fusion |
      | Cost New   | 22000  |
    And I quote the rewrite
    And I issue the rewrite
    Then the rewrite status should be "Bound"
    And the rewrite transaction type should be "Rewrite Full Term"
    And the following vehicle should exist:
      | Model Year | 2018      |
      | Make       | Ford      |
      | Model      | Fusion    |
      | Cost New   | 22000 USD |
    
  Scenario: Rewrite remainder of the term to a new term
    Given an in-force Personal Auto policy
    When I start a Cancellation with the following
      | Source                      | Insurer                     |
      | Reason                      | Policy rewritten (mid-term) |
      | Cancellation Effective Date | 08/01/2018                  |
    And I bind the cancellation with "Cancel Now"
    When I rewrite the policy as "Rewrite Remainder of Term"
    And I select Term Type "Annual"
    And I quote the rewrite
    Then the following Personal Auto costs should exist:
      | Total Premium      | 1359.00 USD |
      | Taxes & Surcharges | 99.00 USD   |
      | Total Cost         | 1458.00 USD |
    When an Underwriter approves "New period end date does not match end date of previous period." UW issue
    And I issue the rewrite
    Then the rewrite status should be "Bound"
    And the rewrite transaction type should be "Rewrite Remainder of Term"