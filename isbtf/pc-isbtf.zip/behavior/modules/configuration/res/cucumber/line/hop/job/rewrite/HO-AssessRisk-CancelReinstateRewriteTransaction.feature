@homeowners @rewrite @HO-AssessRisk-CancelReinstateRewriteTransaction
Feature: Cancellation and Rewrite

  As an underwriter,
  I want to rewrite a canceled policy,
  so that I can make the canceled policy active.
  As an agent,
  I want to rewrite a canceled policy,
  so that I can make the canceled policy active.

  @11540-GW.24
  Scenario: On rewrite additional information field is required
    Given I am a user with the "Underwriter" role
    And an in-force Homeowners policy
    And I cancel the policy for rewrite
    And I rewrite the policy as "Rewrite Remainder of Term"
    And with the following animal information
      | Animal Type  | Other |
      | Breed        | Other |
      | Bite History | No    |
    When I quote the rewrite
    Then the following error messages should occur
      | Additional information field is required for animals with 'Other' breed |
    And the rewrite status should be "Draft"


  Scenario: On rewrite, roof age UW issue is raised when dwelling construction information is added
    Given I am a user with the "Producer" role
    And an in-force Homeowners policy
    And I cancel the policy for rewrite
    And I rewrite the policy as "Rewrite Remainder of Term"
    And the age of the house is more than "25" years
    And the roof was not upgraded
    When I quote the rewrite
    Then the following UW issues should exist
      | Section Title     | Short Description |
      | Blocking Bind     | Roof age          |