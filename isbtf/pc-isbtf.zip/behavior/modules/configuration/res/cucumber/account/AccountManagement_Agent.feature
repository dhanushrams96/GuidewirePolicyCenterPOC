Feature: Account Management

  As an agent, I want to search for an account, create a new account or update information on an existing account.

  Background:
    Given I am a user with the "Producer" role

  Scenario: Create an Account of type Person
    Given the following account of type Person does not exist:
      | First name     | Liz            |
      | Last name      | Jennings       |
    When I create the following account of type Person:
      | First name     | Liz            |
      | Last name      | Jennings       |
      | Address 1      | 111 Main St.   |
      | Address 2      | Floor 1        |
      | Address 3      | Unit #0001     |
      | City           | San Mateo      |
      | State          | CA             |
      | ZIP Code       | 94404          |
    Then an account of type Person exists for the following:
      | First name   | Liz              |
      | Last name    | Jennings         |

  Scenario: Create an Account of type Company
    Given the following account of type Company does not exist:
      | Company name   | Morris Day and Sons |
    When I create the following account of type Company:
      | Company name   | Morris Day and Sons |
      | Address 1      | 111 Main St.        |
      | Address 2      | Floor 1             |
      | Address 3      | Unit #0001          |
      | City           | San Mateo           |
      | State          | CA                  |
      | ZIP Code       | 94404               |
    Then an account of type Company exists for the following:
      | Company name   | Morris Day and Sons |

  Scenario: Update an Account of type Person
    Given an account of type "Person"
      | Account Number | C00014                               |
      | Address 1      | 111 Main St.                         |
      | Address 2      | Floor 1                              |
      | Address 3      | Developer Unit Habitation Cube #0001 |
      | City           | San Mateo                            |
      | State          | CA                                   |
      | ZIP Code       | 94404                                |
    When I update the Account data with the following:
      | Address 1 | 23 Elm St.                           |
      | Address 2 | Floor 5                              |
      | Address 3 | Developer Unit Habitation Cube #0002 |
    Then Account "C00014" should contain the following data:
      | Home Address 1 | 23 Elm St.                           |
      | Home Address 2 | Floor 5                              |
      | Home Address 3 | Developer Unit Habitation Cube #0002 |
      | Home Address 4 | San Mateo, CA 94404                  |