package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.renewal.RenewalContextImplBase

@Export
class PARenewalContextImpl extends RenewalContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    var renewalWizard = loginIfLoggedOut(CurrentUser).goToRenewal(ScenarioInfoProvider.DataSetup.Entity.Renewal)
    var vehicleScreen = renewalWizard.PAMode.goToVehiclesStep()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.verifyVehicleExists(givenFields)
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}