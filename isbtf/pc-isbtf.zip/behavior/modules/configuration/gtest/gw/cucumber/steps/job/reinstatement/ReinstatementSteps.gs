package gw.cucumber.steps.job.reinstatement

uses com.google.inject.Inject
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.transformer.TypelistTransformer

@Export
class ReinstatementSteps {

  @Inject
  var _contextFactory : ContextFactory

  @When("^I reinstate the policy")
  function reinstatePolicy(){
    _contextFactory.getReinstatementContext().reinstatePolicy()
  }

  @Then("^the reinstatement status should be \"(Bound|Quoted)\"$")
  function reinstatementStatus(status : String) {
    _contextFactory.getReinstatementContext().verifyInStatus(status)
  }
}