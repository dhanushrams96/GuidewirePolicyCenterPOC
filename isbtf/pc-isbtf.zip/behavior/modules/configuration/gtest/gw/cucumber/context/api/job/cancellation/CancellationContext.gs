package gw.cucumber.context.api.job.cancellation

uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link Cancellation}
 */
@Export
interface CancellationContext extends JobContext {

  /**
   * Initiates a {@link Cancellation} job in draft status
   */
  function createCancellationSetup()

  /**
   * Start a Cancellation Job and fill in with provided cancellation details
   * @param cancellationInfoMap the Map containing cancellation details
   */
  function startPolicyCancellation(cancellationInfoMap : DataTable)

  /**
   *  Creates a bound cancelled policy
   */
  function createACancelledPolicy()

  /**
   *  Creates a bound cancelled policy for rewrite
   */
  function createACancelledPolicyForRewrite()

  /**
   * Bind a Cancellation Job using provided CancellationMethod (Schedule Cancellation or Cancel Now)
   * @param cancellationMethod
   */
  function bindCancellation(cancellationMethod: String)

  /**
   * Rescind a Cancellation Job
   */
  function rescindCancellationJob()

  /**
   * Verifies cancellation effective date is after given days
   * @param days number of days after effective date
   */
  function verifyCancellationEffectiveDateIsAfter(days : int)

  /**
   * Start Cancellation and select Source, Reason and Effective Date
   * @param source Insured or Insurer
   * @param reason reason for Cancellation
   * @param date Cancellation Effectice Date
   */
  function startCancellationWithSourceReasonAndDate(source : String, reason : String, date : String)
}
