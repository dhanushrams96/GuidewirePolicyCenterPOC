package gw.cucumber.steps.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.pl.currency.MonetaryAmount

/**
 * Personal auto specific Job steps
 */
@Export
class PA_JobSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Given("^I (?:set|add) the \"([^\"]+)\" vehicle-level coverage:$")
  function addVehicleLevelCoverage(covName : String, coverageTermsDataTable : DataTable) {
    var coverageTerms = coverageTermsDataTable.asMap(String, String)
    _contextFactory.getLineContext<PAContext>().addVehicleLevelCoverage(covName, coverageTerms)
  }

  @When("^I add the following vehicle:$")
  function iAddTheFollowingVehicle(vehicleInfoTable: DataTable) {
    _contextFactory.getLineContext<PAContext>().addVehicle(vehicleInfoTable.asMap(String, String))
  }

  @When("^I revise vehicle \"([^\"]+)\" with the following fields:$")
  function iChangeTheVehicle(yearMakeModel : String, changedFields : DataTable) {
    var vehicleFields = changedFields.asMap(String, String)
    _contextFactory.getLineContext<PAContext>().editVehicle(yearMakeModel, vehicleFields)
  }

  @When("^the following vehicle should exist:$")
  function theVehicleShouldExist(vehicleTable : DataTable) {
    _contextFactory.getLineContext<PAContext>().verifyVehicleExists(vehicleTable.asMap(String, String))
  }

  @When("^I add the following driver:$")
  function iAddADriver(driverTable : DataTable) {
    _contextFactory.getLineContext<PAContext>().addDriver(driverTable.asMap(String, String))
  }

  @Given("^the submission has a vehicle garaged in \"([^\"]*)\"$")
  function vehicleWithGarageState(state : String) {
    _contextFactory.getLineContext<PAContext>().setVehicleGarageState(State.getTypeKey(state))
  }

  @Given("^the submission has a driver who is age \"(\\d+)\"$")
  function submissionDriverAge(age : int) {
    _contextFactory.getLineContext<PAContext>().setDriverAge(age)
  }

  @Then("^the following Personal Auto costs should exist:$")
  function verifyCostsExists(costs : DataTable) {
    var costsMap = costs.asMap(String, MonetaryAmount)
    _contextFactory.getJobContext().verifyCostsExists(costsMap)
  }

  @Then("^the following financial transactions should exist:$")
  function financialTransactionsShouldExist(costs : DataTable) {
    var expectedCosts = costs.asMap(String, MonetaryAmount)
    _contextFactory.getLineContext<PAContext>().verifyFinancialTransactions(expectedCosts)
  }

  @When("^the following onset and offset transactions for vehicle \"([^\"]+)\" should exist:$")
  function vehicleFinancialTransactionsShouldExist(yearMakeModel : String, changedFieldsTable : DataTable) {
    _contextFactory.getLineContext<PAContext>().verifyVehicleFinancialTransactions(yearMakeModel, changedFieldsTable.asLists(String))
  }
}