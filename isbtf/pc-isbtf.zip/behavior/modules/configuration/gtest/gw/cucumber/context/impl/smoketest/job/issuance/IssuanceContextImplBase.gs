package gw.cucumber.context.impl.smoketest.job.issuance

uses gw.cucumber.context.api.job.issuance.IssuanceContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.IssuanceDataSetup
uses gw.cucumber.setup.NonSubmissionDataSetup

@Export
abstract class IssuanceContextImplBase extends JobContextImplBase implements IssuanceContext {

  property get IssuanceDataSetup() : IssuanceDataSetup {
    return ScenarioInfoProvider.DataSetup as IssuanceDataSetup
  }

  override function setEffectiveDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function createIssuance() {
    ScenarioInfoProvider.DataSetup = new IssuanceDataSetup(UserUnderwriterRole, ScenarioInfoProvider.BasedOnPolicyPeriod)
    ScenarioInfoProvider.JobSubType = TC_ISSUANCE
    var policySummary = loginAsUser(UserUnderwriterRole).goToPolicySummary(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    policySummary._parent.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.PolicyFileMenuActions_IssueSubmission.click()
    var thisIssuance = NonSubmissionDataSetup.findPolicyPeriodFromBasedOn(ScenarioInfoProvider.BasedOnPolicyPeriod, TC_ISSUANCE)
    IssuanceDataSetup.set(thisIssuance)
  }

  override function quote() {
    var issuanceWizard = loginIfLoggedOut(UserUnderwriterRole).goToIssuance(IssuanceDataSetup.Entity.Issuance)
    var policyReviewStep = issuanceWizard.PolicyReview.click()
    policyReviewStep.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    waitForAutoRefreshToComplete()
    issuanceWizard.ViewQuote.click()
    IssuanceDataSetup.refreshEntity()
  }

  override function issue() {
    var issuanceWizard = loginIfLoggedOut(UserUnderwriterRole).goToIssuance(IssuanceDataSetup.Entity.Issuance)
    var viewQuoteStep = issuanceWizard.ViewQuote.click()
    viewQuoteStep.JobWizardToolbarButtonSet_Issuance.Issue.click()
    IssuanceDataSetup.refreshEntity()
  }

  override function verifyInStatus(status : String) {
    var issuanceWizard = loginIfLoggedOut(CurrentUser).goToIssuance(IssuanceDataSetup.Entity.Issuance)
    NavigationManager.CurrentPCFElement = issuanceWizard.JobWizardInfoBar
    super.verifyInStatus(status)
  }
}
