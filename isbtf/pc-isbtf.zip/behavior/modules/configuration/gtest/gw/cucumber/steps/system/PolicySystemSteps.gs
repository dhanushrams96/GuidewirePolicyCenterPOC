package gw.cucumber.steps.system

uses com.google.inject.Inject
uses cucumber.api.Scenario
uses cucumber.api.java.After
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory

@SuppressWarnings("Method2Property")
@Export
class PolicySystemSteps {

  @Inject
  var _contextFactory : ContextFactory

  @When("^today's date is \"([^\"]+)\"$")
  function setCurrentTime(date : String) {
    _contextFactory.getPolicySystemContext().setCurrentTime(date)
  }

  @After
  function restoreRatingPlugin(scenario : Scenario) {
    _contextFactory.getPolicySystemContext().restorePlugins()
  }

  @When("^the \"([^\"]+)\" batch process is executed$")
  function iRunBatchProcess(batchProcessName : String) {
    _contextFactory.getPolicySystemContext().runBatchProcess(batchProcessName)
  }
}