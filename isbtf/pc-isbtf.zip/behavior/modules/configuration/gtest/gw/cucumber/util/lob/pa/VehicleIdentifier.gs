package gw.cucumber.util.lob.pa

/**
 * Helper class which defines helper methods to uniquely identify a vehicle based on vehicle
 * information on UI. For example, Vehicle can be identified with a string value consisting of Year, Make, and Model.
 */
@Export
public class VehicleIdentifier {

  var _yearMakeModel : String as readonly YearMakeModel

  construct(year : String, make : String, model : String) {
    //StringBuilder.append is null safe
    _yearMakeModel = new StringBuilder().append(year)
        .append(" ")
        .append(make)
        .append(" ")
        .append(model).toString()
  }

  construct(yearMakeModel : String) {
    _yearMakeModel = yearMakeModel
  }

  property get Identifier() : String {
    return YearMakeModel
  }

  override function equals(that: Object): boolean {
    if (this === that) {
      return true
    }

    if (that typeis VehicleIdentifier) {
      return YearMakeModel == that.YearMakeModel
    } else {
      return false
    }
  }

  override function hashCode(): int {
    return Objects.hash({YearMakeModel})
  }
}