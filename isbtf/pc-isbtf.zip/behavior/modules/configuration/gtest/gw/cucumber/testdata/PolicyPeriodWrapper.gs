package gw.cucumber.testdata

uses cucumber.runtime.java.guice.ScenarioScoped

@ScenarioScoped
class PolicyPeriodWrapper extends DataWrapper<PolicyPeriod> {}