package gw.cucumber.context.impl.smoketest.job.policychange

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.job.policychange.PolicyChangeContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.util.common.UIHelper
uses gw.cucumber.setup.NonSubmissionDataSetup
uses gw.cucumber.setup.PolicyChangeDataSetup
uses gw.cucumber.transformer.ConflictOverrideTransformer

@Export
@SuppressWarnings({"unused"})
abstract class PolicyChangeContextImplBase extends JobContextImplBase implements PolicyChangeContext {

  property get PolicyChangeDataSetup() : PolicyChangeDataSetup {
    return ScenarioInfoProvider.DataSetup as PolicyChangeDataSetup
  }

  override function createPolicyChange() {
    ScenarioInfoProvider.DataSetup = new PolicyChangeDataSetup(CurrentUser, ScenarioInfoProvider.BasedOnPolicyPeriod)
    var policySummary = loginAsUser(CurrentUser).goToPolicySummary(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    policySummary._parent.goToStartPolicyChangePage()
  }

  override function setEffectiveDate(effectiveDate : Date) {
    var basedOnPolicyPeriod = PolicyChangeDataSetup.BasedOnPolicyPeriod
    var startPolicyChange = _proxy.CurrentPage as pcftest.StartPolicyChange
    startPolicyChange.EffectiveDateTime = effectiveDate
    startPolicyChange.StartPolicyChangeScreen.NewPolicyChange.click()
    waitForAutoRefreshToComplete()
    var thisPolicyChange = NonSubmissionDataSetup.findNewestPolicyPeriodFromBasedOnAndEffectiveDate(basedOnPolicyPeriod, effectiveDate)
    PolicyChangeDataSetup.set(thisPolicyChange)
  }

  override function issue() {
    var policyPeriod = PolicyChangeDataSetup.Entity
    assertThat(policyPeriod.Status)
        .as("This step assumes that the PolicyPeriod is quoted")
        .isEqualTo(PolicyPeriodStatus.TC_QUOTED)
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var quoteScreen = policyChangeWizard.ViewQuote.click()
    quoteScreen.clickBind()
    waitForAutoRefreshToComplete()
    policyPeriod.refresh()
    ScenarioInfoProvider.BasedOnPolicyPeriod = policyPeriod
    PolicyChangeDataSetup.refreshEntity()
  }

  override function verifyInStatus(status : String) {
    //Logging out here is necessary when the current period has been updated outside of the wizard
    logout()

    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    NavigationManager.CurrentPCFElement = policyChangeWizard.JobWizardInfoBar

    super.verifyInStatus(status)
  }

  override function verifyPolicyChangeIsPreempted() {
    var preemptedJob = PolicyChangeDataSetup.Entity.Job
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(preemptedJob as PolicyChange)

    var quoteScreen = policyChangeWizard.ViewQuote.click()
    assertThat(quoteScreen.JobWizardToolbarButtonSet_PolicyChange.HandlePreemptions.Visible)
        .isTrue()

    var preemptingJob = PolicyChangeDataSetup.Entity.PreemptionsOfThisPeriod
        .map(\r -> r.Job.DisplayType + " " + r.Job.JobNumber).join(", ")
    assertThat(quoteScreen.WarningsPanelSet._Entries.single().PanelSet.Warning.Text)
        .isEqualTo(DisplayKey.get("Web.Job.Preempted.Warning", preemptedJob.DisplayType, preemptingJob))
  }

  override function applyPreemptionChanges() {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.Job as PolicyChange)

    var quoteScreen = policyChangeWizard.ViewQuote.click()
    var preemptionPopup = quoteScreen.JobWizardToolbarButtonSet_PolicyChange.HandlePreemptions.click()
    preemptionPopup.HandlePreemption_DifferencesScreen.ApplyChanges.click()
  }

  override function viewPolicyAsOfDaysIntoTerm(numberOfDaysIntoTerm : int) {
    var period = PolicyChangeDataSetup.Entity
    var viewAsOfDate = period.PeriodStart.addDays(numberOfDaysIntoTerm)
    ScenarioInfoProvider.SliceDate = viewAsOfDate

    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(period.PolicyNumber)
    UIHelper.setPolicyFileDatePicker(policyFile, viewAsOfDate)
  }

  override function applyPendingChangesToUnboundRenewal() {
    logout()
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    assertThat(policyChangeWizard.JobWizardInfoBar.JobLabel.Text)
        .as("The renewal should be " + PolicyPeriodStatus.TC_BOUND)
        .contains(PolicyPeriodStatus.TC_BOUND.DisplayName)
    var policyReviewPage = policyChangeWizard.PolicyReview.click()
    policyReviewPage.getJobWizardToolbarButtonSet_PolicyChange().ApplyToUnboundRenewal.click()
  }

  override function verifyChangeInCost(changeInCost : String) {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var quoteScreen = policyChangeWizard.ViewQuote.click()
    NavigationManager.CurrentPCFElement = quoteScreen.Quote_SummaryDV
    super.verifyChangeInCost(changeInCost)
  }

  override function resolveOOSConflicts(conflictOverride : String) {
    var resolveType = new ConflictOverrideTransformer().transform(conflictOverride)
    var period = PolicyChangeDataSetup.Entity
    var policyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(period.PolicyChange)
    var reviewStep = policyChangeWizard.PolicyReview.click()
    reviewStep.OOSConflictsTab.click()
    var conflictEntriesUI = reviewStep.OOSConflictPanelSet.ConflictTableLV._Entries
    assertThat(conflictEntriesUI.Count)
        .as("There should be atleast 1 or more OOS conflicts")
        .isGreaterThanOrEqualTo(1)

    if (resolveType == DisplayKey.get("Web.Job.Conflict.OverrideNone")) {
      reviewStep.OOSConflictPanelSet.ConflictTableLV_tb.OverrideNone.click()
    } else if (resolveType == DisplayKey.get("Web.Job.Conflict.OverrideAll")) {
      reviewStep.OOSConflictPanelSet.ConflictTableLV_tb.OverrideAll.click()
    } else {
      throw new IllegalArgumentException("No valid conflict override option found for " + conflictOverride)
    }

    assertThat(reviewStep.OOSConflictPanelSet.ConflictTableLV.Done.Enabled).isTrue()
    reviewStep.OOSConflictPanelSet.ConflictTableLV.Done.click()
    PolicyChangeDataSetup.refreshEntity()
  }

  override function verifyOOSConflictsExist(expectedEntries : List<Map<String, String>>) {
    var period = PolicyChangeDataSetup.Entity
    var policyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(period.PolicyChange)

    //assert warning message contains - Your Policy Change is an out-of-sequence transaction. There are future transactions at 09/01/2018.
    var riskAnalysis = policyChangeWizard.RiskAnalysis.click()
    assertThat(riskAnalysis.OOSConflictWarnings.hasMatch(\s ->
        s == DisplayKey.get("Web.Job.OOS.Warning", period.Job.DisplayType, period.BasedOn.EditEffectiveDate.format("short"))))
        .as("Missing warning message:" + DisplayKey.get("Web.Job.OOS.Warning", period.Job.DisplayType, period.BasedOn.EditEffectiveDate.format("short")))
        .isTrue()

    var reviewStep = policyChangeWizard.PolicyReview.click()
    reviewStep.OOSConflictsTab.click()
    var conflictEntriesUI = reviewStep.OOSConflictPanelSet.ConflictTableLV._Entries
    assertThat(conflictEntriesUI.Count).isEqualTo(expectedEntries.Count)

    var conflictEntriesListOfMaps = new ArrayList<HashMap<String, String>>()
    conflictEntriesUI.each(\entry -> {
      var row = new HashMap<String,String>()

      row.putIfAbsent(entry.Description.Label, entry.Description.Value)
      // extract "Policy Change" from UI label of "Policy Change Eff. dd/mm/yyyy"
      row.putIfAbsent(entry.NewValue.Label.substring(0, 13), entry.NewValue.Value)
      row.putIfAbsent(entry.ConflictValue.Label, entry.ConflictValue.Value)
      conflictEntriesListOfMaps.add(row)
    })

    assertThat(conflictEntriesListOfMaps).isEqualTo(expectedEntries)
  }

  override function addContingency(contingencyInfo : Map<String, String>) : void {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function quote() {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    NavigationManager.CurrentPCFElement = policyChangeWizard.PolicyReview.click().JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(issues : List<Map<String, String>>) {
    logout()
    var policyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var riskAnalysisScreen = policyChangeWizard.RiskAnalysisStep.click()
    riskAnalysisScreen.selectViewIssuesBlocking("View All")
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.verifyUWBindBlockingAndApprovedIssuesExist(issues)
  }
}
