package gw.cucumber.util.lob.hop

uses gw.api.locale.DisplayKey
uses gw.cucumber.util.common.UIFieldsProviderBase

@Export
class DwellingUIFieldsProvider extends UIFieldsProviderBase {

  construct(fields : Map<String, String>) {
    super(fields)
  }

  override property get RequiredFields() : Set<String> {
    return {
        DisplayKey.get("Web.Policy.HOP.HOPDwelling.LocationName")
    }
  }

  override property get DefaultFields() : Map<String, String> {
    return {
        DisplayKey.get("Web.Policy.HOP.HOPDwelling.EstimatedReplacementCost") -> "700,000.00"
    }
  }
}