package gw.cucumber.context.impl.smoketest.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.impl.smoketest.job.rewrite.RewriteContextImplBase

@SuppressWarnings("unused")
@Export
class HOPRewriteContextImpl extends RewriteContextImplBase implements HOPContext {

  @Inject delegate _lineContextDelegate represents HOPContext

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}