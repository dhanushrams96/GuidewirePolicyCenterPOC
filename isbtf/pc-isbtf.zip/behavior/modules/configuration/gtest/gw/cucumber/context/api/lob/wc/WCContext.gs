package gw.cucumber.context.api.lob.wc

uses gw.cucumber.context.api.lob.LineContext

/**
 * Methods common to Workers Compensation line
 * These methods are common to {@link Job} subtypes, for example Submission, PolicyChange, etc.
 */
@SuppressWarnings({"unused","Method2Property"})
@Export
interface WCContext extends LineContext {

  /**
   * Add the list of covered employees from the provided data
   * @param data a List where each item represents a row which represents a class of covered employees
   */
  function addCoveredEmployees(data : List<Map<String,String>>)

  /**
   * Set the values of classes of covered employees from the provided data.
   * @param data a List where each item represents a row which represents a class of covered employees
   */
  function setCoveredEmployees(data : List<Map<String,String>>)

  /**
   * Verify that the provided classes of covered employees exist
   * @param data a List where each item represents a row which represents a class of covered employees
   */
  function verifyCoveredEmployees(data : List<Map<String,String>>)

  /**
   * Verify that the provided costs exist
   * Costs are matched by a combination of Location Number and ClassCode
   * @param data a List where each item represents a cost
   *
   * For example, [
   * <pre> {"Loc.":"1", "Code":"0050", "Basis":"10000", "Rate":"13.1180", "Amount":"1312.00"} </pre>
   * ]
   */
  function verifyRates(data : List<Map<String,String>>)

  /**
   * Override the Base Rate for the provided costs.
   * Costs are matched by a combination of Location Number and ClassCode
   * @param data a List where each item represents a cost having an overriding base rate.
   *
   * For example, [
   * <pre> {"Loc.":"1", "Code":"0050", "Rate":"13.1180"} </pre>
   * ]
   */
  function overrideClassBaseRate(data : List<Map<String,String>>)

  /**
   * Add the given experience modifiers.
   * @param data a list where each item represents an experience modifier.
   *
   * For example, [
   * <pre> {"Period":"Period 1", "Experience Modifier":"1.1"} </pre>
   * <pre> {"Period":"Period 2", "Experience Modifier":"0.98"} </pre>]
   *
   */
  function addExperienceModifiers(data : List<Map<String,String>>)
}
