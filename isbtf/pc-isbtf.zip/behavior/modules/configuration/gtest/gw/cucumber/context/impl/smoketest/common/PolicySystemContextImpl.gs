package gw.cucumber.context.impl.smoketest.common

uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.PolicySystemContext
uses gw.workqueue.WorkQueueTestUtil

@Export
class PolicySystemContextImpl extends CucumberStepBase implements PolicySystemContext {

  override function setCurrentTime(date : String) {
    setCurrentSystemTime(date)
  }

  override function restorePlugins() {
    restoreSystemPlugins()
  }

  override function runBatchProcess(batchProcessName : String) {
    checkPolicyIssued()
    var batchProcess = BatchProcessType.AllTypeKeys.singleWhere(\elt -> elt.DisplayName.equals(batchProcessName))
    WorkQueueTestUtil.startWriterViaBatchProcessManagerThenWorkersAndWaitUntilWorkFinishedThenStop(batchProcess, {})

    // Some workqueue might create sub-workflows so we also want to run them to fully simulate the process...
    WorkQueueTestUtil.restartWorkersAndWaitUntilWorkFinishedThenStop(BatchProcessType.TC_WORKFLOW)
  }

  private function checkPolicyIssued(){
    if(ScenarioInfoProvider.BasedOnPolicyPeriod == null) {
      ScenarioInfoProvider.BasedOnPolicyPeriod = ScenarioInfoProvider.DataSetup.Entity
    }
  }
}