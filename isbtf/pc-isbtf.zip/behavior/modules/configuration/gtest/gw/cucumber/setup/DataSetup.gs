package gw.cucumber.setup

uses gw.api.databuilder.DataBuilder
uses gw.pl.persistence.core.Bean
uses gw.pl.persistence.core.Bundle
uses gw.transaction.Transaction

@Export
class DataSetup<T extends Bean, B extends DataBuilder<T, B>> {
  protected var _builder : B
  protected var _entity : T
  protected var _user: String

  construct() {
    // if no default user is specified we use Producer Role user: aarmstrong
    this("aarmstrong")
  }

  construct(user: String) {
    _user = user
  }

  property get Builder() : B {
    if (Status == "Entity") {
      throw new IllegalStateException("can't use builder after entity created");
    }
    if (_builder == null) {
      _builder = createBuilder()
      initializeBuilder(_builder)
    }
    return _builder
  }

  property get Entity() : T {
    if (Status == "Builder") {
      Transaction.runWithNewBundle(\bundle -> {
        _entity = createEntity(bundle)
      }, _user)
    }
    return _entity;
  }

  /**
   * Returns "Builder" if the DataSetup has not yet created the entity. Once the entity has been created, and forever
   * after, returns "Entity".
   * In once case, the SubmissionBuilder will use of different methods depending on whether there is an AccountBuilder
   * or an Account. There may be other usages.
   * @return "Builder" if the entity has not yet been created. Otherwise returns "Entity".
   */
  property get Status() : String {
    return (_entity == null) ? "Builder" : "Entity"
  }

  protected function createBuilder() : B {
    return new B()
  }

  protected function initializeBuilder(builder : B) {}

  protected function createEntity(bundle : Bundle) : T {
    return _builder.create(bundle)
  }

}