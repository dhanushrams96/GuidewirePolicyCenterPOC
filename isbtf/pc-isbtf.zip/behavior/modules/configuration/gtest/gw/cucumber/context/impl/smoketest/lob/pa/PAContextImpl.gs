package gw.cucumber.context.impl.smoketest.lob.pa

uses gw.api.locale.DisplayKey
uses gw.api.util.MonetaryAmounts
uses gw.cucumber.util.lob.pa.VehicleIdentifier
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.lob.LineContextImplBase
uses gw.cucumber.setup.PASubmissionDataSetup
uses gw.cucumber.util.common.PCFReflectUtil
uses gw.cucumber.util.common.ProductModelReflectUtil
uses gw.cucumber.util.common.UIHelper
uses gw.cucumber.util.lob.pa.VehicleUIFieldsProvider
uses gw.pl.currency.MonetaryAmount
uses gw.util.Pair
uses pcftest.PAVehiclesScreen

@Export
class PAContextImpl extends LineContextImplBase implements PAContext {

  override function addDriver(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addVehicle(givenFields : Map<String, String>) {
    var vehicleScreen = NavigationManager.ensureOnPage(PAVehiclesScreen)
    var vehicleFields = givenFields.copy()

    vehicleScreen.CreateVehicleButton.click()
    var vehicleDV = vehicleScreen.PersonalAutoVehicleDV

    var driver = vehicleFields.remove(DisplayKey.get("Web.PolicyLine.Vehicle.Driver.Driver"))
    if (driver == null or driver.Empty) {
      vehicleScreen.addExistingDriver()
    } else {
      vehicleScreen.addExistingDriver(driver)
    }

    UIHelper.setFieldValues(vehicleDV, new VehicleUIFieldsProvider(vehicleFields, ScenarioInfoProvider.DataSetup.Entity))
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    var vehicleScreen = NavigationManager.ensureOnPage(pcftest.PAVehiclesScreen)
    var vehicleFields = givenFields.copy()
    var modelYear = vehicleFields.get(DisplayKey.get("Web.PolicyLine.Vehicle.Year"))
    var make = vehicleFields.get(DisplayKey.get("Web.PolicyLine.Vehicle.Make"))
    var model = vehicleFields.get(DisplayKey.get("Web.PolicyLine.Vehicle.Model"))
    var vIdentifier = new VehicleIdentifier(modelYear, make, model)

    if (vehicleFields.containsKey(DisplayKey.get("Web.PolicyLine.Vehicle.CostNew"))) {
      var costNew = vehicleFields.get(DisplayKey.get("Web.PolicyLine.Vehicle.CostNew"))
      var costAmount = new MonetaryAmount(costNew).Amount.setScale(2)
      vehicleFields.replace(DisplayKey.get("Web.PolicyLine.Vehicle.CostNew"), costAmount.toString())
    }

    var targetVehicle = vehicleScreen.getPAVehicleEntry(vIdentifier)
    targetVehicle.viewDetail()

    UIHelper.assertFieldValues(vehicleScreen.VehicleDetail, vehicleFields)
  }

  override function editVehicle(yearMakeModel : String, givenFields : Map<String, String>) {
    var vehicleScreen = NavigationManager.ensureOnPage(pcftest.PAVehiclesScreen)
    var vehicleFields = givenFields.copy()
    var vehicleIdentifier = new VehicleIdentifier(yearMakeModel)
    var targetVehicle = vehicleScreen.getPAVehicleEntry(vehicleIdentifier)
    targetVehicle.viewDetail()
    var vehicleDV = vehicleScreen.PersonalAutoVehicleDV
    PCFReflectUtil.setFieldValues(vehicleFields, vehicleDV)
  }

  override function verifyVehicleFinancialTransactions(yearMakeModel : String, data : List<List<String>>) {
    var panelSetPersonalAutoLine = NavigationManager.ensureOnPage(pcftest.RatingTxDetailsPanelSet_PersonalAutoLine)
    var vIdentifier = new VehicleIdentifier(yearMakeModel)
    var targetVehiclePanel = panelSetPersonalAutoLine.vehicleIterator._Entries
        .singleWhere(\vehiclePanel -> {
          var vehicleEntry = new VehicleIdentifier(vehiclePanel.Year.Text, vehiclePanel.Make.Text, vehiclePanel.Model.Text)
          return vIdentifier == vehicleEntry
        })

    var valuePairOnPage : List<Pair<String, MonetaryAmount>> = {}
    targetVehiclePanel._Entries.each(\coverage -> {
      var covName = coverage.Description.Text
      var amount = MonetaryAmounts.ofDefaultCurrency(coverage.TxAmount.Value)
      valuePairOnPage.add(Pair.make(covName, amount))
    })

    panelSetPersonalAutoLine._Entries.each(\tax -> {
      var taxName = tax.Description.Text
      var amount = MonetaryAmounts.ofDefaultCurrency(tax.Amount.Value)
      valuePairOnPage.add(Pair.make(taxName, amount))
    })

    var changedFieldsLists = data
    changedFieldsLists.each(\covAndValue -> {
      assertThat(valuePairOnPage.hasMatch(\valuePair ->
          valuePair.First == covAndValue.first() && valuePair.Second == new MonetaryAmount(covAndValue.get(1))
      ))
          .as("No match found for " + covAndValue.first() + ", " + covAndValue.last())
          .isTrue()
    })
  }


  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var policyFilePaCoveragesScreen = NavigationManager.ensureOnPage(pcftest.PolicyFile_PersonalAuto.PolicyFile_PA_Coverages_Screen)
    assertThat(ProductModelReflectUtil.hasCoverageWithCovTermValues(covName, coverageTerms, policyFilePaCoveragesScreen, false))
        .as("This coverage should be selected: " + covName + ", " + coverageTerms.entrySet().map(\row -> row.Key + ", " + row.Value).join("\n"))
        .isTrue()
  }

  override function verifyLineLevelCoverageDoesNotExist(covName : String) {
    var policyFilePaCoveragesScreen = NavigationManager.ensureOnPage(pcftest.PolicyFile_PersonalAuto.PolicyFile_PA_Coverages_Screen)
    assertThat(ProductModelReflectUtil.hasCoverage(covName, policyFilePaCoveragesScreen, false))
        .as("This coverage shouldn't be available: " + covName)
        .isFalse()
  }

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var allLineLevelCoveragesDV = NavigationManager.ensureOnPage(pcftest.PersonalAuto_AllVehicleCoveragesDV)
    assertThat(period.Status)
        .as("this step requires " + period.Job.DisplayName + " in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)
    ProductModelReflectUtil.addAndSetCoverage(covName, coverageTerms, allLineLevelCoveragesDV)
  }

  override function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var allVehicleCoveragesDV = NavigationManager.ensureOnPage(pcftest.PAPerVehiclePanelSet)
    assertThat(period.Status)
        .as("this step requires " + period.Job.DisplayName + " in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)
    ProductModelReflectUtil.addAndSetCoverage(covName, coverageTerms, allVehicleCoveragesDV)
  }

  override function removeLineLevelCoverage(covName: String) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var allLineLevelCoveragesDV = NavigationManager.ensureOnPage(pcftest.PersonalAuto_AllVehicleCoveragesDV)
    assertThat(period.Status)
        .as("this step requires submission in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)

    ProductModelReflectUtil.removeCoverage(covName, allLineLevelCoveragesDV)
  }

  override function viewRatingWorksheet() {
    var ratingPanelSetPA = NavigationManager.ensureOnPage(pcftest.RatingCumulDetailsPanelSet_PersonalAutoLine)
    var popUp = ratingPanelSetPA.RatingOverrideButtonDV.RatingOverrideButtonDV.ViewWorksheet.click()

    NavigationManager.CurrentPCFElement = popUp
  }

  override function setVehicleGarageState(state : State) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setDriverAge(age : int) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setVehicleCost(cost : int) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setupInForcePersonalAutoPolicy() {
    var paSubmissionDataSetup = new PASubmissionDataSetup(UserUnderwriterRole)
    paSubmissionDataSetup.isBound()
    var period = paSubmissionDataSetup.Entity
    ScenarioInfoProvider.BasedOnPolicyPeriod = period
  }

  override function verifyFinancialTransactions(expectedCosts : Map<String, MonetaryAmount>) {
    throw new UnsupportedOperationException("Not implemented")
  }
}