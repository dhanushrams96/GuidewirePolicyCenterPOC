package gw.cucumber.steps.lob

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses cucumber.api.java.en.Then
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.setup.DataTableRepository
uses gw.cucumber.transformer.TypelistTransformer

@Export
class LineSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _dataTableRepository : DataTableRepository

  @When("^I split the period effective \"([^\"]+)\" with Type \"(Forced Rerating|Late Modifier)\"$")
  function iSplitPeriod(splitEffectiveDateStr: String, splitType: String) {
    var rpsdType = new TypelistTransformer<RPSDType>().transform(splitType)
    _contextFactory.getLineContext().splitPeriod(splitEffectiveDateStr, rpsdType)
  }

  @Then("^the following periods should exist:$")
  function followingPeriodsShouldExist(expectedPeriodsTable : DataTable) {
    var expectedPeriods = expectedPeriodsTable.asMaps(String, String)
    _contextFactory.getLineContext().verifySplitPeriods(expectedPeriods)
  }

  @Then("^policy premiums should be calculated for each period of the split$")
  function policyPremiumsShouldBeCalculatedForEachPeriodOfTheSplit(expectedStandardPremiumHeadersTable: DataTable) {
    var expectedStandardPremiumHeaders = expectedStandardPremiumHeadersTable.asMaps(String, String)
    _contextFactory.getLineContext().verifySplitPeriodPremiums(expectedStandardPremiumHeaders)
  }

  @When("^I remove the \"([^\"]+)\" line-level coverage$")
  function removeLineLevelCoverage(covName : String) {
    _contextFactory.getLineContext().removeLineLevelCoverage(covName)
  }

  @When("^I (?:set|add) the \"([^\"]+)\" line-level coverage:$")
  function addLineLevelCoverage(covName : String, coverageTermsDataTable : DataTable) {
    var coverageTerms = _dataTableRepository.dataTableLookup(coverageTermsDataTable).asMap(String, String)
    _contextFactory.getLineContext().addLineLevelCoverage(covName, coverageTerms)
  }

  @When("^I (?:set|add) the \"([^\"]+)\" line-level coverage$")
  function addLineLevelCoverage(covName : String) {
    _contextFactory.getLineContext().addLineLevelCoverage(covName, {})
  }

  @Then("^the \"([^\"]+)\" line-level coverage on Policy File should exist:$")
  function checkLineLevelCoverageExistOnPolicyFile(covName : String, coverageTermsDataTable : DataTable) {
    var coverageTerms = coverageTermsDataTable.asMap(String, String)
    _contextFactory.getLineContext().verifyLineLevelCoverage(covName, coverageTerms)
  }

  @Then("^the \"([^\"]+)\" line-level coverage should exist:$")
  function checkLineLevelCoverageExist(covName : String, coverageTermsDataTable : DataTable) {
    var coverageTerms = _dataTableRepository.dataTableLookup(coverageTermsDataTable).asMap(String, String)
    _contextFactory.getLineContext().verifyLineLevelCoverage(covName, coverageTerms)
  }

  @Then("^the \"([^\"]+)\" line-level coverage should exist$")
  function checkLineLevelCoverageExist(covName : String) {
    _contextFactory.getLineContext().verifyLineLevelCoverage(covName, {})
  }

  @Then("^the \"([^\"]+)\" line-level coverage shouldn't exist$")
  function checkLineLevelCoverageNotExist(covName : String) {
    _contextFactory.getLineContext().verifyLineLevelCoverageDoesNotExist(covName)
  }

  @Then("^the following policy transactions should exist:$")
  function policyTransactionsExist(transactions : DataTable) {
    _contextFactory.getLineContext().verifyPolicyTransactions(transactions.asMaps(String, String))
  }

  @Then("^I view the \"([^\"]+)\" transaction with effective date \"([^\"]+)\"$")
  function iViewTransactionOfDate(transaction : String, date : String) {
    _contextFactory.getLineContext().viewTransaction(transaction, date)
  }

  @Given("^the following UW rules are loaded$")
  function theFollowingUWIssuesAreLoaded(uwRules : DataTable) {
    var expectedLoadedRules = uwRules.asList(String)
    _contextFactory.getAdminContext().verifyUWIssuesLoaded(expectedLoadedRules)
  }
}