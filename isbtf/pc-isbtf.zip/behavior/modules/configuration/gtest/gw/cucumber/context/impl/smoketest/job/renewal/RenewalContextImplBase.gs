package gw.cucumber.context.impl.smoketest.job.renewal

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.job.renewal.RenewalContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.RenewalDataSetup
uses gw.workqueue.WorkQueueTestUtil
uses pcftest.RenewalWizard

@Export
abstract class RenewalContextImplBase extends JobContextImplBase implements RenewalContext {

  property get RenewalDataSetup() : RenewalDataSetup {
    return ScenarioInfoProvider.DataSetup as RenewalDataSetup
  }

  override function setEffectiveDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyInStatus(status : String) {
    var renewalWizard = goToRenewal()
    NavigationManager.CurrentPCFElement = renewalWizard.JobWizardInfoBar

    super.verifyInStatus(status)
  }

  override function startRenewal() {
    var period = ScenarioInfoProvider.BasedOnPolicyPeriod
    ScenarioInfoProvider.DataSetup = new RenewalDataSetup(CurrentUser, period)

    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(period.PolicyNumber)
    policyFile.startPolicyRenewal()
    // For test server the sub-workflow of a renewal process won't be run so we need to start it programmatically
    WorkQueueTestUtil.restartWorkersAndWaitUntilWorkFinishedThenStop(BatchProcessType.TC_WORKFLOW)
    RenewalDataSetup.set(period.Policy.OpenRenewalJob.LatestPeriod)
    RenewalDataSetup.refreshEntity()
  }

  override function edit() {
    goToRenewal().goToViewQuote().JobWizardToolbarButtonSet_Renewal.EditPolicyWorkflow.click()
  }

  override function quote() {
    verifyInStatus(PolicyPeriodStatus.TC_DRAFT.DisplayName)

    var renewalWizard = goToRenewal()
    NavigationManager.CurrentPCFElement = renewalWizard.goToPolicyReview().JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  override function issueRenewal(option : String) {
    verifyInStatus(PolicyPeriodStatus.TC_QUOTED.DisplayName)

    var renewalWizard = goToRenewal()
    switch (option) {
      case DisplayKey.get("Job.Operation.SendToRenewal"):
        renewalWizard.goToViewQuote().JobWizardToolbarButtonSet_Renewal.BindOptions.SendToRenewal.click()
        break
      case DisplayKey.get("Job.Operation.IssueNow"):
        renewalWizard.goToViewQuote().JobWizardToolbarButtonSet_Renewal.BindOptions.IssueNow.click()
        break
      default:
        throw new IllegalArgumentException(option + "is not a valid Renew option. Please select one from : Renew or Issue Now")
    }
  }

  private function goToRenewal() : RenewalWizard {
    return loginIfLoggedOut(CurrentUser).goToTransaction(ScenarioInfoProvider.JobNumber) as RenewalWizard
  }

  override function addContingency(contingencyInfo : Map<String, String>) : void {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(uwIssues : List<Map<String, String>>) {
    logout()
    var renewalWizard = loginIfLoggedOut(UserUnderwriterRole).goToRenewal(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = renewalWizard.RiskAnalysisStep.click()
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.verifyUWBindBlockingAndApprovedIssuesExist(uwIssues)
  }
}