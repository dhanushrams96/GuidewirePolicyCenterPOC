package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.PeriodAnswerBuilder
uses gw.api.builder.PolicyLocationBuilder
uses gw.api.databuilder.hop.HOPCoveragePartBuilder
uses gw.api.databuilder.hop.HOPDwellingBuilder
uses gw.api.databuilder.hop.HOPLineBuilder
uses gw.api.databuilder.hop.HOPSubmissionBuilder

@Export
@ScenarioScoped
class HOPSubmissionDataSetup extends SubmissionDataSetup<HOPSubmissionBuilder> {
  protected static var _vacantQuestion : String = "HOPPreQualPropVacant"
  protected static var _occupantQuestion : String = "HOPPreQualOccupant"
  protected static var _occupiedFullTimeQuestion : String = "HOPPreQualOccupyFullTime"
  protected static var _occupantAnswerMyself : String = "HOPPreQualOccupantMyself"
  protected static var _occupantAnswerTenant : String = "HOPPreQualOccupantTenant"

  private static var OccupantAnswerMap = {"Myself" -> _occupantAnswerMyself, "Tenant" -> _occupantAnswerTenant}

  var _baseState : State as BaseState
  var _hopLineBuilder : HOPLineBuilder as HomeownersLineBuilder
  var _dwellingBuilders : List<HOPDwellingBuilder> as DwellingBuilders = {}
  var _dwellingCoveragePartBuilders : List<HOPCoveragePartBuilder> as DwellingCoveragePartBuilders = {}
  var _answerBuilders : Map<String, PeriodAnswerBuilder> as PrequalAnswerBuilders = new HashMap()

  construct(username : String) {
    super(username)
  }

  protected override function createBuilder() : HOPSubmissionBuilder {
    return new HOPSubmissionBuilder().isDraft()
  }

  protected override function initializeLines() {
    _hopLineBuilder = new HOPLineBuilder()
    Builder.withPolicyLine(HomeownersLineBuilder)

    if(BaseState != null) {
      Builder.withBaseState(BaseState)
    }
  }

  override function provideDefaults() : HOPSubmissionBuilder {
    provideDefaultDwelling()
    addAllHOPPreQualAnswers()
    return Builder
  }

  private function provideDefaultDwelling() : HOPSubmissionBuilder {
    if (_dwellingBuilders.HasElements) {
      return Builder
    }
    createDwelling(CoveragePartType.TC_HOPDWELLING, HOPCoverageForm.TC_HO2)
    return Builder
  }

  function createDwelling(policyType : CoveragePartType, coverageFrom : HOPCoverageForm) : HOPSubmissionBuilder {
    if (DwellingCoveragePartBuilders.HasElements) {
      return Builder
    }
    var hopCoveragePartBuilder = new HOPCoveragePartBuilder()
        .withCoveragePartType(policyType)
        .withHOPDwellingBuilder(createDwellingBuilderFor(coverageFrom))
    DwellingCoveragePartBuilders.add(hopCoveragePartBuilder)
    Builder.withHOPCoveragePartBuilder(hopCoveragePartBuilder)

    return Builder
  }

  private function createDwellingBuilderFor(coverageForm : HOPCoverageForm) : HOPDwellingBuilder {
    var hopDwellingBuilder = new HOPDwellingBuilder()
        .withDefaults()
        .withCoverageForm(coverageForm)
        .createCoverages()
    DwellingBuilders.add(hopDwellingBuilder)

    if (BaseState != null) {
      var dwellingLocationBuilder = new PolicyLocationBuilder()
          .withFireProtectClass(FireProtectClass.TC_3)
          .withState(BaseState)
      hopDwellingBuilder.withPolicyLocationBuilder(dwellingLocationBuilder)
      Builder.withPrimaryPolicyLocation(dwellingLocationBuilder)
    }

    return hopDwellingBuilder
  }

  public function addAllHOPPreQualAnswers(){
    setAnswerForPreQualPropVacant(false)
    setAnswerForPreQualOccupant("Myself")
    setAnswerForPreQualOccupyFullTime(true)
  }

  function setAnswerForPreQualPropVacant(answer:boolean){
    if(not PrequalAnswerBuilders.containsKey(_vacantQuestion)) {
      var answerHOPPreQualPropVacant = new PeriodAnswerBuilder()
          .withQuestionByCodeIdentifier(_vacantQuestion)
          .withBooleanAnswer(answer)
      PrequalAnswerBuilders.put(_vacantQuestion, answerHOPPreQualPropVacant)
      Builder.withAnswer(answerHOPPreQualPropVacant)
    }
  }

  function setAnswerForPreQualOccupant(answer:String) {
    if (not PrequalAnswerBuilders.containsKey(_occupantQuestion)) {
      var answerHOPPreQualOccupant = new PeriodAnswerBuilder()
          .withQuestionByCodeIdentifier(_occupantQuestion)
          .withChoiceAnswer(OccupantAnswerMap.get(answer))
      PrequalAnswerBuilders.put(_occupantQuestion, answerHOPPreQualOccupant)
      Builder.withAnswer(answerHOPPreQualOccupant)
    }
  }

  function setAnswerForPreQualOccupyFullTime(answer:boolean) {
    if (not PrequalAnswerBuilders.containsKey(_occupiedFullTimeQuestion)) {
      var answerHOPPreQualOccupyFullTime = new PeriodAnswerBuilder()
          .withQuestionByCodeIdentifier(_occupiedFullTimeQuestion)
          .withBooleanAnswer(answer)

      PrequalAnswerBuilders.put(_occupiedFullTimeQuestion, answerHOPPreQualOccupyFullTime)
      Builder.withAnswer(answerHOPPreQualOccupyFullTime)
    }
  }

  function withDwellingWiringType(wiringType : typekey.WiringType) : HOPSubmissionBuilder {
    var hopDwellingBuilder = new HOPDwellingBuilder()
        .withDefaults()
        .withCoverageForm(HOPCoverageForm.TC_HO2).createCoverages()
        .withWiringType(wiringType)
    DwellingBuilders.add(hopDwellingBuilder)

    var hopCoveragePartBuilder = new HOPCoveragePartBuilder()
        .withCoveragePartType(CoveragePartType.TC_HOPDWELLING)
        .withHOPDwellingBuilder(hopDwellingBuilder)
    DwellingCoveragePartBuilders.add(hopCoveragePartBuilder)
    Builder.withHOPCoveragePartBuilder(hopCoveragePartBuilder)

    return Builder
  }
}