package gw.cucumber.util.lob.pa

uses gw.api.datagen.DatagenUtil
uses gw.api.locale.DisplayKey
uses gw.command.critical.KeyGenerator
uses gw.cucumber.util.common.UIFieldsProviderBase

@Export
public class DriverUIFieldsProvider extends UIFieldsProviderBase {

  construct(fields : Map<String, String>) {
    super(fields)
  }

  override property get RequiredFields() : Set<String> {
    return {
        DisplayKey.get("Web.ContactDetail.Name.FirstName"),
        DisplayKey.get("Web.ContactDetail.Name.LastName"),
        DisplayKey.get("Web.Account.Contact.Driver.YearGotLicence"),
        DisplayKey.get("Web.ContactDetail.AddressDetail.AddressLine1")
    }
  }

  override property get DefaultFields() : Map<String, String> {
    return {
        DisplayKey.get("Web.ContactDetail.Name.FirstName") -> KeyGenerator.FirstName,
        DisplayKey.get("Web.ContactDetail.Name.LastName") -> KeyGenerator.LastName,
        DisplayKey.get("Web.ContactDetail.AdditionalInfo.DateOfBirth") -> "01/01/1985",
        DisplayKey.get("Web.ContactDetail.AddressDetail.AddressLine1") -> "123 B St.",
        DisplayKey.get("Web.ContactDetail.AddressDetail.City") -> "San Mateo",
        DisplayKey.get("Web.ContactDetail.AddressDetail.State") -> "CA",
        DisplayKey.get("Web.ContactDetail.AddressDetail.Postalcode") -> "94404",
        DisplayKey.get("Web.ContactDetail.AddressDetail.AddressType") -> AddressType.TC_HOME.Code,
        DisplayKey.get("Web.PolicyLine.Drivers.LicenseNumber") -> licenseNumber(),
        DisplayKey.get("Web.PolicyLine.Drivers.LicenseState") -> "CA",
        // Technically -> we only need the Primary Phone and one out of "Home Phone", "Work Phone", and "Mobile Phone", but it's simpler to provide all three phone numbers.
        DisplayKey.get("Web.ContactDetail.Phone.PrimaryPhone") -> PrimaryPhoneType.TC_HOME.DisplayName,
        // Using bare strings for "Home Phone", "Work Phone" and "Mobile Phone" instead of DisplayKeys to simplify
        "Home Phone" -> phoneNumber(),
        "Work Phone" -> phoneNumber(),
        "Mobile Phone" -> phoneNumber(),
        // Roles Tab
        DisplayKey.get("Web.Account.Contact.Driver.YearGotLicence") -> "2001",
        DisplayKey.get("Web.Account.Contact.Driver.NumberOfAccidents") -> "0",
        DisplayKey.get("Web.Account.Contact.Driver.NumberOfViolations") -> "0",
        DisplayKey.get("Web.PolicyLine.Drivers.DoNotOrderMVR") -> "True"
    }
  }

  private static function licenseNumber() : String {
    return DatagenUtil.getRandomAlphaString(8).toUpperCase()
  }

  private static function phoneNumber() : String {
    var sbuf = new StringBuilder(10)
    for (i in 1 .. 10) {
      // For US phone numbers, the first digit cannot be 0 or 1.
      if (i == 1) {
        sbuf.append(DatagenUtil.getRandomNumber(2, 9) as String)
      } else {
        sbuf.append(DatagenUtil.getRandomNumber(9) as String)
      }
      if (i == 3 or i == 6) {
        sbuf.append("-")
      }
    }
    return sbuf.toString()
  }
}