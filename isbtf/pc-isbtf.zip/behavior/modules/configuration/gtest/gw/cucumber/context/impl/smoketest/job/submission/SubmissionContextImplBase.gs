package gw.cucumber.context.impl.smoketest.job.submission

uses gw.api.locale.DisplayKey
uses gw.api.productmodel.Product
uses gw.api.upgrade.PCCoercions
uses gw.api.util.StringUtil
uses gw.cucumber.context.api.job.submission.SubmissionContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.SubmissionDataSetup
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.NewBusinessStepHelper
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses gw.smoketest.pc.job.wizard.SubmissionWizardWrapper
uses pcftest.QuestionSetLV
uses pcftest.SubmissionWizard
uses pcftest.SubmissionWizard_QuoteScreen
uses pcftest.TabBar

/**
 * Base implementation of Submission methods
 */
@Export
@SuppressWarnings({"unused"})
abstract class SubmissionContextImplBase extends JobContextImplBase implements SubmissionContext {

  final var RESPONSES = "Responses"
  final var PREQUALIFICATION_QUESTIONS = "Prequalification Questions"

  override function createNewSubmission() {
    var accountNumber = ScenarioInfoProvider.AccountNumber
    var accountSummary = loginIfLoggedOut(UserProducerRole).goToAccountSummary(accountNumber)
    var newSubmission = accountSummary.MenuActions_NewSubmission.click()
    ScenarioInfoProvider.NewSubmission = newSubmission
    ScenarioInfoProvider.JobSubType = TC_SUBMISSION
  }

  override function selectProduct() {
    if (ScenarioInfoProvider.NewSubmission == null) {
      throw new IllegalStateException("Expected to be on NewSubmission page")
    }
    var newSubmission = ScenarioInfoProvider.NewSubmission
    var productSelections = newSubmission.ProductSelectionLV._Entries
    var productModel = PCCoercions.makeProductModel<Product>(ScenarioInfoProvider.Line.LOBCode)
    var productEntry = productSelections.firstWhere(\elt -> elt.Name.Text == productModel.Name)
    productEntry.addSubmission.click()

    var accountNumber = ScenarioInfoProvider.AccountNumber
    var policyPeriod = DataSetup.findNewestPolicyPeriodFromAccount(accountNumber)
    createLOBSpecificDataSetup()
    ScenarioInfoProvider.DataSetup.set(policyPeriod)
    ScenarioInfoProvider.JobNumber = policyPeriod.Job.JobNumber
    ScenarioInfoProvider.JobSubType = TC_SUBMISSION
  }

  protected abstract function createLOBSpecificDataSetup()

  override function createSubmissionSetup() {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function selectPaymentMethod(paymentMethod : PaymentMethod) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(period)
    var paymentStep = submissionWizard.BillingInfo.click()
    var paymentMethodElement = paymentStep.BillingAdjustmentsPanelSet_Editable.PaymentSchedulePanel.PlanInputSet.PaymentMethod
    var paymentMethodOptionByTypeKey = paymentMethodElement.getOptionByLabel(paymentMethod.DisplayName)
    paymentMethodOptionByTypeKey.click()
  }

  override function selectReportingPlan(reportingPlan : String) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(period)
    var paymentStep = submissionWizard.BillingInfo.click()
    var premiumReportPlan = paymentStep.BillingAdjustmentsPanelSet_Editable.PaymentSchedulePanel.PlanInputSet.PremiumReportPlan
    premiumReportPlan.getOptionByLabel(reportingPlan).click()
  }

  override function setEffectiveDate(effectiveDate : Date) {
    if (ScenarioInfoProvider.DataSetup != null) {
      if (ScenarioInfoProvider.DataSetup.Status == "Builder") {
        ScenarioInfoProvider.DataSetup.Builder.withEffectiveDate(effectiveDate)
      } else {
        throw new UnsupportedOperationException("Not implemented yet for a committed entity.")
      }
    } else if (ScenarioInfoProvider.NewSubmission != null) {
      var newSubmission = ScenarioInfoProvider.NewSubmission
      newSubmission.NewSubmissionScreen.ProductSettingsDV.DefaultPPEffDate.setDateValue(effectiveDate)
    } else {
      throw new UnsupportedOperationException("The date cannot be set when there is a missing DataSetup or when there is no NewSubmission screen.")
    }
  }

  override function setQuoteType(quoteType : QuoteType) {
    if (ScenarioInfoProvider.NewSubmission == null) {
      throw new IllegalStateException("Expected to be on NewSubmission page")
    }
    ScenarioInfoProvider.NewSubmissionQuoteType = quoteType
    var newSubmission = ScenarioInfoProvider.NewSubmission
    newSubmission.NewSubmissionScreen.ProductSettingsDV.QuoteType.Value = quoteType.DisplayName
  }

  override function selectFinalAuditOption(option : FinalAuditOption) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(period)
    var paymentStep = submissionWizard.BillingInfo.click()
    var finalAuditOptions = paymentStep.AuditAdjustmentsDV_Editable.FinalAudit
    if (finalAuditOptions.Enabled) {
      paymentStep.AuditAdjustmentsDV_Editable.FinalAudit.getOptionByValue(option.Code).click()
    }
  }

  override function addContingency(contingencyInfo : Map<String, String>) {
    var submissionWizard = loginAsUser(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.addContingency(contingencyInfo)
  }


  override function setupPolicyEffectiveDate(effectiveDate : Date) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(period)
    var submissionWizardWrapper = new SubmissionWizardWrapper(submissionWizard)
    var policyInfoScreen = submissionWizardWrapper.goToPolicyInfoStep()
    policyInfoScreen.SubmissionWizard_PolicyInfoDV.PolicyInfoInputSet.EffectiveDate.setDateValue(effectiveDate)
  }

  override function setExpirationDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function edit() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var policyReviewScreen = submissionWizard.PolicyReview.click()
    policyReviewScreen.JobWizardToolbarButtonSet_Submission.EditPolicy.click()
    waitForAutoRefreshToComplete()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  property get DataSetup() : SubmissionDataSetup {
    return ScenarioInfoProvider.DataSetup as SubmissionDataSetup
  }

  override function selectProductOffering(productOfferingInfo : Map<String, String>) {
    if (ScenarioInfoProvider.NewSubmission == null) {
      throw new IllegalStateException("Expected to be on NewSubmission page")
    }
    var newSubmission = ScenarioInfoProvider.NewSubmission
    UIHelper.setFieldValues(newSubmission.NewSubmissionScreen.ProductSettingsDV, new UIFieldsProviderBase(productOfferingInfo) {

      override property get RequiredFields() : Set<String> {
        return {}
      }

      override property get DefaultFields() : Map<String, String> {
        return {
            DisplayKey.get("Web.Submission.Products.QuoteType") -> "Full Application",
            DisplayKey.get("Web.NewSubmission.DefaultBaseState") -> "California"
        }
      }
    })
    ScenarioInfoProvider.NewSubmissionQuoteType = new TypelistTransformer<QuoteType>()
        .transform(productOfferingInfo.getOrDefault(DisplayKey.get("Web.Submission.Products.QuoteType"), "Full Application"))
  }

  override function enterPolicyInfo(givenFields : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var infoStep = submissionWizard.PolicyInfo.click()
    UIHelper.setFieldValues(infoStep, new UIFieldsProviderBase(givenFields) {

      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.SubmissionWizard.PolicyInfo.TermType")}
      }

      override property get DefaultFields() : Map<String, String> {
        return {
            DisplayKey.get("Web.SubmissionWizard.PolicyInfo.EffectiveDate") -> StringUtil.formatDate(period.EditEffectiveDate, "MM/dd/yyyy")
        }
      }
    })
    infoStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function selectPreQualification(preQualificationInfoMaps : List<Map<String, String>>) {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var preQualificationScreen = submissionWizard.PreQualification.click()

    var questionSetEntry = preQualificationScreen.PreQualQuestionSetsDV.QuestionSetsDV._Entries.first()
    preQualificationInfoMaps.eachWithIndex(\currentQuestionMap, index -> {
      var preQualificationInfoMap = preQualificationInfoMaps[index]
      var questionText = preQualificationInfoMap.get(PREQUALIFICATION_QUESTIONS)
      var question = questionSetEntry.QuestionSetLV._Entries.singleWhere(\entry -> trimCustomSignFrom(entry.questionText.Text).equalsIgnoreCase(questionText))
      var response = preQualificationInfoMap.get(RESPONSES)
      selectResponse(question, response)
    })

    preQualificationScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  /**
   * Removes an unrecongnized character from the string which is causing the comparision to fail.
   * @param text
   * @return text after removing the character
   */
  private function trimCustomSignFrom(text : String) : String {
    return text.replaceAll((160 as char), '')
  }


  private function selectResponse(question : QuestionSetLV.entry, response : String) {
    if (question.QuestionModalInput_ChoiceSelect_NoPost.ChoiceSelectInput_NoPost.Visible) {
      question.QuestionModalInput_ChoiceSelect_NoPost.ChoiceSelectInput_NoPost.getOptionByLabel(response).click()
    } else if (question.QuestionModalInput_ChoiceSelect.ChoiceSelectInput.Visible) {
      question.QuestionModalInput_ChoiceSelect.ChoiceSelectInput.getOptionByLabel(response).click()
    } else if (question.QuestionModalInput_BooleanRadio_NoPost.BooleanRadioInput_NoPost.Visible) {
      question.QuestionModalInput_BooleanRadio_NoPost.BooleanRadioInput_NoPost.Value = response
    } else if (question.QuestionModalInput_BooleanRadio.BooleanRadioInput.Visible) {
      question.QuestionModalInput_BooleanRadio.BooleanRadioInput.Value = response
    } else if (question.QuestionModalInput_ChoiceRadio_NoPost.ChoiceRadioInput_NoPost.Visible) {
      question.QuestionModalInput_ChoiceRadio_NoPost.ChoiceRadioInput_NoPost.Value = response
    } else if (question.QuestionModalInput_ChoiceRadio.ChoiceRadioInput.Visible) {
      question.QuestionModalInput_ChoiceRadio.ChoiceRadioInput.Value = response
    } else if (question.QuestionModalInput_BooleanCheckbox_NoPost.BooleanCheckboxInput_NoPost.Visible) {
      question.QuestionModalInput_BooleanCheckbox_NoPost.BooleanCheckboxInput_NoPost.Value = response
    } else if (question.QuestionModalInput_BooleanCheckbox.BooleanCheckboxInput.Visible) {
      question.QuestionModalInput_BooleanCheckbox.BooleanCheckboxInput.Value = response
    } else if (question.QuestionModalInput_BooleanSelect_NoPost.BooleanSelectInput_NoPost.Visible) {
      question.QuestionModalInput_BooleanSelect_NoPost.BooleanSelectInput_NoPost.getOptionByLabel(response).click()
    } else if (question.QuestionModalInput_BooleanSelect.BooleanSelectInput.Visible) {
      question.QuestionModalInput_BooleanSelect.BooleanSelectInput.getOptionByLabel(response).click()
    } else if (question.QuestionModalInput_DateField_NoPost.DateFieldInput_NoPost.Visible) {
      question.QuestionModalInput_DateField_NoPost.DateFieldInput_NoPost.Value = response
    } else if (question.QuestionModalInput_DateField.DateFieldInput.Visible) {
      question.QuestionModalInput_DateField.DateFieldInput.Value = response
    } else if (question.QuestionModalInput_IntegerField_NoPost.IntegerFieldInput_NoPost.Visible) {
      question.QuestionModalInput_IntegerField_NoPost.IntegerFieldInput_NoPost.Value = response
    } else if (question.QuestionModalInput_IntegerField.IntegerFieldInput.Visible) {
      question.QuestionModalInput_IntegerField.IntegerFieldInput.Value = response
    } else if (question.QuestionModalInput_StringField_NoPost.StringFieldInput_NoPost.Visible) {
      question.QuestionModalInput_StringField_NoPost.StringFieldInput_NoPost.Value = response
    } else if (question.QuestionModalInput_StringField.StringFieldInput.Visible) {
      question.QuestionModalInput_StringField.StringFieldInput.Value = response
    } else if (question.QuestionModalInput_StringTextArea_NoPost.StringTextAreaInput_NoPost.Visible) {
      question.QuestionModalInput_StringTextArea_NoPost.StringTextAreaInput_NoPost.Value = response
    } else if (question.QuestionModalInput_StringTextArea.StringTextAreaInput.Visible) {
      question.QuestionModalInput_StringTextArea.StringTextAreaInput.Value = response
    }
  }

  override function selectPaymentPlan(paymentPlan : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function causeUWIssue(blockingPoint : UWIssueBlockingPoint) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function selectSideBySideVersion(versionNumber : int) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var sideBySidePage = submissionWizard.goToSideBySidePage()
    sideBySidePage.selectPeriod(versionNumber - 1)

    ScenarioInfoProvider.DataSetup.set(period.Policy.Periods.singleWhere(\prd -> prd.Selected))
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function selectVersion(versionNumber : int) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var versionsPage = submissionWizard.goToManageVersionsPage()
    versionsPage.selectVersion(versionNumber)
    versionsPage.SelectBranchButton.click()
    ScenarioInfoProvider.DataSetup.set(period.Policy.Periods.singleWhere(\prd -> prd.Selected))
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function startSideBySideQuoting() {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    submissionWizard.SideBySide.click()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function initiateANewVersionViaMultiversion() {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var quoteStep = submissionWizard.ViewQuote.click()
    quoteStep.JobWizardToolbarButtonSet_Submission.Versions.NewVersion.click()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function bind() {
    var quoteScreen = gotoQuoteScreen()
    quoteScreen.clickBindOnly()
    //waitForAutoRefreshToComplete is required after the click, its called in the postClickOnBindOrIssueButton
    postClickOnBindOrIssueButton()
  }

  override function issue() {
    var quoteScreen = gotoQuoteScreen()
    quoteScreen.clickBindAndIssue()
    //waitForAutoRefreshToComplete is required after the click, its called in the postClickOnBindOrIssueButton
    postClickOnBindOrIssueButton()
  }

  private function gotoQuoteScreen() : SubmissionWizard_QuoteScreen {
    var policyPeriod = ScenarioInfoProvider.DataSetup.Entity
    assertThat(policyPeriod.Status)
        .as("This step assumes that the PolicyPeriod is quoted")
        .isEqualTo(PolicyPeriodStatus.TC_QUOTED)
    var requiresUnderwriter = isUnderwriterRequired(policyPeriod)
    var tabBar : TabBar
    if (requiresUnderwriter) {
      logout()
      tabBar = loginAsUser(UserUnderwriterRole)
    } else {
      tabBar = loginIfLoggedOut(UserProducerRole)
    }
    var submissionWizard = tabBar.goToSubmission(policyPeriod)
    return submissionWizard.ViewQuote.click()
  }

  private function postClickOnBindOrIssueButton() {
    waitForAutoRefreshToComplete()
    if (isUnderwriterRequired(ScenarioInfoProvider.DataSetup.Entity)) {
      logout()
    }
    ScenarioInfoProvider.DataSetup.refreshEntity()

    ScenarioInfoProvider.BasedOnPolicyPeriod = ScenarioInfoProvider.DataSetup.Entity
  }

  private function isUnderwriterRequired(policyPeriod : PolicyPeriod) : boolean {
    return policyPeriod.BranchName.contains("Version #3")
  }

  override function verifyInStatus(status : String) {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    NavigationManager.CurrentPCFElement = submissionWizard.JobWizardInfoBar

    super.verifyInStatus(status)
  }

  override function verifyNumberOfVersions(numberOfVersions : int) {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    submissionWizard.goToSideBySidePage()
    var actualVersionCount = submissionWizard.SideBySidePaymentPlans.size()
    assertThat(actualVersionCount)
        .as("Number of submission versions does not match")
        .isEqualTo(numberOfVersions)
  }

  override function verifyMultiQuoteVersions(versions : List<List<String>>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var actualEntries : List<String>
    if (PolicyPeriodStatus.TC_BOUND == period.Status) {
      // The version selector is hidden once a multiversion policy is bound; check through database
      actualEntries = period.Policy.Periods.toList().map(\version ->
          NewBusinessStepHelper.getVersionSelectorLabel(version.BranchName, version.Status, version.Selected))
    } else {
      // Unbound policies have the version selector available; check through UI
      actualEntries = (_proxy.CurrentPage as SubmissionWizard).PolicyPeriodSelector.Optionlabels
    }
    var expectedEntries = versions.map(\version ->
        NewBusinessStepHelper.getVersionSelectorLabel(version.get(0), PolicyPeriodStatus.get(version.get(1)), "Selected" == version.get(2)))

    assertThat(actualEntries).containsOnly(expectedEntries.toArray())
  }

  override function verifySelectedReasonCode(reasonCodeValue : String) {
    var reasonCode = new TypelistTransformer<ReasonCode>().transform(reasonCodeValue)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var account = period.Policy.Account
    ScenarioInfoProvider.AccountNumber = account.AccountNumber
    var accountSummary = loginIfLoggedOut(UserProducerRole).goToAccountSummary(ScenarioInfoProvider.AccountNumber)
    var submissionManager = accountSummary.goToSubmissionManager()
    var submissionEntries = submissionManager.SubmissionEntries

    var submissionEntry = submissionEntries.firstWhere(\elt -> elt.SubmissionNumber.Text == period.Job.JobNumber)
    if (submissionEntry.NotTakenLetter.Visible) {
      var rejectLetter = submissionEntry.NotTakenLetter.click()
      var rejectionEntries = rejectLetter.RejectionEntries
      var rejectionEntry = rejectionEntries.firstWhere(\elt -> elt.SubmissionNumber.Text == period.Job.JobNumber)
      assertThat(ReasonCode.get(rejectionEntry.reason.Value))
          .as("Rejection reason does not match")
          .isEqualTo(reasonCode)
    } else if (submissionEntry.DeclineLetter.Visible) {
      var rejectLetter = submissionEntry.DeclineLetter.click()
      var rejectionEntries = rejectLetter.RejectionEntries
      var rejectionEntry = rejectionEntries.firstWhere(\elt -> elt.SubmissionNumber.Text == period.Job.JobNumber)
      assertThat(ReasonCode.get(rejectionEntry.reason.Value))
          .as("Rejection reason does not match")
          .isEqualTo(reasonCode)
    }
  }

  override function setSubmissionBaseState(baseState : String) {
    if (ScenarioInfoProvider.DataSetup == null) {
      throw new IllegalStateException("Expected the DataSetup to have been initialized.")
    }
    if (ScenarioInfoProvider.DataSetup.Status != "Builder") {
      throw new IllegalStateException("Expected the DataSetup to be in the Builder phase, but was in phase " + ScenarioInfoProvider.DataSetup.Status)
    }
    ScenarioInfoProvider.DataSetup.Builder.withBaseState(new TypelistTransformer<State>().transform(baseState))
  }

  override function verifyAdditionalNamedInsuredExists(contactInfo : Map<String, String>) {
    throw new UnsupportedOperationException("Not implemented")
  }

  override function addAdditionalNamedInsured(contactInfo : Map<String, String>) {
    throw new UnsupportedOperationException("Not implemented")
  }

  override function quote() {
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    NavigationManager.CurrentPCFElement = submissionWizard.PolicyReview.click().JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(uwIssues : List<Map<String, String>>) {
    logout()
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.RiskAnalysis.click()
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.verifyUWBindBlockingAndApprovedIssuesExist(uwIssues)
  }

  override function goToReviewPolicy() {
    loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber).PolicyReview.click()
  }
}