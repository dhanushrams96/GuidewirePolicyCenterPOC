package gw.cucumber.context.api.lob

/**
 * A marker interface for a line of business, eg., PersonalAutoLine, HOPLine etc
 */
@Export
interface LineContext {

  /**
   * Adds a line-level coverage given the coverage and coverage terms
   * @param covName the name of the line-level coverage. For example, "Liability - Bodily Injury and Property Damage"
   * @param coverageTerms a map of coverage terms and corresponding cov term values.
   * <pre>For example, {"Auto Liability Package":"100/200/50"}</pre>
   */
  function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>)

  /**
   * Removes a line-level coverage given the coverage name.
   * @param covName the name of the line-level coverage
   */
  function removeLineLevelCoverage(covName: String)

  /**
   * Verify that the specified line-level coverage exists
   * @param covName the name of the line-level coverage. For example, "Liability - Bodily Injury and Property Damage"
   * @param coverageTerms a map of coverage terms and corresponding cov term values.
   * <pre>For example, {"Auto Liability Package":"100/200/50"}</pre>
   */
  function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>)

  /**
   * Verify that the specified line-level coverage does not exist.
   * @param covName the name of the line-level coverage. For example, "Liability - Bodily Injury and Property Damage"
   */
  function verifyLineLevelCoverageDoesNotExist(covName : String)

  /**
   * Navigates to the Quote Screen on a quoted policy and click on the "Show Rating Worksheet" button
   */
  function viewRatingWorksheet()

  /**
   * Navigates to the RatingWorksheet Popup and assert it's not empty
   */
  function verifyRatingWorksheet()

  /**
   * Registers the right Rating Plugin and loads sample data for the tests
   */
  function prepareRating()

  /**
   * Split the Policy Period with the given effective date and split type.
   * @param splitEffectiveDate the effective date to split the period
   * @param splitType the {@link RPSDType} type of Rating Period Start Date
   */
  function splitPeriod(splitEffectiveDate : String, splitType : typekey.RPSDType)

  /**
   * Verify that the given split PolicyPeriods exist on the Policy.
   * @param data a List where each item represents a row which represents a split PolicyPeriod.
   * For example, [
   * <pre> {"Period":"Period 1", "Effective Date Range":"07/01/2018 - 09/01/2018"} </pre>
   * <pre> {"Period":"Period 1", "Effective Date Range":"09/01/2018 - 07/01/2019"} </pre>
   * ]
   */
  function verifySplitPeriods(data : List<Map<String,String>>)

  /**
   * Verify the premium on the {@link PolicyPeriod}s after the split
   * @param data a List where each item represents a row which represents a split PolicyPeriod
   */
  function verifySplitPeriodPremiums(data : List<Map<String,String>>)

  /**
   * Verify the given split {@link PolicyPeriod}s' rates.
   * @param data a List where each item represents a split PolicyPeriod.
   * For example, [
   * <pre> {"Period":"Period 1", "Code":"9903", "Description":"Experience modifier", "Rate":"1.1000"} </pre>
   * <pre> {"Period":"Period 2", "Code":"9903", "Description":"Experience modifier", "Rate":"0.9800"} </pre>
   * ]
   */
  function verifySplitPeriodRates(data : List<Map<String,String>>)

  /**
   * Verify that the policy has expected list of policy transactions.
   * @param expectedTransactions the expected list of transactions
   */
  function verifyPolicyTransactions(expectedTransactions : List<Map<String, String>>)

  /**
   * View the policy transaction based on the given transaction/job type and date
   * @param transaction the expected transaction type
   * @param date the effective date for this transaction
   */
  function viewTransaction(transaction : String, date : String)
}