package gw.cucumber.context.impl.smoketest.lob.wc

@Export
class WCSubmissionContextFullQuoteImpl extends WCSubmissionContextImpl {

}