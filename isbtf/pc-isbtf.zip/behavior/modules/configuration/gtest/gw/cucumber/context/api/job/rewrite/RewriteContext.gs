package gw.cucumber.context.api.job.rewrite

uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link Rewrite}
 */
@Export
interface RewriteContext extends JobContext {

  /**
   * Starts rewrite job for a given {@link RewriteType}
   * @param rewriteType Type of rewite
   */
  function startRewritePolicy(rewriteType : RewriteType)

  /**
   * Verifies {@link RewriteType} on the rewrite job
   * @param rewriteType Type of rewite
   */
  function verifyTransactionType(rewriteType : RewriteType)

}