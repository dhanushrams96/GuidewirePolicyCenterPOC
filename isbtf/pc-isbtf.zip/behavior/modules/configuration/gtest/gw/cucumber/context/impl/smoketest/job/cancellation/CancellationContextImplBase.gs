package gw.cucumber.context.impl.smoketest.job.cancellation

uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.api.util.DateUtil
uses gw.cucumber.context.api.job.cancellation.CancellationContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.CancellationDataSetup
uses gw.cucumber.setup.NonSubmissionDataSetup
uses gw.cucumber.transformer.CancelOptionTransformer
uses gw.cucumber.transformer.DateTransformer
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses gw.pl.currency.MonetaryAmount
uses pcftest.CancellationWizard

@Export
@SuppressWarnings({"unused"})
abstract class CancellationContextImplBase extends JobContextImplBase implements CancellationContext {

  property get CancellationDataSetup() : CancellationDataSetup {
    return ScenarioInfoProvider.DataSetup as CancellationDataSetup
  }

  override function verifyChangeInCost(changeInCost : String) {
    var cancellationWizard = loginIfLoggedOut(CurrentUser).goToCancellation(CancellationDataSetup.Entity.Cancellation)
    var quoteScreen = cancellationWizard.ViewQuote.click()
    NavigationManager.CurrentPCFElement = quoteScreen.Quote_SummaryDV
    super.verifyChangeInCost(changeInCost)
  }

  override function setEffectiveDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function createCancellationSetup(){
    if(not (ScenarioInfoProvider.DataSetup typeis CancellationDataSetup)) {
      var period = ScenarioInfoProvider.BasedOnPolicyPeriod
      ScenarioInfoProvider.DataSetup = new CancellationDataSetup(CurrentUser, period)
      ScenarioInfoProvider.JobSubType = TC_CANCELLATION
    }
  }

  override function createACancelledPolicy() {
    createCancellationSetup()
    CancellationDataSetup.isBound()
    ScenarioInfoProvider.BasedOnPolicyPeriod = CancellationDataSetup.Entity
  }

  override function createACancelledPolicyForRewrite(){
    createCancellationSetup()
    CancellationDataSetup.Source = CancellationSource.TC_INSURED
    CancellationDataSetup.Reason = ReasonCode.TC_MIDTERMREWRITE
    CancellationDataSetup.EffectiveDate = ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyStartDate.addDays(45)
    createACancelledPolicy()
  }

  override function startPolicyCancellation(cancellationInfoTable : DataTable) {
    var period = ScenarioInfoProvider.BasedOnPolicyPeriod
    ScenarioInfoProvider.DataSetup = new CancellationDataSetup(CurrentUser, period)
    ScenarioInfoProvider.JobSubType = TC_CANCELLATION
    var policySummary = loginAsUser(UserUnderwriterRole).goToPolicySummary(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var startCancellationScreen = policySummary._parent.goToCancellationPage().StartCancellationScreen

    UIHelper.setFieldValues(startCancellationScreen.CancelPolicyDV, new UIFieldsProviderBase(cancellationInfoTable.asMap(String, String)) {

      var source = DisplayKey.get("Web.CancellationWizard.Source")
      var reason = DisplayKey.get("Web.CancellationWizard.Reason")

      override property get RequiredFields() : Set<String> {
        return {source, reason}
      }

      override property get DefaultFields() : Map<String, String> {
        return {}
      }

      override property get PreprocessFields() : List<List<String>> {
        return {{source}, {reason}}
      }
    })

    startCancellationScreen.NewCancellation.click()

    var thisCancellation = NonSubmissionDataSetup.findPolicyPeriodFromBasedOn(period, TC_CANCELLATION)
    CancellationDataSetup.set(thisCancellation)
  }

  override function bindCancellation(cancelOption : String) {
    var cancellationMethod = new CancelOptionTransformer().transform(cancelOption)
    var cancellationWizard = navigateToCancellationWizard()
    var quoteScreen = cancellationWizard.ViewQuote.click()
    if (cancellationMethod == DisplayKey.get('Job.Operation.CancelPolicy')) {
      quoteScreen.clickScheduleCancellation()
    } else if (cancellationMethod == DisplayKey.get('Job.Operation.CancelNow')) {
      quoteScreen.clickCancelNow()
    } else {
      throw new IllegalArgumentException("No valid cancellation method found for " + cancelOption)
    }
    ScenarioInfoProvider.BasedOnPolicyPeriod = CancellationDataSetup.Entity
    waitForAutoRefreshToComplete()
  }

  override function verifyInStatus(status : String) {
    var expectedStatus = new TypelistTransformer<PolicyPeriodStatus>().transform(status)
    var cancellationWizard = navigateToCancellationWizard()
    assertThat(cancellationWizard.CancellationWizardInfoBar.CancellationLabel.Text)
        .as("Cancellation should be " + expectedStatus)
        .contains(expectedStatus.DisplayName)
  }

  override function rescindCancellationJob() {
    var cancellationWizard = navigateToCancellationWizard()
    var quoteScreen = cancellationWizard.ViewQuote.click()
    quoteScreen.clickRescindCancellation()
    waitForAutoRefreshToComplete()
  }

  override function startCancellationWithSourceReasonAndDate(source : String, reason : String, date : String) {
    var period = ScenarioInfoProvider.BasedOnPolicyPeriod
    ScenarioInfoProvider.DataSetup = new CancellationDataSetup(CurrentUser, period)
    ScenarioInfoProvider.JobSubType = TC_CANCELLATION

    var policySummary = loginAsUser(UserUnderwriterRole).goToPolicySummary(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var startCancellationScreen = policySummary._parent.goToCancellationPage().StartCancellationScreen
    this.NavigationManager.CurrentPCFElement = startCancellationScreen

    startCancellationScreen.CancelPolicyDV.Source.setValue(source)
    startCancellationScreen.CancelPolicyDV.Reason.setValue(reason)
    startCancellationScreen.CancelPolicyDV.CancelDate.setDateValue(date.toDate())

    startCancellationScreen.NewCancellation.click()
  }

  private function navigateToCancellationWizard() : CancellationWizard {
    return loginIfLoggedOut(UserUnderwriterRole).goToCancellation(ScenarioInfoProvider.DataSetup.Entity.Cancellation)
  }

  override function addContingency(contingencyInfo : Map<String, String>) : void {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function verifyCostsExists(costsMap : Map<String, MonetaryAmount>) {
    var jobWizard = loginAsUser(CurrentUser).goToCancellation(CancellationDataSetup.Entity.Cancellation)
    NavigationManager.CurrentPCFElement = jobWizard.ViewQuote.click().Quote_SummaryDV
    super.verifyCostsExists(costsMap)
  }

  override function verifyCancellationEffectiveDateIsAfter(days : int) {
    var dateTransformer = new DateTransformer()
    var expectedDate = dateTransformer.transform(DateUtil.addDays(DateUtil.currentDate(), days).ShortFormat)
    var actualDate = dateTransformer.transform(CancellationDataSetup.Entity.Cancellation.LatestPeriod.EditEffectiveDate.ShortFormat)

    assertThat(actualDate)
        .as("The cancellation effective date is ${actualDate}, but expected ${expectedDate}")
        .isEqualTo(expectedDate)
  }
}
