package gw.cucumber.context.impl.smoketest.util

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.smoketest.platform.web.PCFElement

/**
 * Class intended to control navigation flow. There are many scenarios where a subclass just needs to navigate to a custom
 * screen and then it can delegate the rest of the work to to the superclass. For example, when adding a vehicle, the
 * PARewriteContextImpl class will override the addVehicle() method so that it can navigate to the right screen, in this
 * case the Vehicles Screen on the Rewrite wizard. Once the navigation is completed, it can delegate the rest of the work
 * to the superclass. The superclass will use the NavigationManager object to get the current screen and make sure it's
 * the expected screen to continue.
 */
@Export
@ScenarioScoped
class NavigationManager {

  var _currentPCFElement: PCFElement as CurrentPCFElement

  /**
   * Ensures that {@code currentPage} is of type {@code expectedType}. Throws an exception in case it's not.
   * This method is useful when CurrentPCFElement was not used to store the current page. Then the caller needs to provide
   * what the current page is. Example of usage:
   *
   * {@code NavigationManager.ensureOnPage(_proxy.CurrentPage, PAVehicleScreen) }
   *
   * @param currentPage - The page we are trying to verify
   * @param expectedType - The type we expect {@code currentPage} to be
   * @return - Returns {@code currentPage} casted to {@code expectedType}
   */
  reified function ensureOnPage<T extends PCFElement>(currentPage : Object, expectedType : Type<T>) : T {
    if (currentPage typeis T) {
      return currentPage
    }
    throw new IllegalStateException("Invalid Navigation State: Current page is ${(typeof currentPage)} but the expected page is ${expectedType}")
  }

  /**
   * Ensures that {@code _currentPCFElement} is of type {@code expectedType}. Throws an exception in case it's not.
   * This method is useful when using the NavigationManager class to set the CurrentPCFElement and later on get the object
   * back.
   *
   * @param expectedType - The type we expect {@code _currentPCFElement} to be
   * @return - Returns {@code _currentPCFElement} casted to {@code expectedType}
   */
  reified function ensureOnPage<T extends PCFElement>(expectedType: Type<T>): T {
    return ensureOnPage(_currentPCFElement, expectedType)
  }
}