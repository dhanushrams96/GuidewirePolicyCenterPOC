package gw.cucumber.steps.job.cancellation

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory

/**
 * {@link Cancellation} steps agnostic of the line of business
 */
@Export
class CancellationSteps {

  @Inject
  var _contextFactory : ContextFactory

  @When("^I start a Cancellation with the following$")
  function iBeginPolicyCancellation(cancellationInfoTable : DataTable) {
    _contextFactory.getCancellationContext().startPolicyCancellation(cancellationInfoTable)
  }

  @Then("^I bind the cancellation with \"(Schedule Cancellation|Cancel Now)\"$")
  function bindCancellationWith(cancellationMethod: String) {
    _contextFactory.getCancellationContext().bindCancellation(cancellationMethod)
  }

  @Then("^the cancellation status should be \"(Draft|Bound|Canceling|Rescinded)\"$")
  function cancellationStatus(status : String) {
    _contextFactory.getCancellationContext().verifyInStatus(status)
  }

  @When("^I rescind the cancellation")
  function rescindCancellation() {
    _contextFactory.getCancellationContext().rescindCancellationJob()
  }

  @Then("^the cancellation effective date should be today plus \"(\\d+)\" days$")
  function theCancellationEffectiveDateShouldBeTodayPlusDays(days : int) {
    _contextFactory.getCancellationContext().verifyCancellationEffectiveDateIsAfter(days)
  }

  @When("^an \"(Insurer|Insured)\" starts a Cancellation because of \"([^\"]+)\" effective on \"([^\"]+)\"$")
  function startCancellationWithSourceDateAndReason(source : String, reason : String, date : String) {
    _contextFactory.getCancellationContext().startCancellationWithSourceReasonAndDate(source, reason, date)
  }
}