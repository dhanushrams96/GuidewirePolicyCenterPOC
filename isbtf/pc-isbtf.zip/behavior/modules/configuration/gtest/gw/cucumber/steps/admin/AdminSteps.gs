package gw.cucumber.steps.admin

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When

@Export
class AdminSteps {

  @Inject
  var _contextFactory : gw.cucumber.context.api.ContextFactory

  @Given("^I (?:am|switch to) a user with the \"([^\"]+)\" role$")
  function iAmAUserWithRole(userRole : String) {
    _contextFactory.getAdminContext().userRoleSetup(userRole)
  }

  @When("^I create a hold with a new Hold Rule:$")
  function iCreateAHold(holdTable : DataTable) {
    _contextFactory.getAdminContext().createPolicyHold(holdTable.asMap(String, String))
  }

  @When("^I remove the Hold having code \"([^\"]+)\"$")
  function iRemoveAHold(code : String) {
    _contextFactory.getAdminContext().deletePolicyHold(code)
  }

}