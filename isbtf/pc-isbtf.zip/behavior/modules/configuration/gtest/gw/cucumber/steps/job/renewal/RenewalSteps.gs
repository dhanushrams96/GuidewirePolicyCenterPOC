package gw.cucumber.steps.job.renewal

uses com.google.inject.Inject
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.steps.ScenarioInfoProvider
uses gw.cucumber.transformer.TypelistTransformer
uses typekey.Job

/**
 * {@link Renewal} steps agnostic of the line of business
 */
@Export
class RenewalSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _scenarioInfoProvider : ScenarioInfoProvider

  @Then("^I renew the policy$")
  function iRenewThePolicy() {
    _scenarioInfoProvider.JobSubType = TC_RENEWAL
    _contextFactory.getRenewalContext().startRenewal()
  }

  @Then("^the Renewal status should be \"(Draft|Renewing|Quoted|Bound)\"$")
  function theRenewalStatus(status : String) {
    _contextFactory.getRenewalContext().verifyInStatus(status)
  }

  @When("^I edit the Renewal$")
  function iEditTheRenewal() {
    _contextFactory.getRenewalContext().edit()
  }

  @Then("^I quote the Renewal$")
  function iQuoteTheRenewal() {
    _contextFactory.getRenewalContext().quote()
  }

  @Then("^I issue the Renewal with \"(Renew|Issue Now)\"$")
  function iIssueTheRenewal(option : String) {
    _contextFactory.getRenewalContext().issueRenewal(option)
  }
}