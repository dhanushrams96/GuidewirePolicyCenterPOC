package gw.cucumber.context.impl.smoketest.common

uses gw.api.locale.DisplayKey
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.ActivityContext
uses gw.cucumber.util.common.UIHelper
uses pcftest.ActivityDetailWorksheet
uses pcftest.MyActivitiesListViewTile

@Export
class ActivityContextImpl extends CucumberStepBase implements ActivityContext {

  override function createAnActivity(category : String, pattern : String, activityDetails : Map<String, String>) {
    var policyFile = loginAsUser(CurrentUser).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    policyFile.PolicyFileMenuActions.PolicyFileMenuActions_Create.PolicyFileMenuActions_NewActivity.NewActivityMenuItemSet
        ._Entries*.NewActivityMenuItemSet_Category.singleWhere(\cat -> cat.Text.equals(category))._Entries*.item
        .singleWhere(\item -> item.Text.equals(pattern)).click()

    var newActivityScreen = (_proxy.CurrentWorksheet as pcftest.NewActivityWorksheet).NewActivityScreen
    UIHelper.setFieldValues(newActivityScreen, activityDetails)
    newActivityScreen.NewActivityScreen_UpdateButton.click()
   }

  override function verifyActivityExists(activityInfo : List<Map<String, String>>) {
    var policyFile = loginAsUser(CurrentUser).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var activityEntries = policyFile.PolicyFile_Summary.CurrentActivitiesLV._Entries
    activityInfo.each(\activity -> {
      var activityDetails = activityEntries.singleWhere(\elt -> elt.Subject.Text == activity.get(elt.Subject.Label))
          .Subject.click().SmokeTest.CurrentWorksheet as ActivityDetailWorksheet
      UIHelper.assertFieldValues(activityDetails.ActivityDetailScreen.ActivityDetailDV_default, activity)
    })
  }

  override function verifyActivityAssignedToUser(activityDetails : List<Map<String, String>>) {
    var deskTop = loginAsUser(CurrentUser).goToDesktop()
    var activities = deskTop.UnderwriterMySummaryDashboard.MyActivitiesListViewTile.MyActivitiesListViewTile_LV

    activityDetails.each(\detailMap -> {
      verifyActivity(detailMap, activities)
    })
  }

  private function verifyActivity(activityDetail : Map<String, String>, activityEntry : MyActivitiesListViewTile.MyActivitiesListViewTile_LV) {
    var subject = activityDetail.get(DisplayKey.get("Web.DesktopActivitiesLV.Subject"))
    var accountHolder = activityDetail.get(DisplayKey.get("Web.DesktopActivitiesLV.AccountHolder"))
    var dueDate = activityDetail.get(DisplayKey.get("Web.DesktopActivitiesLV.DueDate"))
    var status = activityDetail.get(DisplayKey.get("Web.DesktopActivitiesLV.Status"))

    assertThat(activityEntry._Entries.hasMatch(\entry -> entry.Subject.Text == subject
        && entry.AccountHolder.Text ==accountHolder
        && entry.DueDate.Text == dueDate
        && entry.Status.Text == status))
        .as("No matching activity found ! Expected Subject is " + subject
            + " Expected Account Houlder is " + accountHolder
            + " Expected Due Date is " + dueDate
            + " Expected Status is " + status)
        .isTrue()
  }
}