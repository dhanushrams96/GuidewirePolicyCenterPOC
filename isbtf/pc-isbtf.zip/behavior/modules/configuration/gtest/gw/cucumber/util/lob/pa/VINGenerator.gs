package gw.cucumber.util.lob.pa

uses gw.api.databuilder.UniqueKeyGenerator
uses gw.api.datagen.DatagenUtil

uses java.util.concurrent.atomic.AtomicInteger

@Export
class VINGenerator {

  static var MODELYEAR_CODE_LOOKUP : Map<Integer, String> = modelYearToYearCodeMap()

  /**
   * Generates a unique VIN which is more-or-less realistic
   * @param modelYear the model year of the vehicle
   * @return a VIN as a String
   */
  static function getVin(modelYear : int) : String {
    var where = "1" // 1, 4, or 5 indicates made in the US
    var manufacturer = "HG"
    var portrait = DatagenUtil.getRandomAlphaString(5).toUpperCase()
    var securityCode = "X"
    var year = MODELYEAR_CODE_LOOKUP.get(modelYear)
    var plant = "N"
    var serialNumber = String.format("%06d", {UniqueKeyGenerator.get().nextInteger()}) // 6 digit unique number
    return where + manufacturer + portrait + securityCode + year + plant + serialNumber
  }

  /**
   * Generates a map of years to year-codes
   * 1980 returns "A", 1981 returns "B", etc.
   * @return a Map with years as keys and codes as values
   */
  static function modelYearToYearCodeMap() : Map<Integer, String> {
    var yearDigits = "ABCDEFGHJKLMNPQSTVWXY123456789" // skipped I, O, Q, U, Z
    var yearCounter = new AtomicInteger(1980)
    var lookup = new HashMap<Integer, String>()
    yearDigits.split("").each(\character -> {
      lookup.put(yearCounter.getAndIncrement(), character)
    })
    yearCounter = new AtomicInteger(2010)
    yearDigits.split("").each(\character -> {
      lookup.put(yearCounter.getAndIncrement(), character)
    })
    return lookup
  }

}