package gw.cucumber.context.impl.smoketest.lob.hop

uses cucumber.api.DataTable
uses gw.api.database.Query
uses gw.api.database.Relop
uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.impl.smoketest.job.submission.SubmissionContextImplBase
uses gw.cucumber.setup.HOPSubmissionDataSetup
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper

uses java.math.BigDecimal
uses pcftest.LocationPopup

@Export
abstract class HOPSubmissionContextImplBase extends SubmissionContextImplBase implements HOPContext {

  property get DataSetup() : HOPSubmissionDataSetup {
    return ScenarioInfoProvider.DataSetup as HOPSubmissionDataSetup
  }

  override function quote() {
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    submissionWizard.HOPMode.goToCoveragesStep() // refreshes the coverages
    NavigationManager.CurrentPCFElement = submissionWizard.PolicyReview.click().JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  protected function createLOBSpecificDataSetup() {
    if (ScenarioInfoProvider.DataSetup == null) {
      ScenarioInfoProvider.DataSetup = new HOPSubmissionDataSetup(CurrentUser)
    }
  }

  function createSubmissionSetup() {
    ScenarioInfoProvider.JobSubType = TC_SUBMISSION
    var hopSubmissionDataSetup = new HOPSubmissionDataSetup(CurrentUser)
    if (ScenarioInfoProvider.AccountDataSetup != null) {
      hopSubmissionDataSetup.AccountDataSetup = ScenarioInfoProvider.AccountDataSetup
    }
    ScenarioInfoProvider.DataSetup = hopSubmissionDataSetup
  }

  override function createABoundPolicy() {
    createABoundPolicy(false)
  }

  override function createABoundPolicy(skipIssuance : boolean) {
    if(DataSetup == null){
      ScenarioInfoProvider.DataSetup = new HOPSubmissionDataSetup(UserUnderwriterRole)
    }

    DataSetup.isBound(skipIssuance)
    ScenarioInfoProvider.BasedOnPolicyPeriod = DataSetup.Entity
  }

  override function createABoundPolicyFor(baseState : String) {
    createSubmissionSetup()
    DataSetup.BaseState = new TypelistTransformer<State>().transform(baseState)
    createABoundPolicy(false)
  }

  override function createABoundPolicyWithPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String){
    createSubmissionSetup()
    setPolicyTypeAndCoverageForm(policyTypeText, coverageFromText)
    createABoundPolicy(false)
  }

  function setPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String) {
    var policyType = new TypelistTransformer<CoveragePartType>().transform(policyTypeText)
    var coverageFrom = new TypelistTransformer<HOPCoverageForm>().transform(coverageFromText)
    DataSetup.createDwelling(policyType, coverageFrom)
  }

  function setWhoOccupiesThisDwelling(occupier:String){
    DataSetup.setAnswerForPreQualPropVacant(false)
    DataSetup.setAnswerForPreQualOccupant(occupier)
  }

  override function addAdditionalInterestsOfNewCompanyType(addtionalInterestInfo : DataTable) {
    var additionalInfo = addtionalInterestInfo.asMap(String, String)
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()
    dwellingStep.goToAdditionalInterestCardTab()

    var newCompanyAdditionalInterestsPopup = dwellingStep.goToNewCompanyPopupOnAdditionalInterests()
    var contactDetailScreen = newCompanyAdditionalInterestsPopup.ContactDetailScreen

    UIHelper.setFieldValues(contactDetailScreen, new UIFieldsProviderBase(additionalInfo) {

      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.Policy.AdditionalInterest.Type"),
            DisplayKey.get("Web.ContactDetail.Name"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.Address1"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.City"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.State"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.ZIP"),
            DisplayKey.get("Web.AddressDetail.AddressType")}
      }

      override property get DefaultFields() : Map<String, String> {
        return {
        }
      }
    })

    contactDetailScreen.Update.click()

    var row = dwellingStep.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingAdditionalInterestDetailsDV.AdditionalInterestLV._Entries.last()

    row.EffDate.setDateValue(additionalInfo.get("Effective Date").toDate())
    row.ExpDate.setDateValue(additionalInfo.get("Expiration Date").toDate())
    row.Description.setValue(additionalInfo.get("Description of Interest"))

    dwellingStep.getJobWizardToolbarButtonSet_Submission().Draft.click()
    waitForAutoRefreshToComplete()

    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String){
    var contacts = Query.make(Contact).compare(Contact#Name, Relop.Equals, companyName).select()

    assertThat(contacts.toList().size())
    .as("Only one company contact of name ${companyName} should be saved")
    .isEqualTo(1)
  }

  override function verifyScheduledItemPremiumExist() {
    var actualPremiumOnPeriod = ScenarioInfoProvider.DataSetup.Entity.AllCosts.firstWhere(\cost -> cost.DisplayName.contains("Scheduled Personal Property")).ActualAmount
    assertThat(not actualPremiumOnPeriod.Amount.IsZero)
        .as("Scheduled Personal Property premium is ${actualPremiumOnPeriod} but should have been greater than ${BigDecimal.ZERO}")
  }

  override function addNewPolicyLocationWithoutSave(newPolicyLocation : DataTable) {
    var newLocation = newPolicyLocation.asMap(String, String)
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()

    var newPolicyLocationPopup = dwellingStep.clickOnNewDwellingLocation()
    var locationScreen = newPolicyLocationPopup.LocationScreen

    locationScreen.fillLocationInfo(newLocation)
    NavigationManager.CurrentPCFElement = newPolicyLocationPopup
  }

  override function verifyTerritoryCodeOnPopup(code : String){
    var newPolicylocationPopup = NavigationManager.CurrentPCFElement

    if(not (newPolicylocationPopup typeis LocationPopup)){
      throw new UnsupportedOperationException("Not at New Policy Location Popup")
    }

    var territoryCodeActual = (newPolicylocationPopup as LocationPopup).LocationScreen.TerritoryCode.Value

    assertThat(territoryCodeActual)
        .as("Territory code doesn't match, expected <${code}}> but actual <${territoryCodeActual}>")
        .isEqualTo(code)
  }

  override function causeUWIssue(blockingPoint : UWIssueBlockingPoint) {
    if (blockingPoint == TC_BLOCKSBIND) {
      DataSetup.withDwellingWiringType(WiringType.TC_KNOBANDTUBE)
    }
  }

  override function causeNonCopperWiringUWIssue() {
    DataSetup.withDwellingWiringType(WiringType.TC_KNOBANDTUBE)
  }

  protected function gotoHOPCoveragesScreen() : pcftest.HOPCoveragesScreen {
    return loginIfLoggedOut(CurrentUser).goToSubmission(DataSetup.Entity).HOPMode.goToHOPCoveragesScreen()
  }
}

