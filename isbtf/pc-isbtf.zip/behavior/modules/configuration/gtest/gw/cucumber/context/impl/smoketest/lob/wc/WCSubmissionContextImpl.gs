package gw.cucumber.context.impl.smoketest.lob.wc

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.wc.WCContext
uses gw.cucumber.context.impl.smoketest.job.submission.SubmissionContextImplBase
uses gw.cucumber.setup.WCSubmissionDataSetup

@SuppressWarnings("unused")
@Export
class WCSubmissionContextImpl extends SubmissionContextImplBase implements WCContext {

  @Inject delegate _lineContextDelegate represents WCContext

  property get DataSetup() : WCSubmissionDataSetup {
    return ScenarioInfoProvider.DataSetup as WCSubmissionDataSetup
  }

  override function createSubmissionSetup() {
    ScenarioInfoProvider.JobSubType = TC_SUBMISSION
    var wcSubmissionDataSetup = new WCSubmissionDataSetup(CurrentUser)
    if (ScenarioInfoProvider.AccountDataSetup != null) {
      wcSubmissionDataSetup.AccountDataSetup = ScenarioInfoProvider.AccountDataSetup
    }
    ScenarioInfoProvider.DataSetup = wcSubmissionDataSetup
    ScenarioInfoProvider.JobNumber = wcSubmissionDataSetup.Entity.Job.JobNumber
  }

  override function addCoveredEmployees(coveredEmployeeInfoMaps : List<Map<String, String>>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var wcSubmissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(period).WCMode
    wcSubmissionWizard.goToWCCoverageStep()
    var wcClassesInputSet = wcSubmissionWizard.WCCoverageStep.WorkersCompCoverageConfigScreen.WorkersCompCoverageCV.WorkersCompClassesInputSet
    NavigationManager.CurrentPCFElement = wcClassesInputSet
    _lineContextDelegate.addCoveredEmployees(coveredEmployeeInfoMaps)
  }

  override function setCoveredEmployees(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyCoveredEmployees(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function verifySplitPeriodPremiums(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function verifySplitPeriodRates(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function addExperienceModifiers(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function verifyRates(data : List<Map<String, String>>) {
    logout()
    var changeWizardQuoteScreen = loginAndGoToQuoteStep()
    NavigationManager.CurrentPCFElement = changeWizardQuoteScreen.RatingCumulDetailsPanelSet_WorkersCompLine
    _lineContextDelegate.verifyRates(data)
  }

  function overrideClassBaseRate(data : List<Map<String, String>>) {
    logout()
    var changeWizardQuoteScreen = loginAndGoToQuoteStep()
    NavigationManager.CurrentPCFElement = changeWizardQuoteScreen.RatingCumulDetailsPanelSet_WorkersCompLine
    _lineContextDelegate.overrideClassBaseRate(data)
  }

  override function createABoundPolicy() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function createABoundPolicy(skipValidation: boolean) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  private function loginAndGoToQuoteStep() : pcftest.SubmissionWizard_QuoteScreen {
    var wcSubmissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber).WCMode
    var quoteScreen = wcSubmissionWizard.goToQuoteStep()
    return quoteScreen
  }

  protected override function createLOBSpecificDataSetup() {
    if (ScenarioInfoProvider.DataSetup == null) {
      ScenarioInfoProvider.DataSetup = new WCSubmissionDataSetup(CurrentUser)
    }
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    assertThat(period.UWCompany.DisplayName).isEqualTo(uwCompany)
  }

  override function createABoundPolicyFor(baseState : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}