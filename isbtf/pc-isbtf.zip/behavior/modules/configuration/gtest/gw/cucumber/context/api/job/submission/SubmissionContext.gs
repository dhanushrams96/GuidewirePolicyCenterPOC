package gw.cucumber.context.api.job.submission

uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link Submission}
 */
@SuppressWarnings("Method2Property")
@Export
interface SubmissionContext extends JobContext {

  /**
   * Create a Submission Data Setup
   */
  function createSubmissionSetup()

  /**
   * Start creating a new submission from an Account
   */
  function createNewSubmission()

  /**
   * Set the {@link QuoteType} on submission (Full Application vs Quick Quote)
   * @param quoteType Type of quote (Full Application or Quick Quote)
   */
  function setQuoteType(quoteType: QuoteType)

  /**
   * Set prequalification responses for submission
   */
  function selectPreQualification(givenFields : List<Map<String, String>>)

  /**
   * Enter policy information for submission
   */
  function enterPolicyInfo(givenFields : Map<String, String>)

  /**
   * Select Product Offering information
   */
  function selectProductOffering(productOfferingInfo : Map<String, String>)

  /**
   * Select Product (e.g. PersonalAuto, HOPHomeOwners, WorkersCompensation)
   */
  function selectProduct()

  /**
   * Select payment plan
   * @param paymentPlan the payment plan to be used for this policy (e.g. 6 Payments Demo)
   */
  function selectPaymentPlan(paymentPlan : String)

  /**
   * Verify that the specified reason code was used for a declined/not-taken submission
   * @param reasonCode the reason for the closing the submission
   */
  function verifySelectedReasonCode(reasonCode : String)

  /**
   * Sets base state on the submission setup
   * @param baseState Base state for the submission
   */
  function setSubmissionBaseState(baseState : String)

   /**
   * Setup policy to have specified effective date
    * @param effectiveDate Effective date of the policy
   */
  function setupPolicyEffectiveDate(effectiveDate : Date)

  /**
   *  Creates a bound policy by quoting, binding, and issuing submission
   */
  function createABoundPolicy()

  /**
   * Creates a bound policy with spcific base state
   * @param baseState base state for the policy
   */
  function createABoundPolicyFor(baseState : String)

  /**
   * Creates a bound policy by quoting, binding, and OPTIONALLY issuing submission
   *
   * @param skipIssuance - if true, the policy will have to be issued by Issuance job
   */
  function createABoundPolicy(skipIssuance: boolean)

  /**
   * Go to policy review of the submission
   */
  function goToReviewPolicy()
}