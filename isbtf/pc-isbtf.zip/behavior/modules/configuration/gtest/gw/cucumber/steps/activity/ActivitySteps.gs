package gw.cucumber.steps.activity

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory

@Export
class ActivitySteps {

  @Inject
  var _contextFactory : ContextFactory

  @When("^I create a \"([^\"]+)\", \"([^\"]+)\" activity with the following data:$")
  function iStartAnActivity(category : String, pattern : String, details : DataTable) {
    _contextFactory.getActivityContext().createAnActivity(category, pattern, details.asMap(String, String))
  }

  @Then("^the following (?:activity|activities) should exist:$")
  function activityExists(dataTable : DataTable) {
    _contextFactory.getActivityContext().verifyActivityExists(dataTable.asMaps(String, String))
  }

  @Then("^I should be assigned the following activities:$")
  function iShouldBeAssignedTheActivity(activityTable : DataTable) {
    _contextFactory.getActivityContext().verifyActivityAssignedToUser(activityTable.asMaps(String, String))
  }

}