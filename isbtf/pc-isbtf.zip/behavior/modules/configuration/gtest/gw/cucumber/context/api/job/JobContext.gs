package gw.cucumber.context.api.job

uses cucumber.api.DataTable
uses gw.pl.currency.MonetaryAmount

uses java.lang.Deprecated

/**
 * Methods which are specific to {@link Job} subtypes, for example Submission, PolicyChange, etc.
 * Not all jobs will implement every method. Cancellation, for example, will not implement the issue method.
 */
@SuppressWarnings("Method2Property")
@Export
interface JobContext {

  /**
   * Generates a quote
   */
  function quote()

  /**
   * Bind the job
   */
  function bind()

  /**
   * Issue the policy
   */
  function issue()

  /**
   * Edit the policy (and thereby invalidating the current quote)
   */
  function edit()

  /**
   * Set the effective date of the policy with the given date.
   * @param effectiveDate the effective date of the policy
   */
  function setEffectiveDate(effectiveDate : Date)

  /**
   * Setup the job to have specified expiration date
   * @param expirationDate the expiration date of the job
   */
  function setExpirationDate(expirationDate : Date)

  /**
   * Verifies the policy period builder has the expected {@link PolicyPeriodStatus}.
   *
   * @param status - The expected status of the job.
   */
  function setJobStatus(status : PolicyPeriodStatus)

  /**
   * Deperecated use setJobStatus instead
   * Verifies the policy period builder has the expected {@link PolicyPeriodStatus}. If the expected status is QUOTED,
   * the data setup class will request a quote when creating the entity.
   *
   * @param status - The expected status of the job.
   */
  @Deprecated
  function setJobStatusQuoted(status : PolicyPeriodStatus)

  /**
   * Verify the expected job status of the period. Assertion will fail if the actual status does not agree.
   * @param status the expected {@link PolicyPeriodStatus}
   */
  function verifyInStatus(status : String)

  /**
   * Verify the expected job status of the period. Assertion will fail if the actual status does not agree.
   */
  function verifyPolicyIssued()

  /**
   * Stores the current job so that if a future step needs to access the job, it can be retrieved.
   * @param jobName - An ID used to identify the current job
   */
  function storeJobAs(jobName: String)

  /**
   * Retrieves the job with the given job name
   * @param jobName - An ID used to identify the current job
   */
  function retrieveJob(jobName : String): PolicyPeriod

  /**
   * Withdraws the quote with the given close option and reason
   * @param closeOption closing options as not-taken, decline or withdraw
   * @param closeReason reason for closing the transaction
   */
  function withdraw(closeOption : String, closeReason : String)

  /**
   * Stores the given data table with the given tableName as the key
   * @param tableName - The key used to identify the data table
   * @param table - The data table to be stored
   */
  function storeDataTable(tableName : String, table : DataTable)

  /**
   * Set the {@link TermType} of the {@link PolicyPeriod}
   * @param termType
   */
  function setTermType(termType : TermType)

  /**
   * Approves UW issues on a period as a user with Underwriter role
   * @param description - A short approval description
   */
  function approveUWIssuesAsUnderwriter(description : String)

  /**
   * Approves UW issues on a period as a user with Underwriter role
   * @param description - A short approval description
   * @param validUntil - The approval of uw issue is valid until
   */
  function approveUWIssuesAsUnderwriter(description : String, validUntil : String)

  /**
   * Verify the change in cost. Assertion will fail if the actual change in cost does not agree.
   * @param changeInCost the expected change in cost
   */
  function verifyChangeInCost(changeInCost : String)

  /**
   * Select the provided {@link FinalAuditOption} if a selection can be made. If the selection is not editable due to
   * other selection choices, this method will do nothing.
   * @param option the {@link FinalAuditOption} that will be selected if a selection can be made
   */
  function selectFinalAuditOption(option : FinalAuditOption)

  /**
   * Adds a contingency to a policy period with given contingency information
   */
  function addContingency(contingencyInfo : Map<String, String>)

  /**
   * Verifies a contingency with given contingency information exists on a policy
   */
  function verifyContingencyExists(contingenciesInfoMap : Map<String, String>)

  /**
   * Verifies the {@link ContingencyStatus} of the contingency. Note: This method makes an assumption
   * that there is a single contingecy on the policy with the given status
   */
  function verifyContingencyStatus(contingencyStatus : ContingencyStatus)

  /**
   * Resolves a contingency with the given contingency information
   */
  function resolveContingency(contingencyMap : Map<String, String>)

  /**
   * Select the provided {@link PaymentMethod} for this job subtype
   * @param paymentMethod
   */
  function selectPaymentMethod(paymentMethod : PaymentMethod)

  /**
   * Select the provided Reporting Plan for this job subtype
   * @param reportingPlan
   */
  function selectReportingPlan(reportingPlan : String)
  /**
   * Verify if Bind Blocking Underwriting Issues exist on the period
   */
  function verifyUWBindBlockingIssues(shouldExist : boolean)

  /**
   * Verify if approved underwriting issues exist on the period
   */
  function verifyUWApprovedIssues(shouldExist : boolean)

  /**
   * Verifies if the given list of UW issues (blocking bind and approved) exist on the period.
   * @param issues the Underwriting Issues expected to exist
   */
  function verifyUWBindBlockingAndApprovedIssuesExist(issues : List<Map<String, String>>)

  /**
   * Creates an Underwriting Issue on the period for testing purposes
   */
  function causeUWIssue(blockingPoint : UWIssueBlockingPoint)

  /**
   * Approve {@link UWIssue}s on the period
   */
  function approveUWIssues()

  /**
   * Verify total cost. Assertion will fail if the actual cost does not agree with the expected cost
   * @param expectedCost the expected cost
   */
  function verifyTotalCost(expectedCost : String)

  /**
   * Verify total cost exist.
   */
  function verifyTotalCostExist()

  /**
   * Verify that the provided costs exists on the period.
   * @param costsMap map of a cost description and an amount.
   *
   * For example,
   * <pre>[[Total Premium","384.00 USD"], ["Taxes & Surcharges","28.00 USD"]] </pre>
   */
  function verifyCostsExists(costsMap : Map<String, MonetaryAmount>)

  /**
   * Select side by side version
   * @param versionNumber the version to select
   */
  function selectSideBySideVersion(versionNumber : int)

  /**
   * Select a version with the given version number
   * @param versionNumber the version to select
   */
  function selectVersion(versionNumber : int)

  /**
   * Start side by side quoting
   */
  function startSideBySideQuoting()

  /**
   * Initiate new multi-version on the quoted period
   */
  function initiateANewVersionViaMultiversion()

  /**
   * Verify that there are provided number of versions on the period
   * @param numberOfVersions expected number of versions on the period
   */
  function verifyNumberOfVersions(numberOfVersions : int)

  /**
   * Verify that the specified multiple quote versions exist
   * @param versions versions of the period
   */
  function verifyMultiQuoteVersions(versions : List<List<String>>)

  /**
   * Add a new additional named insured
   * @param contactInfo map containing contact info of additional named insured to be added
   */
  function addAdditionalNamedInsured(contactInfo : Map<String, String>)

  /**
   * Verify that the additional named insured exists on the period.
   * @param contactInfo map containing contact info of additional named insured to be added
   */
  function verifyAdditionalNamedInsuredExists(contactInfo : Map<String, String>)

  /**
   * Verifies quote is failed because of validation error
   *
   * @param message - the message that failed the quote
   */
  function verifyQuoteFailedWith(errorMessage : String)

  /**
   * Adds an Additional interest of Company type
   * @param contactInfo
   */
  function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable)

  /**
   * Verifies if the Company is saved in the product
   * @param companyName
   */
  function verifyAdditionalInterestsOfNewCompanyType(companyName : String)

  /**
   * Verifies error messages displayed
   *
   * @param messages - the messages to verify
   */
  function verifyErrorMessagesDisplayed(messages : DataTable)

  /**
   * Verify existence of forms
   * @expectedForms Codes of expected forms
   */
  function verifyForms(expectedForms : DataTable)

  /**
   * Verifies transaction can be saved successfully
   */
  function verifyTransactionSavedSuccessfully()

  /**
   * Verifies UW Company
   */
  function verifyUWCompany(uwCompany : String)
}