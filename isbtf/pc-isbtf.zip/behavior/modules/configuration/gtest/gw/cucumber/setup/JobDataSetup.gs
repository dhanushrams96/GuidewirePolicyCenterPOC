package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.JobBuilder
uses gw.api.database.Query
uses gw.pl.persistence.core.Bundle
uses typekey.Job

@Export
@ScenarioScoped
class JobDataSetup<B extends JobBuilder<B>> extends DataSetup<PolicyPeriod, B> {

  protected var _isQuoted : boolean
  protected var _isBound : boolean
  protected var _bindOnly : boolean
  protected var _isUWIssuesApproved : boolean
  private var _underwriter : String

  construct() {
    super()
  }

  construct(username : String) {
    super(username)
  }

  /**
   * Sets the PolicyPeriod entity directly.
   * Use this setter method if the PolicyPeriod is not created from a builder, for example if the scenario begins with an
   * account and the job is started from the UI.
   * @param period the entity to set on this JobDataSetup
   */
  function set(period : PolicyPeriod) { _entity = period }

  function refreshEntity() {
    var publicID = _entity.PublicID
    _entity = Query.make(PolicyPeriod)
        .compare(PolicyPeriod#PublicID, Equals, publicID).select().single()
  }

  override function createEntity(bundle : Bundle) : PolicyPeriod {
    finishBuilder()
    var period = Builder.createAndCommit()
    if (period.Status >= PolicyPeriodStatus.TC_BOUND) { // we might end up with a bound period if builders were used directly
      return period
    }
    if (_isQuoted || _isBound) {
      period = bundle.add(period)
      period.JobProcess.requestQuote()
      bundle.commit()
    }
    if (_isUWIssuesApproved) { // TODO: the underwriter should approve this
      period = bundle.add(period)
      period.approveUnderwritingIssuesBlockingBind()
      bundle.commit()
    }
    if (_isBound) {
      period = bundle.add(period)
      if (period.Job.Subtype == TC_SUBMISSION && _bindOnly) {
        period.JobProcess.bindOnly(false)
      } else if (period.Job.Subtype == Job.TC_CANCELLATION) {
        period.CancellationProcess.cancelImmediately()
      } else {
        period.JobProcess.bind()
      }
      bundle.commit()
    }
    return period
  }

  /**
   * Resolve any incomplete builders
   * @return the builder
   */
  function finishBuilder() : B {
    return provideDefaults()
  }

  /**
   * If not already provided, provide any defaults that are required
   * @return the builder
   */

  function provideDefaults() : B {
    return Builder
  }
  /**
   * Causes the policy period entity to be quoted before the policy period entity is returned
   * Sets the _isQuoted variable to true for the Builder
   * If _isQuoted is true, a quote will be performed on the policy period entity before it is returned by
   * the get Entity property
   * @return the builder
   */
  function isQuoted() : B {
    _isQuoted = true
    return Builder
  }

  /**
   * Causes the policy period entity to be quoted and issued before the policy period entity is returned
   * Sets the _isQuoted and the _isBound variables to true for the Builder
   * If _isBound is true, a quote and a bind will be performed on the policy period entity before it is returned
   * @return the builder
   */
  function isBound() : B {
    _isBound = true
    return Builder
  }

  /**
   * Causes the underwriter to approve UW issues on the policy period before the policy period entity is returned
   * Sets the _isUWIssuesApproved variable to true and sets the _underwriter variable.
   * If _isUWIssuesApproved is true, the underwriter will approve all UW issues that exist on the policy period
   * entity before it is returned by the get Entity property
   * @param underwriter the user who will approve the UW issues
   * @return the builder
   */
  function doApproveUWIssues(underwriter : String) : B {
    _isUWIssuesApproved = true
    _underwriter = underwriter
    return Builder
  }

}