package gw.cucumber.util.lob.hop

uses gw.api.locale.DisplayKey
uses gw.cucumber.util.common.UIFieldsProviderBase

@Export
class ConstructionUIFieldsProvider extends UIFieldsProviderBase {

  construct(fields : Map<String, String>) {
    super(fields)
  }

  override property get RequiredFields() : Set<String> {
    return {}
  }

  override property get DefaultFields() : Map<String, String> {
    return {
        DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.YearBuilt") -> "2000",
        DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.ConstructionType") -> "Concrete"
    }
  }
}