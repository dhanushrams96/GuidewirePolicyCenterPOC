package gw.cucumber.context.api.job.reinstatement

uses gw.cucumber.context.api.job.JobContext

@Export
interface ReinstatementContext extends JobContext {

  /**
   * Creates a reinstatement
   */
  function reinstatePolicy()

  /**
   * Initiates a {@link Reinstatement} job in draft status
   */
  function createReinstatementSetup()
}