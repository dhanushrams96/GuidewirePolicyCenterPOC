package gw.cucumber.util.common

uses gw.api.system.PCLoggerCategory
uses gw.smoketest.platform.web.CheckboxValueElement
uses gw.smoketest.platform.web.ClickableActionElement
uses gw.smoketest.platform.web.PCFElement
uses gw.smoketest.platform.web.ValueElement
uses pcftest.CoverageInputSet

/**
 * Utility class providing reflection helper methods for setting up product model
 * related data in cucumber tests. Product model related data such as
 * adding/removing/updating/reading clauses from modal CoverageInputSets.
 */

@Export
class ProductModelReflectUtil {

  /**
   * Adds a coverage by looking for the correct modal CoverageInputSet on the given root PCFElement
   * and selects the checkbox to indicate TRUE boolean value.
   * @param coverage the coverage to add on the given root element
   * @param root Root element for this coverage to be set on
   */
  static function addCoverage(coverage : String, root : PCFElement) {
    var checkBoxValueElement = getCheckBoxValueElementForCoverage(coverage, root)
    if (checkBoxValueElement != null) {
      if (checkBoxValueElement.BoolValue) {
        return
      } else if (checkBoxValueElement.Enabled) {
        checkBoxValueElement.setBoolValue(true)
        return
      }
    }
    throw new IllegalStateException("Couldn't add coverage: ${coverage}")
  }

  /**
   * Add and set the coverage and coverageTerms with values on this CoverageInputSet.
   * @param coverage the coverage to add on this root element
   * @param covTerms covterms of the added coverage
   * @param root root element for this coverage/covTerms to be set on
   */
  static function addAndSetCoverage(coverage : String, covTerms : Map<String, String>, root : PCFElement) {
    // select the checkbox to add the coverage
    addCoverage(coverage, root)

    // Set the cov term values
    setCovTerms(coverage, covTerms, root)
  }

  /**
   * Returns true if the coverage exists on the PCF element, false otherwise.
   * @param coverage the coverage to look for on this root element
   * @param root root element for this coverage
   * @param editable true if the root element is in Edit mode
   * @return true if the coverage is successfully found on the PCF element, false otherwise
   */
  static function hasCoverage(coverage : String, root : PCFElement, editable : boolean) : boolean {
    var hasCoverage = false
    if (editable) { // checkboxes for the coverages are available only on Edit mode of the page
      var checkBoxValueElement = getCheckBoxValueElementForCoverage(coverage, root)
      if (checkBoxValueElement != null) {
        hasCoverage = checkBoxValueElement.BoolValue
      }
    } else { // check for coverages by label for their presence when the page is in ReadOnly mode.
      var covInputSets = getAllCoverageInputSetsByLabel(coverage, root)
      if (!covInputSets.Empty) {
        hasCoverage = true
      }
    }
    return hasCoverage
  }

  /**
   * Returns true if the coverage and coverageTerms exists on the PCF element, false otherwise.
   * @param coverage the coverage to look for on this root element
   * @param expectedCovTerms the coverageTerms to look for on this root element
   * @param root root element for this coverage/coverageTerms
   * @param editable true if the root element is in Edit mode
   * @return true if the coverage and coverageTerms are successfully found on the PCF element, false otherwise
   */
  static function hasCoverageWithCovTermValues(coverage : String, expectedCovTerms : Map<String, String>, root : PCFElement, editable : boolean) : boolean {
    if (hasCoverage(coverage, root, editable)) {
      var actualCovTerms = getCoverageTermValues(coverage, root)
          .filterByKeys(\key -> expectedCovTerms.containsKey(key))

      if (!actualCovTerms.Empty) {
        for (covTerm in actualCovTerms.keySet()) {
          if (!expectedCovTerms.get(covTerm).equalsIgnoreCase(actualCovTerms.get(covTerm))) {
            return false
          }
        }
        return true
      }
    }
    return false
  }

  /**
   * Set the coverageTerms with the value provided in a Map on the given coverage of the given root element
   * @param coverage the coverage on the given root element
   * @param covTerms the covTerms to set values on the given root element
   * @param root the root element which has the coverage/covTerms
   */
  static function setCovTerms(coverage : String, covTerms : Map<String, String>, root : PCFElement) {
    if (root typeis ClickableActionElement) {
      root.click()
    }
    var covInputSets = getAllCoverageInputSetsByLabelWithCheck(coverage, root)

    covTerms = covTerms.copy()
    PCFReflectUtil.setFieldValues(covTerms, covInputSets)
    if (!covTerms.Empty) {
      throw new IllegalStateException("Couldn't set coverage terms: ${covTerms}")
    }
  }

  /**
   * Removes the coverage by unselecting the checkbox on coverageInputSet
   * @param coverage the given coverage to remove from the modal CoverageInputSet (PCFElement)
   * @param root the root element that has the coverage
   */
  static function removeCoverage(coverage : String, root : PCFElement) {
    var checkBoxValueElement = getCheckBoxValueElementForCoverage(coverage, root)
    if (checkBoxValueElement != null) {
      if(checkBoxValueElement.BoolValue ) {
        checkBoxValueElement.setBoolValue(false)
        return
      } else {
        checkBoxValueElement.setBoolValue(false)
        return
      }
    }
    throw new IllegalStateException("Couldn't remove coverage: ${coverage}")
  }

  // --------------------------------- private helpers

  private static function getAllCoverageInputSetsByLabelWithCheck(coverage : String, root : PCFElement) : List<CoverageInputSet> {
    var coverageInputSets = getAllCoverageInputSetsByLabel(coverage, root)
    if (coverageInputSets.Empty) {
      throw new IllegalStateException("Couldn't find coverage \"${coverage}\" on root element: ${root}")
    }
    return coverageInputSets
  }

  private static function getAllCoverageInputSetsByLabel(coverage : String, root : PCFElement) : List<CoverageInputSet> {
    var coverageInputSets : List<CoverageInputSet> = {}
    addCoverageInputSetsRecursivelyByLabel(coverage, root, coverageInputSets)
    return coverageInputSets
  }

  private static function addCoverageInputSetsRecursivelyByLabel(coverage : String, element : PCFElement, coverageInputSets : List<CoverageInputSet>) {
    // Base case: return if the correct coverage
    if (element typeis CoverageInputSet) {
      try {
        var labelProp = (typeof element).TypeInfo.getProperty("CovPatternDisplayName")
        if (labelProp == null || labelProp.FeatureType != ValueElement) {
          log("The CoverageInputSet ${element} has no CovPatternDisplayName property.")
        } else {
          var label = labelProp.Accessor.getValue(element) as ValueElement
          var labelText = label.Text
          if (labelText == coverage) {
            coverageInputSets.add(element)
          }
        }
      } catch (e) {
        log("Failed to resolve element ${element} ")
      }
      return
    }

    // Traverse down the pcf element hierarchy searching for additional coverage input sets
    var elementType = typeof element
    for (prop in elementType.TypeInfo.Properties) {
      var propType = prop.FeatureType
      if (PCFReflectUtil.isPCFElement(propType)) {
        // The property returns a pcf element; traverse the element itself
        var childElement = prop.Accessor.getValue(element) as PCFElement
        addCoverageInputSetsRecursivelyByLabel(coverage, childElement, coverageInputSets)
      } else if (PCFReflectUtil.isArrayOfPCFElements(propType)) {
        // The property returns an array of pcf elements; traverse each element in the array
        var array = prop.Accessor.getValue(element) as PCFElement[]
        for (childElement in array) {
          addCoverageInputSetsRecursivelyByLabel(coverage, childElement, coverageInputSets)
        }
      } else if (PCFReflectUtil.isIterableOfPCFElements(propType)) {
        // The property returns an iterable of pcf elements; traverse each element in the iterable
        var iterable = prop.Accessor.getValue(element) as Iterable<PCFElement>
        for (childElement in iterable) {
          addCoverageInputSetsRecursivelyByLabel(coverage, childElement, coverageInputSets)
        }
      }
    }
  }

  private static function getCheckBoxValueElementForCoverage(coverage : String, root : PCFElement) : CheckboxValueElement {
    var covInputSets = getAllCoverageInputSetsByLabelWithCheck(coverage, root)
    var checkboxValueElement : CheckboxValueElement = null

    for (covInputSet in covInputSets) {
      var groupProp = (typeof covInputSet).TypeInfo.getProperty("CovPatternInputGroup")
      if (groupProp == null || !PCFReflectUtil.isPCFElement(groupProp.FeatureType)) {
        log("The CoverageInputSet ${covInputSet} has no CovPatternInputGroup property.")
      } else {
        var covPatternInputGroup = groupProp.Accessor.getValue(covInputSet) as PCFElement
        var checkboxProp = (typeof covPatternInputGroup).TypeInfo.getProperty("_checkbox")
        if (checkboxProp == null || checkboxProp.FeatureType != CheckboxValueElement) {
          log("The CovPatternInputGroup does not have a _checkbox property for CoverageInputSet: ${covInputSet}")
        } else {
          checkboxValueElement = checkboxProp.Accessor.getValue(covPatternInputGroup) as CheckboxValueElement
        }
      }
    }
    return checkboxValueElement
  }

  /**
   * Returns a map of cov terms and their covTerm values
   */
  static function getCoverageTermValues(coverage : String, root : PCFElement) : Map<String, String> {
    var covInputSets = getAllCoverageInputSetsByLabelWithCheck(coverage, root)
    return PCFReflectUtil.getFieldValues(covInputSets)
  }

  private static function log(message : String) {
    PCLoggerCategory.TEST.warn(message)
  }

}