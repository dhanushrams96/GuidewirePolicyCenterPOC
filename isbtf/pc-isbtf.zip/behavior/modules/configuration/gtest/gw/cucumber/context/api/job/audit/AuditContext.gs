package gw.cucumber.context.api.job.audit

uses gw.cucumber.context.api.job.JobContext

@Export
interface AuditContext extends JobContext {

  /**
   * Schedule an audit to {@code scheduledDate}
   * @param scheduledDate - the date in which the audit will be scheduled to
   */
  function scheduleAudit(scheduledDate: Date)

  /**
   * Enter audit information for the report that starts on {@code reportStartingDate}
   * @param reportStartingDate - report starting date
   * @param auditInfo - Audit information
   */
  function enterAuditInfoForReportStartingOn(reportStartingDate: Date, auditInfo: Map<String, String>)

  /**
   * Enter audit summary information
   * @param auditSummaryInfo - the audit into
   */
  function enterAuditSummaryInfo(auditSummaryInfo: Map<String, String>)

  /**
   * Enter audit details
   * @param auditDetails - the audit details
   */
  function enterAuditDetails(auditDetails: List<Map<String, String>>)

  /**
   * Calculate premiums
   */
  function calculatePremiums()

  /**
   * Submit the final/premium audit
   */
  function submitPremiumOrFinalAudit()

  /**
   * Verify that the audit with the audit details of {@auditDetails} exists
   */
  function verifyAuditScheduleExists(auditDetails: List<Map<String, String>>)

}