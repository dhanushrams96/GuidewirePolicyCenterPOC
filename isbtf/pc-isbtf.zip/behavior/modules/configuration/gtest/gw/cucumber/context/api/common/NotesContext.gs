package gw.cucumber.context.api.common

/**
 * Methods specific to Notes
 */

@Export
interface NotesContext {

  /**
   * Creates a note in the UI
   *
   * "Topics" and "Text" fields are required
   *
   * @param givenFields a Map of key and value pairs representing the fields and values.
   */
  function createNote(givenFields : Map<String,String>)

  /**
   * Verifies if a note exists by searching based on the given fields.
   *
   * @param givenFields a Map of key and value pairs representing the fields and values.
   */
  function verifyNoteExistsOnPolicy(givenFields : Map<String,String>)

}