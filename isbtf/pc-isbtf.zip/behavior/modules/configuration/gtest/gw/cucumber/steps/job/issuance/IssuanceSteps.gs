package gw.cucumber.steps.job.issuance

uses com.google.inject.Inject
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.transformer.TypelistTransformer

/**
 * {@link Issuance} steps agnostic of the line of business
 */
@Export
class IssuanceSteps {

  @Inject
  var _contextFactory : gw.cucumber.context.api.ContextFactory

  @When("^I begin an issuance$")
  function iBeginANewIssuance() {
    _contextFactory.getIssuanceContext().createIssuance()
  }

  @When("^I (?:attempt to quote|quote) the issuance$")
  function iQuoteTheIssuance() {
    _contextFactory.getIssuanceContext().quote()
  }

  @When("^I issue the issuance$")
  function iIssueTheIssuance() {
    _contextFactory.getIssuanceContext().issue()
  }

  @Then("^the issuance status (?:should be|should remain) \"(Draft|Quoted|Bound)\"$")
  function theIssuanceStatus(expectedStatus : String) {
    _contextFactory.getIssuanceContext().verifyInStatus(expectedStatus)
  }
}