package gw.cucumber.context.impl.smoketest.common

uses cucumber.api.DataTable
uses entity.AccountContact
uses gw.api.builder.AccountLocationBuilder
uses gw.api.builder.AddressBuilder
uses gw.api.builder.CompanyBuilder
uses gw.api.builder.PersonBuilder
uses gw.api.database.Query
uses gw.api.databuilder.ContactBuilder
uses gw.api.databuilder.UniqueKeyGenerator
uses gw.api.locale.DisplayKey
uses gw.command.critical.KeyGenerator
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.AccountContext
uses gw.cucumber.setup.AccountDataSetup
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses pcftest.AccountFile_Summary
uses pcftest.CreateAccount

@Export
class AccountContextImpl extends CucumberStepBase implements AccountContext {

  override function createAccount(contactTypeText : String, givenFields : Map<String, String>) {
    createAccountWithData(contactTypeText, givenFields)
  }

  private function createAccountWithData(contactTypeText : String, data : Map<String, String>) {
    var contactType = new TypelistTransformer<ContactType>().transform(contactTypeText)
    var contactBuilder : ContactBuilder
    if (contactType == ContactType.TC_PERSON) {
      contactBuilder = new PersonBuilder()
          .withFirstName(data.get("First name") ?: KeyGenerator.getFirstName())
          .withLastName(data.get("Last name") ?: KeyGenerator.getLastName())
          .withEmailAddress1(KeyGenerator.getEmail())
          .withAddress(new AddressBuilder()
              .withAddressLine1(data.get("Address 1") ?: "2211 Bridgepointe Parkway")
              .withAddressLine2(data.get("Address 2") ?: "Floor 2")
              .withAddressLine3(data.get("Address 3") ?: "Developer Unit Habitation Cube #834")
              .withCity(data.get("City") ?: "San Mateo")
              .withState(data.get("State") != null ? typekey.State.getTypeKey(data.get("State")) : State.TC_CA)
              .withPostalCode(data.get("ZIP Code") ?: "94404")
          )
    } else {
      var id = UniqueKeyGenerator.get().nextInteger()
      contactBuilder = new CompanyBuilder(id).withCompanyName(data.get("Company Name") ?: "Our Company Inc" + id)
    }

    var accountDataSetup = new AccountDataSetup()
    accountDataSetup.Builder
        .withAccountLocation(new AccountLocationBuilder())
        .withAccountHolderContact(contactBuilder)
        .withProducerCode("100-002541")//Armstrong (Premier)

    var accountNumber = data.get("Account Number")
    if (accountNumber != null) {
      accountDataSetup.Builder.withAccountNumber(accountNumber)
    }

    ScenarioInfoProvider.AccountDataSetup = accountDataSetup
  }
  override function verifyAccountPersonDoesNotExist(givenFields : Map<String, String>) {
    var query = Query.make(AccountContact)
    var personJoin = query.join(AccountContact#Contact).cast(Person)
    personJoin.compare(Person#FirstName, Equals, givenFields.get("First name"))
    personJoin.compare(Person#LastName, Equals, givenFields.get("Last name"))
    var personCount = query.select().Count
    if (personCount > 0) {
      throw new IllegalArgumentException("Person with given first name " + givenFields.get("First name") + " and last name " + givenFields.get("Last name") + " exists");
    }
  }

  override function verifyAccountCompanyDoesNotExist(givenFields : Map<String, String>) {
    var query = Query.make(AccountContact)
    var companyJoin = query.join(AccountContact#Contact).cast(Company)
    companyJoin.compare(Contact#Name, Equals, givenFields.get("Company name"))
    var companyCount = query.select().Count
    if (companyCount > 0) {
      throw new IllegalArgumentException("Company with given company name " + givenFields.get("Company name") + " exists");
    }
  }

  override function createAccountOfTypePerson(givenFields : Map<String, String>) {
    var newAccount = loginIfLoggedOut(CurrentUser).AccountTab.AccountTab_NewAccount.click()
    var createAccount : CreateAccount
    searchPersonAccountType(newAccount, givenFields)
    createAccount = newAccount.clickCreatePersonAccount()
    setUpFieldsOnUI(createAccount,givenFields)
    var accountSummary = createAccount.update() as AccountFile_Summary
    ScenarioInfoProvider.AccountNumber = accountSummary.AccountNumber.Value
  }

  override function createAccountOfTypeCompany(givenFields : Map<String, String>) {
    var newAccount = loginIfLoggedOut(CurrentUser).AccountTab.AccountTab_NewAccount.click()
    var createAccount : CreateAccount
    searchCompanyAccountType(newAccount, givenFields)
    createAccount = newAccount.clickCreateCompanyAccount()
    setUpFieldsOnUI(createAccount,givenFields)
    var accountSummary = createAccount.update() as AccountFile_Summary
    ScenarioInfoProvider.AccountNumber = accountSummary.AccountNumber.Value
  }

  override function editAccount(givenFields : Map<String, String>) {
    logout()
    var editAccountScreen = loginAsUser(CurrentUser).goToAccountSummary(ScenarioInfoProvider.AccountDataSetup.Entity)
        .editAccount().EditAccountScreen
    UIHelper.setFieldValues(editAccountScreen, givenFields)
    editAccountScreen.Update.click()
  }

  override function editAccountPrimaryLocation(givenFields : DataTable) {
    var locationsScreen = loginIfLoggedOut(CurrentUser).goToAccountSummary(ScenarioInfoProvider.AccountDataSetup.Entity).goToLocations()
    locationsScreen.changeAccountsPrimaryLocationInfo(givenFields.asMap(String, String))
  }

  private function setUpFieldsOnUI(createAccount : pcftest.CreateAccount, accountInfo : Map<String,String>){

    UIHelper.setFieldValues(createAccount, new UIFieldsProviderBase(accountInfo) {
      //Required fields First name, Last name, Company name are already provided in searchCompanyAccountType and searchPersonAccountType
      //Required field producer code is set in the last step
      override property get RequiredFields() : Set<String> {
        return {"Address 1", "City", "State", "ZIP Code", "Address Type"}
      }

      override property get DefaultFields() : Map<String, String> {
        return {DisplayKey.get("Web.AddressDetail.AddressType") -> "Business"}
      }
    })

    if (createAccount.CreateAccountScreen.CreateAccountDV.ProducerSelectionInputSet.Producer.SelectOrganization.Visible) {
      var organizationSearchPopup = createAccount.CreateAccountScreen.CreateAccountDV.ProducerSelectionInputSet.Producer.SelectOrganization.click()
          as pcftest.OrganizationSearchPopup
      organizationSearchPopup.Name.setValue("Enigma Fire & Casualty")
      organizationSearchPopup.clickSearch()
      organizationSearchPopup.getSearchResults().first()._Select.click()
    }

    createAccount.ProducerCode.selectFirstValidOption()
  }

  private function searchPersonAccountType(newAccount : pcftest.NewAccount, personInfoDataMap : Map<String,String>){
    newAccount.FirstName.Value = personInfoDataMap.get("First name")
    newAccount.LastName.Value = personInfoDataMap.get("Last name")
    newAccount.SearchButton.click()
  }

  private function searchCompanyAccountType(newAccount : pcftest.NewAccount, companyInfoDataMap : Map<String,String>){
    newAccount.CompanyName.Value = companyInfoDataMap.get("Company name")
    newAccount.SearchButton.click()
  }

  override function verifyAccountHolderDetails(accNumber : String, givenFields : Map<String, String>) {
    logout()

    givenFields = givenFields.copy()
    var homeAddressFields = {"Home Address 1", "Home Address 2", "Home Address 3", "Home Address 4"}
    var joiner = new StringJoiner("\n")
    homeAddressFields.each(\elt -> {
      joiner.add(givenFields.get(elt))
      givenFields.remove(elt)
    })
    givenFields.putIfAbsent("Home Address", joiner.toString())

    var accountDetails = loginAsUser(CurrentUser).goToAccountSummary(accNumber).AccountDetails
    UIHelper.assertFieldValues(accountDetails, givenFields)
  }

  override function verifyAccountPersonExists(givenFields : Map<String, String>) {
    var newAccount = loginIfLoggedOut(CurrentUser).AccountTab.AccountTab_NewAccount.click()
    searchPersonAccountType(newAccount, givenFields)
    var accountEntries = newAccount.NewAccountScreen.getNewAccountSearchResultsLV()._Entries
    assertThat(accountEntries.Count)
        .as("Person with the given first name - " + givenFields.get("First name") + " and given last name - " + givenFields.get("Last name") + " should exist")
        .isGreaterThan(0)
  }

  override function verifyAccountCompanyExists(givenFields : Map<String, String>) {
    var newAccount = loginIfLoggedOut(CurrentUser).AccountTab.AccountTab_NewAccount.click()
    searchCompanyAccountType(newAccount, givenFields)
    var accountEntries = newAccount.NewAccountScreen.getNewAccountSearchResultsLV()._Entries
    assertThat(accountEntries.Count)
        .as("Company with the given company name - " +  givenFields.get("Company name")+ " should exist")
        .isGreaterThan(0)
  }
}