package gw.cucumber.steps.lob.hop

uses com.google.inject.Inject
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.setup.DataTableRepository

/**
 * Homeowners specific {@link Cancellation} job steps
 */
@Export
class HOP_CancellationSteps {
  @Inject
  var _contextFactory : ContextFactory
  @Inject
  var _dataTableRepository : DataTableRepository

  @Given("^an in-force Homeowners policy with a base state of \"([^\"]*)\"")
  function anInForceHomeownersPolicyWithThePolicyTypeAndCoverageForm(baseState : String) {
    _contextFactory.getSubmissionContext().createABoundPolicyFor(baseState)
  }

  @Given("^a cancelled Homeowners policy$")
  function aCancelledHomeownersPolicy() {
    _contextFactory.getSubmissionContext().createABoundPolicy()
    _contextFactory.getCancellationContext().createACancelledPolicy()
  }

  @Given("^I cancel the policy for rewrite$")
  function aCancelledHomeownersPolicyForRewrite() {
    _contextFactory.getCancellationContext().createACancelledPolicyForRewrite()
  }

  @When("^I start a Reinstatement$")
  function iStartAReinstatement() {
    _contextFactory.getReinstatementContext().createReinstatementSetup()
  }

  @When("^I quote the Reinstatement$")
  function iQuoteTheReinstatement() {
    _contextFactory.getReinstatementContext().quote()
  }
}