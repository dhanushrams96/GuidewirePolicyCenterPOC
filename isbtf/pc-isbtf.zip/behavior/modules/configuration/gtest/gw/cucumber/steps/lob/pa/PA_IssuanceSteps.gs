package gw.cucumber.steps.lob.pa

uses com.google.inject.Inject
uses gw.cucumber.context.api.ContextFactory

/**
 * Personal Auto specific {@link Issuance} job steps
 */
@Export
class PA_IssuanceSteps {

  @Inject
  var _contextFactory : ContextFactory

}
