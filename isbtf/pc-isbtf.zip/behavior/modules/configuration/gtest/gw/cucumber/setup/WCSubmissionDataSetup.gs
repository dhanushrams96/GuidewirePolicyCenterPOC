package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.databuilder.wc.WCSubmissionBuilder

@Export
@ScenarioScoped
class WCSubmissionDataSetup extends SubmissionDataSetup<WCSubmissionBuilder> {
  construct(username: String) {
    super(username)
  }

  protected override function createBuilder() : WCSubmissionBuilder {
    return new WCSubmissionBuilder().isDraft()
  }

  protected override function initializeLines() {
  }
}