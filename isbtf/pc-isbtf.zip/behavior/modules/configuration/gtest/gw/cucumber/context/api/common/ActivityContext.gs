package gw.cucumber.context.api.common

/**
 * Methods specific to Activity
 */
@Export
interface ActivityContext {

  /**
   * Creates an activity with given {@link ActivityCategory}, {@link ActivityPattern} and other activity details.
   * @param category the {@link ActivityCategory} to use for the creation of activity
   * @param pattern the {@link ActivityPattern} to use for the creation of activity
   * @param activityDetails other activityDetails like due date, priority, etc needed for the creation of activity
   */
  function createAnActivity(category : String, pattern : String, activityDetails : Map<String, String>)

  /**
   * Verifies an activity with given activity information exists
   * @param activityInfo list of map of activity details like subject, etc
   */
  function verifyActivityExists(activityInfo : List<Map<String, String>>)

  /**
   * Verifies the activity assigned to the user has correct activity details
   * @param activityDetails list of map of activity details to verify on activity
   */
  function verifyActivityAssignedToUser(activityDetails : List<Map<String, String>>)

}