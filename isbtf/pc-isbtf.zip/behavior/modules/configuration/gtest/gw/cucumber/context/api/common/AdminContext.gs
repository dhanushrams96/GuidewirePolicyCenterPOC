package gw.cucumber.context.api.common

/**
 * Methods specific to Admin steps
 */

@Export
interface AdminContext {

  /**
   * Loads sample data and sets the current user based on the input user role
   *
   * @param userRole
   */
  function userRoleSetup(userRole:String)

  /**
   * Create a new Policy Hold
   * @param holdInfo - Map containing key/value pair for each hold field
   */
  function createPolicyHold(holdInfo : Map<String, String>)

  /**
   * Delete the hold with code equals to {@code holdCode}
   * @param holdCode - the code of the hold to be deleted
   */
  function deletePolicyHold(holdCode: String)

  /**
   * Verifies if the UWIssues are loaded
   * @param uwIssues - list of expected UW issues
   */
  function verifyUWIssuesLoaded(uwIssues : List<String>)
}