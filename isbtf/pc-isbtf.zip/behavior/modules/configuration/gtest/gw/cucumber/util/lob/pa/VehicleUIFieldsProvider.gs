package gw.cucumber.util.lob.pa

uses gw.api.databuilder.UniqueKeyGenerator
uses gw.api.datagen.DatagenUtil
uses gw.api.locale.DisplayKey
uses gw.cucumber.util.common.UIFieldsProviderBase

@Export
public class VehicleUIFieldsProvider extends UIFieldsProviderBase {

  private static var VIN = DisplayKey.get("Web.PolicyLine.Vehicle.Vin")
  private var _period : PolicyPeriod

  construct(fields : Map<String, String>, period : PolicyPeriod) {
    super(fields)
    _period = period
  }

  override property get RequiredFields() : Set<String> {
    return {DisplayKey.get("Web.PolicyLine.Vehicle.Make"), DisplayKey.get("Web.PolicyLine.Vehicle.Model"), DisplayKey.get("Web.PolicyLine.Vehicle.Year")}
  }

  override property get DefaultFields() : Map<String, String> {
    // Find a default GarageLocation from the PolicyPeriod
    return {
        VIN -> VINGenerator.getVin(2012),
        DisplayKey.get("Web.PolicyLine.Vehicle.Type") -> VehicleType.TC_AUTO.DisplayName,
        DisplayKey.get("Web.PolicyLine.Vehicle.LicensePlate") -> generateLicensePlate(),
        DisplayKey.get("Web.PolicyLine.Vehicle.LicenseState") -> "CA",
        DisplayKey.get("Web.PolicyLine.Vehicle.CostNew") -> "25300",
        DisplayKey.get("Web.PolicyLine.Vehicle.WhereGaraged") -> _period.Policy.Account.AccountLocations.first().DisplayName
    }
  }

  override property get PreprocessFields() : List<List<String>> {
    //On the vehicle page, the order matters. The VIN should be set prior to setting Make, Model and Year etc.
    return {{VIN}}
  }

  // a 7-digit licence plate
  private static function generateLicensePlate() : String {
    return (UniqueKeyGenerator.get().nextInteger() % 10).toString() +
        DatagenUtil.getRandomAlphaString(3).toUpperCase() +
        (UniqueKeyGenerator.get().nextInteger() % 10000).toString().leftPad(4).replace(" ", "0")
  }
}