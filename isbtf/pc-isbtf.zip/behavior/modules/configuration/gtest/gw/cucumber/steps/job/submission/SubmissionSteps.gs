package gw.cucumber.steps.job.submission

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.And
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.DataTableRepository
uses gw.cucumber.transformer.DateTransformer
uses gw.cucumber.transformer.TypelistTransformer

/**
 * {@link Submission} steps agnostic of the line of business
 */
@Export
class SubmissionSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _dataTableRepository : DataTableRepository

  @When("^I create a new submission$")
  function createANewSubmission() {
    _contextFactory.getSubmissionContext().createNewSubmission()
  }

  @When("^I make the submission effective today$")
  function iMakeTheSubmissionEffectiveToday() {
    _contextFactory.getSubmissionContext().setEffectiveDate(Date.Today)
  }


  @When("^I select side by side version number \"(\\d+)\"$")
  function selectNumberedVersion(versionNumber : int) {
    _contextFactory.getSubmissionContext().selectSideBySideVersion(versionNumber)
  }

  @When("^I select version number \"(\\d+)\"$")
  function selectNumberVersion(versionNumber : int) {
    _contextFactory.getSubmissionContext().selectVersion(versionNumber)
  }

  @When("^I start side by side quoting$")
  function startSideBySideQuoting() {
    _contextFactory.getSubmissionContext().startSideBySideQuoting()
  }

  @Given("^I create a new version")
  function initiateANewVersionViaMultiversion() {
    _contextFactory.getSubmissionContext().initiateANewVersionViaMultiversion()
  }

  @Then("^the submission status (?:should be|should remain) \"(Not-Taken|Declined|Withdrawn|Draft|Rated|Quoted|Bound)\"$")
  function submissionStatusShouldBe(status : String) {
    _contextFactory.getSubmissionContext().verifyInStatus(status)
  }

  @Then("^policy should be issued$")
  function policyIsIssued() {
    _contextFactory.getSubmissionContext().verifyPolicyIssued()
  }

  @When("^I quote the submission$")
  function quoteTheSubmission() {
    _contextFactory.getSubmissionContext().quote()
  }

  @When("^I select \"(Quick Quote|Full Application)\" quote application$")
  function iSelectQuoteApplication(applicationType : String) {
    var quoteType = new TypelistTransformer<QuoteType>().transform(applicationType)
    _contextFactory.getSubmissionContext().setQuoteType(quoteType)
  }

  @When("^I select the following product offering:$")
  function iSelectProductOffering(productOfferingTable: DataTable) {
    var productOfferingInfo = _dataTableRepository.dataTableLookup(productOfferingTable).asMaps(String, String).single()
    _contextFactory.getSubmissionContext().selectProductOffering(productOfferingInfo)
  }

  @When("^I select \"(?:Personal Auto|HOPHomeowners|Workers\' Compensation)\" as the product$")
  function iSelectTheProduct() {
    _contextFactory.getSubmissionContext().selectProduct()
  }

  @When("^I enter the following qualification information:$")
  function iSelectPreQualification(preQualificationInfoTable: DataTable) {
    _contextFactory.getSubmissionContext().selectPreQualification(preQualificationInfoTable.asMaps(String, String))
  }

  @When("^I select payment plan \"([^\"]+)\"$")
  function selectPaymentPlan(paymentPlan: String) {
    _contextFactory.getSubmissionContext().selectPaymentPlan(paymentPlan)
  }

  @When("^I (?:attempt to issue|issue) the policy$")
  function issueSubmission() {
    _contextFactory.getSubmissionContext().issue()
  }

  @When("^I bind the policy$")
  function bindSubmission() {
    _contextFactory.getSubmissionContext().bind()
  }

  @Then("^the selected reason code should be \"(Insured's request - N.O.C|Loss history)\"$")
  function verifySelectedReasonCode(reasonCode : String) {
    _contextFactory.getSubmissionContext().verifySelectedReasonCode(reasonCode)
  }

  @Given("^the submission has base state \"([^\"]*)\"$")
  function createSubmissionWithBaseState(baseState : String) {
    _contextFactory.getSubmissionContext().setSubmissionBaseState(baseState)
  }

  @When("^I edit the submission$")
  function iEditTheSubmission() {
    _contextFactory.getSubmissionContext().edit()
  }

  @And("^the submission has an effective date of \"([^\"]+)\"$")
  function submissionEffectiveOn(effectiveDate : String) {
    _contextFactory.getSubmissionContext().setEffectiveDate(DateTransformer.transform(effectiveDate))
  }

  @When("^I enter the following policy info:$")
  function iEnterRequiredDefaultPolicyInfo(requiredInfoTable: DataTable) {
    _contextFactory.getSubmissionContext().enterPolicyInfo(requiredInfoTable.asMap(String, String))
  }

  @Given("^the submission has an expiration date of \"([^\"]+)\"$")
  function submissionExpiresOn(expDate : String) {
    _contextFactory.getSubmissionContext().setExpirationDate(DateTransformer.transform(expDate))
  }

  @Given("^the (?:submission|policy) is bound$")
  function submissionIsBound() {
    _contextFactory.getJobContext().setJobStatus(PolicyPeriodStatus.TC_BOUND)
  }

  @Given("^the policy effective date is \"([^\"]+)\"$")
  function policyEffectiveDateIs(effectiveDateStr: String) : void {
    _contextFactory.getSubmissionContext().setupPolicyEffectiveDate(DateTransformer.transform(effectiveDateStr))
  }

  @Given("^the submission has a \"([^\"]+)\" UW issue$")
  function submissionHasBindBlockingUWIssue(blockingPoint : String) {
    _contextFactory.getSubmissionContext().causeUWIssue(new TypelistTransformer<UWIssueBlockingPoint>().transform(blockingPoint))
  }

  @When("^I review the policy with the insured$")
  function iReviewThePolicy() {
    _contextFactory.getSubmissionContext().goToReviewPolicy()
  }
}