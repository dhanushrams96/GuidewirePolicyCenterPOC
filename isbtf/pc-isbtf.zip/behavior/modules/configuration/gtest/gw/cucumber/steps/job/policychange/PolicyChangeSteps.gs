package gw.cucumber.steps.job.policychange

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.steps.ScenarioInfoProvider
uses gw.cucumber.transformer.TypelistTransformer

/**
 * {@link PolicyChange} steps agnostic of the line of business
 */
@Export
class PolicyChangeSteps {

  @Inject
  var _scenarioInfoProvider : ScenarioInfoProvider

  @Inject
  var _contextFactory : ContextFactory

  @When("^I begin (?:a|another) new policy change$")
  function iBeginANewPolicyChangeOnTheSubmission() {
    _scenarioInfoProvider.JobSubType = TC_POLICYCHANGE
    _contextFactory.getPolicyChangeContext().createPolicyChange()
  }

  @When("^I (?:attempt to quote|quote) the policy change$")
  function iQuoteThePolicyChange() {
    _contextFactory.getPolicyChangeContext().quote()
  }

  @When("^I (?:attempt to issue|issue) the policy change$")
  function issuePolicyChange() {
    _contextFactory.getPolicyChangeContext().issue()
  }

  @Then("^the policy change status (?:should be|should remain) \"(Draft|Quoted|Bound)\"$")
  function thePolicyChangeStatus(status : String) {
    _contextFactory.getPolicyChangeContext().verifyInStatus(status)
  }

  @Then("^the policy change should be preempted$")
  function thePolicyChangeShouldBePreempted() {
    _contextFactory.getPolicyChangeContext().verifyPolicyChangeIsPreempted()
  }

  @When("^I apply the preemption forward$")
  function iApplyThePreemption() {
    _contextFactory.getPolicyChangeContext().applyPreemptionChanges()
  }

  @Then("I view the policy as of \"(\\d+)\" days into the term")
  function iViewPolicyAsOfDate(daysIntoTerm : int) {
    _contextFactory.getPolicyChangeContext().viewPolicyAsOfDaysIntoTerm(daysIntoTerm)
  }

  @When("^I apply the pending changes to the unbound renewal")
  function iApplyChangesToUnboundRenewal() {
    _contextFactory.getPolicyChangeContext().applyPendingChangesToUnboundRenewal()
  }

  @When("^there should be the following conflicts:$")
  function oosConflictsShouldExist(conflictEntry : DataTable) {
    var expectedEntries = conflictEntry.asMaps(String, String)
    _contextFactory.getPolicyChangeContext().verifyOOSConflictsExist(expectedEntries)
  }

  @When("^I resolve all conflicts as \"(Override None|Override All)?\"$")
  function iResolveOOSConflicts(resolveType : String) {
    _contextFactory.getPolicyChangeContext().resolveOOSConflicts(resolveType)
  }

}