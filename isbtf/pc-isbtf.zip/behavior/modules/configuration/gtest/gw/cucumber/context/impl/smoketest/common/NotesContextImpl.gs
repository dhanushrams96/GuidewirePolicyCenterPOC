package gw.cucumber.context.impl.smoketest.common

uses gw.api.locale.DisplayKey
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.NotesContext
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper

@Export
class NotesContextImpl extends CucumberStepBase implements NotesContext {

  override function createNote(givenFields : Map<String, String>) {
    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var noteWorksheet = policyFile.clickCreateNewNote()

    UIHelper.setFieldValues(noteWorksheet, new UIFieldsProviderBase(givenFields) {
      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.NewNote.Topic"), DisplayKey.get("Web.NewNote.Text")}
      }

      override property get DefaultFields() : Map<String, String> {
        return {}
      }
    })

    noteWorksheet.NewNoteScreen.NewNoteScreen_UpdateButton.click()
  }

  override function verifyNoteExistsOnPolicy(givenFields : Map<String, String>) {

    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var notesScreen = policyFile.MenuLinks.PolicyFile_PolicyFile_Notes.click().Policy_NotesScreen

    var subject = givenFields.get(DisplayKey.get("Web.NewNote.Subject"))
    var bodyText = givenFields.get(DisplayKey.get("Web.NewNote.Text"))
    assertThat(notesScreen.verifyNoteExists(subject, bodyText)).isTrue()

    var note = notesScreen.getNoteEntryByLanguage(subject, bodyText, null)
    UIHelper.assertFieldValues(note.NoteRowSet, updateNoteInfoMap(givenFields))
  }

  private function updateNoteInfoMap(noteInfo : Map<String, String>) : Map<String, String> {
    var updatedNoteInfo = noteInfo.copy()
    updatedNoteInfo.remove(DisplayKey.get("Web.NewNote.Subject"))
    updatedNoteInfo.remove(DisplayKey.get("Web.NewNote.Text"))

    var noteInfoCopy = new HashMap<String, String>() {
    }
    updatedNoteInfo.eachKeyAndValue(\k, val -> {
      noteInfoCopy.put(k.concat(":"), val)
    })

    return noteInfoCopy
  }
}