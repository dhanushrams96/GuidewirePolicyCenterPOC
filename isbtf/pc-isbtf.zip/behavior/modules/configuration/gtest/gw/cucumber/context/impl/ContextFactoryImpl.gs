package gw.cucumber.context.impl

uses com.google.inject.Inject
uses com.google.inject.name.Named
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.common.AccountContext
uses gw.cucumber.context.api.common.ActivityContext
uses gw.cucumber.context.api.common.AdminContext
uses gw.cucumber.context.api.common.NotesContext
uses gw.cucumber.context.api.common.PolicySystemContext
uses gw.cucumber.context.api.job.JobContext
uses gw.cucumber.context.api.job.audit.AuditContext
uses gw.cucumber.context.api.job.cancellation.CancellationContext
uses gw.cucumber.context.api.job.issuance.IssuanceContext
uses gw.cucumber.context.api.job.policychange.PolicyChangeContext
uses gw.cucumber.context.api.job.reinstatement.ReinstatementContext
uses gw.cucumber.context.api.job.renewal.RenewalContext
uses gw.cucumber.context.api.job.rewrite.RewriteContext
uses gw.cucumber.context.api.job.submission.SubmissionContext
uses gw.cucumber.context.api.lob.LineContext
uses gw.cucumber.steps.ScenarioInfoProvider
uses gw.cucumber.util.lob.ProductCode
uses typekey.Job

@SuppressWarnings({"unused", "Method2Property"})
@Export
class ContextFactoryImpl implements ContextFactory {

  @Inject @Named("QuickQuote")
  var _quickQuoteSubmissionContexts: Map<ProductCode, SubmissionContext>

  @Inject @Named("FullQuote")
  var _fullQuoteSubmissionContexts: Map<ProductCode, SubmissionContext>

  @Inject var _issuanceContexts : Map<ProductCode, IssuanceContext>
  @Inject var _policyChangeContexts : Map<ProductCode, PolicyChangeContext>
  @Inject var _renewalContexts : Map<ProductCode, RenewalContext>
  @Inject var _rewriteContexts : Map<ProductCode, RewriteContext>
  @Inject var _reinstatementContexts : Map<ProductCode, ReinstatementContext>
  @Inject var _cancellationContexts : Map<ProductCode, CancellationContext>
  @Inject var _auditContexts : Map<ProductCode, AuditContext>

  @Inject var _accountContext : AccountContext
  @Inject var _notesContext : NotesContext
  @Inject var _policySystemContext : PolicySystemContext
  @Inject var _activityContext : ActivityContext
  @Inject var _adminContext : AdminContext

  @Inject var _scenarioInfoProvider : ScenarioInfoProvider

  override function getJobContext() : JobContext {
    var jobSubType = getJobSubType()
    switch (jobSubType) {
      case TC_SUBMISSION:
        return this.getSubmissionContext()
      case TC_ISSUANCE:
        return this.getIssuanceContext()
      case TC_POLICYCHANGE:
        return this.getPolicyChangeContext()
      case TC_RENEWAL:
        return this.getRenewalContext()
      case TC_REWRITE:
        return this.getRewriteContext()
      case TC_REINSTATEMENT:
        return this.getReinstatementContext()
      case TC_AUDIT:
        return this.getAuditContext()
      case TC_CANCELLATION:
        return this.getCancellationContext()
      default:
        throw new IllegalStateException("Could not find a valid job context for job type ${jobSubType}.")
    }
  }

  reified function getLineContext<T extends LineContext>() : T {
    var context = getJobContext()
    if (context typeis T) {
      return context
    }
    throw new IllegalStateException("Could not find a valid line context for job type ${getJobSubType()}.")
  }

  function getSubmissionContext() : SubmissionContext {
    return _scenarioInfoProvider.NewSubmissionQuoteType == QuoteType.TC_QUICK
        ? getJobContext(_quickQuoteSubmissionContexts)
        : getJobContext(_fullQuoteSubmissionContexts)
  }

  function getIssuanceContext() : IssuanceContext {
    return getJobContext(_issuanceContexts)
  }

  function getPolicyChangeContext() : PolicyChangeContext {
    return getJobContext(_policyChangeContexts)
  }

  function getRenewalContext(): RenewalContext {
    return getJobContext(_renewalContexts)
  }

  function getRewriteContext(): RewriteContext {
    return getJobContext(_rewriteContexts)
  }

  function getCancellationContext(): CancellationContext {
    return getJobContext(_cancellationContexts)
  }

  override function getReinstatementContext() : ReinstatementContext {
    return getJobContext(_reinstatementContexts)
  }

  override function getAuditContext() : AuditContext {
    return getJobContext(_auditContexts)
  }

  function getAccountContext(): AccountContext { return _accountContext}

  function getNotesContext(): NotesContext { return _notesContext}

  function getPolicySystemContext() : PolicySystemContext {
    return _policySystemContext
  }

  function getActivityContext(): ActivityContext {
    return _activityContext
  }

  function getAdminContext():AdminContext { return _adminContext}

  /**
   * Internal function used to get the right context implementation object from the dependency injection container.
   * @param contextMap - The map that has the pairs product code & job context. This map will be used to get the right
   * implementation object
   * @param <T> - Any specific subtype of JobContext
   * @return - The concrete implementation of JobContext casted to {@code T}
   */
  reified private function getJobContext<T extends JobContext>(contextMap: Map<ProductCode, T>) : T {
    var context = contextMap.get(getProductCode())
    if (context typeis T) {
      return context
    }
    var expectedType = T.Type
    throw new IllegalStateException("Invalid JobContext: Expected type is ${expectedType} but current type is: ${(typeof context)}")
  }

  /**
   * Determines which job subtype is currently set on the context. It uses the {@code ScenarioInfoProvider} to determine
   * what the right job subtype is. The job subtype is determined by the tags added to the feature file.
   * @return - The job subtype currently in the context
   */
  private function getJobSubType() : Job {
    if (_scenarioInfoProvider.JobSubType == null) {
      throw new IllegalStateException("ScenarioInfoProvider.JobSubType cannot be NULL. Please verify that the feature file has the correct tags and the TagInfoProcessor.gs file is populating the ScenarioInfoProvider.JobSubType correctly")
    }
    return _scenarioInfoProvider.JobSubType;
  }

  /**
   * Determines which LOB is currently set on the context. It uses the {@code ScenarioInfoProvider} to determine
   * what the right LOB code is. The LOB is determined by the tags added to the feature file.
   * @return - The LOB currently in the context
   */
  private function getProductCode() : ProductCode {
    if (_scenarioInfoProvider.Line == null) {
      throw new IllegalStateException("ScenarioInfoProvider.Line cannot be NULL. Please verify that the feature file has the correct tags and the TagInfoProcessor.gs file is populating the ScenarioInfoProvider.Line correctly")
    }
    return _scenarioInfoProvider.Line;
  }
}