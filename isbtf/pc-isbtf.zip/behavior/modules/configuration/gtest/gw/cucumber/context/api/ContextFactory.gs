package gw.cucumber.context.api

uses gw.cucumber.context.api.common.AccountContext
uses gw.cucumber.context.api.common.ActivityContext
uses gw.cucumber.context.api.common.AdminContext
uses gw.cucumber.context.api.common.NotesContext
uses gw.cucumber.context.api.common.PolicySystemContext
uses gw.cucumber.context.api.job.JobContext
uses gw.cucumber.context.api.job.audit.AuditContext
uses gw.cucumber.context.api.job.cancellation.CancellationContext
uses gw.cucumber.context.api.job.issuance.IssuanceContext
uses gw.cucumber.context.api.job.policychange.PolicyChangeContext
uses gw.cucumber.context.api.job.reinstatement.ReinstatementContext
uses gw.cucumber.context.api.job.renewal.RenewalContext
uses gw.cucumber.context.api.job.rewrite.RewriteContext
uses gw.cucumber.context.api.job.submission.SubmissionContext
uses gw.cucumber.context.api.lob.LineContext

/**
 * Factory class used to get the right context API implementation.
 * Some methods here use generics to allow the caller to specify a specific type if needed to. For example, the
 * getLineContext() method can be called in two different ways:
 *
 * <li>{@code factory.getLineContext() } - returns the context implementation casted to LineContext, which is useful when
 * processing steps that are line agnostic. </li>
 *
 * <li>{@code factory.getLineContext<PAContext>() } - returns the context implementation casted to PAContext, which is useful
 * when processing steps that are specific to a line of business. </li>
 *
 */
@SuppressWarnings("Method2Property")
@Export
interface ContextFactory {

  /**
   * Gets the implementation for the {@code LineContext} api. If {@code T} is specified it casts the implementation to
   * {@code T}. If not, it casts it to {@code LineContext}.
   *
   * @param <T> - Any specific subtype of {@code LineContext}.
   * @return - The concrete implementation of {@code LineContext} casted to {@code T}.
   */
  reified function getLineContext<T extends LineContext>() : T

  /**
   * Returns the api implementation object casted to {@code JobContext}. This method should be used on steps that
   * are job agnostic.
   */
  function getJobContext(): JobContext

  /**
   * Returns the api implementation object casted to {@code SubmissionContext}. This method should be used on steps that
   * are specific to Submission.
   */
  function getSubmissionContext(): SubmissionContext

  /**
   * Returns the api implementation object casted to {@code IssuanceContext}. This method should be used on steps that
   * are specific to Issuance.
   */
  function getIssuanceContext(): IssuanceContext

  /**
   * Returns the api implementation object casted to {@code PolicyChangeContext}. This method should be used on steps that
   * are specific to PolicyChange.
   */
  function getPolicyChangeContext(): PolicyChangeContext

  /**
   * Returns the api implementation object casted to {@code CancellationContext}. This method should be used on steps that
   * are specific to Cancellation.
   */
  function getCancellationContext(): CancellationContext

  /**
   * Returns the api implementation object casted to {@code RenewalContext}. This method should be used on steps that
   * are specific to Renewal.
   */
  function getRenewalContext(): RenewalContext

  /**
   * Returns the api implementation object casted to {@code RewriteContext}. This method should be used on steps that
   * are specific to Rewrite.
   */
  function getRewriteContext(): RewriteContext

  /**
   * Returns the api implementation object casted to {@code ReinstatementContext}. This method should be used on steps that
   * are specific to Reinstatement.
   */
  function getReinstatementContext(): ReinstatementContext

  /**
   * Returns the api implementation object casted to {@code ReinstatementContext}. This method should be used on steps that
   * are specific to Reinstatement.
   */
  function getAuditContext(): AuditContext

  /**
   * Returns the api implementation object casted to {@code AccountContext}. This method should be used on steps that
   * are specific to Account.
   */
  function getAccountContext(): AccountContext

  /**
   * Returns the api implementation object casted to {@code NotesContext}. This method should be used on steps that
   * are specific to Notes.
   */
  function getNotesContext(): NotesContext

  /**
   * Returns the api implementation object casted to {@code AdminContext}. This method should be used on steps that
   * are specific to Admin.
   */
  function getAdminContext(): AdminContext

  /**
   * Returns the api implementation object casted to {@code PolicySystemContext}. This method should be used on steps that
   * are specific to System setting.
   */
  function getPolicySystemContext() : PolicySystemContext

  /**
   * Returns the api implementation object casted to {@code ActivityContext}. This method should be used on steps that
   * are specific to Activity.
   */
  function getActivityContext(): ActivityContext

}