package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.ReinstatementBuilder

@Export
@ScenarioScoped
class ReinstatementDataSetup extends NonSubmissionDataSetup<ReinstatementBuilder> {

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username,basedOnPeriod)
  }

}