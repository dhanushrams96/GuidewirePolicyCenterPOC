package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.api.util.MonetaryAmounts
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.setup.PASubmissionDataSetup
uses gw.cucumber.transformer.MonetaryAmountTransformer
uses gw.cucumber.util.common.ProductModelReflectUtil
uses gw.cucumber.util.common.UIHelper
uses gw.cucumber.util.lob.pa.DriverUIFieldsProvider
uses gw.pl.currency.MonetaryAmount
uses pcftest.SubmissionWizard

@Export
class PASubmissionContextFullQuoteImpl extends PASubmissionContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addDriver(givenFields : Map<String, String>) {
    var dataSetup = ScenarioInfoProvider.DataSetup as PASubmissionDataSetup
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(dataSetup.Entity)
    var driverStep = submissionWizard.PAMode.goToDriversStep()
    var newPolicyDriverPopup = driverStep.AddNewPersonButton.click() as pcftest.NewPolicyDriverPopup
    var contactDetailScreen = newPolicyDriverPopup.ContactDetailScreen

    UIHelper.setFieldValues(contactDetailScreen, new DriverUIFieldsProvider(givenFields))

    var submissionWizardAgain = contactDetailScreen.Update.click() as SubmissionWizard
    submissionWizardAgain.PAMode.saveDraft()
  }

  override function addVehicle(givenFields : Map<String, String>) {
    // add a vehicle via the full quote wizard
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var vehicleScreen = submissionWizard.PAMode.goToVehiclesStep()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.addVehicle(givenFields)
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function selectPaymentPlan(paymentPlan : String) {
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var paymentStep = submissionWizard.BillingInfo.click()
    paymentStep.PaymentPlans.singleWhere(\elt -> elt.Name.Text == paymentPlan).InstallmentPlan.click()
  }

  override function createABoundPolicyFor(baseState : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setTermType(termType : TermType) {
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var policyInfoScreen = submissionWizard.LOBWizardStepGroup.PolicyInfo.click()
    policyInfoScreen.SubmissionWizard_PolicyInfoDV.PolicyInfoInputSet.TermType.clickFirstOptionWithMatchingValue(\option -> option == termType.Code)
    policyInfoScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    logout()
  }

  override function withdraw(closeOption : String, closeReason : String) {
    var user = (closeOption == "Decline") ? UserUnderwriterRole : CurrentUser // Underwriter role is required to decline
    logout()
    var submissionWizard = loginIfLoggedOut(user).goToSubmission(ScenarioInfoProvider.JobNumber)
    var quoteStep = submissionWizard.ViewQuote.click()

    var closeOptions = quoteStep.JobWizardToolbarButtonSet_Submission.CloseOptions
    if (closeOption == "Not-Taken") {
      closeOptions.NotTakenJob.click()
    } else if (closeOption == "Decline") {
      closeOptions.Decline.click()
    } else if (closeOption == "Withdraw Transaction") {
      closeOptions.WithdrawJob.click()
    }

    // delegate to the super class to finish closing the quote
    super.withdraw(closeOption, closeReason)
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var jobWizard = loginAsUser(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = jobWizard.goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var coverageStep = gotoPersonalAutoScreen()
    NavigationManager.CurrentPCFElement = coverageStep.PAPerVehiclePanelSet
    _lineContextDelegate.addVehicleLevelCoverage(covName, coverageTerms)
  }

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var coverageStep = gotoPersonalAutoScreen()
    NavigationManager.CurrentPCFElement = coverageStep.PersonalAuto_AllVehicleCoveragesDV
    _lineContextDelegate.addLineLevelCoverage(covName, coverageTerms)
  }

  override function removeLineLevelCoverage(covName: String) {
    var coverageStep = gotoPersonalAutoScreen()
    NavigationManager.CurrentPCFElement = coverageStep.PersonalAuto_AllVehicleCoveragesDV
    _lineContextDelegate.removeLineLevelCoverage(covName)
  }

  override function viewRatingWorksheet() {
    var submissionWizard =loginIfLoggedOut(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var quoteStep = submissionWizard.PAMode.goToQuoteStep()

    NavigationManager.CurrentPCFElement = quoteStep.RatingCumulDetailsPanelSet_PersonalAutoLine
    _lineContextDelegate.viewRatingWorksheet()
  }

  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(period)
    var coverageStep = submissionWizard.PAMode.goToPAStep()

    assertThat(period.Status)
        .as("this step requires submission in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)

    // Check coverage and covterms with values
    assertThat(ProductModelReflectUtil.hasCoverage(covName, coverageStep, true))
        .as("This coverage should be selected: " + covName)
        .isTrue()

    if (coverageTerms?.Keys?.HasElements) {
      assertThat(ProductModelReflectUtil.hasCoverageWithCovTermValues(covName, coverageTerms, coverageStep, true))
          .as("Covterms should exist for this coverage")
          .isTrue()
    }
  }

  override function verifyLineLevelCoverageDoesNotExist(covName: String) {
    var period = DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var coverageStep = submissionWizard.PAMode.goToPAStep()
    assertThat(ProductModelReflectUtil.hasCoverage(covName, coverageStep, true))
        .as("This coverage shouldn't be available: " + covName)
        .isFalse()

  }

  override function verifyFinancialTransactions(expectedCosts : Map<String, MonetaryAmount>) {
    var policyFile = loginAsUser("su").goToPolicyFile(ScenarioInfoProvider.PolicyNumber)

    var period = DataSetup.Entity
    period = period.getSlice(period.EditEffectiveDate)

    var costEntriesDatabase = period.PATransactions.mapToKeyAndValue(\transaction -> transaction.Cost.DisplayName, \transaction -> transaction.Amount)

    var policyFileTransactions = policyFile.goToFinancialTransactionsPopup()
    var costEntriesUI = policyFileTransactions._Entries.mapToKeyAndValue(\entry -> entry.Cost.Text, \entry -> MonetaryAmounts.ofDefaultCurrency(entry.TxnAmount.Value))

    assertCostTransactionsAreSame(expectedCosts, costEntriesDatabase)
    assertCostTransactionsAreSame(expectedCosts, costEntriesUI)
  }

  function verifyCostsExists(costsMap : Map<String, MonetaryAmount>) {
    var jobWizard = loginAsUser(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var quoteSummaryDV : pcftest.Quote_SummaryDV
    var otherCostsInMonetaryAmount : Map<String, MonetaryAmount> = new HashMap<String, MonetaryAmount>()
    var quoteStep = jobWizard.PAMode.goToQuoteStep()
    quoteStep.SubmissionWizard_Quote_CumulativeCardTab.click()
    // Only coverages are included here -  Liability - Bodily Injury and Property Damage Coverage,
    // Medical Payments Coverage, Comprehensive Coverage, Collision Coverage, etc
    otherCostsInMonetaryAmount = quoteStep.coveragesForVehicle(0, 0)
        .filterByKeys(\k -> costsMap.containsKey(k))
    // Get all other costs to map - Total Premium, Taxes & Surcharges, Total Cost and other fields which may not be costs (eg. Address, County..etc)
    var uiCostMap = UIHelper.getFieldValues({quoteStep})

    uiCostMap.filterByKeys(\k -> costsMap.containsKey(k)).eachKeyAndValue(\k, val -> {
      otherCostsInMonetaryAmount.put(k, MonetaryAmounts.ofDefaultCurrency(val))
    })
    quoteSummaryDV = quoteStep.Quote_SummaryDV
    assertCostTransactionsAreSame(costsMap, otherCostsInMonetaryAmount)
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}