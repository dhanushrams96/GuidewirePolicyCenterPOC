package gw.cucumber.context.impl.smoketest.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.database.Query
uses gw.api.database.Relop
uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses gw.cucumber.util.lob.hop.ConstructionUIFieldsProvider
uses gw.cucumber.util.lob.hop.DwellingUIFieldsProvider
uses pcftest.HOPDwellingScreen

class HOPSubmissionContextFullQuoteImpl extends HOPSubmissionContextImplBase implements HOPContext {
  @Inject delegate _lineContextDelegate represents HOPContext

  override function viewRatingWorksheet() {
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var quoteStep = submissionWizard.HOPMode.goToQuoteStep()

    NavigationManager.CurrentPCFElement = quoteStep.RatingCumulDetailsPanelSet_HOPLine
    _lineContextDelegate.viewRatingWorksheet()
  }

  override function addScheduledPersonalPropertyCoverage(coverageTerms : DataTable) {
    var coverage = coverageTerms.asMap(String, String)
    var coverageStep = loginIfLoggedOut(CurrentUser).goToSubmission(DataSetup.Entity).HOPMode.goToCoveragesStep()
    coverageStep.addScheduledPersonalPropertyCoverageWith(coverage)
  }

  override function verifyCoverageExistsOnPolicyReview(coverageName : String) {
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var policyReviewStep = submissionWizard.PolicyReview.click()

    var coverageExists = policyReviewStep.HOPMode.OptionalCoverages.hasMatch(\cov ->
        cov.Description.Text == coverageName)

    assertThat(coverageExists)
        .as("Coverage ${coverageName} is not found on Policy Review step")
        .isEqualTo(true)
  }

  override function addDwellingInfo(givenFields : DataTable) {
    var dwellingInfo = givenFields.asMap(String, String)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()

    addLocationInfo(dwellingInfo, dwellingStep)
    UIHelper.setFieldValues(dwellingStep, new DwellingUIFieldsProvider(dwellingInfo))
    dwellingStep.addHazard(dwellingInfo)
    dwellingStep.addAnimal(dwellingInfo)

    dwellingStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  private function addLocationInfo(givenFields : Map<String, String>, dwellingScreen : HOPDwellingScreen) {
    var locationPopup = dwellingScreen.clickOnNewDwellingLocation()
    var locationScreen = locationPopup.LocationScreen

    UIHelper.setFieldValues(locationScreen, new UIFieldsProviderBase(givenFields) {

      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.AddressBook.AddressInputSet.Address1"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.City")}
      }

      override property get DefaultFields() : Map<String, String> {
        var location : String[] = givenFields.get("Location").split(":|,")
        return {
            DisplayKey.get("Web.AddressBook.AddressInputSet.Address1") -> location[1].trim(),
            DisplayKey.get("Web.AddressBook.AddressInputSet.City") -> location[2].trim()
        }
      }
    })
    locationScreen.Update.click()
  }

  override function verifyDwellingInfo(expectedDwellingInfo : DataTable) {
    var expectedFields = expectedDwellingInfo.asMap(String, String)
    var job = Query.make(Job).compare(Job#JobNumber, Relop.Equals, ScenarioInfoProvider.JobNumber).select().AtMostOneRow
    var dwelling = job.LatestPeriod.HOPLine.HOPDwellings.single()
    var location = dwelling.Location
    assertThat(location.DisplayName).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.LocationName")))
    assertThat(location.TerritoryCodes.single().Code).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.LocationContainer.Location.TerritoryCode", "Homeowners Line")))
    assertThat(dwelling.DwellingLocation).isEqualTo(new TypelistTransformer<DwellingLocationType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.LocationType"))))
    assertThat(dwelling.ResidenceType).isEqualTo(new TypelistTransformer<ResidenceType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.ResidenceType"))))
    assertThat(dwelling.ReplacementCost.Amount).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.EstimatedReplacementCost")).toBigDecimal())
    assertThat(dwelling.UnitsNumber).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.NumberOfUnitsBetweenFirewall")).toInt())
    assertThat(dwelling.InsuredUnits).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwelling.NumberOfInsuredUnits")).toInt())
    assertThat(dwelling.DwellingUsage).isEqualTo(new TypelistTransformer<DwellingUsage>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingOccupancy.DwellingUsageType"))))
    assertThat(dwelling.Occupancy).isEqualTo(new TypelistTransformer<DwellingOccupancyType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingOccupancy.DwellingOccupancyType"))))
    assertThat(dwelling.RoomerBoardersNumber).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingOccupancy.NumberOfRoomers")).toInt())
    assertThat(dwelling.BurglarAlarmType).isEqualTo(new TypelistTransformer<BurglarAlarmType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.BurglarAlarmType"))))
    assertThat(dwelling.Deadbolts).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.DoorsHaveDeadbolts")).toBoolean())
    assertThat(dwelling.DistanceToFireHydrant).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.DistanceToFireHydrant")).toInt())
    assertThat(dwelling.DistanceToFireStation).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.DistanceToFireStation")).toInt())
    assertThat(dwelling.Location.FireProtectClass).isEqualTo(new TypelistTransformer<FireProtectClass>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.FireProtectionClass"))))
    assertThat(dwelling.FireAlarmType).isEqualTo(new TypelistTransformer<FireAlarmType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.FireAlarm"))))
    assertThat(dwelling.NumberOfFireExtinguishers).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.NumberOfFireExtinguishers")).toInt())
    assertThat(dwelling.SmokeAlarm).isEqualTo(new TypelistTransformer<SmokeAlarms>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.SmokeAlarms"))))
    assertThat(dwelling.SprinklerSystemType).isEqualTo(new TypelistTransformer<SprinklerSystemType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.SprinklerSystemType"))))
    assertThat(dwelling.VisibleToNeighbors).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.VisibleToNeighbors")).toBoolean())
    dwelling.DwellingHazards.each(\hazard -> {
      assertThat(hazard.SpecificHazard).isEqualTo(new TypelistTransformer<SpecificHazard>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingHazard.SpecificHazard"))))
      assertThat(hazard.HazardType).isEqualTo(new TypelistTransformer<HazardType>().transform(expectedFields.get("Hazard Type")))
      assertThat(hazard.AdditionalInformation).isEqualTo(expectedFields.get("Hazard Additional Information"))
    })
    dwelling.DwellingAnimals.each(\animal -> {
      assertThat(animal.AnimalType).isEqualTo(new TypelistTransformer<AnimalType>().transform(expectedFields.get("Animal Type")))
      assertThat(animal.AnimalBreed).isEqualTo(new TypelistTransformer<AnimalBreed>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBreed"))))
      assertThat(animal.AnimalBiteHistory).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBiteHistory")).toBoolean())
    })
    var hasSwimmingPool = (dwelling.SwimmingPool != null) as Boolean
    assertThat(hasSwimmingPool).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.SwimmingPool.HasPool")).toBoolean())
    assertThat(dwelling.SwimmingPool.PoolType).isEqualTo(new TypelistTransformer<HOPSwimmingPoolType>().transform(expectedFields.get(DisplayKey.get("Web.Policy.HOP.SwimmingPool.Type"))))
    assertThat(dwelling.SwimmingPool.ApprovedFence).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.SwimmingPool.ApprovedFence")).toBoolean())
    assertThat(dwelling.SwimmingPool.DivingBoard).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.SwimmingPool.DivingBoard")).toBoolean())
    assertThat(dwelling.SwimmingPool.Slide).isEqualTo(expectedFields.get(DisplayKey.get("Web.Policy.HOP.SwimmingPool.Slide")).toBoolean())
  }

  override function setDistanceToFireHydrantAndFireStation(firehydrantDistances : DataTable) {
    var firehydrant = firehydrantDistances.asMap(String, String)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()
    var protectionInputSet = dwellingStep.HOPDwellingProtectionInputSet
    UIHelper.setFieldValues(protectionInputSet, new UIFieldsProviderBase(firehydrant) {

      override property get RequiredFields() : Set<String> {
        return {
            DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.DistanceToFireHydrant"),
            DisplayKey.get("Web.Policy.HOP.HOPDwellingProtection.DistanceToFireStation")
        }
      }

      override property get DefaultFields() : Map<String, String> {
        return {}
      }
    })

    dwellingStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function clickAutofillProtectionClass() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()
    dwellingStep.clickAutofillProtectionClass()
    dwellingStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyFireProtectionClassCode(fireProtectionClassCode : String) {
    var job = Query.make(Job).compare(Job#JobNumber, Relop.Equals, ScenarioInfoProvider.JobNumber).select().AtMostOneRow
    var dwelling = job.LatestPeriod.HOPLine.HOPDwellings.single()
    var expectedCode = new TypelistTransformer<FireProtectClass>().transform(fireProtectionClassCode)
    var actualCode = dwelling.Location.FireProtectClass
    assertThat(actualCode)
        .as("Expected fire protection class code ${expectedCode.DisplayName} does not match with actual code ${actualCode.DisplayName}")
        .isEqualTo(expectedCode)
  }

  override function addDwellingHazards(hazardsMap : DataTable) {
    var hazards = hazardsMap.asMaps(String, String)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingStep = submissionWizard.HOPMode.goToDwellingStep()

    for (hazard in hazards) {
      var hazardsInputSet = dwellingStep.HOPDwellingHazardsInputSet
      hazardsInputSet.Add.click()
      var hazardEntry = hazardsInputSet._Entries.last()
      hazardEntry.SpecificHazard.getOptionByLabel(hazard.get("Specific Hazard")).click()
      hazardEntry.HazardType.getOptionByLabel(hazard.get("Type")).click()
      hazardEntry.AdditionalInformation.setValue(hazard.get("Additional Information"))
    }
    dwellingStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyDwellingHazardsInfo(hazardsInfo : DataTable) {
    var expectedHazardsInfoMap = hazardsInfo.asMaps(String, String)
    var job = Query.make(Job).compare(Job#JobNumber, Relop.Equals, ScenarioInfoProvider.JobNumber).select().AtMostOneRow
    var dwelling = job.LatestPeriod.HOPLine.HOPDwellings.single()

    expectedHazardsInfoMap.each(\expectedHazard -> {
      assertThat(dwelling.DwellingHazards.hasMatch(\hazard ->
          hazard.SpecificHazard.equals(expectedHazard.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingHazard.SpecificHazard"))) and
          hazard.HazardType.equals(expectedHazard.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingHazard.HazardType"))) and
          hazard.AdditionalInformation.equals(expectedHazard.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingHazard.AdditionalInformation")))))
    })
  }

  override function setConstructionTypeAsOther() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    constructionDetailsDV.ConstructionType.setTypeKeyValue(HOPConstructionType.TC_OTHER)
    dwellingConstructionStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyConstructionTypeDescriptionFieldProvided() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    assertThat(constructionDetailsDV.ConstructionTypeDescription.Visible and constructionDetailsDV.ConstructionTypeDescription.Visible)
        .as("Construction Type Description field is not found on Dwelling Construction step")
        .isEqualTo(true)
  }

  override function setRoofTypeAsOther() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    constructionDetailsDV.RoofType.setTypeKeyValue(HOPRoofType.TC_OTHER)
    dwellingConstructionStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyRoofTypeDescriptionFieldProvided() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    assertThat(constructionDetailsDV.RoofTypeDescription.Visible and constructionDetailsDV.RoofTypeDescription.Editable)
        .as("Roof Type Description field is not found on Dwelling Construction step")
        .isEqualTo(true)
  }

  override function setPrimaryHeatingTypeAsOil() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    constructionDetailsDV.PrimaryHeatingType.setTypeKeyValue(HeatingType.TC_OIL)
    dwellingConstructionStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyFuelStorageTankAndFuelLineFieldsProvided() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    var constructionDetailsDV = dwellingConstructionStep.HOPDwellingConstructionPanelSet.HOPDwellingConstructionDetailsDV
    assertThat(constructionDetailsDV.FuelStorageTankLocation.Visible and constructionDetailsDV.FuelStorageTankLocation.Editable)
        .as("Fuel Storage Tank field is not found on Dwelling Construction step")
        .isEqualTo(true)
    assertThat(constructionDetailsDV.FuelLineLocation.Visible and constructionDetailsDV.FuelLineLocation.Editable)
        .as("Fuel Line field is not found on Dwelling Construction step")
        .isEqualTo(true)
  }

  override function enterConstructionInfo(constructionInfo : DataTable) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var dwellingConstructionStep = submissionWizard.HOPMode.goToDwellingConstruction()
    UIHelper.setFieldValues(dwellingConstructionStep, new ConstructionUIFieldsProvider(constructionInfo.asMap(String, String)))

    dwellingConstructionStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyConstructionInfo(constructionInfo : DataTable) {
    var expectedConstructionInfo = constructionInfo.asMap(String, String)
    var job = Query.make(Job).compare(Job#JobNumber, Relop.Equals, ScenarioInfoProvider.JobNumber).select().AtMostOneRow
    var dwelling = job.LatestPeriod.HOPLine.HOPDwellings.single()
    assertThat(dwelling.YearBuilt).isEqualTo(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.YearBuilt")).toInt())
    assertThat(dwelling.ConstructionType).isEqualTo(new TypelistTransformer<HOPConstructionType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.ConstructionType"))))
    assertThat(dwelling.StoriesNumber).isEqualTo(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.NumberOfStories")).toInt())
    assertThat(dwelling.GarageType).isEqualTo(new TypelistTransformer<GarageType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.GarageType"))))
    assertThat(dwelling.Foundation).isEqualTo(new TypelistTransformer<FoundationType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.FoundationType"))))
    assertThat(dwelling.RoofType).isEqualTo(new TypelistTransformer<HOPRoofType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.RoofType"))))
    assertThat(dwelling.PrimaryHeatingType).isEqualTo(new TypelistTransformer<HeatingType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.PrimaryHeating"))))
    assertThat(dwelling.SecondaryHeatingType).isEqualTo(new TypelistTransformer<HeatingType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.SecondaryHeating"))))
    assertThat(dwelling.PlumbingType).isEqualTo(new TypelistTransformer<PlumbingType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.Plumbing"))))
    assertThat(dwelling.WiringType).isEqualTo(new TypelistTransformer<WiringType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.Wiring"))))
    assertThat(dwelling.ElectricalType).isEqualTo(new TypelistTransformer<BreakerType>().transform(expectedConstructionInfo.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingConstruction.ElectricalSystem"))))
    assertThat(dwelling.RoofingUpgradeDate).isEqualTo(expectedConstructionInfo.get("Roof - Year").toInt())
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var riskAnalysisScreen = loginAsUser(UserUnderwriterManagerRole).goToSubmission(ScenarioInfoProvider.JobNumber).goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    riskAnalysisScreen.RiskAnalysisCV.RiskEvaluationPanelSet.UserViewFilter.getOptionByLabel("View All").click()
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function approveUWIssuesAsUnderwriter(description : String, validUntil : String) {
    logout()
    var riskAnalysisScreen = loginAsUser(UserUnderwriterManagerRole).goToSubmission(ScenarioInfoProvider.JobNumber).goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    riskAnalysisScreen.RiskAnalysisCV.RiskEvaluationPanelSet.UserViewFilter.getOptionByLabel("View All").click()
    super.approveUWIssuesAsUnderwriter(description, validUntil)
  }

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var coverageStep = gotoHOPCoveragesScreen()
    NavigationManager.CurrentPCFElement = coverageStep.HOPMainCoveragesPanelSet
    _lineContextDelegate.addLineLevelCoverage(covName, coverageTerms)
  }

  override function addScheduledPersonalProperty(scheduledPersonalProperties : DataTable) {
    var propertiesMap = scheduledPersonalProperties.asMaps(String, String)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    var coveragesStep = submissionWizard.HOPMode.goToHOPCoveragesScreen()
    coveragesStep.HOPOptionalCoveragesTab.click()
    coveragesStep.HOPScheduledPersonalPropertyCheckBox.click()
    var hopSchedInputSet = coveragesStep.HOPScheduledPersonalPropertyInput.CovPatternInputGroup.ScheduleInputSet_true
    hopSchedInputSet.Add.click()
    var schedPropEntry = hopSchedInputSet.ScheduledItemsIterator._Entries.last()

    for (prop in propertiesMap) {
      schedPropEntry.PropertyValues._Entries[0].ScheduledItemColumnInput_String.StringValue.Value = prop.get("Description")                       // Description
      schedPropEntry.PropertyValues._Entries[1].ScheduledItemColumnInput_String.StringValue.Value = prop.get("Serial No")                         // Serial No
      schedPropEntry.PropertyValues._Entries[2].ScheduledItemColumnInput_String.StringValue.Value = prop.get("Appraiser")                         // Appraiser
      schedPropEntry.PropertyValues._Entries[4].ScheduledItemColumnInput_Date.DateValue.Value = prop.get("Date Of Appraisal")                     // Date Of Appraisal
      schedPropEntry.CovTermValues._Entries[0].ScheduledItemCovTermInput_Option.TermValue.getOptionByLabel(prop.get("Type")).click()              // Type
      schedPropEntry.CovTermValues._Entries[1].ScheduledItemCovTermInput_Direct.DirectTermInput.Value = prop.get("Limit")                         // Limit
      schedPropEntry.CovTermValues._Entries[2].ScheduledItemCovTermInput_Option.TermValue.getOptionByLabel(prop.get("Deductible")).click()        // Deductible
      schedPropEntry.CovTermValues._Entries[3].ScheduledItemCovTermInput_Option.TermValue.getOptionByLabel(prop.get("Valuation Method")).click()  // Valuation Method
      schedPropEntry.CovTermValues._Entries[4].ScheduledItemCovTermInput_Direct.DirectTermInput.Value = prop.get("Appraised Value")               // Appraised Value
    }

    coveragesStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyHOPInfoAvailable(hopInfo : DataTable) {
    var hopInfoList = hopInfo.asList(String)
    var submissionWizard = loginIfLoggedOut(CurrentUser).goToSubmission(ScenarioInfoProvider.JobNumber)
    var policyReviewScreen = submissionWizard.PolicyReview.click()
    NavigationManager.CurrentPCFElement = policyReviewScreen

    if (hopInfoList.contains(DisplayKey.get("Web.SubmissionWizard.PolicyReview.Product"))) {
      assertThat(policyReviewScreen.SubmissionWizard_ReviewSummaryDV.Product.Visible)
          .as("Product is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.AddressBook.AddressInputSet.AddressSummary"))) {
      assertThat(policyReviewScreen.SubmissionWizard_ReviewSummaryDV.PolicyAddress.PolicyAddressDisplayInputSet.Address.ValueVisible)
          .as("Address is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.SubmissionWizard.PolicyReview.EffectiveDate"))) {
      assertThat(policyReviewScreen.SubmissionWizard_ReviewSummaryDV.EffectiveDate.Visible)
          .as("Effective Date is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.SubmissionWizard.PolicyReview.ExpirationDate"))) {
      assertThat(policyReviewScreen.SubmissionWizard_ReviewSummaryDV.ExpirationDate.Visible)
          .as("Expiration Date is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.HOP.CoveragePart"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.CoveragePartSelectionDV_HOPHomeowners.HOPCoveragePartType.Visible)
          .as("Policy Type is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.HOP.CoverageForm"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.CoveragePartSelectionDV_HOPHomeowners.HOPCoverageForm.Visible)
          .as("Coverage Form is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.HOP.Quote.SectionICoverages.Line.Title"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.SectionICoverageLV.CoverageSummaryLV._Entries.HasElements)
          .as("Section I Coverages is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.HOP.HOPCoveragesScreen.AdditionalCoverages"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.AdditionalCoverageLV.CoverageSummaryLV._Entries.HasElements)
          .as("Additional Coverages is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.HOP.HOPCoveragesScreen.OptionalCoverages"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.OptionalCoverageLV.CoverageSummaryLV._Entries.HasElements)
          .as("Optional Coverages is not found on Policy Review step")
          .isEqualTo(true)
    }
    if (hopInfoList.contains(DisplayKey.get("Web.Policy.Coverages.PolicyConditions"))) {
      assertThat(policyReviewScreen.ReviewSummaryCV_default._Entries[0].PolicyLineSummaryPanelSet_HOPLine.ConditionSummaryLV.CoverageSummaryLV._Entries.HasElements)
          .as("Policy Conditions is not found on Policy Review step")
          .isEqualTo(true)
    }
  }

  override function verifyTransactionSavedSuccessfully() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(period)
    submissionWizard.HOPMode.saveDraft()
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function providesAnApprovedNonCopperWiringUWIssueWithValidUntil(validUntil : String) {
    causeNonCopperWiringUWIssue()
    setJobStatus(new TypelistTransformer<PolicyPeriodStatus>().transform("Quoted"))
    approveUWIssuesAsUnderwriter("Non-copper wiring", validUntil)
  }
}