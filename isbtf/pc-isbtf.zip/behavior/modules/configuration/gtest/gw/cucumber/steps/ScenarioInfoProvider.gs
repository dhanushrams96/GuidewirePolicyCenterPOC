package gw.cucumber.steps

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.cucumber.util.lob.ProductCode
uses gw.cucumber.setup.AccountDataSetup
uses gw.cucumber.setup.JobDataSetup
uses pcftest.NewSubmission
uses typekey.Job

/**
 * Maintains the current state of the scenario.
 * Provides access to the current state for a step.
 * Allows a step to get important strings or numbers to help navigate.
 * Provides access to the {@link gw.cucumber.setup.DataSetup} for a step.
 */
@Export
@ScenarioScoped
class ScenarioInfoProvider {
  var _basedOn : PolicyPeriod as BasedOnPolicyPeriod
  var _accountDataSetup : AccountDataSetup as AccountDataSetup
  var _paDataSetup : JobDataSetup as DataSetup

  var _accountNumber : String as AccountNumber
  var _jobNumber : String as JobNumber
  var _policyNumber : String as PolicyNumber
  var _termNumber : Integer as TermNumber
  var _line : ProductCode as Line
  var _jobSubType : Job as JobSubType
  var _newSubmission: NewSubmission as NewSubmission
  var _newSubmissionQuoteType: QuoteType as NewSubmissionQuoteType
  var _sliceDate : Date as SliceDate

  var _branchMap : Map<String, PolicyPeriod> as BranchMap = {}

  property get AccountNumber() : String {
    _accountNumber = _accountNumber ?: this.AccountDataSetup?.Entity.AccountNumber
    return _accountNumber
  }

  property get JobNumber() : String {
    _jobNumber = _jobNumber ?: this.DataSetup?.Entity.Job.JobNumber
    return _jobNumber
  }

  property get PolicyNumber() : String {
    _policyNumber = _policyNumber ?: this.DataSetup.Entity.PolicyNumber
    return _policyNumber
  }

  property get BasedOnPolicyPeriod() : PolicyPeriod {
    _basedOn = _basedOn ?: this.DataSetup.Entity
    return _basedOn
  }
}