package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.NonSubmissionJobBuilder
uses gw.api.database.Query
uses gw.api.database.Relop
uses typekey.Job

@Export
@ScenarioScoped
class NonSubmissionDataSetup<B extends NonSubmissionJobBuilder<B>> extends JobDataSetup<B> {
  var _basedOnPolicyPeriod : PolicyPeriod as BasedOnPolicyPeriod
  var _username : String

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username)
    _username = username
    _basedOnPolicyPeriod = basedOnPeriod
  }

  construct (basedOnPeriod : PolicyPeriod) {
    super()
    _basedOnPolicyPeriod = basedOnPeriod
  }

  protected override function initializeBuilder(builder : B) {
    super.initializeBuilder(builder)
    if (BasedOnPolicyPeriod == null) {
      BasedOnPolicyPeriod = createBasedOn()
    }
    builder
        .withBasedOnPeriod(BasedOnPolicyPeriod)
        .isDraft()
  }

  protected function createBasedOn() : PolicyPeriod {
    var basedOn : PolicyPeriod
    gw.transaction.Transaction.runWithNewBundle(\ bundle -> {
      var datasetup = new PASubmissionDataSetup(_username)
      datasetup.isQuoted()
      basedOn = datasetup.Entity
      basedOn = bundle.add(basedOn)
      basedOn.JobProcess.bind()
    }, "su")
    return basedOn
  }

  static function findNewestPolicyPeriodFromBasedOnAndEffectiveDate(basedOn : PolicyPeriod, effectiveDate : Date) : PolicyPeriod {
    var dateCondition = effectiveDate != null
        ? \policyPeriod : PolicyPeriod -> policyPeriod.EditEffectiveDate.trimToMidnight() == effectiveDate.trimToMidnight()
        : \policyPeriod : PolicyPeriod -> true
    var queryResult = Query.make(PolicyPeriod)
        .compare(PolicyPeriod#BasedOn, Relop.Equals, basedOn)
        .compare(PolicyPeriod#Status, Relop.Equals, PolicyPeriodStatus.TC_DRAFT)
        .select()
    var period = queryResult
        .where(dateCondition)
        .sortByDescending(\pp -> pp.CreateTime)
        .first()
    if (period == null) {
      throw new IllegalStateException("Can't find the expected PolicyPeriod")
    }
    return period
  }

  static function findPolicyPeriodFromBasedOn(basedOn : PolicyPeriod, jobType : Job) : PolicyPeriod {
    var queryResult = Query.make(PolicyPeriod)
        .compare(PolicyPeriod#BasedOn, Relop.Equals, basedOn).withLogSQL(true)
        .select()
    return queryResult.singleWhere(\elt -> elt.Job.Subtype == jobType)
  }
}