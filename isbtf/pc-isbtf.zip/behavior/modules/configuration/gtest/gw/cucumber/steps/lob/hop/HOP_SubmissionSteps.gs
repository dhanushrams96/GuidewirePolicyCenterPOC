package gw.cucumber.steps.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses cucumber.api.java.en.Then
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.setup.DataTableRepository

/**
 * Homeowners specific {@link Submission} job steps
 */
@Export
class HOP_SubmissionSteps {
  @Inject
  var _contextFactory : ContextFactory
  @Inject
  var _dataTableRepository : DataTableRepository

  @Given("^a Homeowners submission$")
  function aHomeownerSubmission() {
    _contextFactory.getSubmissionContext().createSubmissionSetup()
  }

  @Given("^an in-force Homeowners policy$")
  function anInForceHomeownersPolicy() {
    _contextFactory.getSubmissionContext().createABoundPolicy()
  }

  @Given("^an in-force Homeowners policy of policy type \"([^\"]*)\" and coverage form \"([^\"]*)\"$")
  function anInForceHomeownersPolicyWithThePolicyTypeAndCoverageForm(policyType : String, coverageForm : String) {
    (_contextFactory.getSubmissionContext() as HOPContext).createABoundPolicyWithPolicyTypeAndCoverageForm(policyType, coverageForm)
  }

  @Given("^a bound but not issued Homeowners submission$")
  function givenABoundHomeownersPolicyWithIssuanceHold() {
    _contextFactory.getSubmissionContext().createABoundPolicy(true)
  }

  @Given("^of type \"([^\"]*)\" and coverage form \"([^\"]*)\"$")
  function aHODwellingHomeownersSubmission(policyType : String, coverageForm : String) {
    (_contextFactory.getSubmissionContext() as HOPContext).setPolicyTypeAndCoverageForm(policyType, coverageForm)
  }

  @Given("^a \"([^\"]*)\" occupies this dwelling$")
  function aOccupiesThisDwelling(occupier : String) {
    (_contextFactory.getSubmissionContext() as HOPContext).setWhoOccupiesThisDwelling(occupier)
  }

  @Given("^the submission has a Non-copper wiring UW issue$")
  function submissionHasNonCopperWiringUWIssue() {
    (_contextFactory.getSubmissionContext() as HOPContext).causeNonCopperWiringUWIssue()
  }

  @Then("^a premium exists for the scheduled item$")
  function verifyPremiumForScheduledItem() {
    (_contextFactory.getSubmissionContext() as HOPContext).verifyScheduledItemPremiumExist()
  }

  @When("^I add the Scheduled Personal Property coverage$")
  function iAddTheScheduledPersonalPropertyCoverage(scheduledItemInfoTable : DataTable) {
    (_contextFactory.getSubmissionContext() as HOPContext).addScheduledPersonalPropertyCoverage(scheduledItemInfoTable)
  }

  @Then("^the policy should have the \"([^\"]*)\" optional coverage$")
  function iShouldSeeInPolicyReview(coverageName : String) {
    (_contextFactory.getSubmissionContext() as HOPContext).verifyCoverageExistsOnPolicyReview(coverageName)
  }

  @When("^I set the new policy location without save$")
  function iSetTheNewPolicyLocation(newLocationTable : DataTable) {
    (_contextFactory.getSubmissionContext() as HOPContext).addNewPolicyLocationWithoutSave(newLocationTable)
  }

  @Then("^I should get homeowners territory code \"([^\"]*)\"$")
  function iShouldGetHomeownersTerritoryCodeAs(code : String) {
    (_contextFactory.getSubmissionContext() as HOPContext).verifyTerritoryCodeOnPopup(code)
  }
}