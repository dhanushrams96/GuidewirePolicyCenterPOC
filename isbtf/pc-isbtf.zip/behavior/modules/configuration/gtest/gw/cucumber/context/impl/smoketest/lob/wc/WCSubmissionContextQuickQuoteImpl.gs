package gw.cucumber.context.impl.smoketest.lob.wc

@Export
class WCSubmissionContextQuickQuoteImpl extends WCSubmissionContextImpl {

}