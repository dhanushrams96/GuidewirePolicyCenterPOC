package gw.cucumber.steps.account

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory

@Export
class AccountSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Given("^an account of type \"(Person|Company)\"$")
  function createAccount(contactTypeText : String, accountData : DataTable) {
    _contextFactory.getAccountContext().createAccount(contactTypeText, accountData.asMap(String, String))
  }

  @When("^I update the Account data with the following:$")
  function iUpdateAccount(updateAccountData : DataTable) {
    _contextFactory.getAccountContext().editAccount(updateAccountData.asMap(String, String))
  }

  @When("^I update the Account's primary location data with the following$")
  function iUpdateAccountsPrimaryLocation(updateAccountLocationData : DataTable) {
    _contextFactory.getAccountContext().editAccountPrimaryLocation(updateAccountLocationData)
  }

  @Then("^Account \"([^\"]+)\" should contain the following data:$")
  function verifyAccountHolderDetails(accNumber : String, data : DataTable) {
    _contextFactory.getAccountContext().verifyAccountHolderDetails(accNumber, data.asMap(String,String))
  }


  @Given("^the following account of type Person does not exist:$")
  function accountPersonDoesNotExist(contactInfo : DataTable) {
    _contextFactory.getAccountContext().verifyAccountPersonDoesNotExist(contactInfo.asMap(String, String))
  }

  @Given("^the following account of type Company does not exist:$")
  function accountCompanyDoesNotExist(contactInfo : DataTable) {
    _contextFactory.getAccountContext().verifyAccountCompanyDoesNotExist(contactInfo.asMap(String, String))
  }

  @When("^I create the following account of type Company:$")
  function iCreateAnAccountOfTypeCompany(accountInfo : DataTable) {
    _contextFactory.getAccountContext().createAccountOfTypeCompany(accountInfo.asMap(String, String))
  }


  @When("^I create the following account of type Person:$")
  function iCreateAnAccountOfTypePerson(accountInfo : DataTable) {
    _contextFactory.getAccountContext().createAccountOfTypePerson(accountInfo.asMap(String, String))
  }


  @Then("^an account of type Person exists for the following:$")
  function accountOfTypePersonShouldExist(accountInfo : DataTable) {
    _contextFactory.getAccountContext().verifyAccountPersonExists(accountInfo.asMap(String, String))
  }

  @Then("^an account of type Company exists for the following:$")
  function accountOfTypeCompanyShouldExist(accountInfo : DataTable) {
    _contextFactory.getAccountContext().verifyAccountCompanyExists(accountInfo.asMap(String, String))
  }
}