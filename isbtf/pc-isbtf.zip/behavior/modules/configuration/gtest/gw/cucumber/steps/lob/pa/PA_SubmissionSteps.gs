package gw.cucumber.steps.lob.pa

uses com.google.inject.Inject
uses cucumber.api.java.en.Given
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.pa.PAContext

/**
 * Personal Auto specific {@link Submission} job steps
 */
@Export
class PA_SubmissionSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Given("^a Personal Auto submission$")
  function aPersonalAutoSubmission() {
    _contextFactory.getSubmissionContext().createSubmissionSetup()
  }

  @Given("^an in-force Personal Auto policy$")
  function givenAnInForcePersonalAutoPolicy() {
    _contextFactory.getSubmissionContext().createABoundPolicy()
  }

  @Given("^a bound but not issued Personal Auto policy$")
  function givenABoundPersonalAutoPolicyWithIssuanceHold() {
    _contextFactory.getSubmissionContext().createABoundPolicy(true)
  }

  @Given("^the submission has a vehicle that costs \"(\\d+)\"$")
  function submissionVehicleCost(cost : int) {
    _contextFactory.getLineContext<PAContext>().setVehicleCost(cost)
  }
}
