package gw.cucumber.steps.job

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.And
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses cucumber.api.java.en.Then
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.setup.DataTableRepository
uses gw.cucumber.transformer.DateTransformer
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.steps.ScenarioInfoProvider

/**
 * {@link Job} steps agnostic of the line of business
 */
@Export
class JobSteps {

  @Inject
  var _scenarioInfoProvider : ScenarioInfoProvider

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _dataTableRepository : DataTableRepository

  @Given("^I create \"([^\"]+)\" as the following named DataTable:$")
  function createNamedDataTable(name : String, dataTable : DataTable) {
    _contextFactory.getJobContext().storeDataTable(name, dataTable)
  }

  @When("^I set the (?:transaction|policy change) effective date to \"([^\"]+)\"$")
  function iSetTransactionEffectiveDate(date : String) {
    var changeEffectiveDate = DateTransformer.transform(date)
    _contextFactory.getJobContext().setEffectiveDate(changeEffectiveDate)
  }

  @Given("^the job status is \"(Draft|Quoted)\"$")
  function jobStatusIs(status : String) {
    var policyPeriodStatus = new TypelistTransformer<PolicyPeriodStatus>().transform(status)
    _contextFactory.getJobContext().setJobStatus(policyPeriodStatus)
  }

  @When("^I store the current job as \"([^\"]+)\"$")
  function iStoreTheCurrentJob(name : String) {
    _contextFactory.getJobContext().storeJobAs(name)
  }

  @When("^I recall \"([^\"]+)\" as the current job$")
  function iRecallCurrentJob(name : String) {
    var period = _contextFactory.getJobContext().retrieveJob(name)

    // when we recall a job we need to update the context to refer to that job
    _scenarioInfoProvider.JobSubType = period.Job.getSubtype()
  }

  @When("^I close the quote using the \"(Not-Taken|Decline)\" option having closing reason \"(Insured's request - N.O.C|Loss history)\"$")
  function closeQuoteWithOptions(closeOption : String, closeReason : String) {
    _contextFactory.getJobContext().withdraw(closeOption, closeReason)
  }

  @When("^I close the quote using the \"(Withdraw Transaction)\"$")
  function closeQuoteWithdraw(closeOption : String) {
    _contextFactory.getJobContext().withdraw(closeOption, null)
  }

  @And("^I select Term Type \"([^\"]+)\"$")
  function iSelectTermType(termType : String) {
    _contextFactory.getJobContext().setTermType(new TypelistTransformer<TermType>().transform(termType))
  }

  @When("^an Underwriter approves \"([^\"]+)\" UW issue$")
  function theUnderwriterApprovesThisIssueBlockingBind(issueDescription : String) {
    _contextFactory.getJobContext().approveUWIssuesAsUnderwriter(issueDescription)
  }

  @When("^an Underwriter Manager approves \"([^\"]+)\" UW issue$")
  function theUnderwriterManagerApprovesThisIssueBlockingBind(issueDescription : String) {
    _contextFactory.getJobContext().approveUWIssuesAsUnderwriter(issueDescription)
  }

  @When("^an Underwriter Manager approves \"([^\"]+)\" UW issue which is valid until \"([^\"]+)\"$")
  function theUnderwriterManagerApprovesThisIssueWithValidUntil(issueDescription : String, validUntil : String) {
    _contextFactory.getJobContext().approveUWIssuesAsUnderwriter(issueDescription, validUntil)
  }

  @Then("^the change in cost should be \"([^\"]*)\"$")
  function theChangeInCost(changeInCost : String) {
    _contextFactory.getJobContext().verifyChangeInCost(changeInCost)
  }

  @Then("^the total cost should be \"([^\"]*)\"$")
  function theTotalCostShouldBe(expectedCost : String) {
    _contextFactory.getJobContext().verifyTotalCost(expectedCost)
  }

  @Then("^the total premium exist$")
  function theTotalPremiumExist(){
    _contextFactory.getJobContext().verifyTotalCostExist()
  }

  @Given("^the UW issue has been approved$")
  function theUnderwritingIssueHasBeenApproved() {
    _contextFactory.getJobContext().approveUWIssues()
  }

  @Given("^the policy requires a final audit$")
  function policyRequiresFinalAudit() {
    _contextFactory.getJobContext().selectFinalAuditOption(FinalAuditOption.TC_YES)
  }

  @Given("^the payment schedule plan type is \"(Payment Plan|Reporting Plan)\"$")
  function paymentSchedulePlanTypeIs(paymentSchedulePlanType : String) {
    var paymentMethod = new TypelistTransformer<PaymentMethod>().transform(paymentSchedulePlanType)
    _contextFactory.getJobContext().selectPaymentMethod(paymentMethod)
  }

  @And("the Premium Reporting Plan is \"([^\"]+)\"$")
  function withPremiumReportingPlanType(reportingPlanType : String) {
    _contextFactory.getJobContext().selectReportingPlan(reportingPlanType)
  }

  @When("^I add the following contingency:$")
  function iAddTheContingency(contingenciesDataTable : DataTable) {
    _contextFactory.getJobContext().addContingency(contingenciesDataTable.asMap(String, String))
  }

  @When("^I add a new additional named insured of type person:$")
  function iAddAnAdditionalNamedInsured(contactInfoTable : DataTable) {
    var contactInfo = _dataTableRepository.dataTableLookup(contactInfoTable).asMap(String, String)
    _contextFactory.getJobContext().addAdditionalNamedInsured(contactInfo)
  }

  @Then("^the additional named insured of type person should exist:$")
  function additionalNamedInsuredShouldExist(contactInfoTable : DataTable) {
    var contactInfo = _dataTableRepository.dataTableLookup(contactInfoTable).asMap(String, String)
    _contextFactory.getJobContext().verifyAdditionalNamedInsuredExists(contactInfo)
  }

  @Then("^the policy with following contingency should exist:$")
  function contingecyShouldExist(contingenciesInfo : DataTable) {
    _contextFactory.getJobContext().verifyContingencyExists(contingenciesInfo.asMap(String, String))
  }

  @Then("^the status of the contingency (?:should be|is) \"(Pending)\"$")
  function theStatusOfContingencyIs(status : String) {
    _contextFactory.getJobContext().verifyContingencyStatus(new TypelistTransformer<ContingencyStatus>().transform(status))
  }

  @When("^I resolve the following contingency:$")
  function iResolveTheContingency(contingencyTable : DataTable) {
    _contextFactory.getJobContext().resolveContingency(contingencyTable.asMap(String, String))
  }

  @Then("^the following UW issues should exist$")
  function uwBindBlockingAndApprovedIssuesExist(uwIssuesTable : DataTable) {
    _contextFactory.getJobContext().verifyUWBindBlockingAndApprovedIssuesExist(uwIssuesTable.asMaps(String, String))
  }

  @Then("^\"(all|no)\" UW issues should be approved$")
  function allUWIssuesAreApproved(isAllApproved : String) {
    _contextFactory.getJobContext().verifyUWApprovedIssues(isAllApproved == "all")
    _contextFactory.getJobContext().verifyUWBindBlockingIssues(isAllApproved != "all")
  }

  @Then("^there should be \"(\\d+)\" versions available")
  function verifyNumberOfVersions(numberOfVersions : int) {
    _contextFactory.getJobContext().verifyNumberOfVersions(numberOfVersions)
  }

  @Then("^the following version(?:s)? should exist:$")
  function verifyMultiQuoteVersions(versionsDataTable : DataTable) {
    var versions = versionsDataTable.asLists(String)
    _contextFactory.getJobContext().verifyMultiQuoteVersions(versions)
  }

  @Then("^the job cannot be quoted because the \"([^\"]*)\"$")
  function theJobCannotBeQuotedBecauseThe(message : String) : void {
    _contextFactory.getJobContext().verifyQuoteFailedWith(message)
  }

  @When("^I add the following company as an additional interest$")
  function iAddANewAdditionalInterestOfTypeCompany(additionalInterestInfoTable : DataTable) {
    _contextFactory.getJobContext().addAdditionalInterestsOfNewCompanyType(additionalInterestInfoTable)
  }

  @Then("^\"([^\"]*)\" should exist as an additional interest on the submission$")
  function theAdditionalInterestOfTypeCompanyShouldExist(companyName : String) {
    _contextFactory.getJobContext().verifyAdditionalInterestsOfNewCompanyType(companyName)
  }

  @Then("^the transaction is saved successfully$")
  function theTransactionSavedSuccessfully() {
    _contextFactory.getJobContext().verifyTransactionSavedSuccessfully()
  }

  @Then("^the following forms should be inferred$")
  function verifyingTheForms(forms : DataTable) {
    _contextFactory.getJobContext().verifyForms(forms)
  }

  @Then("^the following error messages should occur$")
  function theFollowingErrorMessagesShouldoccure(errorMessages : DataTable) {
    _contextFactory.getJobContext().verifyErrorMessagesDisplayed(errorMessages)
  }

  @Then("^the UW company should be defaulted to \"([^\"]+)\"$")
  function theUWCompanyShouldBeDefaulted(uwCompany : String) {
    _contextFactory.getJobContext().verifyUWCompany(uwCompany)
  }
}