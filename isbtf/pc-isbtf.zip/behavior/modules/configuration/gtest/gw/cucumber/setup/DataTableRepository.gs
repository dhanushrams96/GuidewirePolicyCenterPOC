package gw.cucumber.setup

uses cucumber.api.DataTable
uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.system.PCLoggerCategory

@Export
@ScenarioScoped
class DataTableRepository {

  var _fieldLabel = "NamedDataTable"

  var _namedDataTables : Map<String, DataTable> as NamedDataTables = {}

  /**
   * If givenDataTable have the same lable as _fieldLabel with two columns and one row, such as
   * | NamedDataTable | XXXX Table |
   * Then it will Look up the data table from DataTables stored in NamedDataTables that matches the name
   * If not, it will return the original givenDataTable
   * @param givenDataTable the data table that passed in for search
   * @return the found DataTable
   */
  function dataTableLookup(givenDataTable : DataTable) : DataTable {
    var rawTable = givenDataTable.raw()

    if (rawTable.size() == 1 && rawTable.single().size() == 2 && rawTable.single().first() == _fieldLabel) {
      var name = givenDataTable.raw().single().last()
      PCLoggerCategory.TEST.debug("Looking up ${_fieldLabel} \"${name}\"")
      var foundDataTable = _namedDataTables.get(name)
      if (foundDataTable == null) {
        throw new IllegalStateException("Failed to find ${_fieldLabel} \"${name}\"")
      }
      return foundDataTable
    } else {
      return givenDataTable
    }
  }
}