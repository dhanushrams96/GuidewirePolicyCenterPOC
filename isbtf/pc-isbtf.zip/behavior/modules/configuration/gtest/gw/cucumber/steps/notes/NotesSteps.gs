package gw.cucumber.steps.notes

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory

@Export
class NotesSteps {

  @Inject
  var _contextFactory : ContextFactory

  @When("^I create a note with the following:$")
  function iStartANote(noteDetail : DataTable) {
    _contextFactory.getNotesContext().createNote(noteDetail.asMap(String, String))
  }

  @Then("^the policy should have the following note:$")
  function thePolicyShouldHaveNote(noteDetail : DataTable) {
    _contextFactory.getNotesContext().verifyNoteExistsOnPolicy(noteDetail.asMap(String, String))
  }
}