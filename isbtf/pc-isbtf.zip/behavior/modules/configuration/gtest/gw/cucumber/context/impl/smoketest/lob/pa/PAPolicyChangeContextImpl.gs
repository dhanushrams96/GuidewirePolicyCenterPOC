package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.policychange.PolicyChangeContextImplBase
uses gw.cucumber.setup.PolicyChangeDataSetup
uses gw.cucumber.util.common.UIHelper
uses gw.cucumber.util.lob.pa.DriverUIFieldsProvider
uses pcftest.PersonalAutoScreen

@SuppressWarnings("unused")
@Export
class PAPolicyChangeContextImpl extends PolicyChangeContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addDriver(givenFields: Map<String, String>) {
    var dataSetup = ScenarioInfoProvider.DataSetup as PolicyChangeDataSetup
    var policyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var driverStep = policyChangeWizard.PAMode.goToDriversStep()
    var newPolicyDriverPopup = driverStep.AddNewPersonButton.click() as pcftest.NewPolicyDriverPopup
    var contactDetailScreen = newPolicyDriverPopup.ContactDetailScreen

    var fieldsProvider = new DriverUIFieldsProvider(givenFields)
    UIHelper.setFieldValues(contactDetailScreen, fieldsProvider)
    contactDetailScreen.Update.click()

    // Set fields on the Roles Tab
    driverStep.goToRolesTab()
    UIHelper.setFieldValues(driverStep.PolicyDriver, fieldsProvider)
  }

  override function addVehicle(givenFields : Map<String, String>) {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var vehicleScreen = policyChangeWizard.PAMode.goToVehiclesStep()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.addVehicle(givenFields)
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var vehicleScreen = policyChangeWizard.PAMode.goToVehiclesStep()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.verifyVehicleExists(givenFields)
  }

  override function editVehicle(yearMakeModel : String, givenFields : Map<String, String>) {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var vehicleScreen = policyChangeWizard.PAMode.goToVehiclesStep()
    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.editVehicle(yearMakeModel, givenFields)
  }

  override function verifyVehicleFinancialTransactions(yearMakeModel : String, changedFieldsTable : List<List<String>>) {
    var policyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var quoteScreen = policyChangeWizard.ViewQuote.click()
    quoteScreen.PolicyChangeWizard_Quote_TransactionCardTab.click()
    var panelSetPersonalAutoLine = quoteScreen.RatingTxDetailsPanelSet_PersonalAutoLine
    NavigationManager.CurrentPCFElement = panelSetPersonalAutoLine
    _lineContextDelegate.verifyVehicleFinancialTransactions(yearMakeModel, changedFieldsTable)
  }

  override function setTermType(termType : TermType) {
    var policyChangeWizard = loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange)
    var policyInfoScreen = policyChangeWizard.LOBWizardStepGroup.PolicyInfo.click()
    policyInfoScreen.PolicyChangeWizard_PolicyInfoDV.PolicyInfoInputSet.TermType.clickFirstOptionWithMatchingValue(\option -> option == termType.Code)
    policyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.Draft.click()
    logout()
  }

  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = PolicyChangeDataSetup.Entity
    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(period.PolicyNumber)
    assertThat(period.Status)
        .isEqualTo(PolicyPeriodStatus.TC_BOUND)

    UIHelper.setPolicyFileDatePicker(policyFile, ScenarioInfoProvider.SliceDate)
    var coverageStep = policyFile.goToPACoveragesStep()

    coverageStep.PolicyFile_PA_Coverages_Screen.CoveragesTab.click()
    NavigationManager.CurrentPCFElement = coverageStep.PolicyFile_PA_Coverages_Screen
    _lineContextDelegate.verifyLineLevelCoverage(covName, coverageTerms)
  }

  override function verifyLineLevelCoverageDoesNotExist(covName : String) {
    var period = PolicyChangeDataSetup.Entity
    var policyFile = loginIfLoggedOut(CurrentUser).goToPolicyFile(period.PolicyNumber)
    assertThat(period.Status)
        .isEqualTo(PolicyPeriodStatus.TC_BOUND)

    UIHelper.setPolicyFileDatePicker(policyFile, ScenarioInfoProvider.SliceDate)

    var coverageStep = policyFile.goToPACoveragesStep()
    var coveragesScreen = coverageStep.PolicyFile_PA_Coverages_Screen
    var coverageTab = coveragesScreen.CoveragesTab.click()

    NavigationManager.CurrentPCFElement = coverageStep.PolicyFile_PA_Coverages_Screen
    _lineContextDelegate.verifyLineLevelCoverageDoesNotExist(covName)
  }

  override function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var coverageStep = gotoPersonalAutoScreen()
    NavigationManager.CurrentPCFElement = coverageStep.PAPerVehiclePanelSet
    _lineContextDelegate.addVehicleLevelCoverage(covName, coverageTerms)
  }

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    NavigationManager.CurrentPCFElement = gotoPersonalAutoScreen().PersonalAuto_AllVehicleCoveragesDV
    _lineContextDelegate.addLineLevelCoverage(covName, coverageTerms)
  }

  private function gotoPersonalAutoScreen() : PersonalAutoScreen {
    return loginIfLoggedOut(CurrentUser).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).PAMode.goToPAStep()
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}
