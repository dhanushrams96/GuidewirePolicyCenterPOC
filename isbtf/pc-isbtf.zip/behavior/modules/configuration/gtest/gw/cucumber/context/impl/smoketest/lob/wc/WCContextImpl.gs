package gw.cucumber.context.impl.smoketest.lob.wc

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.lob.wc.WCContext
uses gw.cucumber.context.impl.smoketest.lob.LineContextImplBase
uses pcftest.RatingOverridePopup
uses pcftest.StateCostRowSet_default
uses pcftest.WorkersCompClassesInputSet
uses pcftest.WorkersCompCoverageConfigScreen

@SuppressWarnings({"unused", "GosuCodeBlock2Expr"})
@Export
class WCContextImpl extends LineContextImplBase implements WCContext {

  override function addCoveredEmployees(coveredEmployeeInfoMaps : List<Map<String, String>>) {
    var wcClassesInputSet = NavigationManager.ensureOnPage(pcftest.WorkersCompClassesInputSet)
    coveredEmployeeInfoMaps.eachWithIndex(\coveredEmployeeInfoMap, index -> {
      populateWCClassRow(wcClassesInputSet, coveredEmployeeInfoMap, index)
    })
  }

  private function populateWCClassRow(wcClassesInputSet : WorkersCompClassesInputSet, coveredEmployeeInfoMap : Map<String, String>, index : int) {
    var wcClass = nextClassRow(wcClassesInputSet, index)
    wcClass.SpecialCoverage.Value = coveredEmployeeInfoMap.get("Governing Law")
    if (coveredEmployeeInfoMap.containsKey("Location")) {
      wcClass.Loc.getOptionByLabel(coveredEmployeeInfoMap.get("Location")).click()
    }
    wcClass.ClassCode.Value = coveredEmployeeInfoMap.get("Class Code")
    wcClass.NumEmployees.Value = coveredEmployeeInfoMap.get("# Employees")
    wcClass.AnnualRenum.Value = coveredEmployeeInfoMap.get("Basis")
  }

  // Returns the next row for adding a class of covered employees. For this particular widget, the add button is not clicked for the first row, but it is clicked for the rest of the rows.
  private function nextClassRow(wcClassesInputSet : WorkersCompClassesInputSet, index : int) : pcftest.WorkersCompClassesInputSet.WCCovEmpLV.entry{
    var addClassButton = wcClassesInputSet.WCCovEmpLV_tb.Add
    if (index > 0) {
      addClassButton.click()
    }
    var wcClass = wcClassesInputSet.WCCovEmpLV._Entries.last()
    return wcClass
  }

  override function setCoveredEmployees(coveredEmployeeInfoMaps : List<Map<String, String>>) {
    var wcClassesInputSet = NavigationManager.ensureOnPage(pcftest.WorkersCompClassesInputSet)
    coveredEmployeeInfoMaps.eachWithIndex(\coveredEmployeeInfoMap, index -> {
      editClassRow(coveredEmployeeInfoMap, wcClassesInputSet.WCCovEmpLV._Entries.get(index))
    })
  }

  private function editClassRow(coveredEmployeeInfoMap : Map<String, String>, wcClass : WorkersCompClassesInputSet.WCCovEmpLV.entry) {
    wcClass.SpecialCoverage.Value = coveredEmployeeInfoMap.get("Governing Law")
    //    Cannot set location, it is read only
    wcClass.ClassCode.Value = coveredEmployeeInfoMap.get("Class Code")
    wcClass.NumEmployees.Value = coveredEmployeeInfoMap.get("# Employees")
    wcClass.AnnualRenum.Value = coveredEmployeeInfoMap.get("Basis")
  }

  override function verifyCoveredEmployees(data : List<Map<String, String>>) {
    var wcClassesInputSet = NavigationManager.ensureOnPage(pcftest.WorkersCompClassesInputSet)
    var coveredEmployeeInfoMaps = data
    coveredEmployeeInfoMaps.eachWithIndex(\coveredEmployeeInfoMap, index -> {
      assertCoveredEmployeeInfoOnWCCoveragesSteps(coveredEmployeeInfoMap, wcClassesInputSet.WCCovEmpLV._Entries.get(index))
    })
  }

  private function assertCoveredEmployeeInfoOnWCCoveragesSteps(coveredEmployeeInfoMap : Map<String, String>, wcClass : WorkersCompClassesInputSet.WCCovEmpLV.entry) {
    var classCode = coveredEmployeeInfoMap.get("Class Code")
    assertThat(wcClass.ClassCode.Text).as("expected class code to be " + classCode).isEqualTo(classCode)

    var specialCoverage = coveredEmployeeInfoMap.get("Governing Law")
    assertThat(wcClass.SpecialCoverage.Text).as("expected governing law to be " + specialCoverage).isEqualTo(specialCoverage)

    var location = coveredEmployeeInfoMap.get("Location")
    assertThat(wcClass.Loc.Text).as("expected location to be " + location).isEqualTo(location)

    var numEmployees = coveredEmployeeInfoMap.get("# Employees")
    assertThat(wcClass.NumEmployees.Text).as("expected # employees to be " + numEmployees).isEqualTo(numEmployees)

    var basis = coveredEmployeeInfoMap.get("Basis")
    assertThat(wcClass.AnnualRenum.Text).as("expected basis to be " + basis).isEqualTo(basis)
  }

  override function verifySplitPeriodPremiums(data : List<Map<String, String>>) {
    var ratingCumulDetailsPanelSet = NavigationManager.ensureOnPage(pcftest.RatingCumulDetailsPanelSet_WorkersCompLine)
    var outerEntries = ratingCumulDetailsPanelSet._Entries
    var stateCostPanels = outerEntries.first().JurisdictionPanelSet._Entries
    assertThat(stateCostPanels.size()).as("expected " + data.size() + " Premium sections, but found " + stateCostPanels.size())
  }

  override function verifySplitPeriodRates(data : List<Map<String, String>>) {
    var ratingCumulDetailsPanelSet = NavigationManager.ensureOnPage(pcftest.RatingCumulDetailsPanelSet_WorkersCompLine)
    data.each(\expectedPremiumInfoMap -> {
      assertSplitPeriodWCCostsOnQuoteScreen(ratingCumulDetailsPanelSet, expectedPremiumInfoMap)
    })
  }

  private function assertSplitPeriodWCCostsOnQuoteScreen(ratingCumulDetailsPanelSet : pcftest.RatingCumulDetailsPanelSet_WorkersCompLine, expectedPremiumInfoMap : Map<String, String>) {
    var periodNum = Integer.valueOf(expectedPremiumInfoMap.get("Period").remove("Period").trim())
    var stateCostEntries = getStateCostPanelForNthPeriod(ratingCumulDetailsPanelSet, periodNum)

    var expectedClassCode = expectedPremiumInfoMap.get("Code")
    var expectedRate = expectedPremiumInfoMap.get("Rate")
    var expectedDescription = expectedPremiumInfoMap.get("Description")

    var matchingStateCosts = stateCostEntries.where(\stateCostEntry -> matchesWithExpectedCostsMap(expectedPremiumInfoMap, stateCostEntry.StateCostRowSet_default))
    assertThat(matchingStateCosts.Count).as("Expected " + 1 + " experience modifier entry in period#" + periodNum).isEqualTo(1)
    var matchingStateCost = matchingStateCosts.single()

    var actualClassCode = matchingStateCost.StateCostRowSet_default.ClassCode.Text
    var actualRate = matchingStateCost.StateCostRowSet_default.Rate.Text
    var actualDescription = matchingStateCost.StateCostRowSet_default.Description.Text

    assertThat(actualClassCode).isEqualTo(expectedClassCode).as("Expected Class Code to be " + expectedClassCode + " | " + expectedDescription + "|" + expectedRate)
    assertThat(actualRate).isEqualTo(expectedRate).as("Expected Rate to be " + expectedClassCode + " | " + expectedDescription + "|" + expectedRate)
    assertThat(actualDescription).isEqualTo(expectedDescription).as("Expected Description to be " + expectedClassCode + " | " + expectedDescription + "|" + expectedRate)
  }

  private function getStateCostPanelForNthPeriod(ratingCumulDetailsPanelSet : pcftest.RatingCumulDetailsPanelSet_WorkersCompLine, periodNum : Integer) : gw.smoketest.platform.web.IteratorEntries<pcftest.StateCostsLV.entry> {
    var outerEntries = ratingCumulDetailsPanelSet._Entries
    var stateCostPanels = outerEntries.first().JurisdictionPanelSet._Entries
    return stateCostPanels.get(periodNum-1).StateCostsLV._Entries
  }

  private function matchesWithExpectedCostsMap(expectedCostsMap: Map<String, String>, stateCostRowSetDefault : StateCostRowSet_default) : boolean {
    return stateCostRowSetDefault.ClassCode.Value == expectedCostsMap.get("Code")
  }

  override function addExperienceModifiers(data : List<Map<String, String>>) {
    var workersCompCoverageConfigScreen = NavigationManager.ensureOnPage(pcftest.WorkersCompCoverageConfigScreen)
    data.eachWithIndex(\experienceModifier, index -> {
      enterExperienceModifier(workersCompCoverageConfigScreen, experienceModifier, index)
    })
  }

  private function enterExperienceModifier(workersCompCoverageConfigScreen : WorkersCompCoverageConfigScreen, experienceModifier : Map<String, String>, index : int) {
    var valueToSet = experienceModifier.get("Experience Modifier")
    var entries = workersCompCoverageConfigScreen.WorkersCompCoverageCV.PolicyLinePerStateConfigDV.SplitModifiers._Entries
    var experienceModifierToBeEntered = entries.get(index).WCModifiersInputSet.ModIteratorEligible._Entries.first().EligibilityInputGroup
    experienceModifierToBeEntered._checkbox.click()
    experienceModifierToBeEntered.ModifierInput.Value = valueToSet
  }

  override function verifyRates(data : List<Map<String, String>>) {
    var ratingDetails = NavigationManager.ensureOnPage(pcftest.RatingCumulDetailsPanelSet_WorkersCompLine)
    data.each(\expectedPremiumInfoMap -> assertWCCostsOnQuoteScreen(ratingDetails, expectedPremiumInfoMap))
  }

  override function overrideClassBaseRate(data : List<Map<String, String>>) {
    var ratingDetails = NavigationManager.ensureOnPage(pcftest.RatingCumulDetailsPanelSet_WorkersCompLine)
    var ratingOverridePopup = ratingDetails.RatingOverrideButtonDV.RatingOverrideButtonDV.OverrideRating.click() as RatingOverridePopup
    var costs = ratingOverridePopup.RatingOverridePanelSet_WorkersCompLine._Entries.first().JurisdictionPanelSet._Entries
        .first().PeriodDetailDV.WCRatingOverrideCostLV._Entries
    data.each(\elt -> {
      var matchingRow = costs.singleWhere(\cost -> cost.LocationNum.Value == elt[DisplayKey.get("Web.SubmissionWizard.Quote.WC.Loc")]
          && cost.ClassCode.Value == elt[DisplayKey.get("Web.Quote.CumulDetail.Default.ClassCode")])
      matchingRow.OverrideBaseRate.setValue(elt.get(DisplayKey.get("Web.Policy.RatingOverride.BaseRate")))
      matchingRow.OverrideAdjustedRate.setValue(elt[DisplayKey.get("Web.Policy.RatingOverride.AdjustedRate")])
      matchingRow.OverrideAmount.setValue(elt[DisplayKey.get("Web.Policy.RatingOverride.Amount")])
      matchingRow.OverrideReason.setValue(elt[DisplayKey.get("Web.Policy.RatingOverride.Reason")])
    })
    ratingOverridePopup.Update.click()
  }

  private function assertWCCostsOnQuoteScreen(ratingDetails : pcftest.RatingCumulDetailsPanelSet_WorkersCompLine, rateMap :
      Map<String, String>){
    var costs = ratingDetails._Entries.first().JurisdictionPanelSet._Entries.first().StateCostsLV._Entries*.StateCostRowSet_default
    var matchingCost = costs.singleWhere(\cost -> cost.LocNumber.Value == rateMap.get("Loc.") && cost.ClassCode.Value == rateMap.get("Code"))

    var actualBasis = matchingCost.Basis.Value
    var actualRate = matchingCost.Rate.Value
    var actualAmount = matchingCost.TermAmount.Value

    assertThat(actualBasis).isEqualTo(rateMap.get("Basis"))
    assertThat(actualRate).isEqualTo(rateMap.get("Rate"))
    assertThat(actualAmount).isEqualTo(rateMap.get("Amount"))
  }

/*
  override function selectProduct() {
    throw new UnsupportedOperationException("Not yet implemented")
  }
*/

  override function removeLineLevelCoverage(covName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

}