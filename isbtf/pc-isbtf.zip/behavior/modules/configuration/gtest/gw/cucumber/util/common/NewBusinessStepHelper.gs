package gw.cucumber.util.common

uses pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector

/**
 * Helper class to provide helper methods for line or job specific steps
 */
@Export
class NewBusinessStepHelper {
  /**
   * Constructs a {@link String} with the same format as the multi-quote
   * {@link PolicyPeriodSelector PolicyPeriodSelector} found in the job wizards.
   *
   * @param name     name of the version
   * @param status   status of the version
   * @param selected whether or not the version is selected
   * @return a {@link String} matching the format of the {@link PolicyPeriodSelector PolicyPeriodSelector}
   */
  static function getVersionSelectorLabel(name : String, status : PolicyPeriodStatus, selected : boolean) : String {
    return (selected ? "* " : "") + name + " : " + status
  }
}