package gw.cucumber.steps.lob.wc

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.wc.WCContext

/**
 * Workers' Comp specific {@link Job} steps
 */
@Export
class WC_JobSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Given("^the policy has the following covered employees:$")
  function policyHasFollowingCoveredEmployees(coveredEmployees : DataTable) {
    var coveredEmployeeInfoMaps = coveredEmployees.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().addCoveredEmployees(coveredEmployeeInfoMaps)
  }

  @Then("^the following Workers Compensation costs? should exist:$")
  function followingRateExist(rate : DataTable) {
    var rateMap = rate.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().verifyRates(rateMap)
  }

  @When("^I override the rate for a class of covered employees with the following:$")
  function iOverrideTheBaseRateForCoveredEmployees(rate:DataTable){
    var rateMap = rate.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().overrideClassBaseRate(rateMap)
  }

  @When("^I set the following covered employees:$")
  function iSetCoveredEmployees(coveredEmployees : DataTable) {
    var coveredEmployeeInfoMaps = coveredEmployees.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().setCoveredEmployees(coveredEmployeeInfoMaps)
  }

  @Then("^the following covered employees should exist on WC Coverages Step$")
  function followingCoveredEmployeesShouldExistOnWCCoveragesStep(coveredEmployees : DataTable) {
    var coveredEmployeeInfoMaps = coveredEmployees.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().verifyCoveredEmployees(coveredEmployeeInfoMaps)
  }

  @When("^I enter experience modifiers:$")
  function iEnterExperienceModifiers(experienceModifiersTable: DataTable) {
    var experienceModifiers = experienceModifiersTable.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().addExperienceModifiers(experienceModifiers)
  }

  @Then("^the following Workers Compensation costs should exist in specified period:$")
  function followingCostsShouldExistForPeriod(premiumInfoTable: DataTable) {
    var expectedPremiumInfoMaps = premiumInfoTable.asMaps(String, String)
    _contextFactory.getLineContext<WCContext>().verifySplitPeriodRates(expectedPremiumInfoMaps)
  }

}

