package gw.cucumber.steps.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.setup.DataTableRepository

class HOP_PolicyChangeSteps {

  @Inject
  var _contextFactory : ContextFactory
  @Inject
  var _dataTableRepository : DataTableRepository

  @When("^I add the following animal information$")
  function addTheFollowingAnimalInformation(animalInfoTable : DataTable) {
    (_contextFactory.getPolicyChangeContext() as HOPContext).addAnimalUsingUI(animalInfoTable)
  }
}