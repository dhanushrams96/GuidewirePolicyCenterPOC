package gw.cucumber.context.impl.smoketest.job

uses cucumber.api.DataTable
uses gw.api.util.MonetaryAmounts
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.job.JobContext
uses gw.smoketest.platform.web.PCFLocation
uses gw.util.IssueRow
uses gw.cucumber.transformer.DateTransformer
uses gw.cucumber.transformer.MonetaryAmountTransformer
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.util.common.UIHelper
uses gw.pl.currency.MonetaryAmount
uses pcftest.JobWizardInfoBar
uses pcftest.PolicyFile
uses pcftest.QuoteTypeToolbarButtonSet_Quote
uses pcftest.WebMessageWorksheet
uses java.math.BigDecimal

@Export
abstract class JobContextImplBase extends CucumberStepBase implements JobContext {

  override function quote() {
    var clickQuote = NavigationManager.ensureOnPage(QuoteTypeToolbarButtonSet_Quote.Quote)
    clickQuote.click()
    waitForAutoRefreshToComplete()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function bind() {
    ScenarioInfoProvider.DataSetup.isBound()
    ScenarioInfoProvider.BasedOnPolicyPeriod = ScenarioInfoProvider.DataSetup.Entity
  }

  override function withdraw(closeOption : String, closingReason : String) {
    var closingPopup = _proxy.CurrentPage
    if (closingPopup typeis pcftest.NotTakenReasonPopup) {
      var rejectionReasons = closingPopup.RejectReason
      assertThat(rejectionReasons.OptionLabels)
          .as("closing reason is not valid!")
          .contains({closingReason})
      rejectionReasons.getOptionByLabel(closingReason).click()
      closingPopup.notTaken()
    } else if (closingPopup typeis pcftest.DeclineReasonPopup) {
      var rejectionReasons = closingPopup.RejectReason
      assertThat(rejectionReasons.OptionLabels)
          .as("closing reason is not valid!")
          .contains({closingReason})
      rejectionReasons.getOptionByLabel(closingReason).click()
      closingPopup.notTaken()
    } else if (!(closingPopup typeis pcftest.JobComplete)) {
      throw new IllegalStateException("Invalid current page: ${closingPopup}")
    }
    logout()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function issue() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function edit() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setJobStatus(status : PolicyPeriodStatus) {
    if (status == PolicyPeriodStatus.TC_QUOTED) {
      ScenarioInfoProvider.DataSetup.isQuoted()
    } else if (status == PolicyPeriodStatus.TC_BOUND) {
      ScenarioInfoProvider.DataSetup.isBound()
    } else if (status == PolicyPeriodStatus.TC_DRAFT) {
      // do nothing as default is already Draft
    } else {
      throw new UnsupportedOperationException("Condition for Status: ${status} is not defined")
    }
  }

  override function setJobStatusQuoted(status : PolicyPeriodStatus) {
    setJobStatus(status)
  }

  override function storeJobAs(jobName : String) {
    ScenarioInfoProvider.BranchMap.put(jobName, ScenarioInfoProvider.DataSetup.Entity)
  }

  override function retrieveJob(jobName : String): PolicyPeriod {
    var period = ScenarioInfoProvider.BranchMap.get(jobName)
    ScenarioInfoProvider.DataSetup.set(period)
    return period
  }

  override function storeDataTable(tableName : String, table : DataTable) {
    var previousValue = DataTableRepository.NamedDataTables.put(tableName, table)
    if (previousValue != null) {
      _proxy.Logger.warn("NamedDataTable " + tableName + " has been overwritten")
    }
  }

  override function verifyInStatus(status : String) {
    var expectedStatus = new TypelistTransformer<PolicyPeriodStatus>().transform(status)
    var currentWizardInfoBar = NavigationManager.ensureOnPage(JobWizardInfoBar)
    assertThat(currentWizardInfoBar.JobLabel.Text)
        .as("The Job Status should be " + expectedStatus)
        .contains(expectedStatus.DisplayName)
  }

  override function verifyPolicyIssued() {
    var period = ScenarioInfoProvider.DataSetup.Entity
    assertThat(period.Policy.Issued).as("Policy is not issued")
  }

  override function setTermType(termType : TermType) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    var riskAnalysisScreen = NavigationManager.ensureOnPage(pcftest.Job_RiskAnalysisScreen)
    riskAnalysisScreen.approveUWIssue(description)
    waitForAutoRefreshToComplete()
    logout()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function approveUWIssuesAsUnderwriter(description : String, validUntil : String) {
    var riskAnalysisScreen = NavigationManager.ensureOnPage(pcftest.Job_RiskAnalysisScreen)
    riskAnalysisScreen.approveUWIssue(description, validUntil)
    waitForAutoRefreshToComplete()
    logout()
    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function verifyChangeInCost(changeInCost : String) {
    var expectedAmount = new MonetaryAmountTransformer().transform(changeInCost)
    var quoteSummaryDV = NavigationManager.ensureOnPage(pcftest.Quote_SummaryDV)
    var actualCostChange = MonetaryAmounts.ofDefaultCurrency(quoteSummaryDV.ChangeInCost.Value.toBigDecimal())
    assertMonetaryAmountEquals("This amount should be close to the expected amount", expectedAmount, actualCostChange, 5)
  }

  override function selectFinalAuditOption(option : FinalAuditOption) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function addContingency(contingencyInfo : Map<String, String>) : void {
    var riskAnalysisScreen = NavigationManager.ensureOnPage(pcftest.Job_RiskAnalysisScreen)
    riskAnalysisScreen.goToContingencyCard()
    var newContingencyPopup = riskAnalysisScreen.clickAddContingency()
    UIHelper.setFieldValues(newContingencyPopup, contingencyInfo)
    newContingencyPopup.Update.click()

    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function verifyContingencyExists(contingenciesInfoMap : Map<String, String>) {
    var contingency = ScenarioInfoProvider.DataSetup.Entity.Policy.Contingencies.single()
    checkContingencyStatusAndInfo(contingency.Status, contingenciesInfoMap)
  }

  override function verifyContingencyStatus(contingencyStatus : ContingencyStatus) {
    // assumes there is a single contingecy on the policy with the given status
    var contingency = ScenarioInfoProvider.DataSetup.Entity.Policy.Contingencies.single()
    assertThat(contingency.Status).isEqualTo(contingencyStatus)
  }

  override function resolveContingency(contingencyMap : Map<String, String>) {
    var contingencyStatus = new TypelistTransformer<ContingencyStatus>().transform(contingencyMap.get("Status"))
    var contingencyTitle = contingencyMap.get("Title")
    var dueDate = DateTransformer.transform(contingencyMap.get("Due Date"))
    var contingencyPopup = goToPolicyFile().goToContingencyPopup(contingencyStatus, contingencyTitle, dueDate)
    contingencyPopup.BaseContingencyInfoDV.Resolve.click()
  }

  private function goToPolicyFile() : PolicyFile {
    return loginIfLoggedOut(UserUnderwriterRole).goToPolicyFile(ScenarioInfoProvider.PolicyNumber)
  }

  private function checkContingencyStatusAndInfo(contingencyStatus : ContingencyStatus, contingencyInfo : Map<String, String>) {
    var riskanalysisStep = goToPolicyFile().goToRiskAnalysisScreen()
    riskanalysisStep.PolicyFile_RiskAnalysisScreen.PolicyFile_RiskAnalysisCV.PolicyFile_ContingenciesCardTab.click()
    var contingencyPanelSet = riskanalysisStep.PolicyFile_RiskAnalysisScreen.PolicyFile_RiskAnalysisCV.ContingencyPanelSet
    var title = contingencyInfo.get("Title")
    var entriesUI :  Map<String, String> = new HashMap<String, String>()

    if (contingencyStatus == TC_PENDING) {
      var contingenciesPendingLV = contingencyPanelSet.ContingenciesPendingLV
      var matchingEntry = contingenciesPendingLV._Entries.firstWhere(\entry -> entry.ContingencyTitle.Value == title)
      entriesUI = UIHelper.getFieldValues({matchingEntry})
    } else if (contingencyStatus == ContingencyStatus.TC_RESOLVED or contingencyStatus == ContingencyStatus.TC_WAIVED) {
      var resolvedWaivedLV = contingencyPanelSet.ContingenciesResolvedWaivedLV
      var matchingEntry = resolvedWaivedLV._Entries.firstWhere(\entry -> entry.ContingencyTitle.Value == title)
      entriesUI = UIHelper.getFieldValues({matchingEntry})
    } else if (contingencyStatus == ContingencyStatus.TC_FAILED) {
      var failedLV = contingencyPanelSet.ContingenciesFailedActionInitiatedLV
      var matchingEntry = failedLV._Entries.firstWhere(\entry -> entry.ContingencyTitle.Value == title)
      entriesUI = UIHelper.getFieldValues({matchingEntry})
    } else {
      throw new Exception("Contingengy Status unknown: ${contingencyStatus}}")
    }
    assertThat(entriesUI.filterByKeys(\k -> contingencyInfo.containsKey(k))).isEqualTo(contingencyInfo)
  }

  function selectPaymentMethod(paymentMethod : PaymentMethod) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  function selectReportingPlan(reportingPlan : String) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyUWBindBlockingIssues(shouldExist : boolean) {
    logout()
    var submissionWizard = loginAsUser(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    var issuesBlockingBind = riskAnalysisScreen.BlockingIssues
    if (shouldExist) {
      assertThat(issuesBlockingBind)
          .as("There should be an underwriting issue blocking bind")
          .isNotEmpty()
    } else {
      assertThat(issuesBlockingBind)
          .as("The underwriting issues should be empty")
          .isEmpty()
    }
    logout()
  }

  override function verifyUWApprovedIssues(shouldExist : boolean) {
    logout()
    var submissionWizard = loginAsUser(UserUnderwriterRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    var approvedIssues = riskAnalysisScreen.ApprovedIssues
    if (shouldExist) {
      assertThat(approvedIssues)
          .as("There should be an approved issue blocking bind")
          .isNotEmpty()
    } else {
      assertThat(approvedIssues)
          .as("The approved issues should be empty")
          .isEmpty()
    }
    logout()
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(issues : List<Map<String, String>>) {
    var riskAnalysisScreen = NavigationManager.ensureOnPage(pcftest.Job_RiskAnalysisScreen)
    var expectedIssues = issues.map(\row -> new IssueRow() {:Title = row.get("Section Title"), :ShortDescription = row.get("Short Description")})
    assertThat(riskAnalysisScreen.BlockingAndApprovedIssues)
        .as("The UW issues should exist")
        .contains(expectedIssues.toTypedArray())
    logout()
  }

  override function causeUWIssue(blockingPoint : UWIssueBlockingPoint) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function approveUWIssues() {
    ScenarioInfoProvider.DataSetup.doApproveUWIssues(UserUnderwriterRole)
  }

  override function verifyTotalCost(expectedCost : String) {
    var expectedAmount = new MonetaryAmountTransformer().transform(expectedCost)
    ScenarioInfoProvider.DataSetup.refreshEntity()

    var period = ScenarioInfoProvider.DataSetup.Entity
    assertMonetaryAmountEquals("On the period Total cost is ${period.TotalCostRPT} but should have been ${expectedCost}", expectedAmount, period.TotalCostRPT)
  }

  override function verifyTotalCostExist(){
    var totalCost = ScenarioInfoProvider.DataSetup.Entity.TotalCostRPT
    assertThat(not totalCost.Amount.IsZero)
        .as("Total cost is ${totalCost} but should have been greater than ${BigDecimal.ZERO}")
  }

  protected function assertCostTransactionsAreSame(expectedCosts : Map<String, MonetaryAmount>, actualCosts : Map<String, MonetaryAmount>) {
    assertThat(actualCosts.size()).isEqualTo(expectedCosts.size())
    actualCosts.Keys.each(\actualCostKey -> {
      var matchingExpectedCostKey = expectedCosts.Keys.singleWhere(\expectedCostKey -> actualCostKey.contains(expectedCostKey))
      var actualValue = actualCosts.get(actualCostKey)
      var expectedValue = expectedCosts.get(matchingExpectedCostKey)
      assertMonetaryAmountEquals("The Cost ${actualCostKey} should have expected value of ${actualValue}", expectedValue, actualValue, 5)
    })
  }

  override function verifyCostsExists(costsMap : Map<String, MonetaryAmount>) {
    var quoteSummaryDV = NavigationManager.ensureOnPage(pcftest.Quote_SummaryDV)
    var otherCostsInMonetaryAmount : Map<String, MonetaryAmount> = new HashMap<String, MonetaryAmount>()

    var otherCosts = UIHelper.getFieldValues({quoteSummaryDV})
    // Convert values(costs) from String to MonetaryAmount.
    otherCosts.filterByKeys(\k -> costsMap.containsKey(k)).eachKeyAndValue(\k, val -> {
      otherCostsInMonetaryAmount.put(k, MonetaryAmounts.ofDefaultCurrency(val))
    })
    assertCostTransactionsAreSame(costsMap, otherCostsInMonetaryAmount)
  }

  override function selectSideBySideVersion(versionNumber : int) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function selectVersion(versionNumber : int) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function startSideBySideQuoting() {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function initiateANewVersionViaMultiversion() {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyNumberOfVersions(numberOfVersions : int) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyMultiQuoteVersions(versions : List<List<String>>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function addAdditionalNamedInsured(contactInfo : Map<String, String>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyAdditionalNamedInsuredExists(contactInfo : Map<String, String>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function setEffectiveDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function setExpirationDate(expirationDate : Date) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyQuoteFailedWith(message : String) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var validationMessageExist = false
    try {
      gw.transaction.Transaction.runWithNewBundle(\bundle -> {
        period = bundle.add(period)
        period.JobProcess.requestQuote()
      }, CurrentUser)
    } catch (e : Exception) {
      validationMessageExist = e.Message.contains(message)
    }

    if (not period.ValidQuote) {
      assertThat(validationMessageExist).as("Quote was unsuccesful but the validation message /'${message}/' did not appear")
    } else {
      fail("Quote was generated hence validation message /'${message}/' did not appear")
    }
  }

  override function verifyErrorMessagesDisplayed(expectedErrorMessages : DataTable) {
    assertThat(retrieveAllMessagesFromUI())
        .as("Error messages: ${expectedErrorMessages} were not displayed on the UI")
        .contains(expectedErrorMessages.asList(String).toArray())
  }

  override function verifyForms(expectedForms : DataTable) {
    var period = ScenarioInfoProvider.DataSetup.Entity.Job.LatestPeriod
    var forms = period.NewlyAddedForms.map(\form -> form.FormNumber)

    assertThat(forms)
        .as("Wrong forms are inferred for Homeowners submission")
        .contains(expectedForms.asList(String).toArray())
  }

  private function retrieveAllMessagesFromUI() : List<String>{
    var messages = UIHelper.getAllMessagesFrom(_proxy.CurrentPage as PCFLocation)
    messages.addAll(UIHelper.getAllMessagesFrom(_proxy.CurrentWorksheet as PCFLocation))
    return messages
  }
}