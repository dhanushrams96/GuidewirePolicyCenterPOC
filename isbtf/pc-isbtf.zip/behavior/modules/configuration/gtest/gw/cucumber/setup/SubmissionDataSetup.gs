package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.SubmissionBuilderBase
uses gw.api.database.Query
uses gw.api.database.Relop
uses gw.api.databuilder.pa.PersonalAutoLineBuilder

@Export
@ScenarioScoped
abstract class SubmissionDataSetup<B extends SubmissionBuilderBase<B>> extends JobDataSetup<B> {

  var _accountDataSetup : AccountDataSetup as AccountDataSetup
  var _defaultLineBuilder : PersonalAutoLineBuilder

  construct(username : String) {
    super(username)
  }

  abstract protected function initializeLines()

  protected override function initializeBuilder(builder : B) {
    super.initializeBuilder(builder)
    if (AccountDataSetup == null) {
      AccountDataSetup = new AccountDataSetup()
      AccountDataSetup.provideDefaultAccountHolder()
    }
    AccountDataSetup.withSubmissionBuilder(builder)
    initializeLines()
  }

  static function findNewestPolicyPeriodFromAccount(accountNumber : String) : PolicyPeriod {
    var queryResult = Query.make(PolicyPeriod)
        .compare(PolicyPeriod#Status, Relop.Equals, PolicyPeriodStatus.TC_DRAFT)
        .join(PolicyPeriod#Policy)
        .join(Policy#Account)
        .compare(Account#AccountNumber, Equals, accountNumber)
        .select()
    var policyChange = queryResult.toList()
        .sortByDescending(\pp -> pp.CreateTime)
        .first()
    if (policyChange == null) {
      throw new IllegalStateException("Can't find the expected PolicyPeriod")
    }
    return policyChange
  }

  function isBound(skipIssuance : boolean) : B {
    if (skipIssuance) {
      _bindOnly = true
    }
    _isBound = true
    return Builder
  }

}