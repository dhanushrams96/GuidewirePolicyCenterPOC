package gw.cucumber.context.impl.smoketest.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.impl.smoketest.job.policychange.PolicyChangeContextImplBase
uses gw.cucumber.transformer.TypelistTransformer

@SuppressWarnings("unused")
@Export
class HOPPolicyChangeContextImpl extends PolicyChangeContextImplBase implements HOPContext {

  @Inject delegate _lineContextDelegate represents HOPContext

  override function addAnimalUsingUI(animalInfo : DataTable) {
    var animal = animalInfo.asMap(String, String)
    var period = ScenarioInfoProvider.DataSetup.Entity
    var policyChangeWizard = loginIfLoggedOut(UserProducerRole).goToPolicyChange(period.PolicyChange)
    var dwellingStep = policyChangeWizard.HOPMode.goToDwellingStep()
    dwellingStep.addAnimal(animal)

    dwellingStep.JobWizardToolbarButtonSet_PolicyChange.Draft.click()
  }

  override function addAnimalToPeriod(animalInfo : DataTable) {
    var policyPeriod = PolicyChangeDataSetup.Entity
    var animalMap = animalInfo.asMap(String, String)
    gw.transaction.Transaction.runWithNewBundle(\bundle -> {
      policyPeriod = bundle.add(policyPeriod)
      var animal = new DwellingAnimal(policyPeriod)
      animal.AnimalType = new TypelistTransformer<AnimalType>().transform(animalMap.get("Animal Type"))
      animal.AnimalBreed = new TypelistTransformer<AnimalBreed>().transform(animalMap.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBreed")))
      animal.AnimalBiteHistory = animalMap.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBiteHistory")) == "Yes" ? Boolean.TRUE : Boolean.FALSE
      policyPeriod.HOPLine.HOPDwellings.first().addToDwellingAnimals(animal)
    }, CurrentUser)
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var riskAnalysisScreen = loginAsUser(UserUnderwriterRole).goToPolicyChange(ScenarioInfoProvider.DataSetup.Entity.PolicyChange).goToRiskAnalysis()
    riskAnalysisScreen.selectViewIssuesBlocking("View All")
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}