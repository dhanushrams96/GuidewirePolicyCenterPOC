package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.IssuanceBuilder

@Export
@ScenarioScoped
class IssuanceDataSetup extends NonSubmissionDataSetup<IssuanceBuilder> {

  construct(basedOnPeriod : PolicyPeriod) {
    super(basedOnPeriod)
  }

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username, basedOnPeriod)
  }

}
