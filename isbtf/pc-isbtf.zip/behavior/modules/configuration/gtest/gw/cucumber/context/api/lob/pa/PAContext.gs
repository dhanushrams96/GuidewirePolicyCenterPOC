package gw.cucumber.context.api.lob.pa

uses gw.cucumber.context.api.lob.LineContext
uses gw.pl.currency.MonetaryAmount

/**
 * Methods common to {@link PersonalAutoLine}.
 * These methods are common to {@link Job} subtypes, for example Submission, PolicyChange, etc.
 */
@Export
interface PAContext extends LineContext {

  /**
   * Add a driver to the job with the provided map of fields and values.
   * "First name" and "Last name" fields are required to be populated. Other fields are optional because defaults
   * will be provided for any required fields like "Date of Birth" etc. that are not passed in.
   * A full list of fields can be found in the documentation.
   *
   * @param givenFields a Map of key and value pairs representing the fields and values of a driver
   */
  function addDriver(givenFields : Map<String, String>)

  function addVehicle(givenFields : Map<String, String>)

  /**
   * Edit the vehicle identified by the year, make, and model with the provided map of fields and values.
   * @param vehicleIdentifier A String that identifes the vehicle. For example, "2018 Ford Focus"
   * @param data a Map of key and value pairs representing the fields and values to be updated on the vehicle
   */
  function editVehicle(vehicleIdentifier : String, data : Map<String, String>)

  function verifyVehicleExists(givenFields : Map<String, String>)

  /**
   * Verify that the provided financial transactions exist for the given vehicle
   * @param vehicleIdentifier A String that identifes the vehicle. For example, "2018 Ford Focus"
   * @param data a List of Lists where each inner list has two elements: a coverage description and an amount.
   *   For example, [["Comprehensive Coverage","51.00 USD"], ["Collision Coverage","83.00 USD"]]
   */
  function verifyVehicleFinancialTransactions(vehicleIdentifier : String, data : List<List<String>>)

  /**
   * Verify that the provided financial transactions exist
   * @param data a List of Lists where each inner list has two elements: a coverage description and an amount.
   *   For example, [["Comprehensive Coverage","51.00 USD"], ["Collision Coverage","83.00 USD"]]
   */
  function verifyFinancialTransactions(expectedCosts : Map<String, MonetaryAmount>)

  /**
   * Adds a vehicle-level coverage given the coverage and coverage terms
   * @param covName the name of the line-level coverage. For example, "Liability - Bodily Injury and Property Damage"
   * @param coverageTerms a Map of coverage terms and corresponding values.
   *   For example, {"Auto Liability Package":"100/200/50"}
   */
  function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>)

  function setVehicleGarageState(state: State)

  function setDriverAge(age : int)

  function setVehicleCost(cost : int)

  function setupInForcePersonalAutoPolicy()
}
