package gw.cucumber.setup

uses gw.api.builder.AccountBuilder
uses gw.api.builder.AccountContactBuilder
uses gw.api.builder.AccountLocationBuilder
uses gw.api.builder.PersonBuilder
uses gw.api.builder.SubmissionBuilderBase
uses gw.pl.persistence.core.Bundle
uses gw.transaction.Transaction

@Export
class AccountDataSetup extends DataSetup<Account, AccountBuilder> {
  protected override function createEntity(bundle : Bundle) : Account {
    return super.createEntity(bundle)
  }

  protected override function initializeBuilder(builder : AccountBuilder) {
    super.initializeBuilder(builder)
    builder.withPrimaryLocation(new AccountLocationBuilder().withName("San Francisco").withState(State.TC_CA))
  }

  override property get Entity() : Account {
    if (_entity == null) {
      Transaction.runWithNewBundle(\bundle -> {
        _entity = createEntity(bundle)
      }, "su")
    }
    return _entity;
  }

  override function createBuilder() : AccountBuilder {
    return new AccountBuilder(false)
  }

  function withSubmissionBuilder(submissionBuilder : SubmissionBuilderBase) {
    if (this.Status == "Builder") {
      Transaction.runWithNewBundle(\bundle -> {
        _entity = createEntity(bundle)
      }, "su")
    }
    submissionBuilder.withAccount(Entity)
    submissionBuilder.withProducer(Entity.ProducerCodes.first().ProducerCode)
  }

  function withAccountContact(accountContactBuilder : AccountContactBuilder) {
    if (this.Status == "Entity") {
      Transaction.runWithNewBundle(\bundle -> {
        accountContactBuilder.onAccount(Entity)
        accountContactBuilder.create(bundle)
      }, _user)
    } else {
      Builder.withAccountContact(accountContactBuilder)
    }
  }

  function provideDefaultAccountHolder() {
    Builder.withAccountHolderContact(new PersonBuilder())
  }
}