package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.PolicyChangeBuilder

@Export
@ScenarioScoped
class PolicyChangeDataSetup extends NonSubmissionDataSetup<PolicyChangeBuilder> {

  construct(basedOnPeriod : PolicyPeriod) {
    super(basedOnPeriod)
  }

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username, basedOnPeriod)
  }
}