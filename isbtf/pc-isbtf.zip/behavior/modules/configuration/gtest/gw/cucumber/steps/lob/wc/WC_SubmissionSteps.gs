package gw.cucumber.steps.lob.wc

uses com.google.inject.Inject
uses cucumber.api.java.en.Given
uses gw.cucumber.context.api.ContextFactory

/**
 * Workers' Comp specific {@link Submission} job steps
 */
@Export
class WC_SubmissionSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Given("^a Workers Compensation (?:submission|policy)$")
  function givenAWorkersCompensationSubmission() {
    _contextFactory.getSubmissionContext().createSubmissionSetup()
  }

}