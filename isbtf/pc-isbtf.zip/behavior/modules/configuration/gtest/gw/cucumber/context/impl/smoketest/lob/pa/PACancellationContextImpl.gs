package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.cancellation.CancellationContextImplBase

@SuppressWarnings("unused")
@Export
class PACancellationContextImpl extends CancellationContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addDriver(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addVehicle(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function editVehicle(vehicleIdentifier : String, data : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyVehicleFinancialTransactions(vehicleIdentifier : String, data : List<List<String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverageDoesNotExist(covName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}
