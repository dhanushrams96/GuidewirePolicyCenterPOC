package gw.cucumber.context.impl.smoketest.job.reinstatement

uses gw.cucumber.context.api.job.reinstatement.ReinstatementContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.NonSubmissionDataSetup
uses gw.cucumber.setup.ReinstatementDataSetup
uses gw.cucumber.transformer.TypelistTransformer
uses pcftest.ReinstatementWizard

@Export
abstract class ReinstatementContextImplBase extends JobContextImplBase implements ReinstatementContext {

  property get ReinstatementDataSetup() : ReinstatementDataSetup {
    return ScenarioInfoProvider.DataSetup as ReinstatementDataSetup
  }

  override function createReinstatementSetup() {
    var cancellation = ScenarioInfoProvider.BasedOnPolicyPeriod
    ScenarioInfoProvider.DataSetup = new ReinstatementDataSetup(UserUnderwriterRole, cancellation)
    ReinstatementDataSetup.Builder.withPaymentReinstatementCode()
  }

  override function quote() {
    var reinstatementWizard = loginIfLoggedOut(UserUnderwriterRole).goToReinstatement(ReinstatementDataSetup.Entity.Reinstatement)
    NavigationManager.CurrentPCFElement = reinstatementWizard.Draft.ReinstatementWizard_ReinstatePolicyScreen.JobWizardToolbarButtonSet_Reinstatement.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  override function reinstatePolicy() {
    var basedOnPolicyPeriod = ScenarioInfoProvider.BasedOnPolicyPeriod
    var reinstatementDataSetup = new ReinstatementDataSetup(CurrentUser , basedOnPolicyPeriod)
    ScenarioInfoProvider.DataSetup = reinstatementDataSetup
    var policyFile = loginIfLoggedOut(UserUnderwriterRole).goToPolicyFile(basedOnPolicyPeriod.PolicyNumber)
    var reinstatementWizard = policyFile.startReinstatement() as ReinstatementWizard
    var startReinstatementPage = reinstatementWizard.Draft.ReinstatementWizard_ReinstatePolicyScreen
    startReinstatementPage.ReinstatePolicyDV.ReasonCode.Value = ReinstateCode.TC_PAYMENT.Code
    startReinstatementPage.JobWizardToolbarButtonSet_Reinstatement.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    reinstatementWizard.clickReinstate()
    var thisReinstatement = NonSubmissionDataSetup.findPolicyPeriodFromBasedOn(basedOnPolicyPeriod, TC_REINSTATEMENT)
    ReinstatementDataSetup.set(thisReinstatement)
    ReinstatementDataSetup.refreshEntity()
  }

  override function verifyInStatus(status : String) {
    var expectedStatus = new TypelistTransformer<PolicyPeriodStatus>().transform(status)
    var reinstatement = ScenarioInfoProvider.DataSetup.Entity.Reinstatement
    var reinstatementWizard = loginIfLoggedOut(UserUnderwriterRole).goToReinstatement(reinstatement)
    assertThat(reinstatementWizard.ReinstatementWizardInfoBar.ReinstatementLabel.Text)
        .as("Reinstatement should be " + expectedStatus)
        .contains(expectedStatus.DisplayName)
  }
}