package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.rewrite.RewriteContextImplBase

@Export
class PARewriteContextImpl extends RewriteContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addVehicle(givenFields : Map<String, String>) {
    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(ScenarioInfoProvider.DataSetup.Entity.Rewrite)
    var vehicleScreen = rewriteWizard.PAMode.goToVehiclesStep()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.addVehicle(givenFields)
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(ScenarioInfoProvider.DataSetup.Entity.Rewrite)
    var vehicleScreen = rewriteWizard.PAMode.VehiclesStep.click()

    NavigationManager.CurrentPCFElement = vehicleScreen
    _lineContextDelegate.verifyVehicleExists(givenFields)
  }

  override function setTermType(termType : TermType) {
    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(ScenarioInfoProvider.DataSetup.Entity.Rewrite)
    var policyInfoScreen = rewriteWizard.LOBWizardStepGroup.PolicyInfo.click()
    policyInfoScreen.RewriteWizard_PolicyInfoDV.PolicyInfoInputSet.TermType.clickFirstOptionWithMatchingValue(\option -> option == termType.Code)
    policyInfoScreen.JobWizardToolbarButtonSet_Rewrite.Draft.click()
    logout()
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var jobWizard = loginAsUser(UserUnderwriterRole).goToRewrite(ScenarioInfoProvider.DataSetup.Entity.Rewrite)
    var riskAnalysisScreen = jobWizard.goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}