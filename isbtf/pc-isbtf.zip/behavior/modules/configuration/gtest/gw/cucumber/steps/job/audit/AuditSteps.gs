package gw.cucumber.steps.job.audit

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.And
uses cucumber.api.java.en.Then
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.transformer.DateTransformer

/**
 * {@link Audit} steps agnostic of the line of business
 */
@Export
class AuditSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Then("^audit is scheduled to \"([^\"]+)\"$")
  function auditIsScheduledTo(date : String) {
    var scheduledDate = DateTransformer.transform(date)
    _contextFactory.getAuditContext().scheduleAudit(scheduledDate)
  }

  @And("^I enter the following audit information for the report starting on \"([^\"]+)\"$")
  function iEnterAuditInfoForReportWithPeriodStartAs(date : String, auditInfo : DataTable) {
    var reportStartingDate = DateTransformer.transform(date)
    _contextFactory.getAuditContext().enterAuditInfoForReportStartingOn(reportStartingDate, auditInfo.asMap(String, String))
  }

  @Then("^I enter the following audit summary information:$")
  function iEnterAuditSummayInformation(auditSummaryTable : DataTable) {
    _contextFactory.getAuditContext().enterAuditSummaryInfo(auditSummaryTable.asMap(String, String))
  }

  @Then("^I enter the following audit details:$")
  function iEnterAuditDetails(auditDetailTable : DataTable) {
    _contextFactory.getAuditContext().enterAuditDetails(auditDetailTable.asMaps(String, String))
  }

  @Then("^I calculate the premiums$")
  function iCalculateThePremiums() {
    _contextFactory.getAuditContext().calculatePremiums()
  }

  @Then("^I submit the ..*$|(?:final|premium) audit$")
  function iSubmitTheAudit() {
    _contextFactory.getAuditContext().submitPremiumOrFinalAudit()
  }

  @And("^the following audit schedule should exist:$")
  function auditScheduleExists(auditScheduleDataTable : DataTable) {
    _contextFactory.getAuditContext().verifyAuditScheduleExists(auditScheduleDataTable.asMaps(String, String))
  }
}