package gw.cucumber.steps.job.rewrite

uses com.google.inject.Inject
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.steps.ScenarioInfoProvider

/**
 * {@link Rewrite} steps agnostic of the line of business

 */
@Export
class RewriteSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _scenarioInfoProvider : ScenarioInfoProvider

  @When("^I rewrite the policy as \"(Rewrite Full Term|Rewrite Remainder of Term|Rewrite New Term)\"$")
  function iRewriteThePolicy(rewriteTerm : String) {
    var rewriteType = new TypelistTransformer<RewriteType>().transform(rewriteTerm)
    _scenarioInfoProvider.JobSubType = TC_REWRITE
    _contextFactory.getRewriteContext().startRewritePolicy(rewriteType)
  }

  @When("^I (?:attempt to issue|issue) the rewrite$")
  function issueRewrite() {
    _contextFactory.getRewriteContext().issue()
  }

  @When("^I (?:attempt to quote|quote) the rewrite$")
  function iQuoteTheRewrite() {
    _contextFactory.getRewriteContext().quote()
  }

  @Then("^the rewrite status (?:should be|should remain) \"(Draft|Quoted|Bound)\"$")
  function theRewriteStatus(status : String) {
    _contextFactory.getRewriteContext().verifyInStatus(status)
  }

  @Then("^the rewrite transaction type should be \"(Rewrite Full Term|Rewrite Remainder of Term|Rewrite New Term)\"$")
  function theRewriteTransactionType(rewriteString : String) {
    var rewriteType = new TypelistTransformer<RewriteType>().transform(rewriteString)
    _contextFactory.getRewriteContext().verifyTransactionType(rewriteType)
  }
}