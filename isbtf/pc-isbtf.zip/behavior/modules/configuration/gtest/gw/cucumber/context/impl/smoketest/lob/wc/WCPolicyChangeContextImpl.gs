package gw.cucumber.context.impl.smoketest.lob.wc

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.wc.WCContext
uses gw.cucumber.context.impl.smoketest.job.policychange.PolicyChangeContextImplBase
uses gw.smoketest.platform.web.ValueElement

@SuppressWarnings("unused")
@Export
class WCPolicyChangeContextImpl extends PolicyChangeContextImplBase implements WCContext {

  @Inject delegate _lineContextDelegate represents WCContext

  override function addCoveredEmployees(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setCoveredEmployees(coveredEmployeeInfoMaps : List<Map<String, String>>) {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    wcPolicyChangeWizard.goToWCCoverageStep()
    var wcClassesInputSet = wcPolicyChangeWizard.WCCoverageStep.WorkersCompCoverageConfigScreen.ClassesInputSet
    NavigationManager.CurrentPCFElement = wcClassesInputSet
    _lineContextDelegate.setCoveredEmployees(coveredEmployeeInfoMaps)
  }

  override function verifyCoveredEmployees(data : List<Map<String, String>>) {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    wcPolicyChangeWizard.goToWCCoverageStep()
    var wcClassesInputSet = wcPolicyChangeWizard.WCCoverageStep.WorkersCompCoverageConfigScreen.ClassesInputSet
    NavigationManager.CurrentPCFElement = wcClassesInputSet
    _lineContextDelegate.verifyCoveredEmployees(data)
  }

  override function splitPeriod(splitEffectiveDateStr : String, splitType : typekey.RPSDType) {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    wcPolicyChangeWizard.goToWCCoverageStep()
    wcPolicyChangeWizard.splitPeriod(splitEffectiveDateStr, splitType.DisplayName)
  }

  override function verifySplitPeriods(data : List<Map<String, String>>) {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    var workersCompCoverageConfigScreen = wcPolicyChangeWizard.goToWCCoverageStep()
    var periodsEntriesOnUI = workersCompCoverageConfigScreen.WorkersCompCoverageCV.PolicyLinePerStateConfigDV.RatingPeriodsIterator._Entries

    data.eachWithIndex(\expectedPeriod, index -> {
      var actualPeriod = periodsEntriesOnUI.get(index).Period
      assertPeriods(expectedPeriod, actualPeriod)
    })
  }

  private function assertPeriods(expectedPeriod : Map<String, String>, actualPeriod : ValueElement) {
    assertThat(actualPeriod.Label).isEqualTo(expectedPeriod.get("Period"))
    assertThat(actualPeriod.Value).isEqualTo(expectedPeriod.get("Effective Date Range"))
  }

  override function verifySplitPeriodPremiums(data : List<Map<String,String>>) {
    var changeWizardQuoteScreen = loginAndGoToQuoteStep()
    NavigationManager.CurrentPCFElement = changeWizardQuoteScreen.RatingCumulDetailsPanelSet_WorkersCompLine
    _lineContextDelegate.verifySplitPeriodPremiums(data)
  }

  override function verifySplitPeriodRates(data : List<Map<String, String>>) {
    var changeWizardQuoteScreen = loginAndGoToQuoteStep()
    NavigationManager.CurrentPCFElement = changeWizardQuoteScreen.RatingCumulDetailsPanelSet_WorkersCompLine
    _lineContextDelegate.verifySplitPeriodRates(data)
  }

  override function addExperienceModifiers(data : List<Map<String, String>>) {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    var workersCompCoverageConfigScreen = wcPolicyChangeWizard.goToWCCoverageStep()
    NavigationManager.CurrentPCFElement = workersCompCoverageConfigScreen
    _lineContextDelegate.addExperienceModifiers(data)
  }

  function verifyRates(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  function overrideClassBaseRate(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  private function loginAndGoToCoverageStep() : pcftest.WorkersCompCoverageConfigScreen {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    var workersCompCoverageConfigScreen = wcPolicyChangeWizard.goToWCCoverageStep()
    return workersCompCoverageConfigScreen
  }

  private function loginAndGoToQuoteStep() : pcftest.PolicyChangeWizard_QuoteScreen {
    var wcPolicyChangeWizard = loginIfLoggedOut(UserUnderwriterRole).goToPolicyChange(PolicyChangeDataSetup.Entity.PolicyChange).WCMode
    var changeWizardQuoteScreen = wcPolicyChangeWizard.goToQuoteStep()
    return changeWizardQuoteScreen
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}