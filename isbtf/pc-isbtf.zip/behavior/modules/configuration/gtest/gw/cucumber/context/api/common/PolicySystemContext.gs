package gw.cucumber.context.api.common

/**
 * Methods specific to system in general
 */
@Export
interface PolicySystemContext {

  /**
   * Set the current system clock to the given date
   * @param date the given date for setting the clock
   */
  function setCurrentTime(date : String)

  /**
   * Roll back the system plugins
   */
  function restorePlugins()

  /**
   * Run batch process based on the given batch process name
   * @param batchProcessName the given batch process name to run
   */
  function runBatchProcess(batchProcessName : String)
}