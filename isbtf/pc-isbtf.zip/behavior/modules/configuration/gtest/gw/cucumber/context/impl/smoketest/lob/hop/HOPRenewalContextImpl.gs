package gw.cucumber.context.impl.smoketest.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.database.Query
uses gw.api.database.Relop
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.impl.smoketest.job.renewal.RenewalContextImplBase

@Export
class HOPRenewalContextImpl extends RenewalContextImplBase implements HOPContext {

  @Inject delegate _lineContextDelegate represents HOPContext

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var riskAnalysisScreen = loginAsUser(UserUnderwriterManagerRole).goToRenewal(ScenarioInfoProvider.JobNumber).goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    riskAnalysisScreen.RiskAnalysisCV.RiskEvaluationPanelSet.UserViewFilter.getOptionByLabel("View All").click()
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function verifyNonCopperWiringUWissueExists() {
    var job = Query.make(Job).compare(Job#JobNumber, Relop.Equals, ScenarioInfoProvider.JobNumber).select().AtMostOneRow
    assertThat(job.LatestPeriod.UWIssuesIncludingSoftDeleted.hasMatch(\uwIssue -> uwIssue.ShortDescription == "Non-copper wiring"))
        .as("The Non-copper wiring UW issue should exist")
        .isEqualTo(true)
  }
}