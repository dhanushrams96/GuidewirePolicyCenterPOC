package gw.cucumber.testdata

@Export
class RoleSampleData {

  public static var ROLE_TO_USERS_MAP : Map<String, List<String>> = {
      "Audit Examiner"->{"tallen"},
      "Audit Supervisor"->{"avisor"},
      "Community Admin"->{"iadmin"},
      "Auditor"->{"aauditor"},
      "Premium Auditor"->{"aauditor"},
      "Processor"->{"pprocessor"},
      "Producer"->{"aarmstrong"},
      "Underwriter"->{"bbaker", "aapplegate", "ccraft", "dhenson"},
      "Underwriting Supervisor"->{"svisor", "ssmith", "dpofficer"}
  }

}