package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.RewriteBuilder

@ScenarioScoped
@Export
class RewriteDataSetup extends NonSubmissionDataSetup<RewriteBuilder>{

  construct(basedOnPeriod : PolicyPeriod) {
    super(basedOnPeriod)
  }

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username, basedOnPeriod)
  }
}