package gw.cucumber.testdata

uses cucumber.runtime.java.guice.ScenarioScoped

@Export
@ScenarioScoped
class AccountWrapper extends DataWrapper<Account> {

}