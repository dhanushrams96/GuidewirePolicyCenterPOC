package gw.cucumber.context.impl.smoketest.job.rewrite

uses gw.cucumber.context.api.job.rewrite.RewriteContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.setup.NonSubmissionDataSetup
uses gw.cucumber.setup.RewriteDataSetup
uses gw.cucumber.transformer.TypelistTransformer
uses gw.pl.currency.MonetaryAmount
uses pcftest.RewriteWizard

@Export
abstract class RewriteContextImplBase extends JobContextImplBase implements RewriteContext {

  override function setEffectiveDate(effectiveDate : Date) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyInStatus(status : String) {
    var expectedStatus = new TypelistTransformer<PolicyPeriodStatus>().transform(status)
    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(RewriteSetup.Entity.Rewrite)

    assertThat(rewriteWizard.JobWizardInfoBar.JobLabel.Text)
        .as("The rewrite should be " + expectedStatus)
        .contains(expectedStatus.DisplayName)
  }

  property get RewriteSetup() : RewriteDataSetup {
    return ScenarioInfoProvider.DataSetup as RewriteDataSetup
  }

  override function startRewritePolicy(rewriteType : RewriteType) {
    var cancellation = ScenarioInfoProvider.BasedOnPolicyPeriod
    ScenarioInfoProvider.DataSetup = new RewriteDataSetup(CurrentUser, cancellation)

    var policyFile = loginAsUser(UserUnderwriterRole).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)

    policyFile.clickRewrite(rewriteType)
    var rewritePeriod = NonSubmissionDataSetup.findPolicyPeriodFromBasedOn(cancellation, TC_REWRITE)
    RewriteSetup.set(rewritePeriod)
  }

  override function issue() {
    var policyPeriod = RewriteSetup.Entity
    assertThat(policyPeriod.Status)
        .as("This step assumes that the PolicyPeriod is quoted")
        .isEqualTo(PolicyPeriodStatus.TC_QUOTED)

    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(RewriteSetup.Entity.Rewrite)
    var quoteScreen = rewriteWizard.ViewQuote.click()
    quoteScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    waitForAutoRefreshToComplete()
    policyPeriod.refresh()

    ScenarioInfoProvider.BasedOnPolicyPeriod = policyPeriod
    RewriteSetup.refreshEntity()
  }

  override function quote() {
    verifyInStatus(PolicyPeriodStatus.TC_DRAFT.DisplayName)

    var rewriteWizard = goToRewrite()
    NavigationManager.CurrentPCFElement = rewriteWizard.PolicyReview.click().JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote
    super.quote()
  }

  override function verifyTransactionType(rewriteType : RewriteType ) {
    var rewriteWizard = loginIfLoggedOut(CurrentUser).goToRewrite(RewriteSetup.Entity.Rewrite)

    assertThat(rewriteWizard.JobWizardInfoBar.JobLabel.Text)
        .as("The rewrite should be " + rewriteType)
        .contains(rewriteType.DisplayName)
  }

  override function addContingency(contingencyInfo : Map<String, String>) : void {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  private function goToRewrite() : RewriteWizard {
    return loginIfLoggedOut(CurrentUser).goToTransaction(ScenarioInfoProvider.JobNumber) as RewriteWizard
  }

  function verifyCostsExists(costsMap : Map<String, MonetaryAmount>) {
    var jobWizard = loginAsUser(CurrentUser).goToRewrite(ScenarioInfoProvider.DataSetup.Entity.Rewrite)
    NavigationManager.CurrentPCFElement = jobWizard.ViewQuote.click().Quote_SummaryDV
    super.verifyCostsExists(costsMap)
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(issues : List<Map<String, String>>) {
    var saveCurrentUser = CurrentUser
    logout()
    var rewriteWizard = loginIfLoggedOut(UserUnderwriterRole).goToRewrite(RewriteSetup.Entity.Rewrite)
    var riskAnalysisScreen = rewriteWizard.RiskAnalysisStep.click()
    riskAnalysisScreen.selectViewIssuesBlocking("View All")
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.verifyUWBindBlockingAndApprovedIssuesExist(issues)
    logout()
    var tabBar = loginIfLoggedOut(saveCurrentUser)
  }
}