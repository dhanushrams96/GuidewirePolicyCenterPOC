package gw.cucumber.util.lob

@SuppressWarnings("unused")
@Export
enum ProductCode {

  PERSONAL_AUTO("PersonalAuto"),
  HOMEOWNERS("HOPHomeowners"),
  WORKERS_COMPENSATION("WorkersComp")

  final var lobCode : String as readonly LOBCode

  private construct(productCode: String) {
    lobCode = productCode
  }
}