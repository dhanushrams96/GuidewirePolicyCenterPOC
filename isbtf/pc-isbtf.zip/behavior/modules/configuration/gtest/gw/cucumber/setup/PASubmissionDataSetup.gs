package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.AccountContactBuilder
uses gw.api.builder.CoverageBuilder
uses gw.api.builder.DriverBuilder
uses gw.api.builder.PersonBuilder
uses gw.api.builder.PolicyLocationBuilder
uses gw.api.databuilder.UniqueKeyGenerator
uses gw.api.databuilder.pa.PASubmissionBuilder
uses gw.api.databuilder.pa.PAVehicleBuilder
uses gw.api.databuilder.pa.PersonalAutoLineBuilder
uses gw.api.databuilder.pa.PolicyDriverBuilder
uses gw.api.databuilder.pa.VehicleDriverBuilder

uses java.math.BigDecimal

/**
 * How to use this class in step file glue code
 *
 * 1. Use injection in the step file
 *    @Inject
 *    var _paSubmissionDataSetup : PASubmissionDataSetup
 *
 * 2. @Given steps
 *    Use _paSubmissionDataSetup or _paSubmissionDataSetup.Builder as appropriate
 *    There are useful methods on PASubmissionDataSetup that can be used directly,
 *    withDriver(age) for example.
 *    If the submission is created via the UI and not from the builder, for example if starting from an account,
 *    then use the set method to set the policy period directly on the PASubmissionDataSetup
 *
 * 3. @When steps
 *    Use _paSubmissionDataSetup.Entity in each When step
 *    If a UI action takes place within the When step which changes state, call .refreshEntity()
 *
 * 4. @Then steps
 *    Use _paSubmissionDataSetup.Entity in each Then step
 *
 */
@Export
@ScenarioScoped
class PASubmissionDataSetup extends SubmissionDataSetup<PASubmissionBuilder> {

  // related builders required for adding drivers and vehicles
  var _personalAutoLineBuilder : PersonalAutoLineBuilder as PALineBuilder
  var _policyDriverBuilders : List<PolicyDriverBuilder> as DriverBuilders = {}
  var _policyVehicleBuilders : List<PAVehicleBuilder> as VehicleBuilders = {}

  construct(username : String) {
    super(username)
  }

  protected override function createBuilder() : PASubmissionBuilder {
    return new PASubmissionBuilder(0)
  }

  protected override function initializeLines() {
    _personalAutoLineBuilder = new PersonalAutoLineBuilder()
    Builder.withPolicyLine(PALineBuilder)
  }

  /**
   * If not already provided, provide a default driver and/or a default vehicle
   * @return the builder
   */
  override function provideDefaults() : PASubmissionBuilder {
    provideDefaultDriver()
    provideDefaultVehicle()
    provideDefaultCoverages()
    return Builder
  }

  /**
   * By setting the following deductibles, the Producer role will avoid UWIssues
   */
  function provideDefaultCoverages() {
    VehicleBuilders.each(\vehicleBuilder -> {
      vehicleBuilder.withCoverage(new CoverageBuilder(PACollisionCov)
          .withPatternByCodeIdentifier("PACollisionCov")
          .withOptionCovTerm("PACollDeductible", "1,000"))
      vehicleBuilder.withCoverage(new CoverageBuilder(PAComprehensiveCov)
          .withPatternByCodeIdentifier("PAComprehensiveCov")
          .withOptionCovTerm("PACompDeductible", "1,000"))
    })
  }

  /**
   * If not already provided, provide a default driver
   * @return the builder
   */
  function provideDefaultDriver() : PASubmissionBuilder {
    if (_policyDriverBuilders.HasElements) {
      return Builder
    }
    withDriver(new PersonBuilder())
    return Builder
  }

  /**
   * If not already provided, provide a default vehicle with an existing driver
   * If no driver is yet provided, provide a default driver for the vehicle
   * @return the builder
   */
  function provideDefaultVehicle() : PASubmissionBuilder {
    if (_policyVehicleBuilders.HasElements) {
      return Builder
    }
    provideDefaultDriver()
    withVehicle()
    return Builder
  }

  /**
   * Add a driver having the given age to the builder
   * A driver under the age of 25 will cause a UW rule to execute
   * @param age of the driver
   * @return the builder
   */
  function withDriverAge(age : int) : PASubmissionBuilder {
    var person = new PersonBuilder().asDriver(age)
    return withDriver(person)
  }

  /**
   * Add a driver with the given PersonBuilder to the submission
   * @param person the PersonBuilder for this driver
   * @return the builder
   */
  function withDriver(person : PersonBuilder) : PASubmissionBuilder {
    var driverBuilder = new DriverBuilder()
    var accountContactBuilder = new AccountContactBuilder().withRole(driverBuilder).withContact(person)
    var policyDriverBuilder = new PolicyDriverBuilder().withAccountContactRole(driverBuilder)
    Builder.withPolicyContactRole(policyDriverBuilder)
    AccountDataSetup.withAccountContact(accountContactBuilder)
    PALineBuilder.withPolicyDriver(policyDriverBuilder)
    DriverBuilders.add(policyDriverBuilder)
    return Builder
  }

  /**
   * Add a vehicle having the given garage state
   * @param state the location of the vehicle
   * @return the builder
   */
  function withVehicleGarageState(state : State) : PASubmissionBuilder {
    provideDefaultDriver()
    return withVehicle(:state = state)
  }

  /**
   * Add a vehicle with the given price, given state, and given driver to the submission
   * @param costNew the cost of the vehicle when new. The default value is 22000
   * @param state the location of the vehicle. The default state "CA"
   * @param driverBuilder the driver of the vehicle. If null, the first available driver will be used
   * @return the builder
   */
  function withVehicle(costNew : int = 22000, state : State = null, driverBuilder : PolicyDriverBuilder = null) : PASubmissionBuilder {
    var policyLocationBuilder = new PolicyLocationBuilder().withState(state ?: TC_CA)
    var paVehicleBuilder = new PAVehicleBuilder().withLocation(policyLocationBuilder)
        .withVIN(UniqueKeyGenerator.get().nextKey())
        .withCostNew(new BigDecimal(costNew))
    if (driverBuilder == null) {
      provideDefaultDriver()
      driverBuilder = DriverBuilders.first()
    } else if (not DriverBuilders.contains(driverBuilder)) {
      DriverBuilders.add(driverBuilder)
    }
    var vehicleDriverBuilder = new VehicleDriverBuilder()
    driverBuilder.withVehicleDriver(vehicleDriverBuilder)
    paVehicleBuilder.withVehicleDriver(vehicleDriverBuilder)
    PALineBuilder.withVehicle(paVehicleBuilder)
    VehicleBuilders.add(paVehicleBuilder)
    Builder.withPolicyLocation(policyLocationBuilder)
    return Builder
  }

}