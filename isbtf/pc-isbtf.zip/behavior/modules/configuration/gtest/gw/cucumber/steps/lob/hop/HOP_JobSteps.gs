package gw.cucumber.steps.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.When
uses cucumber.api.java.en.Then
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.setup.DataTableRepository

/**
 * Home owners specific Job steps
 */
@Export
class HOP_JobSteps {

  @Inject
  var _contextFactory : ContextFactory

  @Inject
  var _dataTableRepository : DataTableRepository

  @Given("^I add the following Scheduled Personal Property:$")
  function iAddScheduledPersonalProperty(propertiesDataTable : DataTable) {
    _contextFactory.getLineContext<HOPContext>().addScheduledPersonalProperty(propertiesDataTable)
  }

  @When("^an approved Non-copper wiring UW issue which is valid until \"([^\"]+)\"$")
  function anApprovedNonCopperWiringUWIssueWithValidUntil(validUntil : String) {
    (_contextFactory.getLineContext() as HOPContext).providesAnApprovedNonCopperWiringUWIssueWithValidUntil(validUntil)
  }

  @When("^I set the dwelling with the information provided in the table:$")
  function iEnterTheDwellingInfo(dwellingDataTable : DataTable) {
    _contextFactory.getLineContext<HOPContext>().addDwellingInfo(dwellingDataTable)
  }

  @When("^I set the distance to fire hydrant and fire station as$")
  function setTheDistanceToFireHydrantAndFireStation(distanceInfo : DataTable) {
    _contextFactory.getLineContext<HOPContext>().setDistanceToFireHydrantAndFireStation(distanceInfo)
  }

  @When("^I infer the protection class code for the risk$")
  function iInferTheProtectionClass() {
    _contextFactory.getLineContext<HOPContext>().clickAutofillProtectionClass()
  }

  @When("^I add dwelling hazards as$")
  function iAddDwellingHazards(hazardsDataTable : DataTable){
    _contextFactory.getLineContext<HOPContext>().addDwellingHazards(hazardsDataTable)
  }

  @When("^I set construction type as Other$")
  function setConstructionTypeAsOther() {
    _contextFactory.getLineContext<HOPContext>().setConstructionTypeAsOther()
  }

  @When("^I set roof type as Other$")
  function setTheRoofTypeAsOther() {
    _contextFactory.getLineContext<HOPContext>().setRoofTypeAsOther()
  }

  @When("^I set primary heating as Oil$")
  function setPrimaryHeatingTypeAsOil() {
    _contextFactory.getLineContext<HOPContext>().setPrimaryHeatingTypeAsOil()
  }

  @When("^I set construction as$")
  function iEnterTheConstructionInfo(constructionDataTable: DataTable) {
    _contextFactory.getLineContext<HOPContext>().enterConstructionInfo(constructionDataTable)
  }

  @Then("^the dwelling should exist$")
  function dwellingInfoShouldBeSaved(dwellingDataTable: DataTable) {
    _contextFactory.getLineContext<HOPContext>().verifyDwellingInfo(dwellingDataTable)
  }

  @Then("^I should see a fire protection class code of \"(Superior|Standard|Limited|Poor|None)\"$")
  function fireProtectionClassCodeShouldBe(fireProtectionClassCode : String) {
    _contextFactory.getLineContext<HOPContext>().verifyFireProtectionClassCode(fireProtectionClassCode)
  }

  @Then("^the dwelling hazards should exist$")
  function dwellingHazardsInfoShouldBeSaved(hazardsDataTable: DataTable) {
    _contextFactory.getLineContext<HOPContext>().verifyDwellingHazardsInfo(hazardsDataTable)
  }

  @Then("^the Construction Type Description field should be provided$")
  function constructionTypeDescriptionFieldShouldBeProvided() {
    _contextFactory.getLineContext<HOPContext>().verifyConstructionTypeDescriptionFieldProvided()
  }

  @Then("^the Roof Type Description field should be provided$")
  function roofTypeDescriptionFieldShouldBeProvided() {
    _contextFactory.getLineContext<HOPContext>().verifyRoofTypeDescriptionFieldProvided()
  }

  @Then("^the Fuel Storage Tank and Fuel Line fields should be provided$")
  function fuelStorageTankAndFuelLineFieldsShouldBeProvided() {
    _contextFactory.getLineContext<HOPContext>().verifyFuelStorageTankAndFuelLineFieldsProvided()
  }

  @Then("^the dwelling construction should exist$")
  function constructionInfoShouldBeSaved(constructionDataTable: DataTable) {
    _contextFactory.getLineContext<HOPContext>().verifyConstructionInfo(constructionDataTable)
  }

  @Then("^I should have the following product information available$")
  function iShouldHaveTheHOPInfoAvailable(hopInfo : DataTable) {
    _contextFactory.getLineContext<HOPContext>().verifyHOPInfoAvailable(hopInfo)
  }

  @Then("^the Non-copper wiring UW issue should exist$")
  function nonCopperWiringUWIssueShouldExist() {
    _contextFactory.getLineContext<HOPContext>().verifyNonCopperWiringUWissueExists()
  }

  @Given("^with the following animal information$")
  function withTheFollowingAnimalInformation(animalInfoTable : DataTable) {
    _contextFactory.getLineContext<HOPContext>().addAnimalToPeriod(animalInfoTable)
  }

  @Given("^the age of the house is more than \"(\\d+)\" years$")
  function theAgeOfTheHouseIsMoreThanYears(houseAgeInYears : int) {
    _contextFactory.getLineContext<HOPContext>().setHouseAge(houseAgeInYears)
  }

  @Given("^the roof was not upgraded$")
  function theRoofWasNotUpgraded() {
    _contextFactory.getLineContext<HOPContext>().roofWasNotUpgraded()
  }
}