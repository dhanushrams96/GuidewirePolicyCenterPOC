package gw.cucumber

uses com.google.inject.multibindings.MapBinder
uses com.google.inject.name.Names
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.context.api.common.AccountContext
uses gw.cucumber.context.api.common.ActivityContext
uses gw.cucumber.context.api.common.AdminContext
uses gw.cucumber.context.api.common.NotesContext
uses gw.cucumber.context.api.common.PolicySystemContext
uses gw.cucumber.context.api.job.audit.AuditContext
uses gw.cucumber.context.api.job.cancellation.CancellationContext
uses gw.cucumber.context.api.job.issuance.IssuanceContext
uses gw.cucumber.context.api.job.policychange.PolicyChangeContext
uses gw.cucumber.context.api.job.reinstatement.ReinstatementContext
uses gw.cucumber.context.api.job.renewal.RenewalContext
uses gw.cucumber.context.api.job.rewrite.RewriteContext
uses gw.cucumber.context.api.job.submission.SubmissionContext
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.api.lob.wc.WCContext
uses gw.cucumber.context.impl.ContextFactoryImpl
uses gw.cucumber.context.impl.smoketest.common.AccountContextImpl
uses gw.cucumber.context.impl.smoketest.common.ActivityContextImpl
uses gw.cucumber.context.impl.smoketest.common.AdminContextImpl
uses gw.cucumber.context.impl.smoketest.common.NotesContextImpl
uses gw.cucumber.context.impl.smoketest.common.PolicySystemContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPCancellationContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPIssuanceContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPPolicyChangeContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPReinstatementContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPRewriteContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPRenewalContextImpl
uses gw.cucumber.context.impl.smoketest.lob.hop.HOPSubmissionContextFullQuoteImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PACancellationContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PAContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PAIssuanceContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PAPolicyChangeContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PAReinstatementContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PARenewalContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PARewriteContextImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PASubmissionContextFullQuoteImpl
uses gw.cucumber.context.impl.smoketest.lob.pa.PASubmissionContextQuickQuoteImpl
uses gw.cucumber.context.impl.smoketest.lob.wc.WCAuditContextImpl
uses gw.cucumber.context.impl.smoketest.lob.wc.WCContextImpl
uses gw.cucumber.context.impl.smoketest.lob.wc.WCPolicyChangeContextImpl
uses gw.cucumber.context.impl.smoketest.lob.wc.WCSubmissionContextFullQuoteImpl
uses gw.cucumber.context.impl.smoketest.lob.wc.WCSubmissionContextQuickQuoteImpl
uses gw.cucumber.util.lob.ProductCode

/**
 * Class defined to extend the platform behavior and add custom bindings. To make things simpler, each job context can
 * have one or multiple binds, one for each lob.
 *
 * If the OOTB behavior needs to be extended for any of the Impl classes, the recommendation is to create a new class and
 * register it here. For example:
 *
 * If there is a need to add custom methods to PAPersonalAutoSubmissionImpl, a recommendation would be to create a new class
 * PAPersonalAutoContextImpl_Ext that extends from the OOTB PAPersonalAutoContextImpl. Then just modify modify the binding
 * configuration here to register the new class as follows:
 *
 * - submissionContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PASubmissionContextImpl_Ext)
 *
 */
@Export
class PCRemoteSmokeTestHelperModule extends RemoteSmokeTestHelperModule {

  construct(appSpecificSmokeTestProxyType : Type<ICucumberSmokeTestProxy>) {
    super(appSpecificSmokeTestProxyType)
  }

  protected override function configure() {
    super.configure()

    // Quick Quote Submission Contexts
    var quickQuoteSubmissionContexts = MapBinder.newMapBinder(binder(), ProductCode, SubmissionContext, Names.named("QuickQuote"))
    quickQuoteSubmissionContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PASubmissionContextQuickQuoteImpl)
    quickQuoteSubmissionContexts.addBinding(ProductCode.WORKERS_COMPENSATION).to(WCSubmissionContextQuickQuoteImpl)

    // Full Quote Submission Contexts
    var fullQuoteSubmissionContexts = MapBinder.newMapBinder(binder(), ProductCode, SubmissionContext, Names.named("FullQuote"))
    fullQuoteSubmissionContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PASubmissionContextFullQuoteImpl)
    fullQuoteSubmissionContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPSubmissionContextFullQuoteImpl)
    fullQuoteSubmissionContexts.addBinding(ProductCode.WORKERS_COMPENSATION).to(WCSubmissionContextFullQuoteImpl)

    // Issuance Contexts
    var issuanceContexts = MapBinder.newMapBinder(binder(), ProductCode, IssuanceContext)
    issuanceContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PAIssuanceContextImpl)
    issuanceContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPIssuanceContextImpl)

    // Policy Change Contexts
    var policyChangeContexts = MapBinder.newMapBinder(binder(), ProductCode, PolicyChangeContext)
    policyChangeContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PAPolicyChangeContextImpl)
    policyChangeContexts.addBinding(ProductCode.WORKERS_COMPENSATION).to(WCPolicyChangeContextImpl)
    policyChangeContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPPolicyChangeContextImpl)

    // Renewal Contexts
    var renewalContexts = MapBinder.newMapBinder(binder(), ProductCode, RenewalContext)
    renewalContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PARenewalContextImpl)
    renewalContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPRenewalContextImpl)

    // Rewrite Contexts
    var rewriteContexts = MapBinder.newMapBinder(binder(), ProductCode, RewriteContext)
    rewriteContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PARewriteContextImpl)
    rewriteContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPRewriteContextImpl)

    // Reinstatement Contexts
    var reinstatementContexts = MapBinder.newMapBinder(binder(), ProductCode, ReinstatementContext)
    reinstatementContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PAReinstatementContextImpl)
    reinstatementContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPReinstatementContextImpl)

    // Audit Contexts
    var auditContexts = MapBinder.newMapBinder(binder(), ProductCode, AuditContext)
    auditContexts.addBinding(ProductCode.WORKERS_COMPENSATION).to(WCAuditContextImpl)

    // Cancellation Contexts
    var cancellationContexts = MapBinder.newMapBinder(binder(), ProductCode, CancellationContext)
    cancellationContexts.addBinding(ProductCode.PERSONAL_AUTO).to(PACancellationContextImpl)
    cancellationContexts.addBinding(ProductCode.HOMEOWNERS).to(HOPCancellationContextImpl)

    // Line specific contexts
    bind(PAContext).to(PAContextImpl)
    bind(HOPContext).to(HOPContextImpl)
    bind(WCContext).to(WCContextImpl)

    //Account context
    bind(AccountContext).to(AccountContextImpl)

    //Notes context
    bind(NotesContext).to(NotesContextImpl)

    //Admin context
    bind(AdminContext).to(AdminContextImpl)

    //Policy System context
    bind(PolicySystemContext).to(PolicySystemContextImpl)

    //Activity context
    bind(ActivityContext).to(ActivityContextImpl)

    // Factory
    bind(ContextFactory).to(ContextFactoryImpl)

  }
}