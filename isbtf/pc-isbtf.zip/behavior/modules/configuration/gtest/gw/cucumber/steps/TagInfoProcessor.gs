package gw.cucumber.steps

uses com.google.inject.Inject
uses cucumber.api.java.Before
uses gw.cucumber.util.lob.ProductCode
uses typekey.Job

@SuppressWarnings("ALL")
@Export
class TagInfoProcessor {

  @Inject
  var _scenarioInfoProvider : ScenarioInfoProvider

  // LOB tags

  @Before(:value = {"@personal_auto"})
  function personalAuto() {
    setLine(ProductCode.PERSONAL_AUTO)
  }

  @Before(:value = {"@homeowners"})
  function homeowners() {
    setLine(ProductCode.HOMEOWNERS)
  }

  @Before(:value = {"@workers_compensation"})
  function workersCompensation() {
    setLine(ProductCode.WORKERS_COMPENSATION)
  }

  // Job tags

  @Before(:value = {"@audit"})
  function audit() {
    setJobSubtype(Job.TC_AUDIT)
  }

  @Before(:value = {"@submission"})
  function submission() {
    setJobSubtype(Job.TC_SUBMISSION)
  }

  @Before(:value = {"@issuance"})
  function issuance() {
    setJobSubtype(Job.TC_ISSUANCE)
  }

  @Before(:value = {"@policy_change"})
  function policyChange() {
    setJobSubtype(Job.TC_POLICYCHANGE)
  }

  @Before(:value = {"@renewal"})
  function renewal() {
    setJobSubtype(Job.TC_RENEWAL)
  }

  @Before(:value = {"@rewrite"})
  function rewrite() {
    setJobSubtype(Job.TC_REWRITE)
  }

  @Before(:value = {"@cancellation"})
  function cancellation() {
    setJobSubtype(Job.TC_CANCELLATION)
  }

  /**
   * Assigns the lob to the scenario info provider. There is validation to avoid overriding this value if already specified,
   * for example if the feature file is double tagged as @personal_auto and @homeowners, an exception will be thrown.
   *
   * @param line
   */
  private function setLine(line : ProductCode) {
    if (_scenarioInfoProvider.Line != null) {
      throw new IllegalStateException("TagInfoProcessor: Cannot assign the line to ${line} because the line has already been assigned to ${_scenarioInfoProvider.Line}.")
    }
    _scenarioInfoProvider.Line = line
  }

  /**
   * Assigns the job subtype to the scenario info provider. There is validation to avoid overriding this value if already
   * specified, for example if the feature file is double tagged as @submission and @policy_change, an exception will be thrown.
   *
   * @param jobSubtype
   */
  private function setJobSubtype(jobSubtype : Job) {
    if (_scenarioInfoProvider.JobSubType != null) {
      throw new IllegalStateException("TagInfoProcessor: Cannot assign the job subtype to ${jobSubtype} because the job subtype has already been assigned to ${_scenarioInfoProvider.JobSubType}.")
    }
    _scenarioInfoProvider.JobSubType = jobSubtype
  }
}