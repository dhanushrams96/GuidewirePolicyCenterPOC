package gw.cucumber.context.impl.smoketest.job.audit

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.job.audit.AuditContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.transformer.MonetaryAmountTransformer
uses gw.cucumber.util.common.UIHelper
uses pcftest.AuditDetailsPanelSet_WorkersComp

@Export
abstract class AuditContextImplBase extends JobContextImplBase implements AuditContext {

  override function scheduleAudit(scheduledDate : Date) {
    var policyFile = loginAsUser(CurrentUser).goToPolicyFile(ScenarioInfoProvider.BasedOnPolicyPeriod.PolicyNumber)
    var auditSchedule = policyFile.MenuLinks.PolicyFile_PolicyFile_Audits.click().AuditInformationScreen

    var popUp = auditSchedule.AuditsLV._Entries.single().Edit.click()
    popUp.InitDate.setDateValue(scheduledDate)
    popUp.Update.click()
  }

  override function enterAuditInfoForReportStartingOn(reportStartingDate : Date, auditInfo : Map<String, String>) {
    var auditWizard = loginAsUser(CurrentUser).goToAudit(AuditJobNumber)
    var summaryStep = auditWizard.Summary.AuditWizard_SummaryScreen
    assertThat(summaryStep.AuditSummaryDV.PeriodStart.DateValue)
        .as("The report start date should be ${reportStartingDate}")
        .isEqualTo(reportStartingDate)

    var auditInfoMap = auditInfo.copy()
    var paymentReceivedString = auditInfoMap.get(DisplayKey.get("Web.AuditWizard.PaymentReceived"))
    var paymentReceived = new MonetaryAmountTransformer().transform(paymentReceivedString).Amount.toPlainString()
    auditInfoMap.replace(DisplayKey.get("Web.AuditWizard.PaymentReceived"), paymentReceived)
    UIHelper.setFieldValues(summaryStep, auditInfoMap)
    summaryStep.JobWizardToolbarButtonSet_Audit.Draft.click()
    auditWizard.Next.click()
  }

  override function enterAuditSummaryInfo(auditSummaryInfo : Map<String, String>) {
    var auditWizard = loginAsUser(CurrentUser).goToAudit(AuditJobNumber)
    var summaryStep = auditWizard.Summary.AuditWizard_SummaryScreen

    var auditSummaryInfoMap = auditSummaryInfo.copy()
    var auditFeeString = auditSummaryInfoMap.get(DisplayKey.get("Web.AuditWizard.AuditFee"))
    var auditFee = new MonetaryAmountTransformer().transform(auditFeeString).Amount.toPlainString()
    auditSummaryInfoMap.replace(DisplayKey.get("Web.AuditWizard.AuditFee"), auditFee)

    UIHelper.setFieldValues(summaryStep, auditSummaryInfoMap)
    summaryStep.JobWizardToolbarButtonSet_Audit.Draft.click()
    auditWizard.Next.click()
  }

  override function enterAuditDetails(auditDetails : List<Map<String, String>>) {
    var auditWizard = loginAsUser(CurrentUser).goToAudit(AuditJobNumber)
    auditWizard.Details.click()
    var detailStep = auditWizard.Details.AuditWizard_DetailsScreen

    // Assuming it's a single state and a single period for this policy. Because there are three layer of iteration
    // on this PCF page, by having multiple states and/or mutiple periods we'll have to specify the state and period
    // slice date details to match the desired one
    var panelSet = detailStep.AuditDetailsPanelSet_WorkersComp._Entries.single() //assume single State
    var periodPanel = panelSet.StatePanelSet._Entries.single() //assume single period

    fillInDefaultAuditPayroll(periodPanel)
    auditDetails.each(\auditInfo -> {
      findAndSetAuditInfo(auditInfo, periodPanel)
    })

    detailStep.JobWizardToolbarButtonSet_Audit.Draft.click()
  }

  override function calculatePremiums() {
    var auditWizard = loginAsUser(CurrentUser).goToAudit(AuditJobNumber)
    var detailsPage = auditWizard.Details.click()
    detailsPage.Quote.click()
    assertThat(auditWizard.Premiums.AuditWizard_PremiumsScreen.PremiumsSummaryCardTab.Visible)
        .isTrue()
  }

  override function submitPremiumOrFinalAudit() {
    var auditWizard = loginAsUser(CurrentUser).goToAudit(AuditJobNumber)
    var premiumsPage = auditWizard.Premiums.click()
    premiumsPage.JobWizardToolbarButtonSet_Audit.SubmitAudit.click()
  }

  override function verifyAuditScheduleExists(auditDetails : List<Map<String, String>>) {
    var policyFile = loginAsUser(CurrentUser).goToPolicyFile(ScenarioInfoProvider.PolicyNumber)
    var policyFileAuditsScreen = policyFile.MenuLinks.PolicyFile_PolicyFile_Audits.click()
    var auditsLV = policyFileAuditsScreen.AuditInformationScreen.AuditsLV

    //make a list of Maps from AuditsLV filtering on the the fields we care about
    var lvMapList = new ArrayList<Map<String, String>>()
    auditsLV._Entries.each(\entry -> {
      lvMapList.add({entry.AuditType.Label -> entry.AuditType.Value,
          entry.AuditStatus.Label -> entry.AuditStatus.Value,
          entry.AuditPeriodStartDate.Label -> entry.AuditPeriodStartDate.Value,
          entry.AuditPeriodEndDate.Label -> entry.AuditPeriodEndDate.Value})
    })
    lvMapList.sort(\s1, s2 -> s1.get("Type") > s2.get("Type"))
    assertThat(auditDetails).isEqualTo(lvMapList.toList())
  }

  private property get AuditJobNumber() : String {
    var policySummary = loginAsUser(CurrentUser).goToPolicySummary(ScenarioInfoProvider.PolicyNumber)

    //assume only one Final Audit/Premium Report Job
    var auditEntry = policySummary.PendingTransactionsLV._Entries
        .singleWhere(\pendingJob -> pendingJob.JobInProgressType.Text == "Final Audit" or pendingJob.JobInProgressType.Text == "Premium Report" )
    return auditEntry.JobNumber.Text
  }

  private function fillInDefaultAuditPayroll(auditDetails: AuditDetailsPanelSet_WorkersComp.entry.StatePanelSet.entry2) {
    auditDetails.PeriodDV._Entries.each(\entry -> {
      entry.AuditedAmt.setValue(entry.EstPayroll.Text)
    })
  }

  private function findAndSetAuditInfo (auditInfo : Map<String, String>, auditDetails: AuditDetailsPanelSet_WorkersComp.entry.StatePanelSet.entry2) {
    var location = auditInfo.get(DisplayKey.get("Web.AuditWizard.Details.Location"))
    var classCode = auditInfo.get(DisplayKey.get("Web.AuditWizard.Details.ClassCode"))
    var estimatedPayroll = auditInfo.get(DisplayKey.get("Web.AuditWizard.EstPayroll"))
    var auditedPayroll = auditInfo.get(DisplayKey.get("Web.AuditWizard.AuditedPayroll"))

    auditDetails.PeriodDV._Entries.each(\entry -> {
      if (entry.Location.Text == location
          && entry.ClassCode.Text == classCode
          && entry.EstPayroll.Text == estimatedPayroll) {
        entry.AuditedAmt.setValue(auditedPayroll)
      }
    })
  }
}