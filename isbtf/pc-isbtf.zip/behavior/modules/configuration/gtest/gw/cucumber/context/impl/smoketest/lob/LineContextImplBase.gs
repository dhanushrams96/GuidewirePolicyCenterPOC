package gw.cucumber.context.impl.smoketest.lob

uses com.google.common.collect.ImmutableMap
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.lob.LineContext
uses pcftest.PolicyFile

@Export
abstract class LineContextImplBase extends CucumberStepBase implements LineContext {

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverageDoesNotExist(covName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function viewRatingWorksheet() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyRatingWorksheet() {
    var ratingWorksheetPopup = NavigationManager.ensureOnPage(pcftest.RatingWorksheetPopup)
    var worksheet = ratingWorksheetPopup.WorksheetLV._Entries
    assertThat(worksheet).as("Rating worksheet should not be empty!").isNotEmpty()
  }

  override function prepareRating() {
    prepareRatingEnvironment()
  }

  override function splitPeriod(splitEffectiveDateStr : String, splitType : typekey.RPSDType) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifySplitPeriods(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifySplitPeriodPremiums(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifySplitPeriodRates(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Subclass must override this method")
  }

  override function verifyPolicyTransactions(expectedTransactions : List<Map<String, String>>) {
    var transactionsOnJobsScreen = {}
    goToPolicyFile().goToPolicy_JobsScreen().DetailPanel.JobsLV._Entries.each(\elt -> {
      var transaction = ImmutableMap.builder<String, String>()
          .put(elt.Type.Label, elt.Type.Value)
          .put(elt.EffectiveDate.Label, elt.EffectiveDate.Value)
          .put(elt.Status.Label, elt.Status.Value)
          .build()
      transactionsOnJobsScreen.add(transaction)
    })

    assertThat(transactionsOnJobsScreen).contains(expectedTransactions.toArray())
  }

  override function viewTransaction(transaction : String, date : String) {
    var detailPanel = goToPolicyFile().goToPolicy_JobsScreen().DetailPanel
    var transactionNumber = detailPanel.JobsLV._Entries.singleWhere(\elt -> elt.Type.Value == transaction &&
        elt.EffectiveDate.Value == date).JobNumber.Value
    ScenarioInfoProvider.JobNumber = transactionNumber
  }

  private function goToPolicyFile() : PolicyFile {
    return loginIfLoggedOut(UserUnderwriterRole).goToPolicyFile(ScenarioInfoProvider.PolicyNumber)
  }

}