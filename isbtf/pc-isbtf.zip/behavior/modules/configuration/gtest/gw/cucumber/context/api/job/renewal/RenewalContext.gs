package gw.cucumber.context.api.job.renewal

uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link Renewal}
 */
@Export
interface RenewalContext extends JobContext {

  /**
   * Start a Renewal job in draft status
   */
  function startRenewal()

  /**
   * Issue a Renewal job based on the given option (Renew, Issue now, etc)
   * @param : option the given Renewal option
   */
  function issueRenewal(option : String)
}