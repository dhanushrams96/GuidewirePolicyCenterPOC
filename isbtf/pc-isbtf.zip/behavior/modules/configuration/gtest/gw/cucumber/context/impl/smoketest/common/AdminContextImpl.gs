package gw.cucumber.context.impl.smoketest.common

uses gw.api.database.Query
uses gw.cucumber.CucumberStepBase
uses gw.cucumber.context.api.common.AdminContext
uses gw.cucumber.testdata.RoleSampleData
uses gw.sampledata.SampleData
uses pcftest.PolicyHolds

@Export
class AdminContextImpl extends CucumberStepBase implements AdminContext {

  override function userRoleSetup(userRole : String) {
    logout()
    SampleData.loadSampleDataSet(SampleDataSet.TC_SMALL)

    var username = RoleSampleData.ROLE_TO_USERS_MAP.get(userRole).first()
    CurrentUser = username
  }

  override function createPolicyHold(holdInfo : Map<String, String>) {
    goToPolicyHoldScreen().setUpFieldsOnUI(holdInfo)
    logout()
  }

  override function deletePolicyHold(holdCode : String) {
    goToPolicyHoldScreen().deleteHold(holdCode)
    logout()
  }

  private function goToPolicyHoldScreen(): PolicyHolds.PolicyHoldsScreen {
    logout()
    return loginIfLoggedOut("su").AdminTab.Admin_BusinessSettings.BusinessSettings_PolicyHolds.click().PolicyHoldsScreen
  }

  override function verifyUWIssuesLoaded(uwRules : List<String>){
    var usIssuesInDatabase = Query.make(UWRule).select()

    assertThat(usIssuesInDatabase.map(\rule -> rule.Name))
        .as("UW issues are not loaded, UWIssues ${uwRules}")
        .contains(uwRules.toArray())
  }
}