package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.RenewalBuilder

@Export
@ScenarioScoped
class RenewalDataSetup extends NonSubmissionDataSetup<RenewalBuilder> {

  construct(basedOnPeriod : PolicyPeriod) {
    super(basedOnPeriod)
  }

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username, basedOnPeriod)
  }
}