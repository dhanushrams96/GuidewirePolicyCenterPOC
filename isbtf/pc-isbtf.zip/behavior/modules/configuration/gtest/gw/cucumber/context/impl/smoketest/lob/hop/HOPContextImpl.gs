package gw.cucumber.context.impl.smoketest.lob.hop

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.api.util.DateUtil
uses gw.cucumber.context.api.lob.hop.HOPContext
uses gw.cucumber.context.impl.smoketest.lob.LineContextImplBase
uses gw.cucumber.util.common.ProductModelReflectUtil
uses gw.cucumber.transformer.TypelistTransformer
uses gw.cucumber.setup.DataTableRepository

class HOPContextImpl extends LineContextImplBase implements HOPContext{

  @Inject
  var _dataTableRepository : DataTableRepository

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var allLineLevelCoveragesDV = NavigationManager.ensureOnPage(pcftest.HOPMainCoveragesPanelSet)
    assertThat(period.Status)
        .as("this step requires " + period.Job.DisplayName + " in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)
    ProductModelReflectUtil.addAndSetCoverage(covName, coverageTerms, allLineLevelCoveragesDV)
  }

  override function removeLineLevelCoverage(covName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyLineLevelCoverageDoesNotExist(covName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function viewRatingWorksheet() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyRatingWorksheet() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function prepareRating() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function splitPeriod(splitEffectiveDate : String, splitType : RPSDType) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifySplitPeriods(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifySplitPeriodPremiums(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifySplitPeriodRates(data : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setWhoOccupiesThisDwelling(occupier : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addScheduledPersonalPropertyCoverage(coverageTerms : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyScheduledItemPremiumExist() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyCoverageExistsOnPolicyReview(coveragename : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addDwellingInfo(givenFields : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyDwellingInfo(expectedDwellingInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addNewPolicyLocationWithoutSave(newPolicyLocation : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTerritoryCodeOnPopup(code : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setDistanceToFireHydrantAndFireStation(firehydrantDistances : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function clickAutofillProtectionClass() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyFireProtectionClassCode(fireProtectionClassCode : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function createABoundPolicyWithPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addAnimalUsingUI(animalInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addDwellingHazards(hazardsMap : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyDwellingHazardsInfo(expectedHazardsInfoMap : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setConstructionTypeAsOther() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyConstructionTypeDescriptionFieldProvided() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setRoofTypeAsOther() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyRoofTypeDescriptionFieldProvided() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function setPrimaryHeatingTypeAsOil() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyFuelStorageTankAndFuelLineFieldsProvided() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function enterConstructionInfo(constructionInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyConstructionInfo(constructionInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addScheduledPersonalProperty(scheduledPersonalProperties : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyHOPInfoAvailable(hopInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function causeNonCopperWiringUWIssue() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function providesAnApprovedNonCopperWiringUWIssueWithValidUntil(validUntil : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyNonCopperWiringUWissueExists() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function addAnimalToPeriod(animalInfoTable : DataTable) {
    var animalMap = _dataTableRepository.dataTableLookup(animalInfoTable).asMap(String, String)
    var policyPeriod = ScenarioInfoProvider.DataSetup.Entity
    policyPeriod = policyPeriod.getSlice(policyPeriod.EditEffectiveDate)

    gw.transaction.Transaction.runWithNewBundle(\bundle -> {
      policyPeriod = bundle.add(policyPeriod)
      var animal = new DwellingAnimal(policyPeriod)
      animal.AnimalType = new TypelistTransformer<AnimalType>().transform(animalMap.get("Animal Type"))
      animal.AnimalBreed = new TypelistTransformer<AnimalBreed>().transform(animalMap.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBreed")))
      animal.AnimalBiteHistory = animalMap.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBiteHistory")) == "Yes" ? Boolean.TRUE : Boolean.FALSE
      policyPeriod.HOPLine.HOPDwellings.first().addToDwellingAnimals(animal)
    }, CurrentUser)
  }

  override function setHouseAge(houseAgeInYears : int){
    var policyPeriod = ScenarioInfoProvider.DataSetup.Entity
    policyPeriod = policyPeriod.getSlice(policyPeriod.EditEffectiveDate)
    var dwelling = policyPeriod.HOPLine.HOPDwellings.first()

    gw.transaction.Transaction.runWithNewBundle(\bundle -> {
      dwelling = bundle.add(dwelling)
      dwelling.YearBuilt = DateUtil.addYears(DateUtil.currentDate(), -(houseAgeInYears + 1)).YearOfDate
    }, CurrentUser)
  }

  override function roofWasNotUpgraded(){
    var policyPeriod = ScenarioInfoProvider.DataSetup.Entity
    policyPeriod = policyPeriod.getSlice(policyPeriod.EditEffectiveDate)
    var dwelling = policyPeriod.HOPLine.HOPDwellings.first()

    gw.transaction.Transaction.runWithNewBundle(\bundle -> {
      dwelling = bundle.add(dwelling)
      dwelling.RoofingUpgradeDate = null
    }, CurrentUser)
  }
}