package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.api.locale.DisplayKey
uses gw.api.util.MonetaryAmounts
uses gw.api.util.StringUtil
uses gw.command.critical.KeyGenerator
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.JobContextImplBase
uses gw.cucumber.transformer.MonetaryAmountTransformer
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses gw.util.IssueRow

@Export
class PASubmissionContextQuickQuoteImpl extends PASubmissionContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addDriver(givenFields : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToQuickSubmission(period)
    var quickQuoteWizard = submissionWizard.PAMode
    var infoStep = quickQuoteWizard.goToInfoStep()

    var driverPanelSet = infoStep.DriverDetails1.PAQuickQuoteDriverPanelSet
    driverPanelSet.AddDriverButton._Entries[0].ContactType.click()

    UIHelper.setFieldValues(driverPanelSet, new UIFieldsProviderBase(givenFields) {

      override property get RequiredFields() : Set<String> {
        return {
            DisplayKey.get("Web.ContactDetail.Name.FirstName"),
            DisplayKey.get("Web.ContactDetail.Name.LastName")
        }
      }

      override property get DefaultFields() : Map<String, String> {
        return {
            DisplayKey.get("Web.ContactDetail.Name.FirstName") -> KeyGenerator.FirstName,
            DisplayKey.get("Web.ContactDetail.Name.LastName") -> KeyGenerator.LastName,
            DisplayKey.get("Web.ContactDetail.Person.DateOfBirth") -> "01/01/1985",
            DisplayKey.get("Web.ContactDetail.Person.MaritalStatus") -> "Married",
            DisplayKey.get("Web.Account.Contact.Driver.YearGotLicence") -> "2001",
            DisplayKey.get("Web.Account.Contact.Driver.NumberOfAccidents") -> "0",
            DisplayKey.get("Web.Account.Contact.Driver.NumberOfViolations") -> "0"
        }
      }
    })
    infoStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function addVehicle(givenFields : Map<String, String>) {
    var period = ScenarioInfoProvider.DataSetup.Entity
    var submissionWizard = loginIfLoggedOut("bbaker").goToQuickSubmission(period)
    var quickQuoteWizard = submissionWizard.PAMode

    var infoStep = quickQuoteWizard.goToInfoStep()

    var vehiclePanelSet = infoStep.VehicleDetails1.PAQuickQuoteVehiclePanelSet
    vehiclePanelSet.AddVehicleButton.click()

    UIHelper.setFieldValues(vehiclePanelSet, new UIFieldsProviderBase(givenFields) {

      override property get RequiredFields() : Set<String> {
        return {
            DisplayKey.get("Web.PolicyLine.Vehicle.Make"),
            DisplayKey.get("Web.PolicyLine.Vehicle.Model"),
            DisplayKey.get("Web.PolicyLine.Vehicle.PrimaryDriver")
        }
      }

      override property get DefaultFields() : Map<String, String> {
        return {
            DisplayKey.get("Web.PolicyLine.Vehicle.Year") -> "2000",
            DisplayKey.get("Web.PolicyLine.Vehicle.Make") -> "Ford",
            DisplayKey.get("Web.PolicyLine.Vehicle.Model") -> "Fusion",
            DisplayKey.get("Web.PolicyLine.Vehicle.CostNew") -> "25300"
        }
      }
    })
    infoStep.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  override function verifyVehicleExists(givenFields : Map<String, String>) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function enterPolicyInfo(givenFields : Map<String, String>) {
      var period = ScenarioInfoProvider.DataSetup.Entity
      var submissionWizard = loginIfLoggedOut(CurrentUser).goToQuickSubmission(period)
      var quickQuoteWizard = submissionWizard.PAMode

      var infoStep = quickQuoteWizard.goToInfoStep()
      UIHelper.setFieldValues(infoStep, new UIFieldsProviderBase(givenFields) {

        override property get RequiredFields() : Set<String> {
          return {
              DisplayKey.get("Web.SubmissionWizard.PolicyInfo.TermType"),
              DisplayKey.get("Web.SubmissionWizard.PolicyInfo.BaseState")
          }
        }

        override property get DefaultFields() : Map<String, String> {
          return {
              DisplayKey.get("Web.SubmissionWizard.PolicyInfo.EffectiveDate") -> StringUtil.formatDate(period.EditEffectiveDate, "MM/dd/yyyy")
          }
        }
      })
      infoStep.JobWizardToolbarButtonSet_Submission.Draft.click()
    }

  override function selectPreQualification(givenFields : List<Map<String, String>>) {
    throw new UnsupportedOperationException("Not supported in Quick Quote")
  }

  override function quote() {
    var quickQuoteSubmissionWizard = loginIfLoggedOut(CurrentUser).goToQuickSubmission(ScenarioInfoProvider.JobNumber)
    quickQuoteSubmissionWizard.ViewQuote.click().quote()
  }

  override function withdraw(closeOption : String, closeReason : String) {
    throw new UnsupportedOperationException("Not implemented")
  }

  override function approveUWIssuesAsUnderwriter(description : String) {
    logout()
    var jobWizard = loginAsUser(UserUnderwriterRole).goToQuickSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = jobWizard.goToRiskAnalysis()

    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    super.approveUWIssuesAsUnderwriter(description)
  }

  override function verifyUWBindBlockingIssues(shouldExist : boolean) {
    logout()
    var submissionWizard = loginAsUser(UserUnderwriterRole).goToQuickSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    var issuesBlockingBind = riskAnalysisScreen.BlockingIssues
    if (shouldExist) {
      assertThat(issuesBlockingBind)
          .as("There should be an underwriting issue blocking bind")
          .isNotEmpty()
    } else {
      assertThat(issuesBlockingBind)
          .as("The underwriting issues should be empty")
          .isEmpty()
    }
    logout()
  }

  override function verifyUWApprovedIssues(shouldExist : boolean) {
    logout()
    var submissionWizard = loginAsUser(UserUnderwriterRole).goToQuickSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    var approvedIssues = riskAnalysisScreen.ApprovedIssues
    if (shouldExist) {
      assertThat(approvedIssues)
          .as("There should be an approved issue blocking bind")
          .isNotEmpty()
    } else {
      assertThat(approvedIssues)
          .as("The approved issues should be empty")
          .isEmpty()
    }
    logout()
  }

  override function verifyUWBindBlockingAndApprovedIssuesExist(uwIssues : List<Map<String, String>>) {
    logout()
    var submissionWizard = loginIfLoggedOut(UserUnderwriterRole).goToQuickSubmission(ScenarioInfoProvider.JobNumber)
    var riskAnalysisScreen = submissionWizard.goToRiskAnalysis()
    NavigationManager.CurrentPCFElement = riskAnalysisScreen
    var expectedIssues = uwIssues.map(\row -> new IssueRow() {:Title = row.get("Section Title"), :ShortDescription = row.get("Short Description")})
    assertThat(riskAnalysisScreen.BlockingAndApprovedIssues)
        .as("The UW issues should exist")
        .contains(expectedIssues.toTypedArray())
    logout()
  }

  override function addVehicleLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    throw new UnsupportedOperationException("Not implemented")
  }

  override function setupInForcePersonalAutoPolicy() {
    _lineContextDelegate.setupInForcePersonalAutoPolicy()
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function createABoundPolicyFor(baseState : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
 }