package gw.cucumber.steps.lob.pa

uses com.google.inject.Inject
uses gw.cucumber.context.api.ContextFactory

/**
 * Personal Auto specific {@link PolicyChange} job steps
 */
@Export
class PA_PolicyChangeSteps {

  @Inject
  var _contextFactory : ContextFactory

}
