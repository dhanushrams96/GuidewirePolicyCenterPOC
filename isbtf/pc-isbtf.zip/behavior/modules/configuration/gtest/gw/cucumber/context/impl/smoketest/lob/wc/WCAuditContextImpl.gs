package gw.cucumber.context.impl.smoketest.lob.wc

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.wc.WCContext
uses gw.cucumber.context.impl.smoketest.job.audit.AuditContextImplBase

@Export
class WCAuditContextImpl extends AuditContextImplBase implements WCContext {

  @Inject delegate _lineContextDelegate represents WCContext

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}