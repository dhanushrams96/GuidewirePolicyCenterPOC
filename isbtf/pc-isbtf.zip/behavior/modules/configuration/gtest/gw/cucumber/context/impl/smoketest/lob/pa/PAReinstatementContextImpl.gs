package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.reinstatement.ReinstatementContextImplBase

@Export
class PAReinstatementContextImpl extends ReinstatementContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}