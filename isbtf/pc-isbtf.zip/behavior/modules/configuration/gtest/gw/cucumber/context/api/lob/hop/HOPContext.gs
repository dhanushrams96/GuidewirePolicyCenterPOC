package gw.cucumber.context.api.lob.hop

uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.LineContext


/**
 * Methods common to {@link HOPLine}.
 * These methods are common to {@link Job} subtypes, for example Submission, PolicyChange, etc.
 */
@Export
interface HOPContext extends LineContext{

  /**
   * Sets Policy type and Coverage forms on the job
   * @param policyTypeText : Policy type ie. Dwelling, Renters, Condominium
   * @param coverageFromText : Coverage forms ie. HO1, HO2, HO3, HO4, HO5, HO6
   */
  function setPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String)

  /**
   * Sets the answer for the prequalification question "Who occupies this Dwelling?"
   * @param occupier : Answer ie Myself or Tenant
   */
  function setWhoOccupiesThisDwelling(occupier : String)

  /**
   * Adds Scheduled Personal Property coverage with the provided coverage terms
   * @param coverageTerms
   */
  function addScheduledPersonalPropertyCoverage(coverageTerms : DataTable)

  /**
   * Verifies scheduled item premium exist
   * @param premium
   */
  function verifyScheduledItemPremiumExist()

  /**
   * Verifies coverage has been added on policy review screen
   * @param coveragename
   */
  function verifyCoverageExistsOnPolicyReview(coveragename: String)

  /**
   * Adds and saves dwelling information provided
   * @param dwellingInfo - Dwelling information
   */
  function addDwellingInfo(dwellingInfo : DataTable)

  /**
   * Verifies saved dwelling fields match provided dwelling information
   * @param dwellingInfo - Dwelling information which gets verified
   * e.g.
   * | Location                           | 2: 121 Main St, Foster City, CA |
   * | Territory Code for Homeowners Line | 30                              |
   * | Location Type                      | In City Limits                  |
   * | Residence                          | 1 Family Residence              |
   */
  function verifyDwellingInfo(dwellingInfo : DataTable)

  /**
   * Adds new location on the policy without saving
   * @param newPolicyLocation - Table containing the address for the new Location
   *       | Address 1    | address line 1            |
   *       | County       | County of the address     |
   *       | State        | Name of the state         |
   *       | ZIP Code     | zip code                  |
   * Example:
   *       | Address 1    | 234 hope  |
   *       | County       | Clark     |
   *       | State        | Nevada    |
   *       | ZIP Code     | 88000     |
   */
  function addNewPolicyLocationWithoutSave(newPolicyLocation : DataTable)

  /**
   * Verifies given code is set on the New Location popup.
   * @param code - Territory code value
   */
  function verifyTerritoryCodeOnPopup(code : String)

  /**
   * Sets Distance to fire hydrant and fire station
   * @param firehydrantDistances - Map of distance for Firehydrant and fire station
   */
  function setDistanceToFireHydrantAndFireStation(firehydrantDistances : DataTable)

  /**
   * Clicks on Auto Fill Protection Class button
   */
  function clickAutofillProtectionClass()

  /**
   * Verifies Fire protection class code matches
   * @param fireProtectionClassCode - Expected {@link FireProtectClass} possible values Superior|Standard|Limited|Poor|None
   */
  function verifyFireProtectionClassCode(fireProtectionClassCode : String)

  /**
   * Creates a bound policy with Policy type and Coverage form
   * @param policyTypeText : Policy type ie. Dwelling, Renters, Condominium
   * @param coverageFromText : Coverage forms ie. HO1, HO2, HO3, HO4, HO5, HO6
   */
  function createABoundPolicyWithPolicyTypeAndCoverageForm(policyTypeText : String, coverageFromText : String)

  /**
   * Adds provided animal using the UI
   *
   * @param animalInfo - Table containing the animal information
   *       | Type         | Type of animal |
   *       | Breed        | Type of breed  |
   *       | Bite History | Yes or No      |
   * Example:
   *       | Type         | Dog       |
   *       | Breed        | Pit Bulls |
   *       | Bite History | Yes       |
   */
  function addAnimalUsingUI(animalInfo : DataTable)

  /**
   * Adds provided animal to the policy period
   *
   * @param animal table containing the animal information
   *       | Type         | Type of animal |
   *       | Breed        | Type of breed  |
   *       | Bite History | Yes or No      |
   * Example:
   *       | Type         | Dog       |
   *       | Breed        | Pit Bulls |
   *       | Bite History | Yes       |
   */
  function addAnimalToPeriod(animalInfo : DataTable)

  /**
   * Adds hazards to the dwelling
   * @param hazardsMap - List containing the map for hazards
   *       | Specific Hazard   | Type                  | Additional Information |
   *       | A specific hazard | Property or Liability | Additional Information |
   * Example:
   *       | Specific Hazard | Type      | Additional Information           |
   *       | Woodstove       | Property  | Woodstove located in living area |
   *       | Woodstove       | Liability | Woodstove located in living area |
   */
  function addDwellingHazards(hazardsMap : DataTable)

  /**
   * Verifies saved dwelling hazards information matches provided dwelling hazards information
   * @param expectedHazardsInfoMap - Dwelling hazards information which gets verified
   */
  function verifyDwellingHazardsInfo(expectedHazardsInfoMap : DataTable)

  /**
   * Sets dwelling construction type as Other
   */
  function setConstructionTypeAsOther()

  /**
   * Verifies construction type description field is provided
   */
  function verifyConstructionTypeDescriptionFieldProvided()

  /**
   * Sets dwelling roof type as Other
   */
  function setRoofTypeAsOther()

  /**
   * Verifies roof type description field is provided
   */
  function verifyRoofTypeDescriptionFieldProvided()

  /**
   * Sets primary heating type as Oil
   */
  function setPrimaryHeatingTypeAsOil()

  /**
   * Verifies Fuel Storage Tank and Fuel Line Fields are provided
   */
  function verifyFuelStorageTankAndFuelLineFieldsProvided()

  /**
   * Sets dwelling construction
   * @param constructionInfo - Map of construction info
   */
  function enterConstructionInfo(constructionInfo : DataTable)

  /**
   * Verifies saved dwelling construction information matches provided construction information
   * @param constructionInfo - Dwelling construction information which gets verified
   */
  function verifyConstructionInfo(constructionInfo : DataTable)

  /**
   * Adds scheduled personal property
   * @param scheduledPersonalProperties - List of scheduled properties info map
   */
  function addScheduledPersonalProperty(scheduledPersonalProperties : DataTable)

  /**
   * Verifies saved homeowners policy information available
   * @param hopInfo - List of hop information which gets verified
   */
  function verifyHOPInfoAvailable(hopInfo : DataTable)

  /**
   * Creates a Non-copper Wiring Underwriting Issue on the period for testing purposes
   */
  function causeNonCopperWiringUWIssue()

  /**
   * Provides an approved Non-copper wiring uw issue
   * @param validUntil - The approval of uw issue is valid until
   */
  function providesAnApprovedNonCopperWiringUWIssueWithValidUntil(validUntil : String)

  /**
   * Verifies Non-copper wiring UW issue exists
   */
  function verifyNonCopperWiringUWissueExists()

  /**
   * Sets the Year Built on the dwelling construction with the passed years plus 1
   * @param houseAge age of the house
   */
  function setHouseAge(houseAgeInYears : int)

  /**
   * Sets the RoofUpgradeDate to be empty
   */
  function roofWasNotUpgraded()
}