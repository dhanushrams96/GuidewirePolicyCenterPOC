package gw.cucumber.steps.rating

uses com.google.inject.Inject
uses cucumber.api.java.en.Given
uses cucumber.api.java.en.Then
uses cucumber.api.java.en.When
uses gw.cucumber.context.api.ContextFactory
uses gw.cucumber.testdata.PolicyPeriodWrapper

@Export
class RatingSteps {

  @Inject
  var _policyPeriod : PolicyPeriodWrapper

  @Inject
  var _contextFactory : ContextFactory

  @Given("^Rating Plugin is PCRatingPlugin$")
  function registerRatingPlugin() {
    _contextFactory.getLineContext().prepareRating()
  }

  @When("^I view rating worksheet$")
  function viewRatingWorksheet() {
    _contextFactory.getLineContext().viewRatingWorksheet()
  }

  @Then("^rating worksheet should be available for review$")
  function ratingWorksheetAvailableForReview() {
    _contextFactory.getLineContext().verifyRatingWorksheet()
  }
}