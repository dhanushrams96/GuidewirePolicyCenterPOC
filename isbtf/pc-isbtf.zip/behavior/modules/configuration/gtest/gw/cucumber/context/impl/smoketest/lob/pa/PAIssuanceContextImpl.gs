package gw.cucumber.context.impl.smoketest.lob.pa

uses com.google.inject.Inject
uses cucumber.api.DataTable
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.issuance.IssuanceContextImplBase

@SuppressWarnings("unused")
@Export
class PAIssuanceContextImpl extends IssuanceContextImplBase implements PAContext {

  @Inject delegate _lineContextDelegate represents PAContext

  override function addLineLevelCoverage(covName : String, coverageTerms : Map<String, String>) {
    var period = IssuanceDataSetup.Entity
    var issuanceWizard = loginIfLoggedOut(UserUnderwriterRole).goToIssuance(period.Issuance)
    var coverageStep = issuanceWizard.PAMode.goToPAStep()

    assertThat(period.Status)
        .as("this step requires issuance job in draft mode")
        .isEqualTo(PolicyPeriodStatus.TC_DRAFT)

    NavigationManager.CurrentPCFElement = coverageStep.PersonalAuto_AllVehicleCoveragesDV
    _lineContextDelegate.addLineLevelCoverage(covName, coverageTerms)
  }

  override function addAdditionalInterestsOfNewCompanyType(contactInfo : DataTable) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyAdditionalInterestsOfNewCompanyType(companyName : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyTransactionSavedSuccessfully() {
    throw new UnsupportedOperationException("Not yet implemented")
  }

  override function verifyUWCompany(uwCompany : String) {
    throw new UnsupportedOperationException("Not yet implemented")
  }
}
