package gw.cucumber.testdata

uses cucumber.runtime.java.guice.ScenarioScoped

@Export
@ScenarioScoped
class StringWrapper extends DataWrapper<String> {

}