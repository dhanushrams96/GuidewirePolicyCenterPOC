package gw.cucumber.context.api.common

uses cucumber.api.DataTable

/**
 * Methods specific to Account
 */
@Export
interface AccountContext {

  /**
   * Queries the DB to check if account of type person exists based on the given input fields
   *
   * "First name" and "Last name" fields are required
   *
   * @param givenFields a Map of key and value pairs representing the fields and values.
   */
  function verifyAccountPersonDoesNotExist(givenFields : Map<String,String>)

  /**
   * Queries the DB to check if account of type company exists based on the given input fields
   *
   * "Company name" field is required
   *
   * @param givenFields a Map of key and value pairs representing the fields and values for "Company name"
   */
  function verifyAccountCompanyDoesNotExist(givenFields : Map<String,String>)

  /**
   * Performs UI search based on the provided fields to check for the existence of an account of type person
   *
   * "First name" and "Last name" fields are required
   *
   * @param givenFields a Map of key and value pairs representing the fields and values for "First name" and "Last name"
   */
  function verifyAccountPersonExists(givenFields : Map<String,String>)

  /**
   * Performs UI search based on the provided fields to check for the existence of an account of type company
   *
   * "Company name" field is required
   *
   * @param givenFields a Map of key and value pairs representing the fields and values for "Company name"
   */
  function verifyAccountCompanyExists(givenFields : Map<String,String>)

  /**
   * Uses builder to create an account of type person or company with provided fields
   *
   * "First name" and "Last name" fields are required to be populated for account type Person."Company name" is required for
   * account type company. Other fields are not needed because defaults will be provided for any required fields like "Address" etc.
   *
   * @param contactTypeText Person or Company
   * @param givenFields a Map of key and value pairs representing the fields and values for "First name" and "Last name"
   */
  function createAccount(contactTypeText : String, givenFields : Map<String,String>)

  /**
   * Creates an account of type person with provided fields in the UI
   *
   * "First name" and "Last name" fields are required to be populated. Other fields are not needed because defaults
   * will be provided for any required fields like "Address" etc.
   *
   * @param givenFields a Map of key and value pairs representing the fields and values for "First name" and "Last name"
   */
  function createAccountOfTypePerson(givenFields : Map<String,String>)

  /**
   * Creates an account of type company with provided fields in the UI
   *
   * "Company name" field is required to be populated. Other fields are not needed because defaults
   * will be provided for any required fields like "Address" etc.
   *
   * @param givenFields a Map of key and value pairs representing the field and value for "Company name"
   */
  function createAccountOfTypeCompany(givenFields : Map<String,String>)

  /**
   * Edits an account with provided fields in the UI
   *
   * @param givenFields a Map of key and value pairs representing the field and value.
   */
  function editAccount(givenFields : Map<String,String>)

  /**
   * Edits an account's primary location with provided fields in the UI
   *
   * @param givenFields a Map of key and value pairs representing the field and value.
   */
  function editAccountPrimaryLocation(givenFields : DataTable)

  /**
   * Verifies the account holder details
   *
   * @param accNumber account number of the account
   * @param givenFields a Map of key and value pairs representing the field and value.
   */
  function verifyAccountHolderDetails(accNumber : String, givenFields : Map<String,String>)

}