package gw.cucumber.context.impl.smoketest.lob.pa

uses gw.api.locale.DisplayKey
uses gw.cucumber.context.api.lob.pa.PAContext
uses gw.cucumber.context.impl.smoketest.job.submission.SubmissionContextImplBase
uses gw.cucumber.setup.PASubmissionDataSetup
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses pcftest.PersonalAutoScreen
uses pcftest.SubmissionWizard

@Export
abstract class PASubmissionContextImplBase extends SubmissionContextImplBase implements PAContext {

  protected function createLOBSpecificDataSetup() {
    if (ScenarioInfoProvider.DataSetup == null) {
      ScenarioInfoProvider.DataSetup = new PASubmissionDataSetup(CurrentUser)
    }
  }

  function createSubmissionSetup() {
    ScenarioInfoProvider.JobSubType = TC_SUBMISSION
    var paSubmissionDataSetup = new PASubmissionDataSetup(CurrentUser)
    if (ScenarioInfoProvider.AccountDataSetup != null) {
      paSubmissionDataSetup.AccountDataSetup = ScenarioInfoProvider.AccountDataSetup
    }
    ScenarioInfoProvider.DataSetup = paSubmissionDataSetup
  }

  override function causeUWIssue(blockingPoint : UWIssueBlockingPoint) {
    if (blockingPoint == TC_BLOCKSBIND) {
      DataSetup.withDriverAge(20)
    }
  }

  override function setVehicleGarageState(state : State) {
    DataSetup.withVehicleGarageState(state)
  }

  override function setDriverAge(age : int) {
    DataSetup.withDriverAge(age)
  }

  override function setVehicleCost(cost : int) {
    DataSetup.withVehicle(:costNew = cost)
  }

  protected function gotoPersonalAutoScreen() : PersonalAutoScreen {
    return loginIfLoggedOut(CurrentUser).goToSubmission(DataSetup.Entity).PAMode.goToPAStep()
  }

  property get DataSetup() : PASubmissionDataSetup {
    return ScenarioInfoProvider.DataSetup as PASubmissionDataSetup
  }

  override function addAdditionalNamedInsured(contactInfo : Map<String, String>) {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var policyInfoStep = submissionWizard.PAMode.goToPolicyInfoStep()

    var newAdditionalInsuredPopup = policyInfoStep.goToNewPersonPopup()
    var contactDetailScreen = newAdditionalInsuredPopup.ContactDetailScreen

    UIHelper.setFieldValues(contactDetailScreen, new UIFieldsProviderBase(contactInfo) {

      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.ContactDetail.Name.FirstName"), DisplayKey.get("Web.ContactDetail.Name.LastName")}
      }

      override property get DefaultFields() : Map<String, String> {
        return {
            DisplayKey.get("Web.AddressBook.AddressInputSet.Address1") -> "1 A St.",
            DisplayKey.get("Web.AddressBook.AddressInputSet.City") -> "San Mateo",
            DisplayKey.get("Web.AddressBook.AddressInputSet.State") -> "California",
            DisplayKey.get("Web.AddressBook.AddressInputSet.ZIP") -> "94404",
            DisplayKey.get("Web.AddressDetail.AddressType") -> "Business"
        }
      }
    })
    submissionWizard = contactDetailScreen.Update.click() as SubmissionWizard
    waitForAutoRefreshToComplete()

    ScenarioInfoProvider.DataSetup.refreshEntity()
  }

  override function verifyAdditionalNamedInsuredExists(contactInfo : Map<String, String>) {
    var submissionWizard = loginIfLoggedOut(UserProducerRole).goToSubmission(ScenarioInfoProvider.JobNumber)
    var policyInfoStep = submissionWizard.PAMode.goToPolicyInfoStep()

    UIHelper.assertRequiredFields({DisplayKey.get("Web.ContactDetail.Name.FirstName"), DisplayKey.get("Web.ContactDetail.Name.LastName")}, contactInfo.keySet())

    var firstName = contactInfo.get(DisplayKey.get("Web.ContactDetail.Name.FirstName"))
    var lastName = contactInfo.get(DisplayKey.get("Web.ContactDetail.Name.LastName"))

    var additionalNamedInsureds = policyInfoStep.AdditionalNamedInsuredsLVEntries
    // NOTE : we may want to use NameFormatter in the future
    var entry = additionalNamedInsureds.singleWhere(\nameInsured -> nameInsured.Name.Text == firstName + " " + lastName)
    var detailPopup = entry.Name.click()
    var contactDetailScreen = detailPopup.ContactDetailScreen
    try {
      var cardView = contactDetailScreen.PolicyContactRoleDetailsCV

      UIHelper.assertFieldValues({cardView.PolicyContactRoleDetailCardTab, cardView.RolesCardTab}, contactInfo)
    } finally {
      // We cancel to prevent the page from blocking subsequent navigation
      contactDetailScreen.Cancel.click()
    }
  }

  override function createABoundPolicy() {
    createABoundPolicy(false)
  }

  override function createABoundPolicy(skipIssuance : boolean) {
    var paSubmissionDataSetup = new PASubmissionDataSetup(UserUnderwriterRole)
    paSubmissionDataSetup.isBound(skipIssuance)
    ScenarioInfoProvider.BasedOnPolicyPeriod = paSubmissionDataSetup.Entity
  }

  override function setExpirationDate(expirationDate : Date) {
    var submissionBuilder = ScenarioInfoProvider.DataSetup.Builder
    submissionBuilder.withPolicyTerm(TermType.TC_HALFYEAR)
    submissionBuilder.withEffectiveDate(expirationDate.addMonths(-6))
  }

}