package gw.cucumber.context.api.job.issuance

uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link Issuance}
 */
@Export
interface IssuanceContext extends JobContext {

  /**
   * Creates new Issuance job in draft mode
   */
  function createIssuance()

}
