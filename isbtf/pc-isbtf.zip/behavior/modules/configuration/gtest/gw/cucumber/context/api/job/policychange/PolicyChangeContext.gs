package gw.cucumber.context.api.job.policychange

uses gw.cucumber.context.api.job.JobContext

/**
 * Methods specific to {@link PolicyChange}
 */
@Export
interface PolicyChangeContext extends JobContext {

  /**
   * Initiates a {@link PolicyChange} job in draft status
   */
  function createPolicyChange()

  /**
   * Verifies the policy change job is preempted by another period.
   */
  function verifyPolicyChangeIsPreempted()

  /**
   * Resolves and applies unhandled preemptions on the period.
   */
  function applyPreemptionChanges()

  /**
   * View the policy effective as of the given number of days into policy term.
   * @param numberOfDaysIntoTerm the number of days into term
   */
  function viewPolicyAsOfDaysIntoTerm(numberOfDaysIntoTerm: int)

  /**
   * Applies any of the pending updates from the policy change to unbound renewal
   */
  function applyPendingChangesToUnboundRenewal()

  /**
   * Resolve Out of Sequence conflicts with the given resolve type(Override None or Override all)
   * @param resolveType the type of resolve, Override None or Override all
   */
  function resolveOOSConflicts(resolveType : String)

  /**
   * Verify that the provided Out of Sequence conflicts exist on the policy change.
   * @param data a List of Maps where each Map in the List represents an Out of Sequence conflict that is expected to exist.
   *
   *  For example,
   *   <pre>[{"Item":"Rental Car Loss of Use Limit", "Policy Change":"2,000","Conflict":"1,000"}]</pre>
   */
  function verifyOOSConflictsExist(data : List<Map<String, String>>)

}