package gw.cucumber.setup

uses cucumber.runtime.java.guice.ScenarioScoped
uses gw.api.builder.CancellationBuilder

@Export
@ScenarioScoped
class CancellationDataSetup extends NonSubmissionDataSetup<CancellationBuilder> {

  var _cancellationSource : CancellationSource as Source
  var _reasonCode : ReasonCode as Reason
  var _effectiveDate : Date as EffectiveDate

  construct(basedOnPeriod : PolicyPeriod) {
    super(basedOnPeriod)
  }

  construct(username : String, basedOnPeriod : PolicyPeriod) {
    super(username, basedOnPeriod)
  }

  protected override function initializeBuilder(builder : CancellationBuilder) {
    super.initializeBuilder(builder)
  }

  override function provideDefaults() : CancellationBuilder {
    initializeCancellation()
    return Builder
  }

  private function initializeCancellation() {
    if(Source == null){
      Source = CancellationSource.TC_INSURED
    }

    if(Reason == null){
      Reason = ReasonCode.TC_MIDTERMREWRITE
    }

    Builder.withCancellationSource(Source)
        .withCancelReasonCode(Reason)

    if(EffectiveDate != null){
      Builder.withEffectiveDate(EffectiveDate)
          .withProrataRefund()
    }
  }
}