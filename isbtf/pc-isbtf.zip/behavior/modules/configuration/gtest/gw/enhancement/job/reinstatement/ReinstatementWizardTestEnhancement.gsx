package gw.enhancement.job.reinstatement

uses gw.smoketest.platform.web.PCFLocation
uses pcftest.ReinstatementWizard

enhancement ReinstatementWizardTestEnhancement : ReinstatementWizard {

  function clickReinstate() : PCFLocation {
    return this.ViewQuote.ReinstatementWizard_QuoteScreen.JobWizardToolbarButtonSet_Reinstatement.Reinstate.click()
  }
}