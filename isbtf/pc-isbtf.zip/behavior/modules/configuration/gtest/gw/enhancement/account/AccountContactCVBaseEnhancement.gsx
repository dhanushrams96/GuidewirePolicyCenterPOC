package gw.enhancement.account

uses gw.smoketest.pc.account.AccountContactCVCompanyMode
uses gw.smoketest.pc.account.AccountContactCVPersonMode

uses java.lang.Throwable

enhancement AccountContactCVBaseEnhancement : pcftest.AccountContactCV {

  //-------------------------------------------------------------------------------- Contact Detail Tab

  property get AccountContactDVSafely() : pcftest.AccountContactDV {
    try {      
      this.AccountContactDetailCardTab.click()
    } catch (t : Throwable) {
      print("Caught throwable: " + t.Message)
    }
    return this.AccountContactDV
  }

  //-------------------------------------------------------------------------------- Roles Tab

  property get AccountContactRolesDVSafely() : pcftest.AccountContactCV.ContactRolesDV {
    try {
      this.RolesCardTab.click()
    } catch (t : Throwable) {
      print("Caught throwable: " + t.Message)
    }
    return this.ContactRolesDV
  }
  
  property get AddRoleButton() : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.AddRoleButton {
    return AccountContactRolesDVSafely.ContactRolesLV_tb.AddRoleButton
  }
  
  function getRoleMenuItemFromAddRoleButton(accountContactRoleType : Type<AccountContactRole>) : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.AddRoleButton.entry {
    return AddRoleButton._Entries.firstWhere(\ entry -> entry.RoleType.Text == accountContactRoleType.TypeInfo.DisplayName)
  }
  
  property get RemoveRoleButton() : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.Remove {
    return AccountContactRolesDVSafely.ContactRolesLV_tb.Remove
  }
  
  function getContactRoleEntry(accountContactRoleType : Type<AccountContactRole>) : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV.entry {
    return AccountContactRolesDVSafely.ContactRolesLV._Entries.firstWhere(\ entry -> entry.ContactRole.Text == accountContactRoleType.TypeInfo.DisplayName)
  }

  //-------------------------------------------------------------------------------- Address Tab

  property get AddressesLVSafely() : pcftest.AddressesPanelSet.AddressesLV {
    try {
      this.AddressesCardTab.click()
    } catch (t : Throwable) {
      print("Caught throwable: " + t.Message)
    }
    return this.AddressesPanelSet.AddressesLV
  }

  property get AddressesLV_tbSafely() : pcftest.AddressesPanelSet.AddressesLV_tb {
    try {
      this.AddressesCardTab.click()
    } catch (t : Throwable) {
      print("Caught throwable: " + t.Message)
    }
    return this.AddressesPanelSet.AddressesLV_tb
  }
  
  property get AddressesDVSafely() : pcftest.AddressesPanelSet.AddressDetailDV {
    try {
      this.AddressesCardTab.click()
    } catch (t : Throwable) {
      print("Caught throwable: " + t.Message)
    }
    return this.AddressesPanelSet.AddressDetailDV
  }

  function getAddressEntry(forAddress : String) : pcftest.AddressesPanelSet.AddressesLV.entry {
    return AddressesLVSafely._Entries.singleWhere(\ e -> e.DisplayedName.Value == forAddress)  
  }
  
  //-------------------------------------------------------------------------------- Modes

  property get CompanyMode() : AccountContactCVCompanyMode {
    return new AccountContactCVCompanyMode(this)
  }

  property get PersonMode() : AccountContactCVPersonMode {
    return new AccountContactCVPersonMode(this)
  }

}
