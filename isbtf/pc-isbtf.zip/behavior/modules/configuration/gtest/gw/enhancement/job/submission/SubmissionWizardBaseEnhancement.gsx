package gw.enhancement.job.submission

uses gw.smoketest.pc.lob.gl.SubmissionWizardGLMode
uses gw.smoketest.pc.lob.hop.SubmissionWizardHOPMode
uses gw.smoketest.pc.lob.pa.SubmissionWizardPAMode

// Enhances the Submission Wizard. Has some helper methods to navigate to and verify current screen
// Methods are grouped by product and order they appear on the UI navigation
enhancement SubmissionWizardBaseEnhancement: pcftest.SubmissionWizard {

  property get GLMode() : SubmissionWizardGLMode {
    return new SubmissionWizardGLMode(this)
  }

  property get PAMode() : SubmissionWizardPAMode {
    return new SubmissionWizardPAMode(this)
  }

  property get HOPMode() : SubmissionWizardHOPMode {
    return new SubmissionWizardHOPMode(this)
  }

  function goToRiskAnalysis(): pcftest.Job_RiskAnalysisScreen {
    return this.RiskAnalysis.click()
  }

  property get NotesPage() : pcftest.JobWizardToolsMenuWizardStepSet.Notes {
    return this.JobWizardToolsMenuWizardStepSet.Notes
  }

  function goToNotesPage(): pcftest.Policy_NotesScreen {
    return this.JobWizardToolsMenuWizardStepSet.Notes.click()
  }

  property get DocumentsPage() : pcftest.JobWizardToolsMenuWizardStepSet.Documents {
    return this.JobWizardToolsMenuWizardStepSet.Documents
  }

  function goToDocumentsPage(): pcftest.Policy_DocumentsScreen {
    return this.JobWizardToolsMenuWizardStepSet.Documents.click()
  }

  function goToHistoryPage(): pcftest.Job_HistoryScreen {
    return this.JobWizardToolsMenuWizardStepSet.History.click()
  }

  function goToManageVersionsPage(): pcftest.ManageBranchesScreen {
    return this.JobWizardToolsMenuWizardStepSet.ManageBranches.click()
  }

  function goToReinsurancePage(): pcftest.PolicyReinsuranceScreen {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance.click()
  }

  function goToReinsuranceCV(): pcftest.PolicyReinsuranceCV {
    return goToReinsurancePage().PolicyReinsuranceCV
  }

  function goToSideBySidePage(): pcftest.SideBySideScreen {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide.click()
  }

  property get HistoryPage() : pcftest.JobWizardToolsMenuWizardStepSet.History {
    return this.JobWizardToolsMenuWizardStepSet.History
  }

  property get ManageVersionsPage() : pcftest.JobWizardToolsMenuWizardStepSet.ManageBranches {
    return this.JobWizardToolsMenuWizardStepSet.ManageBranches
  }

  property get ReinsurancePage() : pcftest.JobWizardToolsMenuWizardStepSet.Reinsurance {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance
  }

  property get ParticipantsPage() : pcftest.JobWizardToolsMenuWizardStepSet.Participants {
    return this.JobWizardToolsMenuWizardStepSet.Participants
  }

  property get SideBySidePage() : pcftest.JobWizardToolsMenuWizardStepSet.SideBySide {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide
  }

  property get WorkplansPage() : pcftest.JobWizardToolsMenuWizardStepSet.Workplan {
    return this.JobWizardToolsMenuWizardStepSet.Workplan
  }

}
