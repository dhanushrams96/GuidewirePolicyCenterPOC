package gw.enhancement.policyfile

uses gw.smoketest.platform.web.DateElement
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.ValueElement
uses pcftest.*

enhancement PolicyFile_SummaryBaseEnhancement : PolicyFile_Summary {

  property get AccountDetailsDV() : AccountDetailViewTile.AccountDetailViewTile_DV {
    return this.PolicyOverviewDashboard.AccountDetailViewTile.AccountDetailViewTile_DV
  }

  property get AccountName(): ValueElement {
    return this.AccountDetailsDV.AccountName
  }

  property get AccountNumber(): ValueElement {
    return this.AccountDetailsDV.AccountNumber
  }

  property get CompletedTransactionsLV(): CompletedPolicyTransactionsListViewTile.CompletedPolicyTransactionsListViewTile_LV {
    return this.PolicyOverviewDashboard.CompletedPolicyTransactionsListViewTile.CompletedPolicyTransactionsListViewTile_LV
  }

  property get CurrentActivitiesLV(): CurrentActivitiesPolicyListViewTile.CurrentActivitiesPolicyListViewTile_LV {
    return this.PolicyOverviewDashboard.CurrentActivitiesPolicyListViewTile.CurrentActivitiesPolicyListViewTile_LV
  }

  property get IssueDate(): DateElement {
    return this.PolicyOverviewDashboard.PolicyDetailsDetailViewTile.PolicyDetailsDetailViewTile_DV.IssueDate
  }

  property get Issued(): boolean {
    return this.PolicyOverviewDashboard.PolicyDetailsDetailViewTile.PolicyDetailsDetailViewTile_DV.IssueDate.DateValue != null
  }

  property get PendingTransactionsLV() : PendingPolicyTransactionsListViewTile.PendingPolicyTransactionsListViewTile_LV {
    return this.PolicyOverviewDashboard.PendingPolicyTransactionsListViewTile.PendingPolicyTransactionsListViewTile_LV
  }

  property get PolicyDetailsDV(): PolicyDetailsDetailViewTile.PolicyDetailsDetailViewTile_DV {
    return this.PolicyOverviewDashboard.PolicyDetailsDetailViewTile.PolicyDetailsDetailViewTile_DV
  }

  property get PolicyNumber(): ValueElement {
    return this.PolicyDetailsDV.PolicyNumber
  }

  property get PolicyType() : ValueElement   {
    return this.PolicyOverviewDashboard.CompletedPolicyTransactionsListViewTile.CompletedPolicyTransactionsListViewTile_LV._Entries.first().Type
  }

  property get PolicyProduct():ValueElement {
    return this.PolicyDetailsDV.Product
  }

  property get EffectiveDate() : DateElement {
    return this.PolicyDetailsDV.EffectiveDate
  }

  property get ExpirationDate() : DateElement {
    return this.PolicyDetailsDV.ExpirationDate
  }

  property get PremiumTileDV(): TermFinancialsViewTile.TermFinancialsViewTile_DV {
    return this.PolicyOverviewDashboard.TermFinancialsViewTile.TermFinancialsViewTile_DV
  }

  property get PrimaryNamedInsured(): ValueElement {
    return this.PolicyDetailsDV.PrimaryNamedInsured
  }

  property get SplitPolicyLV(): SplitPolicyListViewTile.SplitPolicyListViewTile_LV {
    return this.PolicyOverviewDashboard.SplitPolicyListViewTile.SplitPolicyListViewTile_LV
  }

  public function getWorkorderRow(jobNumber : String): PendingPolicyTransactionsListViewTile.PendingPolicyTransactionsListViewTile_LV.entry {
    var workOrders = PendingTransactionsLV._Entries.where( \ job -> job.JobNumber.Text == jobNumber )
    if (workOrders.isEmpty()) {
      return null
    }
    if (workOrders.Count > 1) {
      throw "Multiple jobs with job number \"" + jobNumber + "\" exist"
    }
    return workOrders.first()
  }

  public function getTransactionRow(jobNumber : String): CompletedPolicyTransactionsListViewTile.CompletedPolicyTransactionsListViewTile_LV.entry {
    var workOrders = CompletedTransactionsLV._Entries.where( \ transaction -> transaction.Number.Text == jobNumber )
    if (workOrders.isEmpty()) {
      return null
    }
    if (workOrders.Count > 1) {
      throw "Multiple jobs with job number \"" + jobNumber + "\" exist"
    }
    return workOrders.first()
  }

  public function openWorkorder(jobNumber: String): PCFLocation {
    var transaction = getTransactionRow(jobNumber)
    if (transaction != null) {
      return transaction.Number.click()
    }

    var workOrder = getWorkorderRow(jobNumber)
    if (workOrder != null) {
      return workOrder.JobNumber.click()
    }

    throw "Cannot find job (bound or draft): " + jobNumber
  }

  function goToContacts() : PolicyFile_Contacts {
    return this._parent.MenuLinks.PolicyFile_PolicyFile_Contacts.click()
  }

  function goToBilling() : PolicyFile_Billing {
    return this._parent.MenuLinks.PolicyFile_PolicyFile_Billing.click()
  }

  property get PolicyPeriodEffDate() : Date {
    return this._parent.PolicyFileAcceleratedMenuActions.PolicyPeriodEffDateID.PolicyPeriodEffDateID_Arg.DateValue
  }

  function setPolicyPeriodEffDate(effDate : Date) {
    this._parent.PolicyFileAcceleratedMenuActions.PolicyPeriodEffDateID.PolicyPeriodEffDateID_Arg.DateValue = effDate
  }

}
