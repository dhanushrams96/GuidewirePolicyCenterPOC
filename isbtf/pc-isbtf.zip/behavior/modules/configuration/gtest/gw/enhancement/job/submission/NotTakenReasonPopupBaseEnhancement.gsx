package gw.enhancement.job.submission

uses gw.smoketest.platform.web.PCFLocation

enhancement NotTakenReasonPopupBaseEnhancement : pcftest.NotTakenReasonPopup {

  property get RejectReason() : pcftest.RejectReasonDV.RejectReason {
    return this.RejectScreen.RejectReasonDV.RejectReason
  }

  function setReason(reason: ReasonCode) {
    this.RejectScreen.RejectReasonDV.RejectReason.getOptionByTypeKey(reason).click()
  }

  function notTaken(): PCFLocation {
    return this.RejectScreen.Update.click()
  }

}
