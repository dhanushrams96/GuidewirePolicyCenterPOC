package gw.enhancement.policyfile

uses pcftest.JobComplete
uses pcftest.PolicyFile_Summary

enhancement JobCompleteBaseEnhancement : JobComplete {

  function goToPolicyFile() : PolicyFile_Summary {
    return this.JobCompleteScreen.JobCompleteDV.ViewPolicy.click() as PolicyFile_Summary
  }

}
