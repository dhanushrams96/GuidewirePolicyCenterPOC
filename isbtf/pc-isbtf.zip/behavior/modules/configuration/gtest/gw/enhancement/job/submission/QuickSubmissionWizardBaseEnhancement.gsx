package gw.enhancement.job.submission

uses gw.smoketest.pc.lob.pa.QuickSubmissionWizardPAMode

enhancement QuickSubmissionWizardBaseEnhancement : pcftest.QuickSubmissionWizard {

  property get PAMode() : QuickSubmissionWizardPAMode {
    return new QuickSubmissionWizardPAMode(this)
  }

  function goToRiskAnalysis(): pcftest.Job_RiskAnalysisScreen {
    return this.JobWizardToolsMenuWizardStepSet.RiskEvaluation.click()
  }
}
