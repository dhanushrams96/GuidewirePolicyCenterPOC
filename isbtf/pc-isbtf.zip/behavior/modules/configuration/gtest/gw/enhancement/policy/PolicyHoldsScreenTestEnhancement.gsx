package gw.enhancement.policy

uses com.google.common.collect.ImmutableMap
uses com.google.common.collect.Sets
uses gw.api.locale.DisplayKey
uses gw.cucumber.util.common.UIHelper
uses pcftest.PolicyHolds

@Export
enhancement PolicyHoldsScreenTestEnhancement : PolicyHolds.PolicyHoldsScreen {

  static property get HoldType() : String {return DisplayKey.get("Web.Admin.PolicyHold.HoldType")}
  static property get Code() : String {return  DisplayKey.get("Web.Admin.PolicyHold.Code")}
  static property get UWIssueType() : String {return DisplayKey.get("Web.Admin.PolicyHold.UWIssueType")}
  static property get LineOfBusiness() : String {return DisplayKey.get("Web.Admin.PolicyHold.PolicyLine")}
  static property get PolicyTransactionType() : String {return DisplayKey.get("Web.Admin.PolicyHold.Job")}
  static property get TransactionDateType() : String {return DisplayKey.get("Web.Admin.PolicyHold.JobDateType")}
  static property get Coverage() : String {return DisplayKey.get("Web.Admin.PolicyHold.Coverage")}

  static property get RequiredFields() : Set<String> {
    return {HoldType, Code, UWIssueType, LineOfBusiness, TransactionDateType, Coverage}.toSet()
  }

  static property get DefaultFields() : Map<String, String> {
    return ImmutableMap.builder<String, String>()
        .put(HoldType, UWIssueCheckingSet.TC_REGULATORYHOLD.DisplayName)
        .put(Code, "Code:55555")
        .put(DisplayKey.get("Web.Admin.PolicyHold.Description"), "Sandy Hurricane")
        .put(DisplayKey.get("Web.Admin.PolicyHold.StartDate"), "05/01/2018")
        .put("Web.Admin.PolicyHold.EndDate", "09/01/2018")
        .put(UWIssueType, entity.UWIssueType.finder.findUWIssueTypeByCheckingSet(UWIssueCheckingSet.TC_REGULATORYHOLD).first().DisplayName)
        .put(DisplayKey.get("Web.Admin.PolicyHold.LongDesc"), "Sandy Hurricane")
        .put(LineOfBusiness, PersonalAutoLine.DisplayName)
        .put(PolicyTransactionType, PolicyChange.DisplayName)
        .put(TransactionDateType, JobDateType.TC_REFERENCE.DisplayName)
        .put(Coverage, PATowingLaborCov.DisplayName)
        .build()
  }

  function setUpFieldsOnUI(fieldMap : Map<String, String>) {
    UIHelper.assertRequiredFields(RequiredFields, fieldMap.Keys)
    var policyHoldDetailScreen = this.PolicyHolds_NewPolicyHoldsButton.click().PolicyHoldDetailScreen

    policyHoldDetailScreen.PolicyHoldDetailCV.PolicyHoldDetailDV.HoldType.setValue(fieldMap.get(HoldType))
    fieldMap = new HashMap<String, String>(fieldMap)
    DefaultFields.eachKeyAndValue(\k, val -> fieldMap.putIfAbsent(k, val))

    var holdRuleFields = Sets.newHashSet({LineOfBusiness, PolicyTransactionType, TransactionDateType, Coverage})
    UIHelper.setFieldValues(policyHoldDetailScreen, fieldMap.filterByKeys(\k -> not holdRuleFields.contains(k)))

    // The following fields are in ListView so we need to set them up manually
    policyHoldDetailScreen.PolicyHoldDetailCV.PolicyHoldRuleLV_tb.Add.click()
    var holdRuleLV = policyHoldDetailScreen.PolicyHoldDetailCV.PolicyHoldRuleLV
    holdRuleLV._Entries.single().PolicyLine.setValue(fieldMap.get(LineOfBusiness))
    holdRuleLV._Entries.single().Job.setValue(fieldMap.get(PolicyTransactionType))
    holdRuleLV._Entries.single().JobDateType.setValue(fieldMap.get(TransactionDateType))

    var covPatternSearchPopup = holdRuleLV._Entries.single().Coverage.SelectCoverage.click()
    var coveragePatternSearchDV = covPatternSearchPopup.CovPatternSearchScreen.CoveragePatternSearchDV
    coveragePatternSearchDV.Keyword.setValue(fieldMap.get(Coverage))
    coveragePatternSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
    covPatternSearchPopup.CovPatternSearchScreen.CovPatternSearchResultsLV._Entries.first().select()
    policyHoldDetailScreen.Update.click()
  }

  function deleteHold(code : String) {
    this.PolicyHoldsPanelSet.PolicyHoldsLDP.PolicyHoldsLV._Entries.singleWhere(\elt -> elt.Code.Value == code)._Checkbox.click()
    this.PolicyHolds_DeleteButton.click()
  }
}
