package gw.enhancement.job.submission

enhancement SubmissionWizard_PolicyReviewScreenEnhancement : pcftest.SubmissionWizard_PolicyReviewScreen {

  property get QuoteButton() : pcftest.QuoteTypeToolbarButtonSet_Quote.Quote {
    return this.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote
  }

  property get EditPolicyButton() : pcftest.JobWizardToolbarButtonSet_Submission.EditPolicy {
    return this.JobWizardToolbarButtonSet_Submission.EditPolicy
  }

  property get ConvertToFullAppButton() : pcftest.JobWizardToolbarButtonSet_Submission.ConvertToFullApp {
    return this.JobWizardToolbarButtonSet_Submission.ConvertToFullApp
  }

  property get BindOnlyButton() : pcftest.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly {
    return this.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly
  }

  property get BindButton() : pcftest.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue {
    return this.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue
  }

  property get IssueButton() : pcftest.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue {
    return this.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue
  }

  property get WithdrawJobButton() : pcftest.JobWizardToolbarButtonSet_Submission.CloseOptions.WithdrawJob {
    return this.JobWizardToolbarButtonSet_Submission.CloseOptions.WithdrawJob
  }

  property get DeclineButton() : pcftest.JobWizardToolbarButtonSet_Submission.CloseOptions.Decline {
    return this.JobWizardToolbarButtonSet_Submission.CloseOptions.Decline
  }

  property get NotTakenJobButton() : pcftest.JobWizardToolbarButtonSet_Submission.CloseOptions.NotTakenJob {
    return this.JobWizardToolbarButtonSet_Submission.CloseOptions.NotTakenJob
  }

  property get NewVersionButton() : pcftest.JobWizardToolbarButtonSet_Submission.Versions.NewVersion {
    return this.JobWizardToolbarButtonSet_Submission.Versions.NewVersion
  }

  property get DraftButton() : pcftest.JobWizardToolbarButtonSet_Submission.Draft {
    return this.JobWizardToolbarButtonSet_Submission.Draft
  }

  property get UnlockButton() : pcftest.JobWizardToolbarButtonSet_Submission.Unlock {
    return this.JobWizardToolbarButtonSet_Submission.Unlock
  }

  property get SideBySideButton() : pcftest.JobWizardToolbarButtonSet_Submission.Versions.SideBySide {
    return this.JobWizardToolbarButtonSet_Submission.Versions.SideBySide
  }

  property get HOPMode() : SubmissionWizardPolicyReviewScreenHOPMode {
    var panelSetEntry = this.ReviewSummaryCV_default._Entries.singleWhere(\entry -> entry.PolicyLineSummaryPanelSet_HOPLine != null)
    return new SubmissionWizardPolicyReviewScreenHOPMode(panelSetEntry.PolicyLineSummaryPanelSet_HOPLine)
  }
}