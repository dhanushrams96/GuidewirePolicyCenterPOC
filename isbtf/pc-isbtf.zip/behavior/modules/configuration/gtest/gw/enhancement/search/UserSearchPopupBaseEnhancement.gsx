package gw.enhancement.search

uses gw.smoketest.platform.web.ValueElement
uses gw.smoketest.platform.web.CheckboxValueElement
uses gw.smoketest.platform.web.SelectElement

enhancement UserSearchPopupBaseEnhancement : pcftest.UserSearchPopup {

  property get UserSearchResultsLV() : pcftest.UserSearchResultsLV { return this.UserSearchPopupScreen.UserSearchResultsLV }

  property get Username() : ValueElement { return this.UserSearchPopupScreen.UserSearchDV.Username }

  property get FirstName() : ValueElement { return this.UserSearchPopupScreen.UserSearchDV.ContactInputSet.GlobalPersonNameInputSet_default.FirstName }

  property get LastName() : ValueElement { return this.UserSearchPopupScreen.UserSearchDV.ContactInputSet.GlobalPersonNameInputSet_default.LastName }

  property get GroupName() : ValueElement { return this.UserSearchPopupScreen.UserSearchDV.GroupNameInputSet.GlobalContactNameInputSet_default.Name }

  property get NotInAnyGroup() : CheckboxValueElement { return this.UserSearchPopupScreen.UserSearchDV.NotInAnyGroup }

  property get Role() : SelectElement { return this.UserSearchPopupScreen.UserSearchDV.Role }

  property get ProducerCode() : ValueElement { return this.UserSearchPopupScreen.UserSearchDV.ProducerCode }

  property get Organization() : pcftest.UserSearchDV.Organization { return this.UserSearchPopupScreen.UserSearchDV.Organization }

  function clickSearchButton() : gw.smoketest.platform.web.PCFLocation {
    return this.UserSearchPopupScreen.UserSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  } 
  
  function clickResetButton() : gw.smoketest.platform.web.PCFLocation {
    return this.UserSearchPopupScreen.UserSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
  }    
  
  function searchUserViaUserName( name : String) : java.util.List<pcftest.UserSearchResultsLV.entry> {
    this.clickResetButton()    
    this.Username.Value = name
    this.clickSearchButton()
    return UserSearchResultsLV._Entries.where( \ a -> a.Username.Text == name ).toList()
  }

}
