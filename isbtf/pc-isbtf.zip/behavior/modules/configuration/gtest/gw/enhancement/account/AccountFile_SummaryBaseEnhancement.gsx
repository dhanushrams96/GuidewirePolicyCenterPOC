package gw.enhancement.account

uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.ValueElement
uses org.junit.Assert
uses pcftest.*
uses typekey.Job

enhancement AccountFile_SummaryBaseEnhancement : AccountFile_Summary {

  // Wrapper Properties

  property get AccountNumber() : ValueElement {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV.AccountNumber
  }

  property get AccountHolder() : ValueElement {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV.AccountHolder
  }

  property get Address() : ValueElement {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV.Address
  }

  property get AddressDescription() : ValueElement {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV.AddressDescription
  }

  // Menu Actions

  property get MenuActions_NewSubmission() : pcftest.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewSubmission {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewSubmission
  }

  property get MenuActions_WithdrawAccount() : pcftest.AccountFileMenuActions.AccountFileMenuActions_WithdrawAccount {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_WithdrawAccount
  }

  property get MenuActions_MovePolicies() : pcftest.AccountFileMenuActions.AccountFileMenuActions_MovePolicies {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_MovePolicies
  }

  property get MenuActions_MergeAccounts() : pcftest.AccountFileMenuActions.AccountFileMenuActions_MergeAccounts {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_MergeAccounts
  }

  property get MenuActions_RewritePolicies() : pcftest.AccountFileMenuActions.AccountFileMenuActions_RewritePolicies {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_RewritePolicies
  }

  function clickMovePolicies() : pcftest.AccountFile_AccountSearch {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_MovePolicies.click()
  }

  function clickMergeAccounts() : pcftest.AccountFile_AccountSearch {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_MergeAccounts.click()
  }

  function clickRewritePolicies() : pcftest.AccountFile_AccountSearch {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_RewritePolicies.click()
  }

  property get MenuActions_ReopenAccount() : pcftest.AccountFileMenuActions.AccountFileMenuActions_ReopenAccount {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_ReopenAccount
  }

  property get MenuActions_NewActivity() : pcftest.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewActivity {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewActivity
  }

  property get MenuActions_NewEmail() : pcftest.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewEmail {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewEmail
  }

  property get MenuActions_NewDocument() : pcftest.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewDocument {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewDocument
  }

  function clickCreateNewDocFromTemplate<T extends PCFLocation>(expectedType: Class<T>): T {
    return MenuActions_NewDocument.AccountNewDocumentMenuItemSet
        .AccountNewDocumentMenuItemSet_Template.clickThis(expectedType)
  }

  function clickCreateNewDocFromTemplate(): AccountNewDocumentFromTemplateWorksheet {
    return clickCreateNewDocFromTemplate(AccountNewDocumentFromTemplateWorksheet)
  }

  property get MenuActions_NewNote() : pcftest.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewNote {
    return this._parent.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewNote
  }

  public function editAccount(): pcftest.EditAccountPopup {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.Actions.EditAccount.click() as EditAccountPopup
  }

  public function editPrimaryLocation(): pcftest.EditAccountPopup {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.Actions.EditAccount.click() as EditAccountPopup
  }

  function getActivityBySubject(activitySubject: String) : CurrentActivitiesAccountListViewTile.CurrentActivitiesAccountListViewTile_LV.entry {
    var chosenEntry = findActivityBySubject(activitySubject)
    Assert.assertNotNull("Could not find activity with subject '" + activitySubject + "'", chosenEntry)
    return chosenEntry
  }

  function findActivityBySubject(activitySubject: String) : CurrentActivitiesAccountListViewTile.CurrentActivitiesAccountListViewTile_LV.entry {
    return ActivitiesLV._Entries.firstWhere(\ e -> e.Subject.Text == activitySubject)
  }

  function goToActivityBySubject(activitySubject : String) : pcftest.ActivityDetailWorksheet {
    getActivityBySubject(activitySubject).Subject.click()
    return this.SmokeTest.getCurrentWorksheet() as pcftest.ActivityDetailWorksheet
  }

  function goToPolicy(policyNumber: String): pcftest.PolicyFile_Summary {
    var row = PoliciesLV._Entries.firstWhere(\row -> row.Policy.Text == policyNumber)
    Assert.assertNotNull("Policy " + policyNumber + " not found", row)
    return row.Policy.click() as pcftest.PolicyFile_Summary
  }

  function goToWorkOrder(jobNumber: String): pcftest.SubmissionWizard {
    var jobsLV = this._parent.MenuLinks.AccountFile_AccountFile_WorkOrders.click()
    var row = jobsLV.AccountFile_WorkOrdersScreen.AccountWorkOrdersLV._Entries.firstWhere(\row -> row.WorkOrderNumber.Text == jobNumber)
    Assert.assertNotNull("WorkOrder " + jobNumber + " not found", row)
    return row.WorkOrderNumber.click() as pcftest.SubmissionWizard
  }

  function getWorkOrdersByType(jobType: Job) : List<OpenPolicyTransactionsAccountListViewTile.OpenPolicyTransactionsAccountListViewTile_LV.entry> {
    return this.WorkOrdersLV._Entries.where(\ e -> e.Type.Value == jobType.DisplayName)
  }

  function goToAccountRoles() : pcftest.AccountFile_Roles {
    return this._parent.MenuLinks.AccountFile_AccountFile_Roles.click()
  }

  function goToUnderwritingFiles() : pcftest.UnderwritingFiles {
    return this._parent.MenuLinks.AccountFile_UnderwritingFiles.click()
  }

  function goToClaims() : pcftest.AccountFile_Claims {
    return this._parent.MenuLinks.AccountFile_AccountFile_Claims.click()
  }

  function goToBilling() : pcftest.AccountFile_Billing {
    return this._parent.MenuLinks.AccountFile_AccountFile_Billing.click()
  }

  function goToSubmissionManager() : pcftest.SubmissionManager {
    return this._parent.MenuLinks.AccountFile_SubmissionManager.click()
  }

  function goToContacts() : pcftest.AccountFile_Contacts {
    return this._parent.MenuLinks.AccountFile_AccountFile_Contacts.click()
  }

  function goToLocations() : pcftest.AccountFile_Locations {
    return this._parent.MenuLinks.AccountFile_AccountFile_Locations.click()
  }

  function goToRelatedAccounts() : pcftest.AccountFile_RelatedAccounts {
    return this._parent.MenuLinks.AccountFile_AccountFile_RelatedAccounts.click()
  }

  function goToHistory() : pcftest.AccountFile_History {
    return this._parent.MenuLinks.AccountFile_AccountFile_History.click()
  }

  function goToNotes() : pcftest.AccountFile_Notes {
    return this._parent.MenuLinks.AccountFile_AccountFile_Notes.click()
  }

  function goToDocuments() : pcftest.AccountFile_Documents {
    return this._parent.MenuLinks.AccountFile_AccountFile_Documents.click()
  }

  property get WorkOrdersLV() : OpenPolicyTransactionsAccountListViewTile.OpenPolicyTransactionsAccountListViewTile_LV {
    return this.AccountSummaryDashboard.OpenPolicyTransactionsAccountListViewTile.OpenPolicyTransactionsAccountListViewTile_LV
  }

  function goToWorkOrdersPage() : pcftest.AccountFile_WorkOrders {
    return this._parent.goToWorkOrdersPage()
  }

  function goToSubmissionManagerPage() : pcftest.SubmissionManager {
    return this._parent.goToSubmissionManagerPage()
  }

  property get PoliciesLV() : CurrentPolicyTermsListViewTile.CurrentPolicyTermsListViewTile_LV {
    return this.AccountSummaryDashboard.CurrentPoliciesTileLV.CurrentPolicyTermsListViewTile
        .CurrentPolicyTermsListViewTile_LV
  }

  property get ActivitiesLV() : CurrentActivitiesAccountListViewTile.CurrentActivitiesAccountListViewTile_LV {
    return this.AccountSummaryDashboard.CurrentActivitiesAccountListViewTile.CurrentActivitiesAccountListViewTile_LV
  }

  property get AccountDetails() : AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV {
    return this.AccountSummaryDashboard.AccountDetailsDetailViewTile.AccountDetailsDetailViewTile_DV
  }
}
