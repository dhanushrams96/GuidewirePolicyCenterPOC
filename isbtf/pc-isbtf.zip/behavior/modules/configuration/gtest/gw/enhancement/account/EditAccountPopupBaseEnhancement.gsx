package gw.enhancement.account

uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.pc.contacts.EditAccountPopupPersonMode
uses gw.smoketest.pc.contacts.EditAccountPopupCompanyMode

enhancement EditAccountPopupBaseEnhancement : pcftest.EditAccountPopup {
  
  property get PersonMode():EditAccountPopupPersonMode{
    return new EditAccountPopupPersonMode(this)
  }
  
  property get CompanyMode():EditAccountPopupCompanyMode{
    return new EditAccountPopupCompanyMode(this)
  }
  
  public function update(): PCFLocation {
    return this.EditAccountScreen.Update.click()
  }
    
  public function cancel(): PCFLocation{
    return this.EditAccountScreen.Cancel.click()
  }

  property get PreferredSettlementCurrency() :  pcftest.AccountCurrencyInputSet.PreferredSettlementCurrency {
    return this.EditAccountScreen.AccountCurrency.AccountCurrencyInputSet.PreferredSettlementCurrency
  }
  
  property get PreferredCoverageCurrency() :  pcftest.AccountCurrencyInputSet.PreferredCoverageCurrency {
    return this.EditAccountScreen.AccountCurrency.AccountCurrencyInputSet.PreferredCoverageCurrency
  }

}
