package gw.enhancement.job.submission

uses pcftest.ManageBranchesScreen

enhancement ManageBranchesScreenBaseEnhancement : ManageBranchesScreen {

  function selectVersion(versionNumber : int ) {
    this.Wizard_ManageBranchesDV.Wizard_ManageBranchesLV.br._Entries[versionNumber - 1].BranchNameCB.click()
  }

  property get SelectBranchButton() : pcftest.ManageBranchesScreen.Wizard_ManageBranchesDV.Wizard_ManageBranchesLV_tb.Wizard_ManageBranchesDV_SelectBranchButton {
    return this.Wizard_ManageBranchesDV.Wizard_ManageBranchesLV_tb.Wizard_ManageBranchesDV_SelectBranchButton
  }

}
