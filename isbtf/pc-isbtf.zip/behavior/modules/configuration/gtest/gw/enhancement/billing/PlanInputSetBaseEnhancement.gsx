package gw.enhancement.billing

uses gw.smoketest.platform.web.OptionElement
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement
uses pcftest.BillingAdjustmentsPanelSet_Editable
uses pcftest.PaymentsPlanInputSet_Installments

enhancement PlanInputSetBaseEnhancement : BillingAdjustmentsPanelSet_Editable.PaymentSchedulePanel.PlanInputSet {

  property get InstallmentPlan() : PaymentsPlanInputSet_Installments.InstallmentPlan {
    return this.PaymentsPlanDV.PaymentsPlanInputSet_Installments.InstallmentPlan
  }

  property get PremiumReportPlan() : SelectElement<OptionElement> {
    return this.PaymentsPlanDV.PaymentsPlanInputSet_ReportingPlan.PremiumReportPlan
  }

  property get DepositOverride(): ValueElement {
    return this.PaymentsPlanDV.PaymentsPlanInputSet_ReportingPlan.DepositOverride
  }

  property get DepositAmount(): ValueElement {
    return this.PaymentsPlanDV.PaymentsPlanInputSet_ReportingPlan.DepositAmount
  }

  property get DepositDefault(): ValueElement {
    return this.PaymentsPlanDV.PaymentsPlanInputSet_ReportingPlan.DepositDefault
  }

}
