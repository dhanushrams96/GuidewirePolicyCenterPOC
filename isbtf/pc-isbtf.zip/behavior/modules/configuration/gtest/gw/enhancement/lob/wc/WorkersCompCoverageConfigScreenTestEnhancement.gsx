package gw.enhancement.lob.wc

uses pcftest.WorkersCompClassesInputSet

enhancement WorkersCompCoverageConfigScreenTestEnhancement : pcftest.WorkersCompCoverageConfigScreen {

  property get ClassesInputSet() : WorkersCompClassesInputSet {
    return this.WorkersCompCoverageCV.WorkersCompClassesInputSet
  }
}
