package gw.enhancement.job.policychange

uses gw.smoketest.pc.lob.gl.PolicyChangeWizardGLMode
uses gw.smoketest.pc.lob.hop.PolicyChangeWizardHOPMode
uses gw.smoketest.pc.lob.pa.PolicyChangeWizardPAMode

enhancement PolicyChangeWizardBaseEnhancement: pcftest.PolicyChangeWizard {

  property get GLMode() : PolicyChangeWizardGLMode {
    return new PolicyChangeWizardGLMode(this)
  }

  property get PAMode() : PolicyChangeWizardPAMode {
    return new PolicyChangeWizardPAMode(this)
  }

  property get HOPMode() : PolicyChangeWizardHOPMode {
    return new PolicyChangeWizardHOPMode(this)
  }

  property get ReinsurancePage() : pcftest.JobWizardToolsMenuWizardStepSet.Reinsurance {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance
  }

  property get SideBySidePage() : pcftest.JobWizardToolsMenuWizardStepSet.SideBySide {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide
  }

  function goToReinsurance() : pcftest.PolicyReinsuranceScreen {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance.click()
  }

  function goToReinsuranceCV() : pcftest.PolicyReinsuranceCV {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance.click().PolicyReinsuranceCV
  }

  function goToSideBySidePage(): pcftest.SideBySideScreen {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide.click()
  }

  property get RiskAnalysisStep() : pcftest.PolicyChangeWizard.RiskAnalysis {
    return this.RiskAnalysis
  }

  function goToRiskAnalysis() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    return screen
  }

  function goToNotesPage(): pcftest.Policy_NotesScreen {
    return this.JobWizardToolsMenuWizardStepSet.Notes.click()
  }

  function goToDocumentsPage(): pcftest.Policy_DocumentsScreen {
    return this.JobWizardToolsMenuWizardStepSet.Documents.click()
  }

  function goToHistoryPage(): pcftest.Job_HistoryScreen {
    return this.JobWizardToolsMenuWizardStepSet.History.click()
  }

  function goToManageVersionsPage(): pcftest.ManageBranchesScreen {
    return this.JobWizardToolsMenuWizardStepSet.ManageBranches.click()
  }

}
