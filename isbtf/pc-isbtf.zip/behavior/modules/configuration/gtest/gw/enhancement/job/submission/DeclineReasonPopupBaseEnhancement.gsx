package gw.enhancement.job.submission

uses gw.smoketest.platform.web.PCFLocation
uses pcftest.DeclineReasonPopup

enhancement DeclineReasonPopupBaseEnhancement : DeclineReasonPopup {

  property get RejectReason() : pcftest.RejectReasonDV.RejectReason {
    return this.RejectScreen.RejectReasonDV.RejectReason
  }

  function notTaken(): PCFLocation {
    return this.RejectScreen.Update.click()
  }

}
