package gw.enhancement.contacts
uses gw.api.databuilder.UniqueKeyGenerator
uses gw.smoketest.platform.web.ValueElement

enhancement ContactNameInputSet_personBaseEnhancement : pcftest.ContactNameInputSet_person {

  function withName(fName : String, lName : String) : pcftest.ContactNameInputSet_person{
    this.DefaultFirstName.Value = fName
    this.DefaultLastName.Value = lName
    return this
  }

  function withEmailAddress1(address1 : String) : pcftest.ContactNameInputSet_person{
    this.EmailAddress1.Value = address1
    return this
  }

  function withWorkPhone(phone : String) : pcftest.ContactNameInputSet_person{
    this.PrimaryPhone.TypeKeyValue = typekey.PrimaryPhoneType.TC_WORK
    this.WorkPhoneNumber.Value = phone
    return this
  }

  function fillDefaults() : pcftest.ContactNameInputSet_person {
    var key = UniqueKeyGenerator.get().nextKey()
    this.DefaultFirstName.Value = key
    this.DefaultLastName.Value = key
    this.EmailAddress1.Value = "${key}1@${key}.com"
    this.EmailAddress2.Value = "${key}2@${key}.com"
    this.FaxPhoneNumber.Value = "510-455-4566"
    this.WorkPhoneNumber.Value = "420-345-2344"
    return this
  }

  property get DefaultFirstName(): ValueElement {
    return this.GlobalPersonNameInputSet_default.FirstName
  }

  property get DefaultLastName(): ValueElement {
    return this.GlobalPersonNameInputSet_default.LastName
  }

  property get WorkPhoneNumber() : ValueElement{
    return this.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get WorkPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode{
    return this.WorkPhone.GlobalPhoneInputSet.CountryCode
  }

  property get HomePhoneNumber() : ValueElement{
    return this.HomePhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get HomePhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode{
    return this.HomePhone.GlobalPhoneInputSet.CountryCode
  }

  property get CellPhoneNumber() : ValueElement{
    return this.CellPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get CellPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode{
    return this.CellPhone.GlobalPhoneInputSet.CountryCode
  }

  property get FaxPhoneNumber() : ValueElement{
    return this.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode{
    return this.FaxPhone.GlobalPhoneInputSet.CountryCode
  }

}
