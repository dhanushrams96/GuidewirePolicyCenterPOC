package gw.enhancement.search

uses pcftest.HVQPolicySearchPanelSet


enhancement HVQSearchDVBaseEnhancement : HVQPolicySearchPanelSet.HVQPolicySearchDV {

  function clickSearch() {
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

}
