package gw.enhancement.job.submission

enhancement NewSubmissionBaseEnhancement : pcftest.NewSubmission {

  property get ProductSelectionLV() : pcftest.ProductSelectionLV {
    return this.NewSubmissionScreen.ProductOffersDV.ProductSelectionLV
  }

  property get QuoteTypeList() : pcftest.NewSubmission.NewSubmissionScreen.ProductSettingsDV.QuoteType {
    return this.NewSubmissionScreen.ProductSettingsDV.QuoteType
  }

  property get QuoteTypeKey() : QuoteType {
    return this.NewSubmissionScreen.ProductSettingsDV.QuoteType.TypeKeyValue
  }

  property set QuoteTypeKey(quoteType: QuoteType) {
    this.NewSubmissionScreen.ProductSettingsDV.QuoteType.setTypeKeyValue(quoteType)
  }

}
