package gw.enhancement.job.issuance

uses gw.smoketest.pc.lob.gl.IssuanceWizardGLMode
uses gw.smoketest.pc.lob.hop.IssuanceWizardHOPMode
uses gw.smoketest.pc.lob.pa.IssuanceWizardPAMode

// Enhances the Issuance Wizard. Has some helper methods to navigate to and verify current screen
// Methods are grouped by product and order they appear on the UI navigation
enhancement IssuanceWizardBaseEnhancement: pcftest.IssuanceWizard {

  property get GLMode() : IssuanceWizardGLMode {
    return new IssuanceWizardGLMode(this)
  }

  property get PAMode() : IssuanceWizardPAMode {
    return new IssuanceWizardPAMode(this)
  }

  property get HOPMode() : IssuanceWizardHOPMode {
    return new IssuanceWizardHOPMode(this)
  }

  property get RiskAnalysisStep() : pcftest.IssuanceWizard.RiskAnalysis {
    return this.RiskAnalysis
  }

  function goToRiskAnalysis() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    return screen
  }

}
