package gw.enhancement.lob.pa

uses gw.api.productmodel.ClausePatternLookup
uses gw.smoketest.platform.web.SelectElement
uses pcftest.PersonalAutoScreen

enhancement PersonalAutoScreenBaseEnhancement : PersonalAutoScreen {

  property get AutoLiabCov() : pcftest.CoverageInputSet_PALiabilityCov {
    return this.PersonalAuto_AllVehicleCoveragesDV.PALiabCategoryIterator._Entries
        .firstWhere(\e -> e.CoverageInputSet_PALiabilityCov.CovPatternDisplayName.Text == ClausePatternLookup.getCoveragePatternByPublicID("PALiabilityCov").Name)
        .CoverageInputSet_PALiabilityCov
  }

  property get AutoLiabCovTerm() : SelectElement {
    return AutoLiabCov.CovPatternInputGroup.LiabilityTermInput
  }

}
