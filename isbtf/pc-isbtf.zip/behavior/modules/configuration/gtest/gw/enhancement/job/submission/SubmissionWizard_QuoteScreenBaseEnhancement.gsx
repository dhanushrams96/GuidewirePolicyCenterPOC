package gw.enhancement.job.submission

uses gw.api.util.MonetaryAmounts
uses gw.pl.currency.MonetaryAmount

enhancement SubmissionWizard_QuoteScreenBaseEnhancement : pcftest.SubmissionWizard_QuoteScreen {

  property get ViewRatingWorksheet() : pcftest.RatingOverrideButtonDV.ViewWorksheet{
    return this.RatingCumulDetailsPanelSet_PersonalAutoLine.RatingOverrideButtonDV.RatingOverrideButtonDV.ViewWorksheet
  }

  /**
   * Returns a map of vehicle coverages and their cost from quote page
   * @param garageNum the number for the garage. Eg. A vehicle could be garaged at California in loc1 or loc2...
   * @param vehicleNum the number of vehicle from the garaged location.
   * @return
   */
  function coveragesForVehicle(garageNum : int, vehicleNum : int) : Map<String, MonetaryAmount>{
    var garageEntry = this.RatingCumulDetailsPanelSet_PersonalAutoLine._Entries.get(garageNum)
    var vehicle = garageEntry._Entries.get(vehicleNum)
    var coverages = vehicle.costLV._Entries
    //The String value returned from UI is not in Amount Currency format. So, we need to convert the String to BigDecimal
    return coverages.mapToKeyAndValue(\desc -> desc.Description.Text, \premium -> MonetaryAmounts.ofDefaultCurrency(premium.TxAmount.Value.toBigDecimal()))
  }

}
