package gw.enhancement.job.cancellation

uses pcftest.CancellationWizard_QuoteScreen

enhancement CancellationWizard_QuoteScreenBaseEnhancement : CancellationWizard_QuoteScreen {

  property get CancelNowButton() : pcftest.JobWizardToolbarButtonSet_Cancellation.BindOptions.CancelNow {
    return this.JobWizardToolbarButtonSet_Cancellation.BindOptions.CancelNow
  }

}
