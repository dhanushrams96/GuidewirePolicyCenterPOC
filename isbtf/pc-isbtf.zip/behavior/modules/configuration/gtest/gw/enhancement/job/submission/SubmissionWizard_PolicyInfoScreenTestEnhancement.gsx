package gw.enhancement.job.submission

uses gw.smoketest.platform.web.IteratorEntriesWithPaging
uses pcftest.AdditionalNamedInsuredInputSet
uses pcftest.NewAdditionalNamedInsuredPopup
uses pcftest.SubmissionWizard_PolicyInfoScreen

enhancement SubmissionWizard_PolicyInfoScreenTestEnhancement : SubmissionWizard_PolicyInfoScreen {

  property get AdditionalNamedInsuredsLVEntries() : IteratorEntriesWithPaging<AdditionalNamedInsuredInputSet.NamedInsuredsLV.entry> {
    return this.SubmissionWizard_PolicyInfoDV.AdditionalNamedInsuredInputSet.NamedInsuredsLV._Entries
  }

  function goToNewPersonPopup() : NewAdditionalNamedInsuredPopup {
    var additionalNamedInsuredInputSet = this.SubmissionWizard_PolicyInfoDV.AdditionalNamedInsuredInputSet
    additionalNamedInsuredInputSet.NamedInsuredsLV_tb.AddContactsButton.click()
    var newAdditionalInsuredPopup = additionalNamedInsuredInputSet.NamedInsuredsLV_tb.AddContactsButton._Entries
        .firstWhere(\entry -> entry.ContactType.Text == "New Person")
        .ContactType.click() as NewAdditionalNamedInsuredPopup
    return newAdditionalInsuredPopup
  }

}