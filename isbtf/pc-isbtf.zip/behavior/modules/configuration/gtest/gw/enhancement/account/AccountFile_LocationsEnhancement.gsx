package gw.enhancement.account

uses gw.cucumber.util.common.UIHelper
uses gw.smoketest.platform.web.ValueElement
uses gw.test.pl.util.BulkVerifier
uses org.junit.Assert

enhancement AccountFile_LocationsEnhancement : pcftest.AccountFile_Locations {
  function changeAccountsPrimaryLocationInfo(newLocation: Map<String,String>) {
    var rowSelector = \row:pcftest.AccountFile_LocationsLV.entry ->row.PrimaryLocation.Value.toBoolean()
    var accountLocationPopup = this.AccountFile_LocationsScreen.AccountFile_LocationsLV._Entries.firstWhere(rowSelector).Loc.click()
    UIHelper.setFieldValues(accountLocationPopup, newLocation)
    accountLocationPopup.update()
  }
}