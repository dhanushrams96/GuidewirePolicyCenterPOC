package gw.enhancement.contacts

uses gw.smoketest.pc.account.AccountContactCVPersonMode
uses gw.smoketest.pc.account.AccountContactCVCompanyMode

enhancement EditAccountContactPopupBaseEnhancement : pcftest.EditAccountContactPopup {

  property get EditButton() : pcftest.EditAccountContactPopup.ContactDetailScreen.Edit {
    return this.ContactDetailScreen.Edit
  }

  property get UpdateButton() : pcftest.EditAccountContactPopup.ContactDetailScreen.Update {
    return this.ContactDetailScreen.Update
  }

  property get CancelButton() : pcftest.EditAccountContactPopup.ContactDetailScreen.Cancel {
    return this.ContactDetailScreen.Cancel
  }

  property get BreadCrumbLink() : pcftest.EditAccountContactPopup.__crumb__ {
    return this.__crumb__
  }
  
  //-------------------------------------------------------------------------------- Modes

  property get CompanyMode() : AccountContactCVCompanyMode {
    return this.ContactDetailScreen.AccountContactCV.CompanyMode
  }
  
  property get PersonMode() : AccountContactCVPersonMode {
    return this.ContactDetailScreen.AccountContactCV.PersonMode
  }
  
  //-------------------------------------------------------------------------------- Contact Detail Tab

  property get AccountContactDVSafely() : pcftest.AccountContactDV {
    return this.ContactDetailScreen.AccountContactCV.AccountContactDVSafely
  }

  //-------------------------------------------------------------------------------- Roles Tab

  property get ContactRolesDVSafely() : pcftest.AccountContactCV.ContactRolesDV {
    return this.ContactDetailScreen.AccountContactCV.AccountContactRolesDVSafely
  }

  property get AddRoleButton() : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.AddRoleButton {
    return this.ContactDetailScreen.AccountContactCV.AddRoleButton
  }
  
  function getRoleMenuItemFromAddRoleButton(accountContactRoleType : Type<AccountContactRole>) : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.AddRoleButton.entry {
    return this.ContactDetailScreen.AccountContactCV.getRoleMenuItemFromAddRoleButton(accountContactRoleType)
  }
  
  property get RemoveRoleButton() : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV_tb.Remove {
    return this.ContactDetailScreen.AccountContactCV.RemoveRoleButton
  }
  
  function getContactRoleEntry(accountContactRoleType : Type<AccountContactRole>) : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV.entry {
    return this.ContactDetailScreen.AccountContactCV.getContactRoleEntry( accountContactRoleType )
  }

  //-------------------------------------------------------------------------------- Address Tab

  property get AddressesLVSafely() : pcftest.AddressesPanelSet.AddressesLV {
    return this.ContactDetailScreen.AccountContactCV.AddressesLVSafely
  }

  property get AddressesDVSafely() : pcftest.AddressesPanelSet.AddressDetailDV {
    return this.ContactDetailScreen.AccountContactCV.AddressesDVSafely
  }
  
  property get AddressesLV_tbSafely() : pcftest.AddressesPanelSet.AddressesLV_tb{
    return this.ContactDetailScreen.AccountContactCV.AddressesLV_tbSafely
  }

  property get AddressToolsMergeMenuSafely() : pcftest.AddressesPanelSet.MergeAddresses {
    return this.ContactDetailScreen.AccountContactCV.AddressesPanelSet.MergeAddressButtonSafely
  }
  
  //-------------------------------------------------------------------------------- misc...

  function addRole(roleType : Type<AccountContactRole>) {
    addRole(roleType.TypeInfo.DisplayName)
  }
  
  function addRole(role:String) {
    AddRoleButton._Entries.firstWhere( \ a -> a.RoleType.Text == role ).RoleType.click()
  }

  function getAccountContactRoleEntry(acrType : Type<AccountContactRole>) : pcftest.AccountContactCV.ContactRolesDV.ContactRolesLV.entry {
    return this.getContactRoleEntry(acrType)
  }
  
  property get ErrorMessages() : java.lang.String[] {
    return this.ContactDetailScreen._msgs.Messages
  }
}
