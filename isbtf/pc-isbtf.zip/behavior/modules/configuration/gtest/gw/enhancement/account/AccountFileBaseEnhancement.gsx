package gw.enhancement.account

uses pcftest.AccountFile_Summary

enhancement AccountFileBaseEnhancement : pcftest.AccountFile {

  function goToSummary(): AccountFile_Summary {
    return this.MenuLinks.AccountFile_AccountFile_Summary.click()
  }

  function goToContactsPage(): pcftest.AccountFile_Contacts {
    return this.MenuLinks.AccountFile_AccountFile_Contacts.click()
  }

  function goToClaimsPage() : pcftest.AccountFile_Claims {
    return this.MenuLinks.AccountFile_AccountFile_Claims.click()
  }

  function goToBillingPage(): pcftest.AccountFile_Billing {
    return this.MenuLinks.AccountFile_AccountFile_Billing.click()
  }

  function goToLocationsPage(): pcftest.AccountFile_Locations {
    return this.MenuLinks.AccountFile_AccountFile_Locations.click()
  }

  function goToSubmissionManagerPage(): pcftest.SubmissionManager {
    return this.MenuLinks.AccountFile_SubmissionManager.click()
  }

  function goToWorkOrdersPage(): pcftest.AccountFile_WorkOrders {
    return this.MenuLinks.AccountFile_AccountFile_WorkOrders.click()
  }

  function goToUnderwritingFiles() : pcftest.UnderwritingFiles {
    return this.MenuLinks.AccountFile_UnderwritingFiles.click()
  }

  function newSubmission(): pcftest.NewSubmission {
    return this.AccountFileMenuActions.AccountFileMenuActions_Create.AccountFileMenuActions_NewSubmission.click()
  }

}
