package gw.enhancement.job.common

uses gw.smoketest.platform.web.IteratorEntries
uses gw.smoketest.platform.web.PCFLocation
uses pcftest.SideBySideToolbarButtonSet

enhancement SideBySideScreenBaseEnhancement : pcftest.SideBySideScreen {

  function quoteAll() : PCFLocation {
    if (QuoteAllButton.Visible) {
      return (QuoteAllButton.click())
    }
    return null
  }

  function saveAll() : PCFLocation {
    return SaveAllButton.click()
  }

  function selectPeriod(periodIndex : int) : PCFLocation {
    return this.SideBySideTableLayoutDV.ActionButtonSetsId._Entries[periodIndex].SelectButtonId.click()
  }

  function getPremium(periodIndex : int) : String {
    return this.SideBySideTableLayoutDV.periodInfoPremiumIterator._Entries[periodIndex].PremiumValue.Value
  }

  property get QuoteAllButton() : pcftest.SideBySideToolbarButtonSet.QuoteAll {
    return this.SideBySideToolbarButtonSet.QuoteAll
  }

  property get LineLevelCoverages() : IteratorEntries<pcftest.SideBySideTableLayoutDV.lineLevelCoverages.entry>{
    return this.SideBySideTableLayoutDV.lineLevelCoverages._Entries
  }

  property get SaveAllButton() : SideBySideToolbarButtonSet.SaveAll{
    return this.SideBySideToolbarButtonSet.SaveAll
  }

}
