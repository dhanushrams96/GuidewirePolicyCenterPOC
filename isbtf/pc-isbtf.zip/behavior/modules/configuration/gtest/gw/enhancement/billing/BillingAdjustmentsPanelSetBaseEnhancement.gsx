package gw.enhancement.billing

uses gw.smoketest.platform.web.BooleanValueElement
uses gw.smoketest.platform.web.IteratorEntriesWithPaging
uses gw.smoketest.platform.web.ValueElement
uses pcftest.BillingAdjustmentsPanelSet_Editable
uses pcftest.BillingAdjustmentsInstallmentsLV
uses pcftest.BillingInvoiceStreamInputSet
uses pcftest.InvoiceStreamsLV
uses pcftest.PaymentInstrumentsLV

enhancement BillingAdjustmentsPanelSetBaseEnhancement : BillingAdjustmentsPanelSet_Editable {

  property get AltBillingAccountInput() : pcftest.AccountContactBillingInputSet.AltBillingAccount {
    return this.BillingPanel.AccountContactBillingInputSet.AltBillingAccount
  }

  property get SubAccounts() : pcftest.AccountContactBillingInputSet.AltBillingAccount.SubAccounts {
    return this.AltBillingAccountInput.SubAccounts
  }

  property get RemoveAlternateBilling() : pcftest.AccountContactBillingInputSet.AltBillingAccount.Remove {
    return this.AltBillingAccountInput.Remove
  }

  property get BillingAdjustmentsInstallmentsLV() : BillingAdjustmentsInstallmentsLV {
    return this.PaymentSchedulePanel.PlanInputSet.InstallmentPlan.BillingAdjustmentsInstallmentsLV
  }

  property get PaymentPlans() : IteratorEntriesWithPaging<BillingAdjustmentsInstallmentsLV.entry> {
    return this.BillingAdjustmentsInstallmentsLV._Entries
  }

  property get CustomBilling() : gw.smoketest.platform.web.CheckboxValueElement {
    return this.OverridesAndPaymentsPanel.Custom
  }

  property get NewInvoicing(): BooleanValueElement {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.NewInvoicing
  }

  property get InvoiceStreams(): pcftest.InvoiceStreamsLV {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.InvoiceStreams.InvoiceStreamsLV
  }

  property get SelectInvoiceStream() : InvoiceStreamsLV.entry.InvoiceStream {
    var streamEntries = this.OverridesAndPaymentsPanel.InvoicingInputSet.InvoiceStreams.InvoiceStreamsLV._Entries
    return streamEntries.firstWhere(\e -> e.InvoiceStream.Editable == true).InvoiceStream
  }

  property get UnappliedFund() : BooleanValueElement {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.UnappliedFund
  }

  property get PaymentInstrument() : BooleanValueElement {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.BillingInvoiceStreamInputSet.Automatic
  }

  property get PaymentInstruments() : IteratorEntriesWithPaging<PaymentInstrumentsLV.entry> {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.BillingInvoiceStreamInputSet.PaymentInstrument.PaymentInstrumentsLV._Entries
  }

  property get AddPaymentInstrument() : BillingInvoiceStreamInputSet.PaymentInstrument.PaymentInstrumentsLV_tb.AddPaymentInstrument {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.BillingInvoiceStreamInputSet.PaymentInstrument.PaymentInstrumentsLV_tb.AddPaymentInstrument
  }

  property get ChangeBillingContact(): pcftest.AccountContactBillingInputSet.ChangeBillingContactButton {
    return this.BillingPanel.AccountContactBillingInputSet.ChangeBillingContactButton
  }

  property get BillingInvoiceStreamInputSet(): pcftest.BillingInvoiceStreamInputSet {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.BillingInvoiceStreamInputSet
  }

  property get OverrideBillingInvoiceStreamInputSet(): pcftest.BillingInvoiceStreamInputSet {
    return this.OverridesAndPaymentsPanel.OverriddenInvoiceStreamInput.BillingInvoiceStreamInputSet
  }

  property get UnappliedFundInput() : ValueElement {
    return this.OverridesAndPaymentsPanel.InvoicingInputSet.UnappliedFundInput
  }

  function selectSubAccount() : String {
    this.AltBillingAccountInput.SubAccounts.click()
    this.AltBillingAccountInput.SubAccounts._Entries.first().SubAccount.click()
    return this.AltBillingAccountInput.Value
  }

}
