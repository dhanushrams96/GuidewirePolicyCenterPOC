package gw.enhancement.job.common

uses gw.smoketest.platform.web.ValueElement

// NOTE: Defaults to "default" mode
enhancement PolicyAddressDisplayInputSetBaseEnhancement : pcftest.PolicyAddressDisplayInputSet {

  property get Address() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressSummary
  }

  property get County() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.County
  }

  property get Country() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.Country
  }

}
