package gw.enhancement.job.renewal

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.pc.lob.gl.RenewalWizardGLMode
uses gw.smoketest.pc.lob.pa.RenewalWizardPAMode
uses gw.smoketest.platform.web.WizardMenuLinkElement

enhancement RenewalWizardBaseEnhancement: pcftest.RenewalWizard {

  property get CancelButton() : pcftest.RenewalWizard.Cancel { return this.Cancel }

  property get PrevButton() : pcftest.RenewalWizard.Prev { return this.Prev }

  property get NextButton() : pcftest.RenewalWizard.Next { return this.Next }

  property get FinishButton() : pcftest.RenewalWizard.Finish { return this.Finish }

  // ---- Fields ---- //

  property get SideBySideStep() : pcftest.JobWizardToolsMenuWizardStepSet.SideBySide {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide
  }

  property get BillingInfoStep() : pcftest.RenewalWizard.PostQuoteWizardStepSet.BillingInfo {
    return this.PostQuoteWizardStepSet.BillingInfo
  }

  property get PolicyInfoStep() : pcftest.RenewalWizard.LOBWizardStepGroup.PolicyInfo {
    return this.LOBWizardStepGroup.PolicyInfo
  }

  property get RiskAnalysisStep() : pcftest.RenewalWizard.LOBWizardStepGroup.RiskAnalysis {
    return this.LOBWizardStepGroup.RiskAnalysis
  }

  property get PolicyReviewStep() : pcftest.RenewalWizard.LOBWizardStepGroup.PolicyReview {
    return this.LOBWizardStepGroup.PolicyReview
  }

  property get ViewQuoteStep() : pcftest.RenewalWizard.PostQuoteWizardStepSet.ViewQuote {
    return this.PostQuoteWizardStepSet.ViewQuote
  }

  // ---- "goTo" methods --- //

  function goToBillingInfo() : pcftest.RenewalWizard_PaymentScreen {
    var screen = BillingInfoStep.click()
    assertOnStep( BillingInfoStep )
    return screen
  }

  function goToPolicyInfo() : pcftest.RenewalWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  function goToReinsuranceScreen() : pcftest.PolicyReinsuranceScreen {
    return this.JobWizardToolsMenuWizardStepSet.Reinsurance.click()
  }

  function goToRiskAnalysis() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep( RiskAnalysisStep )
    return screen
  }

  function goToPolicyReview() : pcftest.RenewalWizard_DifferencesScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep( PolicyReviewStep )
    return screen
  }

  function goToViewQuote() : pcftest.RenewalWizard_QuoteScreen {
    var screen = ViewQuoteStep.click()
    assertOnStep( ViewQuoteStep )
    return screen
  }

  function goToSideBySidePage(): pcftest.SideBySideScreen {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide.click()
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( this )
    AssertUtil.assertOnScreen( step )
  }

  property get GLMode() : RenewalWizardGLMode {
    return new RenewalWizardGLMode(this)
  }

  property get PAMode() : RenewalWizardPAMode {
    return new RenewalWizardPAMode(this)
  }

}
