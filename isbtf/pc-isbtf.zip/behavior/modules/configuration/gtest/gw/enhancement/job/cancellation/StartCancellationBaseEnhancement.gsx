package gw.enhancement.job.cancellation

uses pcftest.StartCancellation

@Export
enhancement StartCancellationBaseEnhancement : StartCancellation {

  property get Source() : pcftest.StartCancellation.StartCancellationScreen.CancelPolicyDV.Source {
    return this.StartCancellationScreen.CancelPolicyDV.Source
  }

  property get Reason() : pcftest.StartCancellation.StartCancellationScreen.CancelPolicyDV.Reason {
    return this.StartCancellationScreen.CancelPolicyDV.Reason
  }

  property set CancelDateTime(d : Date) {
    if (d == null) {
      this.StartCancellationScreen.CancelPolicyDV.CancelDate.Value = ""
    } else {
      this.StartCancellationScreen.CancelPolicyDV.CancelDate.DateValue = d
    }
  }

  property get CancelDateTime() : Date {
    return this.StartCancellationScreen.CancelPolicyDV.CancelDate.DateValue
  }

}
