package gw.enhancement.desktop

uses gw.smoketest.platform.web.PCFLocation
uses pcftest.DesktopMenuActions

enhancement PCLoginBaseEnhancement : pcftest.Login {

  function loginAndReturnTabBar(username: String, password: String): pcftest.TabBar {
    return (loginToDesktopActivities(username, password))._parent.TabBar
  }

  function loginAndReturnTabBar(): pcftest.TabBar {
    return loginAndReturnTabBar("aapplegate", "gw")
  }

  function loginAndReturnMenuActionsCreate(): DesktopMenuActions.DesktopMenuActions_Create {
    return openMenuActionsCreate("aapplegate", "gw")
  }

  function loginAndReturnTabBar(userName: String): pcftest.TabBar {
    return loginAndReturnTabBar(userName, "gw")
  }

  function loginToDesktopActivities(username: String, password: String): pcftest.DesktopActivities {
    var page = this.login(username, password)
    page.assertOnPage()
    return openDesktopActivities(page)
  }

  function openMenuActionsCreate(username: String, password: String): DesktopMenuActions.DesktopMenuActions_Create {
    var desktopPage = this.login(username, password)
    var desktop = desktopPage.getOrCreateProperty("_parent", pcftest.Desktop)
    return desktop.DesktopMenuActions.getDesktopMenuActions_Create()
  }

  private function openDesktopActivities(desktopPage: PCFLocation): pcftest.DesktopActivities {
    var desktop = desktopPage.getOrCreateProperty("_parent", pcftest.Desktop)
    return desktop.MenuLinks.Desktop_DesktopActivities.click()
  }

}
