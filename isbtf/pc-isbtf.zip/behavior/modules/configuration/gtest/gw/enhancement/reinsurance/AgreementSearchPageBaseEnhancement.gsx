package gw.enhancement.reinsurance

uses gw.smoketest.platform.web.IteratorEntriesWithPaging
uses gw.smoketest.platform.web.ValueElement
uses org.junit.Assert

enhancement AgreementSearchPageBaseEnhancement : pcftest.AgreementSearchPage {

  property get MenuActions() : pcftest.ReinsuranceMenuActions {
    return this._parent.ReinsuranceMenuActions
  }

  property get AgreementType() : ValueElement {
    return this.AgreementSearchScreen.AgreementSearchDV.AgreementType
  }

  property get AgreementNumber() : ValueElement {
    return this.AgreementSearchScreen.AgreementSearchDV.AgreementNumber
  }

  property get Arrangement() : pcftest.AgreementSearchDV.Arrangement {
    return this.AgreementSearchScreen.AgreementSearchDV.Arrangement
  }

  function searchByCustomDates(effDate : Date, expDate : Date) : IteratorEntriesWithPaging<pcftest.AgreementSearchResultsLV.entry>{
    var inputSet = this.AgreementSearchScreen.AgreementSearchDV.EffectivePeriodInputSet
    inputSet.PeriodType.TypeKeyValue = typekey.ContractEffectivePeriod.TC_CUSTOM
    inputSet.EffectiveDate.DateValue = effDate
    inputSet.ExpirationDate.DateValue = expDate
    this.AgreementSearchScreen.AgreementSearchDV.Arrangement.getOption(0).click()
    search()
    return Results
  }

  function searchByNumber(number : String) : pcftest.AgreementSearchResultsLV.entry{
    this.AgreementNumber.Value = number
    this.Arrangement.getOption(0).click()
    search()
    Assert.assertEquals("Should return only one result", 1, Results.Count)
    return Results.single()
  }

  function searchByCoverage(coverage : String) : pcftest.AgreementSearchResultsLV.entry{
    this.AgreementSearchScreen.AgreementSearchDV.CoverageGroup.Value = coverage
    search()
    Assert.assertEquals("Should return only one result", 1, Results.Count)
    return Results.single()
  }

  function search() {
    this.AgreementSearchScreen.AgreementSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  property get Results() : IteratorEntriesWithPaging<pcftest.AgreementSearchResultsLV.entry>{
    return this.AgreementSearchScreen.AgreementSearchResultsLV._Entries
  }

  function goToEditScreenByNumber(number : String) : pcftest.AgreementScreen {
    var row = searchByNumber(number)
    var editPage = row.AgreementNumber.click()
    return editPage.AgreementScreen
  }

}
