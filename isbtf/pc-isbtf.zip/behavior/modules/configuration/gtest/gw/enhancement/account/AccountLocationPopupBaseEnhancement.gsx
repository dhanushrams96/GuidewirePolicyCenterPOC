package gw.enhancement.account

uses gw.smoketest.platform.web.BooleanValueElement
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement

enhancement AccountLocationPopupBaseEnhancement : pcftest.AccountLocationPopup {
  
  // fields
  property get NonSpecificLocation() : BooleanValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.NonSpecificLocation
  }

  property get LocationCode() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.LocationCode
  }

  property get LocationName() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.LocationName
  }

  property get Address1() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.AddressLine1
  }

  property get Address2() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.AddressLine2
  }

  property get City() : pcftest.GlobalAddressInputSet_default.City {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.City
  }

  property get State() : SelectElement {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.State
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.PostalCode
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.Country
  }

  property get County() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressInputSet.County
  }

  property get AddressDescription() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.AddressDescription
  }

  property get Phone() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.Phone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get EmployeeCount() : ValueElement {
    return this.LocationScreen.AccountLocationDetailInputSet.EmployeeCount
  }

  function update() {
    this.LocationScreen.Update.click()
  }
  
}
