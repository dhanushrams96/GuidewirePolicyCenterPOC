package gw.enhancement.search

uses gw.smoketest.platform.web.ValueElement

enhancement OrganizationSearchPopupTestEnhancement : pcftest.OrganizationSearchPopup {

  function clickSearch() : gw.smoketest.platform.web.PCFLocation {
    return this.OrganizationSearchPopupScreen.OrganizationSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  property get Name() : ValueElement {
    return this.OrganizationSearchPopupScreen.OrganizationSearchDV.GlobalContactNameInputSet_default.Name
  }

  function getSearchResults() : gw.smoketest.platform.web.IteratorEntriesWithPaging<pcftest.OrganizationSearchPopup.OrganizationSearchPopupScreen.OrganizationSearchResultsLV.entry> {
    return this.OrganizationSearchPopupScreen.OrganizationSearchResultsLV._Entries
  }

}
