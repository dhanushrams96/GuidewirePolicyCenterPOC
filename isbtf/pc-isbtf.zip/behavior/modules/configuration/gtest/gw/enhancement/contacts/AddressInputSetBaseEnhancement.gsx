package gw.enhancement.contacts
uses gw.api.databuilder.UniqueKeyGenerator
uses gw.smoketest.platform.web.ValueElement

enhancement AddressInputSetBaseEnhancement : pcftest.AddressInputSet {

  function fillDefaults() : pcftest.AddressInputSet {
    var key = UniqueKeyGenerator.get()
    this.AddressLine1.Value = key.nextKey()
    this.AddressLine2.Value = key.nextKey()
    this.City.Value = key.nextKey()
    this.Country.TypeKeyValue = TC_US
    this.County.Value = key.nextKey()
    this.PostalCode.Value = "12345"
    this.State.Value = typekey.State.TC_CA.Code
    return this
  }

  function withAddressLine1(line1 : String) : pcftest.AddressInputSet {
    this.AddressLine1.Value = line1
    return this
  }

  property get AddressSummary() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressSummary
  }

  property get AddressLine1() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine1
  }

  property get AddressLine1Kanji() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_BigToSmall.AddressLine1Kanji
  }

  property get AddressLine2() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine2
  }

  property get AddressLine2Kanji() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_BigToSmall.AddressLine2Kanji
  }

  property get AddressLine3() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine3
  }

  property get City() : pcftest.GlobalAddressInputSet_default.City {
    return this.globalAddressContainer.GlobalAddressInputSet_default.City
  }

  property get CityKanji() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_BigToSmall.CityKanji
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return this.globalAddressContainer.GlobalAddressInputSet_default.Country
  }

  property get County() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.County
  }

  property get State() : gw.smoketest.platform.web.SelectElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.State
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return this.globalAddressContainer.GlobalAddressInputSet_default.PostalCode
  }

}
