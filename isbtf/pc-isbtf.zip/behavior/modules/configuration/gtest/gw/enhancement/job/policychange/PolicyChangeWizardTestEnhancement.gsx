package gw.enhancement.job.policychange

uses gw.smoketest.pc.job.policychange.PolicyChangeWizardWCMode
uses pcftest.PolicyChangeWizard

enhancement PolicyChangeWizardTestEnhancement : PolicyChangeWizard {

  function clickQuote() {
    var policyReviewStep = this.PolicyReview.click()
    policyReviewStep.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
  }

  property get WCMode() : PolicyChangeWizardWCMode {
    return new PolicyChangeWizardWCMode(this)
  }

}
