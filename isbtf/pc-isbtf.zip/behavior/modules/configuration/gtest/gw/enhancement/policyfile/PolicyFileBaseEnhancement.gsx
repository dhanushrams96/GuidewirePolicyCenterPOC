package gw.enhancement.policyfile

uses gw.smoketest.platform.web.DateElement
uses pcftest.ContingencyPopup
uses pcftest.NewNoteWorksheet
uses pcftest.PolicyFile
uses pcftest.PolicyFile_Jobs
uses pcftest.PolicyFile_Transactions_AllPopup
uses pcftest.RenewalWizard

@Export
enhancement PolicyFileBaseEnhancement : PolicyFile {

  function goToCancellationPage() : pcftest.StartCancellation {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.PolicyFileMenuActions_CancelPolicy.click()
  }

  function goToStartPolicyChangePage() : pcftest.StartPolicyChange {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.PolicyFileMenuActions_ChangePolicy.click()
  }

  function startReinstatement(): pcftest.ReinstatementWizard {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.PolicyFileMenuActions_ReinstatePolicy.click() as pcftest.ReinstatementWizard
  }

  function goToFinancialTransactionsPopup() : PolicyFile_Transactions_AllPopup {
    var transactions = this.MenuLinks.PolicyFile_PolicyFile_Transactions.click()
    return transactions.AllTransactions.click()
  }

  property get PolicyPeriodViewAsOfEffDate() : DateElement {
    return this.PolicyFileAcceleratedMenuActions.PolicyPeriodEffDateID.PolicyPeriodEffDateID_Arg
  }

  function goToPACoveragesStep() : pcftest.PolicyFile_PersonalAuto {
    return this.PolicyFileAcceleratedMenuActions.PolicyMenuItemSet_PersonalAuto.PolicyMenuItemSet_PersonalAuto.click()
  }

  function startPolicyRenewal() : RenewalWizard {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.PolicyFileMenuActions_RenewPolicy.click() as pcftest.RenewalWizard
  }

  function goToPolicy_JobsScreen() : PolicyFile_Jobs.Policy_JobsScreen {
    return this.MenuLinks.PolicyFile_PolicyFile_Jobs.click().Policy_JobsScreen
  }

  function goToRiskAnalysisScreen() : pcftest.PolicyFile_RiskAnalysis {
    return this.MenuLinks.PolicyFile_PolicyFile_RiskAnalysis.click()
  }

  function goToContingencyPopup(contingencyStatus : ContingencyStatus, contingencyTitle : String, dueDate : Date) : ContingencyPopup {
    var riskanalysisStep= goToRiskAnalysisScreen()
    riskanalysisStep.PolicyFile_RiskAnalysisScreen.PolicyFile_RiskAnalysisCV.PolicyFile_ContingenciesCardTab.click()
    var contingencyPanelSet = riskanalysisStep.PolicyFile_RiskAnalysisScreen.PolicyFile_RiskAnalysisCV.ContingencyPanelSet
    if (contingencyStatus == TC_PENDING) {
      return contingencyPanelSet.ContingenciesPendingLV._Entries
          .firstWhere(\e -> e.ContingencyTitle.Value == contingencyTitle and e.DueDate.DateValue == dueDate).ContingencyTitle.click()
    } else if (contingencyStatus == TC_RESOLVED or contingencyStatus == TC_WAIVED) {
      return contingencyPanelSet.ContingenciesResolvedWaivedLV._Entries
          .firstWhere(\e -> e.ContingencyTitle.Value == contingencyTitle and e.DueDate.DateValue == dueDate).ContingencyTitle.click()
    } else if (contingencyStatus == ContingencyStatus.TC_FAILED) {
      return contingencyPanelSet.ContingenciesFailedActionInitiatedLV._Entries
          .firstWhere(\e -> e.ContingencyTitle.Value == contingencyTitle and e.DueDate.DateValue == dueDate).ContingencyTitle.click()
    } else {
      throw new Exception("Contingengy Status unknown: ${contingencyStatus}}")
    }
  }

  function clickRewriteFullTerm() : pcftest.RewriteWizard {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.StartRewriteMenuItemSet.RewriteFullTerm.click() as pcftest.RewriteWizard
  }

  function clickRewriteNewTerm() : pcftest.RewriteWizard {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.StartRewriteMenuItemSet.RewriteNewTerm.click() as pcftest.RewriteWizard
  }

  function clickRewriteRemainderTerm() : pcftest.RewriteWizard {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_NewWorkOrder.StartRewriteMenuItemSet.RewriteRemainderOfTerm.click() as pcftest.RewriteWizard
  }

  function clickCreateNewNote() : pcftest.NewNoteWorksheet {
    return this.PolicyFileMenuActions.PolicyFileMenuActions_Create.PolicyFileMenuActions_NewNote.click()
  }

  function clickRewrite(rewriteType : RewriteType) : pcftest.RewriteWizard {
    switch (rewriteType) {
      case RewriteType.TC_REWRITEFULLTERM : return clickRewriteFullTerm()
      case RewriteType.TC_REWRITEREMAINDEROFTERM : return clickRewriteRemainderTerm()
      case RewriteType.TC_REWRITENEWTERM : return clickRewriteNewTerm()
      default: throw new IllegalArgumentException("Unknown type of Rewrite : " + rewriteType.Description)
    }
  }

  function startPolicyChange(date : Date) : pcftest.PolicyChangeWizard {
    var policyChange = goToStartPolicyChangePage()

    // set given date as policy change effective date; otherwise use default
    if(date != null)
      policyChange.EffectiveDateTime = date
    // click on Next button to go to Policy Info page
    var policyChangeWizard = policyChange.StartPolicyChangeScreen.NewPolicyChange.click() as pcftest.PolicyChangeWizard

    return policyChangeWizard
  }

}