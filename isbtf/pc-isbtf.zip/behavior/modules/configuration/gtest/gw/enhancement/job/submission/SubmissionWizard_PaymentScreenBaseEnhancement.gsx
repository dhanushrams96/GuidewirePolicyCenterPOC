package gw.enhancement.job.submission

uses gw.smoketest.platform.web.BooleanValueElement
uses gw.smoketest.platform.web.IteratorEntriesWithPaging
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.SelectElement

enhancement SubmissionWizard_PaymentScreenBaseEnhancement : pcftest.SubmissionWizard_PaymentScreen {

  public function setDirectBillWithDeposit(depositAmt : String) {
    this.BillingAdjustmentsPanelSet_Editable.BillingPanel.BillingMethod.getOptionByValue("DirectBill")
  }


  function bindOnly() {
    this.JobWizardBillingToolbarButtonSet_Submission.BindOptions.BindOnly.click()
  }

  function issue() : PCFLocation {
    return this.JobWizardBillingToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
  }

  function Withdraw() {
    this.JobWizardBillingToolbarButtonSet_Submission.CloseOptions.WithdrawJob.click()
  }

  function Decline() {
    this.JobWizardBillingToolbarButtonSet_Submission.CloseOptions.Decline.click()
  }

  function NotTaken() {
    this.JobWizardBillingToolbarButtonSet_Submission.CloseOptions.NotTakenJob.click()
  }

  function saveDraft() {
    this.JobWizardBillingToolbarButtonSet_Submission.Draft.click()
  }

  function editTransaction() {
    this.JobWizardBillingToolbarButtonSet_Submission.EditPolicy.click()
  }

  function startMultiVersion() {
    this.JobWizardBillingToolbarButtonSet_Submission.Versions.NewVersion.click()
  }

  function startSideBySide() {
    this.JobWizardBillingToolbarButtonSet_Submission.Versions.SideBySide.click()
  }

  function viewSideBySide() {
    this.JobWizardBillingToolbarButtonSet_Submission.Versions.ViewSideBySide.click()
  }

  property get BillingContactInput(): pcftest.AccountContactBillingInputSet {
    return this.BillingAdjustmentsPanelSet_Editable.BillingPanel.AccountContactBillingInputSet
  }

  property get AltBillingAccountInput(): pcftest.AccountContactBillingInputSet.AltBillingAccount {
    return this.BillingAdjustmentsPanelSet_Editable.BillingPanel.AccountContactBillingInputSet.AltBillingAccount
  }

  function searchAndSetAltBillingAccount(accountNumber : String) {
    var popup = AltBillingAccountInput.SearchBillingAccount.click()
    popup.searchAndSelectBillingAccountWith(accountNumber)
  }

  property get InvoiceStreams(): pcftest.InvoiceStreamsLV {
    return this.BillingAdjustmentsPanelSet_Editable.InvoiceStreams
  }

  property get EmptyInvoiceStreams(): pcftest.EmptyInvoiceStreamsLV {
    return this.BillingAdjustmentsPanelSet_Editable.OverridesAndPaymentsPanel.InvoicingInputSet.EmptyInvoiceStreams.EmptyInvoiceStreamsLV
  }

  property get PaymentPlans(): IteratorEntriesWithPaging<pcftest.BillingAdjustmentsInstallmentsLV.entry> {
    return this.BillingAdjustmentsPanelSet_Editable.PaymentPlans
  }

  property get BillingInvoiceStreamInputSet(): pcftest.BillingInvoiceStreamInputSet {
    return this.BillingAdjustmentsPanelSet_Editable.BillingInvoiceStreamInputSet
  }

  property get NewInvoicing(): BooleanValueElement {
    return this.BillingAdjustmentsPanelSet_Editable.NewInvoicing
  }

  property get BillingMethod(): SelectElement {
    return this.BillingAdjustmentsPanelSet_Editable.BillingPanel.BillingMethod
  }

  property get ChangeBillingContactButton(): pcftest.AccountContactBillingInputSet.ChangeBillingContactButton {
    return this.BillingContactInput.ChangeBillingContactButton
  }

}
