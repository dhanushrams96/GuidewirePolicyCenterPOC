package gw.enhancement.job.submission

uses gw.smoketest.platform.web.IteratorEntries
uses pcftest.CoverageSummaryLV
uses pcftest.PolicyLineSummaryPanelSet_HOPLine

class SubmissionWizardPolicyReviewScreenHOPMode {
  var _panelSet: PolicyLineSummaryPanelSet_HOPLine

  construct(panelSet: PolicyLineSummaryPanelSet_HOPLine) {
    _panelSet = panelSet
  }

  property get OptionalCoverages(): IteratorEntries<CoverageSummaryLV.entry> {
    return _panelSet.OptionalCoverageLV.CoverageSummaryLV._Entries
  }
}