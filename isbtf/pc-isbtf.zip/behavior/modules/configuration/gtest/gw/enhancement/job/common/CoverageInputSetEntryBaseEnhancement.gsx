package gw.enhancement.job.common

enhancement CoverageInputSetEntryBaseEnhancement : pcftest.CoverageInputSet_default.CovPatternInputGroup.entry {

  /**
   * Exposes the label of a cov term.
   */
  property get Label() : String {
    if(this.CovTermInputSet_bit.BooleanTermInput.Visible){
      return this.CovTermInputSet_bit.BooleanTermInput.Label
    } else if(this.CovTermInputSet_datetime.DateTimeTermInput.Visible){
      return this.CovTermInputSet_datetime.DateTimeTermInput.Label
    } else if(this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Visible){
      return this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Label
    } else if(this.CovTermInputSet_Option.OptionTermInput.Visible){
      return this.CovTermInputSet_Option.OptionTermInput.Label
    } else if(this.CovTermInputSet_Package.PackageTermInput.Visible){
      return this.CovTermInputSet_Package.PackageTermInput.Label
    } else if(this.CovTermInputSet_shorttext.StringTermInput.Visible){
      return this.CovTermInputSet_shorttext.StringTermInput.Label
    } else if(this.CovTermInputSet_Typekey.TypekeyTermInput.Visible){
      return this.CovTermInputSet_Typekey.TypekeyTermInput.Label
    } else {
      throw "Unable to find a visible child of this covterm input widget.  This may be because a new " +
            "type of covterm was added"
    }
  }

  /**
   * Exposes the value of a cov term.
   */
  property get Value() : String {
    if(this.CovTermInputSet_bit.BooleanTermInput.Visible){
      return this.CovTermInputSet_bit.BooleanTermInput.Value
    } else if(this.CovTermInputSet_datetime.DateTimeTermInput.Visible){
      return this.CovTermInputSet_datetime.DateTimeTermInput.Value
    } else if(this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Visible){
      return this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Value
    } else if(this.CovTermInputSet_Option.OptionTermInput.Visible){
      return this.CovTermInputSet_Option.OptionTermInput.Text
    } else if(this.CovTermInputSet_Package.PackageTermInput.Visible){
      return this.CovTermInputSet_Package.PackageTermInput.Text
    } else if(this.CovTermInputSet_shorttext.StringTermInput.Visible){
      return this.CovTermInputSet_shorttext.StringTermInput.Value
    } else if(this.CovTermInputSet_Typekey.TypekeyTermInput.Visible){
      return this.CovTermInputSet_Typekey.TypekeyTermInput.Value
    } else {
      throw "Unable to find a visible child of this covterm input widget.  This may be because a new " +
            "type of covterm was added"
    }
  }

  /**
   * Sets the label of a cov term, using coercion where appropriate. For options and packages,
   * pass in the label text.
   */
  property set Value( v : String ) {
    if(this.CovTermInputSet_bit.BooleanTermInput.Visible){
      this.CovTermInputSet_bit.BooleanTermInput.Value = v
    } else if(this.CovTermInputSet_datetime.DateTimeTermInput.Visible){
      this.CovTermInputSet_datetime.DateTimeTermInput.Value = v
    } else if(this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Visible){
      this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Value = v
    } else if(this.CovTermInputSet_Option.OptionTermInput.Visible){
      this.CovTermInputSet_Option.OptionTermInput.getOptionByLabel( v ).click()
    } else if(this.CovTermInputSet_Package.PackageTermInput.Visible){
      this.CovTermInputSet_Package.PackageTermInput.getOptionByLabel( v ).click()
    } else if(this.CovTermInputSet_shorttext.StringTermInput.Visible){
      this.CovTermInputSet_shorttext.StringTermInput.Value = v
    } else if(this.CovTermInputSet_Typekey.TypekeyTermInput.Visible){
      this.CovTermInputSet_Typekey.TypekeyTermInput.Value = v
    } else {
      throw "Unable to find a visible child of this covterm input widget.  This may be because a new " +
            "type of covterm was added"
    }
  }

  /**
   * Sets the label of a cov term, using coercion where appropriate. For options and packages,
   * pass in the label text.
   */
  property get Visible() : boolean {
    return this.CovTermInputSet_bit.BooleanTermInput.Visible or
           this.CovTermInputSet_datetime.DateTimeTermInput.Visible or
           this.CovTermInputSet_Direct.CovTermDirectInputSet.DirectTermInput.Visible or
           this.CovTermInputSet_Option.OptionTermInput.Visible or
           this.CovTermInputSet_Package.PackageTermInput.Visible or
           this.CovTermInputSet_shorttext.StringTermInput.Visible  or
           this.CovTermInputSet_Typekey.TypekeyTermInput.Visible
  }

}
