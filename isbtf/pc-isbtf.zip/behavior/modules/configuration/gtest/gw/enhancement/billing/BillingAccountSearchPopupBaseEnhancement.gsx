package gw.enhancement.billing

enhancement BillingAccountSearchPopupBaseEnhancement : pcftest.BillingAccountSearchPopup {

  function searchAndSelectBillingAccountWith(accountNumber: String) {
    this.AccountNumber.Value = accountNumber
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
    this._Entries.first().select()
  }

}
