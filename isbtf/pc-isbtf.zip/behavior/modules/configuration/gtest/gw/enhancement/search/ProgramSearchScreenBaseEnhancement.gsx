package gw.enhancement.search

uses gw.smoketest.platform.web.IteratorEntriesWithPaging

enhancement ProgramSearchScreenBaseEnhancement : pcftest.ProgramSearchScreen {

  function clearFields() {
    this.Name.Value = ""
    this.CoverageGroup.getOption(0).click()
    this.Status.getOption(0).click()
    this.EffectivePeriodInputSet.PeriodType.getOption(0).click()
  }

  function searchByName(programName : String) : IteratorEntriesWithPaging<pcftest.ProgramSearchResultsLV.entry> {
    clearFields()
    this.Name.Value = programName
    search()
    return Results
  }

  function searchByCoverage(coverage : String) : IteratorEntriesWithPaging<pcftest.ProgramSearchResultsLV.entry> {
    clearFields()
    this.CoverageGroup.Value = coverage
    search()
    return Results
  }

  function searchByStatus(status : String) : IteratorEntriesWithPaging<pcftest.ProgramSearchResultsLV.entry> {
    clearFields()
    this.Status.Value = status
    search()
    return Results
  }

  function searchByCustomDates(effDate : Date, expDate : Date) : IteratorEntriesWithPaging<pcftest.ProgramSearchResultsLV.entry> {
    var inputSet = this.EffectivePeriodInputSet
    clearFields()
    inputSet.PeriodType.TypeKeyValue = TC_CUSTOM
    inputSet.EffectiveDate.DateValue = effDate
    inputSet.ExpirationDate.DateValue = expDate
    search()
    return Results
  }

  // Used to find and go to a specific program
  function searchProgram(program : RIProgram) : pcftest.ProgramSearchResultsLV.entry {
    clearFields()
    this.Name.Value = program.Name
    this.Status.Value = program.Status.Code
    search()
    return Results.single()
  }

  private function search(){
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  property get Results() : IteratorEntriesWithPaging<pcftest.ProgramSearchResultsLV.entry> {
    return this.ProgramSearchResultsLV._Entries
  }

}
