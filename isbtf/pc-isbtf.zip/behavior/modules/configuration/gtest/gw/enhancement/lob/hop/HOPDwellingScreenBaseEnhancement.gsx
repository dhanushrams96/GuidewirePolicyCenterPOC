package gw.enhancement.lob.hop

uses gw.api.locale.DisplayKey
uses pcftest.LocationPopup
uses pcftest.NewAdditionalInterestPopup
uses pcftest.TerritoryCodeInputSet

enhancement HOPDwellingScreenBaseEnhancement : pcftest.HOPDwellingScreen {

  property get HOPDwellingHazardsInputSet() : pcftest.HOPDwellingHazardsInputSet {
    return this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingDetailsDV.HOPDwellingHazardsInputSet
  }

  property get HOPDwellingAnimalsInputSet() : pcftest.HOPDwellingAnimalsInputSet {
    return this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingDetailsDV.HOPDwellingAnimalsInputSet
  }

  property get HOPDwellingInputSet() : pcftest.HOPDwellingInputSet {
    return this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingDetailsDV.HOPDwellingInputSet
  }

  property get HOPDwellingProtectionInputSet() : pcftest.HOPDwellingProtectionInputSet {
    return this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingDetailsDV.HOPDwellingProtectionInputSet
  }

  function clickAutofillProtectionClass() {
    this.HOPDwellingProtectionInputSet.AutoFillProtClass.click()
  }

  function goToAdditionalInterestCardTab() {
    this.HOPDwellingPanelSet.HOPDwellingCV.AdditionalInterestCardTab.click()
  }

  function goToNewCompanyPopupOnAdditionalInterests() : NewAdditionalInterestPopup {
    var additionalInterestLV = this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingAdditionalInterestDetailsDV.AdditionalInterestLV_tb
    additionalInterestLV.AddContactsButton.click()
    var newCompanyAdditionalInsuredPopup = additionalInterestLV.AddContactsButton._Entries
        .firstWhere(\entry -> entry.ContactType.Text == DisplayKey.get("Web.ContactDetail.NewCompany"))
        .ContactType.click() as NewAdditionalInterestPopup
    return newCompanyAdditionalInsuredPopup
  }

  function clickOnNewDwellingLocation() : LocationPopup {
    return this.HOPDwellingInputSet.Location.NewDwellingLocation.click() as pcftest.LocationPopup
  }

  function getTerritoryCodeField() : TerritoryCodeInputSet.entry.TerritoryCode {
    return this.HOPDwellingPanelSet.HOPDwellingCV.HOPDwellingDetailsDV.HOPDwellingInputSet.TerritoryCodeInputSet._Entries.first().TerritoryCode
  }

  function addAnimal(animal : Map<String, String>) {
    HOPDwellingAnimalsInputSet.Add.click()
    var animalEntry = HOPDwellingAnimalsInputSet._Entries.last()
    animalEntry.AnimalType.getOptionByLabel(animal.get("Animal Type")).click()
    animalEntry.AnimalBreed.getOptionByLabel(animal.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBreed"))).click()
    animalEntry.AnimalBiteHistory.setValue(animal.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingAnimal.AnimalBiteHistory")))
  }

  function addHazard(givenFields : Map<String, String>) {
    HOPDwellingHazardsInputSet.Add.click()
    var hazardEntry = HOPDwellingHazardsInputSet._Entries.last()
    hazardEntry.SpecificHazard.getOptionByLabel(givenFields.get(DisplayKey.get("Web.Policy.HOP.HOPDwellingHazard.SpecificHazard"))).click()
    hazardEntry.HazardType.getOptionByLabel(givenFields.get("Hazard Type")).click()
    hazardEntry.AdditionalInformation.setValue(givenFields.get("Hazard Additional Information"))
  }
}