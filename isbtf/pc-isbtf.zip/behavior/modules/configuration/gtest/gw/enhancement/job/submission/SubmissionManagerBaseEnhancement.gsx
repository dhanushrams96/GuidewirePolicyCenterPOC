package gw.enhancement.job.submission

uses gw.smoketest.platform.web.IteratorEntries

enhancement SubmissionManagerBaseEnhancement : pcftest.SubmissionManager {

  property get SubmissionEntries() : IteratorEntries<pcftest.SubmissionManagerLV.entry> {
    return this.SubmissionManagerScreen.SubmissionManagerLV._Entries
  }

}
