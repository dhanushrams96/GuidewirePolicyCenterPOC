package gw.enhancement.job.common

uses gw.util.IssueRow
uses pcftest.Job_RiskAnalysisScreen

enhancement RiskAnalysisScreenBaseEnhancement : Job_RiskAnalysisScreen {
  property get BlockingIssues() : List<IssueRow> {
    return parseEntries().where(\row -> row.Title.contains("Blocking"))
  }

  property get ApprovedIssues() : List<IssueRow> {
    return parseEntries().where(\row -> row.Title == "Already Approved")
  }

  property get BlockingAndApprovedIssues() : List<IssueRow> {
    var issues = ApprovedIssues
    issues.addAll(BlockingIssues)
    return issues
  }

  function selectViewIssuesBlocking(option : String) {
    this.RiskAnalysisCV.RiskEvaluationPanelSet.UserViewFilter.getOptionByLabel(option).click()
  }

  function parseEntries() : List<IssueRow> {
    var issueRows : List<IssueRow> = {}
    var currentTitle : String
    this.IssueEntries.each(\entry -> {
      // Entry rows will either be a Title or the Issue's content
      var titleText = entry.UWIssueRowSet_label.testTitle.Text
      if (titleText.NotBlank) {
        currentTitle = titleText
      } else {
        var issueRow = new IssueRow()
        issueRow.Title = currentTitle
        issueRow.ShortDescription = entry.UWIssueRowSet_issue.ShortDescription.Text
        issueRow.ApproveVisible = entry.UWIssueRowSet_issue.Approve.Visible
        issueRow.RejectVisible = entry.UWIssueRowSet_issue.Reject.Visible
        issueRow.ReopenVisible = entry.UWIssueRowSet_issue.Reopen.Visible
        issueRows.add(issueRow)
      }
    })
    return issueRows
  }

  function approveUWIssue(shortDescription : String) {
    var issueToApprove = this.IssueEntries.firstWhere(\issueRow ->
        issueRow.UWIssueRowSet_issue.ShortDescription.Text == shortDescription
    )
    if (issueToApprove == null) {
      throw new NoSuchElementException("Issue Entry " + shortDescription + " is not found.")
    }
    if (not issueToApprove.UWIssueRowSet_issue.Approve.Visible or not issueToApprove.UWIssueRowSet_issue.Approve.Enabled) {
      throw new IllegalStateException("Issue Entry " + shortDescription + " cannot be approved.")
    }
    var approvalPopup = issueToApprove.UWIssueRowSet_issue.Approve.click()
    approvalPopup.Update.click()
  }

  function approveUWIssue(shortDescription : String, validUntil : String) {
    var issueToApprove = this.IssueEntries.firstWhere(\issueRow ->
        issueRow.UWIssueRowSet_issue.ShortDescription.Text == shortDescription
    )
    if (issueToApprove == null) {
      throw new NoSuchElementException("Issue Entry " + shortDescription + " is not found.")
    }
    if (not issueToApprove.UWIssueRowSet_issue.Approve.Visible or not issueToApprove.UWIssueRowSet_issue.Approve.Enabled) {
      throw new IllegalStateException("Issue Entry " + shortDescription + " cannot be approved.")
    }
    var approvalPopup = issueToApprove.UWIssueRowSet_issue.Approve.click()
    approvalPopup._Entries[0].IssueDetailsDV.UWApproval.UWApprovalLV.Duration.Value = validUntil
    approvalPopup.Update.click()
  }

  property get OOSConflictWarnings() : String[] {
    return this.OOSEPanelSet.WarningsPanelSet._Entries*.PanelSet*.Warning*.Text
  }

  function clickAddContingency(): pcftest.NewContingencyPopup {
    return this.RiskAnalysisCV_tb.AddNewContingencyButton.click()
  }

  function goToContingencyCard() {
    this.RiskAnalysisCV.ContingenciesCardTab.click()
  }

}