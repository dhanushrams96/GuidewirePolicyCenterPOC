package gw.enhancement.account

uses gw.api.locale.DisplayKey
uses gw.smoketest.pc.account.AccountContactCVCompanyMode
uses gw.smoketest.pc.account.AccountContactCVPersonMode
uses org.junit.Assert
uses pcftest.AccountFile_Contacts
uses pcftest.ChangeAccountHolderMenuItemSet

enhancement AccountFile_ContactsBaseEnhancement : pcftest.AccountFile_Contacts {

  property get PersonMode() : AccountContactCVPersonMode {
    return new AccountContactCVPersonMode(this.AccountFile_ContactsScreen.AccountContactCV)
  }
  
  property get CompanyMode() : AccountContactCVCompanyMode {
    return new AccountContactCVCompanyMode(this.AccountFile_ContactsScreen.AccountContactCV)
  }

  property get ContactsLV() : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV {
    return this.AccountFile_ContactsScreen.AccountContactsLV
  }
  
  property get createNewContactButton() : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton {
    return this.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton
  }
  
  property get removeContactButton() : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV_tb.removeContact {
    return this.AccountFile_ContactsScreen.AccountContactsLV_tb.removeContact
  }
  
  function hasContactWithRole(contact:String, role: String): boolean {
    var rows = ContactsLV._Entries.where( \ row -> row.Name.Text == contact and row.Roles.Text.contains(role) )
    Assert.assertTrue("This test is ND; use unique contact names", rows.Count < 2)
    if (rows.Count == 1){
      return true
    }
    return false
  }

  function getContact(contactName : String) : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV.entry {
    return ContactsLV._Entries.firstWhere( \ row -> row.Name.Text == contactName )
  }

  function viewContactDetail(contactName : String) : pcftest.AccountContactDV {
    ContactsLV._Entries.singleWhere( \ row -> row.Name.Text == contactName ).viewDetail()
    return this.AccountFile_ContactsScreen.AccountContactCV.AccountContactDV
  }
      
  property set RoleFilter(role: String) {
    this.AccountFile_ContactsScreen.AccountContactsLV.roleFilters.getOptionByLabel( role ).click()
  }
  
  property set ContactFilter(contactType: String) {
    this.AccountFile_ContactsScreen.AccountContactsLV.personCompanyFilters.getOptionByLabel( contactType ).click()
  }

  /**
   * Get one of the menu items from the "Create New Contact" button
   * (e.g., Create New Contact:Accounting Contact:New Company).  It throws an IllegalStateException if
   * the expected contactRole/contactType doesn't exist.
   * 
   * @param contactRole the contactRole menu item to get (e.g., Accounting Contact, Additional Insured, etc).
   * Throws an IllegalStateException if the contactRole doesn't exist in the menu item list.
   * 
   * @param the contactType menu item to get (i.e., New Company, New Person).
   * Throws an IllegalStateException if the contactType doesn't exist in the menu item list.
   */
  function getCreateNewContactMenuItem(contactRole : String, contactType : ContactType) : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton.entry.roleType.entry2 {
    var roleMenuItem = createNewContactButton._Entries.singleWhere(\ item -> item.roleType.Text == contactRole)
    return roleMenuItem.roleType._Entries.singleWhere(\ item -> item.contactType.Text == DisplayKey.get("Web.Contact.AddNewOfType", contactType))
  }

  function removeItemWithCode(contactCode : String) {
    var n1 = ContactsLV._Entries.size()
    var contact = ContactsLV._Entries.firstWhere( \ item -> item.Email.Value.contains( contactCode ))
    var removed = false
    if (contact != null) {
      contact._Checkbox.click()
      removed = true
    }
    removeContactButton.click()

    var n2 = ContactsLV._Entries.size()
    Assert.assertTrue(not removed or n1 >= 14 or (n1 - n2) == 1)
  }

  function editAccountContact(contactName:String): pcftest.EditAccountContactPopup{
    return ContactsLV._Entries.firstWhere(\a->a.Name.Text == contactName).EditButton.click()
  }

  function removeAccountContact(contactName:String) {
    ContactsLV._Entries.firstWhere(\a->a.Name.Text == contactName)._Checkbox.click()
    removeContactButton.click()
  }

  function getAddAccountContactMenuItem(accountContactRoleType : Type<AccountContactRole>)
          : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton.entry {
    var roleText = accountContactRoleType.TypeInfo.DisplayName
    var addRoleMenuItems = this.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton._Entries
    var addRoleMenuItem = addRoleMenuItems.firstWhere(\ menuItem -> menuItem.roleType.Text == roleText)
    return addRoleMenuItem
  }

  function getAddAccountContactSubMenuItem(accountContactRoleType : Type<AccountContactRole>, contactType : ContactType)
          : pcftest.AccountFile_Contacts.AccountFile_ContactsScreen.AccountContactsLV_tb.addContactButton.entry.roleType.entry2 {
    var contactText = DisplayKey.get("Web.Contact.AddNewOfType", contactType)
    var roleMenuItem = getAddAccountContactMenuItem(accountContactRoleType)
    var addContactMenuItems = roleMenuItem.roleType._Entries
    var addContactMenuItem = addContactMenuItems.firstWhere(\ menuItem -> menuItem.contactType.Text == contactText)
    return addContactMenuItem
  }

  function addAccountContact(accountContactRoleType : Type<AccountContactRole>, contactType : ContactType) : pcftest.NewAccountContactPopup {
    var menuItem = getAddAccountContactSubMenuItem(accountContactRoleType, contactType)
    return menuItem.contactType.click()
  }

  property get PreferredSettlementCurrency() : pcftest.ContactCurrencyInputSet.PreferredSettlementCurrency {
    return this.AccountFile_ContactsScreen.AccountContactCV.AccountContactDV.ContactCurrency.ContactCurrencyInputSet.PreferredSettlementCurrency
  }

  function changeAccountHolderTo(displayName : String) {
    var entry = changeAccountHolderExistingContactEntry(displayName)
    Assert.assertNotNull("did not find a contact with name: " + displayName, entry)
    entry.click()
  }

  function changeAccountHolderExistingContactEntry(displayName: String) : ChangeAccountHolderMenuItemSet.entry.UnassignedContact {
    return this.ChangeAccountHolder.ChangeAccountHolderMenuItemSet._Entries.firstWhere(\ a -> a.UnassignedContact.Text == displayName).UnassignedContact
  }

  property get ChangeAccountHolder() : AccountFile_Contacts.AccountFile_ContactsScreen.ChangeAccountHolder {
    var menu = this.AccountFile_ContactsScreen.ChangeAccountHolder
    if (menu.Visible) {
      menu.click()
    }
    return menu
  }

  property get ChangeAccountHolderToNewPerson() : ChangeAccountHolderMenuItemSet.ChangeToPerson {
    return this.ChangeAccountHolder.ChangeAccountHolderMenuItemSet.ChangeToPerson
  }

  property get ChangeAccountHolderToNewCompany() : ChangeAccountHolderMenuItemSet.ChangeToCompany {
    return this.ChangeAccountHolder.ChangeAccountHolderMenuItemSet.ChangeToCompany
  }

  property get ChangeAccountHolderSearchAB() : ChangeAccountHolderMenuItemSet.Search {
    return this.ChangeAccountHolder.ChangeAccountHolderMenuItemSet.Search
  }

}
