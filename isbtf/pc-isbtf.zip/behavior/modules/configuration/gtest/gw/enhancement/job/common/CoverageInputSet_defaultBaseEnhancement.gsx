package gw.enhancement.job.common
uses gw.api.productmodel.CovTermPatternLookup

enhancement CoverageInputSet_defaultBaseEnhancement : pcftest.CoverageInputSet_default {

  /**
   * Indicates whether coverage is selected.
   */
  property get SelectedValue() : boolean {
    return this.CovPatternInputGroup._checkbox.BoolValue
  }

  /**
   * Selects coverage.
   */
  property set SelectedValue( v : boolean ) {
    this.CovPatternInputGroup._checkbox.BoolValue = v
  }

  /**
  * Gets the value of a coverage term by label
  */
  function getCovTermByLabel( label : String) : pcftest.CoverageInputSet_default.CovPatternInputGroup.entry {
    return this.CovPatternInputGroup._Entries.firstWhere( \ term -> term.Label == label )
  }
  
  /**
   * Gets a coverage term by its pattern code
   */
  function getCovTermByCode(code : String) : pcftest.CoverageInputSet_default.CovPatternInputGroup.entry {
    var covTermName = CovTermPatternLookup.getByPublicID(code).Name
    return getCovTermByLabel(covTermName)
  }
  
  function selectCheckBox() {
    this.CovPatternInputGroup._checkbox.click()
  }

}
