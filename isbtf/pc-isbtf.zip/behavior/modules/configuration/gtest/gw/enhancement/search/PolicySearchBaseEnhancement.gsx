package gw.enhancement.search

uses gw.policy.PolicyPeriodSearchCriteria
uses gw.smoketest.platform.web.OptionElement
uses gw.smoketest.platform.web.ValueElement
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.DateElement
uses gw.smoketest.platform.web.CheckboxValueElement
uses pcftest.DatabasePolicySearchPanelSet

enhancement PolicySearchBaseEnhancement : pcftest.PolicySearch {

  property get SearchDV() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV
  }

  property get SolrDV() : pcftest.SolrPolicySearchPanelSet {
    return this.PolicySearchScreen.SolrPolicySearchPanelSet
  }

  property get PolicySearch_ResultsLV() : pcftest.PolicySearch_ResultsLV {
    return PolicySearch_ResultsLV
  }

  /**
   * Label: "Source"<br>
   * Type: java.lang.Boolean
   * The label is misleading, but this is really for if we include archived periods or not.
   */
  property get IncludeArchived() : SelectElement<OptionElement> {
    return this.PolicySearchScreen.DataBaseSearchDV.IncludeArchived
  }

  /**
   * Label: "Search For"<br>
   * Type: SearchObjectType<br>
   */
  property get SearchFor() : SelectElement {
    return this.PolicySearchScreen.DataBaseSearchDV.SearchFor
  }

  /**
   * Label: "First Name"<br>
   * Type: String<br>
   */
  property get FirstName() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalPersonNameInputSet_default.FirstName
  }

  /**
   * Kanji-specific fields, exposed through locale settings
   */
  property get KanjiFields() : pcftest.GlobalPersonNameInputSet_Japan {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalPersonNameInputSet_Japan
  }

  /**
   * Kanji-specific company fields, exposed through locale settings
   */
  property get KanjiCompanyFields() : pcftest.GlobalContactNameInputSet_Japan { return
      this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalContactNameInputSet_Japan
  }

  /**
   * Label: "Country"<br>
   * Type: String<br>
   */
  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.AddressOwnerAddressInputSet.Country
  }

  /**
   * Label: "City"<br>
   * Type: String<br>
   */
  property get City() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.AddressOwnerAddressInputSet.City
  }

  /**
   * Label: "PostalCode"<br>
   * Type: String<br>
   */
  property get PostalCode() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.AddressOwnerAddressInputSet.globalAddressContainer.GlobalAddressInputSet_default.PostalCode
  }


  /**
   * Label: "PostalCode"<br>
   * Type: String<br>
   */
  property get Phone() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.Phone
  }

  /**
   * Label: "Last Name"<br>
   * Type: String<br>
   */
  property get LastName() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalPersonNameInputSet_default.LastName
  }

  /**
   * Label: "Particle"<br>
   * Type: String<br>
   */
  property get Particle() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalPersonNameInputSet_default.Particle
  }

  /**
   * Label: "Company Name"<br>
   * Type: String<br>
   */
  property get CompanyName() : ValueElement {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearchDV.GlobalContactNameInputSet_default.Name
  }

  /**
   * Label: "Official ID"<br>
   * Type: String<br>
   */
  property get TaxID() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.TaxID
  }

  /**
   * Label: "Account Number"<br>
   * Type: String<br>
   */
  property get AccountNumber() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AccountNumber
  }

  property get PolicyNumber() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.PolicyNumberCriterion
  }

  /**
   * Label: "Submission Number"<br>
   * Type: String<br>
   */
  property get SubmissionNumber() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.SubmissionNumber
  }

  /**
   * Label: "Assigned Risk"<br>
   * Type: Boolean<br>
   */
  property get AssignedRisk() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AssignedRisk
  }

  /**
   * Label: "Underwriting Company"<br>
   * Type: UWCompany<br>
   */
  property get UWCompany() : SelectElement {
    return this.PolicySearchScreen.DataBaseSearchDV.UWCompany
  }

  /**
   * Label: "Declination Reason"<br>
   * Type: ReasonCode<br>
   */
  property get RejectReason() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.RejectReason {
    return this.PolicySearchScreen.DataBaseSearchDV.RejectReason
  }

  /**
   * Label: "Non Renewal Code"<br>
   * Type: NonRenewalCode<br>
   */
  property get NonRenewalCode() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.NonRenewalCode {
    return this.PolicySearchScreen.DataBaseSearchDV.NonRenewalCode
  }

  /**
   * Label: "Audit Method"<br>
   * Type: AuditMethod<br>
   */
  property get AuditMethod() : DatabasePolicySearchPanelSet.PolicySearchDV.AuditMethod {
    return this.PolicySearchScreen.DataBaseSearchDV.AuditMethod
  }

  /**
   * Label: "Product"<br>
   * Type: Product<br>
   */
  property get ProductName() : SelectElement {
    return this.PolicySearchScreen.DataBaseSearchDV.ProductName
  }

  /**
   * Label: "State"<br>
   * Type: State<br>
   */
  property get State() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.State {
    return this.PolicySearchScreen.DataBaseSearchDV.State
  }

  /**
   * Label: "Producer"<br>
   * Type: Organization<br>
   */
  property get Producer() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.Producer {
    return this.PolicySearchScreen.DataBaseSearchDV.Producer
  }

  /**
   * Label: "Producer Code"<br>
   * Type: Object<br>
   */
  property get ProducerCode() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.ProducerCode {
    return this.PolicySearchScreen.DataBaseSearchDV.ProducerCode
  }

  /**
   * Label: "Date Field to Search"<br>
   * Type: DateFieldsToSearchType<br>
   */
  property get DateFieldToSearchType() : SelectElement {
    return this.PolicySearchScreen.DataBaseSearchDV.DateFieldToSearchType
  }

  /**
   * Label: "Search by Date"<br>
   * Type: DateCriteria<br>
   */
  property get DateRangeForJobSearch() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV.DateRangeForJobSearch {
    return this.PolicySearchScreen.DataBaseSearchDV.DateRangeForJobSearch
  }

  /**
   * Label: "As of Date"<br>
   * Type: Date<br>
   */
  property get AsOfDate() : DateElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AsOfDate
  }

  /**
   * Label: "First Name Exact"<br>
   * Type: String<br>
   */
  property get FirstNameExact() : CheckboxValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.FirstNameExact
  }

  /**
   * Label: "Last Name Exact"<br>
   * Type: String<br>
   */
  property get LastNameExact() : CheckboxValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.LastNameExact
  }

  /**
   * Label: "Company Name Exact"<br>
   * Type: String<br>
   */
  property get CompanyNameExact() : CheckboxValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.CompanyNameExact
  }

  property get PNICity() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AddressOwnerAddressInputSet.globalAddressContainer.GlobalAddressInputSet_default.City
  }

  property get PNICityKanji() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AddressOwnerAddressInputSet.globalAddressContainer.GlobalAddressInputSet_BigToSmall.CityKanji
  }

  property get PNIState() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AddressOwnerAddressInputSet.globalAddressContainer.GlobalAddressInputSet_default.State
  }

  property get PNIPostalCode() : ValueElement {
    return this.PolicySearchScreen.DataBaseSearchDV.AddressOwnerAddressInputSet.globalAddressContainer.GlobalAddressInputSet_default.PostalCode
  }

  property get PolicySearchResultsLV_Submission() : pcftest.PolicySearch_ResultsLV_Submission {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Submission
  }

  property get PolicySearchResultsLV_Policy() : pcftest.PolicySearch_ResultsLV_Policy {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Policy
  }

  property get PolicySearchResultsLV_PolicyChange() : pcftest.PolicySearch_ResultsLV_PolicyChange {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_PolicyChange
  }

  property get PolicySearchResultsLV_RewriteNewAccount() : pcftest.PolicySearch_ResultsLV_RewriteNewAccount {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_RewriteNewAccount
  }

  property get PolicySearchResultsLV_Renewal() : pcftest.PolicySearch_ResultsLV_Renewal {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Renewal
  }

  property get PolicySearchResultsLV_Audit() : pcftest.PolicySearch_ResultsLV_Audit {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Audit
  }

  property get SearchButton() : pcftest.SearchLinksInputSet.Search {
    return this.PolicySearchScreen.DataBaseSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search
  }

  property get ResetButton() : pcftest.SearchLinksInputSet.Reset {
    return this.PolicySearchScreen.DataBaseSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset
  }

  property get PolicyResults () : pcftest.PolicySearch_ResultsLV_Policy {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Policy
  }

  property get CancellationResults () : pcftest.PolicySearch_ResultsLV_Cancellation {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Cancellation
  }

  property get RenewalResults () : pcftest.PolicySearch_ResultsLV_Renewal {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Renewal
  }

  property get RewriteNewAccountResults () : pcftest.PolicySearch_ResultsLV_RewriteNewAccount {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_RewriteNewAccount
  }

  property get SubmissionResults () : pcftest.PolicySearch_ResultsLV_Submission {
    return this.PolicySearchScreen.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Submission
  }

  function clickSelectProducer() : pcftest.OrganizationSearchPopup {
    return this.Producer.SelectOrganization.click()
  }

  function clickSelectProducerCode() : pcftest.ProducerCodeSearchPopup {
    return this.ProducerCode.SelectProducerCode.click()
  }

  function clickSearchButton() : gw.smoketest.platform.web.PCFLocation {
    return SearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  function clickResetButton() : gw.smoketest.platform.web.PCFLocation {
    return SearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
  }

  function searchForSubmission() : pcftest.PolicySearch {
    this.clickResetButton()
    this.SearchFor.Value = PolicyPeriodSearchCriteria.PolicyPeriodSearchType.Submission.toString()
    return this
  }

  function searchForPolicy() : pcftest.PolicySearch {
    this.clickResetButton()
    this.SearchFor.Value = PolicyPeriodSearchCriteria.PolicyPeriodSearchType.Policy.toString()
    return this
  }

  function searchForRewriteNewAccount() : pcftest.PolicySearch {
    this.clickResetButton()
    this.SearchFor.Value = PolicyPeriodSearchCriteria.PolicyPeriodSearchType.RewriteNewAccount.toString()
    return this
  }

  function findSubmissionRow(criteria : block(entry : pcftest.PolicySearch_ResultsLV_Submission.entry) : boolean ) : pcftest.PolicySearch_ResultsLV_Submission.entry {
    var listPaging = this.PolicySearchResultsLV_Submission._ListPaging.Visible
    var listPageCount = listPaging ? this.PolicySearchResultsLV_Submission._ListPaging.NumOptions : 1
    for ( page in 0..|listPageCount ) {
      if ( listPaging ) {
        this.PolicySearchResultsLV_Submission._ListPaging.Value = ( page + 1 ) as String
      }
      var result = this.PolicySearchResultsLV_Submission._Entries.firstWhere( criteria )
      if ( result != null ) {
        return result
      }
    }
    return null
  }

}
