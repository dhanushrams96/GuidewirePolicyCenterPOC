package gw.enhancement.job.submission

uses gw.smoketest.pc.lob.wc.submission.SubmissionWizardWCMode
uses gw.smoketest.platform.web.IteratorEntries
uses gw.smoketest.platform.web.PCFLocation
uses pcftest.*

enhancement SubmissionWizardTestEnhancement : pcftest.SubmissionWizard {

  property get SideBySidePaymentPlans() : IteratorEntries<pcftest.SideBySideTableLayoutDV.offeringPeriodInfoIterator.entry> {
    return this.SideBySidePage.SideBySideScreen.SideBySideTableLayoutDV.offeringPeriodInfoIterator._Entries
  }

  property get PolicyPeriodSelector() : MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return this.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get FormLabels() : String[] {
    var forms = this.Forms.click()
    return forms.FormsDV.FormsLV._Entries*.FormNumber*.Text
  }

  property get SideBySide() : JobWizardToolbarButtonSet_Submission.Versions.SideBySide {
    var policyReviewStep = this.PolicyReview.click()
    return policyReviewStep.JobWizardToolbarButtonSet_Submission.Versions.SideBySide
  }

  function clickQuote() : PCFLocation {
    var policyReviewScreen = this.PolicyReview.click()
    return policyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
  }

  property get FirstPaymentPlanAvailable() : BillingAdjustmentsInstallmentsLV.entry.InstallmentPlan {
    var paymentStep = this.BillingInfo.click()
    return paymentStep.BillingAdjustmentsPanelSet_Editable.BillingAdjustmentsInstallmentsLV._Entries[0].InstallmentPlan
  }

  function clickMultiVersionOptionWithMatchingLabel(containedString : String) {
    this.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector.PolicyPeriodSelector_Arg.clickFirstOptionWithMatchingLabel(\ label -> label.contains(containedString))
  }

  property get PolicyInfo() : SubmissionWizard.LOBWizardStepGroup.PolicyInfo {
    return this.LOBWizardStepGroup.PolicyInfo
  }

  property get WCMode() : SubmissionWizardWCMode {
    return new SubmissionWizardWCMode(this)
  }

}
