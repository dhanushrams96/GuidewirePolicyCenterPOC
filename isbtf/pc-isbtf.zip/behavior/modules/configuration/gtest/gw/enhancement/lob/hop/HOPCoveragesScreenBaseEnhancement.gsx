package gw.enhancement.lob.hop

uses gw.smoketest.platform.web.CheckboxValueElement
uses gw.smoketest.platform.web.PCFElement
uses pcftest.CoverageInputSet_default
uses pcftest.HOPCoveragesScreen
uses pcftest.HOPOptionalCoveragesPanelSet
uses pcftest.ScheduleInputSet_true

enhancement HOPCoveragesScreenBaseEnhancement : HOPCoveragesScreen {

  function clickOnOptionalCoveragesTab(){
    this.HOPOptionalCoveragesTab.click()
  }

  property get HOPSchedPropCovInput() : CoverageInputSet_default {
    return this.HOPOptionalCoveragesPanelSet.liabilityCoveragePatternIterator._Entries
        .firstWhere(\entry -> entry.CoverageInputSet_default.CovPatternDisplayName.Text == "Scheduled Personal Property")
        .CoverageInputSet_default
  }

  property get HOPSchedPropCovCheckBox() : CheckboxValueElement {
    return HOPSchedPropCovInput.CovPatternInputGroup._checkbox
  }

  function selectOptionalCoverage(){
    if(HOPSchedPropCovCheckBox.BoolValue != true){
      HOPSchedPropCovCheckBox.BoolValue = Boolean.TRUE
    }
  }

  function addNewRowForSceduledPersonalProperty(){
    HOPSchedPropCovInput.CovPatternInputGroup.ScheduleInputSet_true.getAdd().click()
  }

  function addScheduledPersonalPropertyCoverageWith(coverageTerms : Map<String, String>){
    clickOnOptionalCoveragesTab()
    selectOptionalCoverage()
    fillScheduledPersonalPropertyInformation(coverageTerms)
  }

  function fillScheduledPersonalPropertyInformation(coverageTerms : Map<String, String>){
    addNewRowForSceduledPersonalProperty()
    var scheduledPersonalPropertyCoverageLastEntry = HOPSchedPropCovInput.CovPatternInputGroup.ScheduleInputSet_true.ScheduledItemsIterator._Entries.last()

    var cellMap = scheduledPersonalPropertyCoverageLastEntry.PropertyValues._Entries.mapToKeyAndValue(\entry -> entry.Id, \entry -> entry as PCFElement)

    cellMap.putAll(scheduledPersonalPropertyCoverageLastEntry.CovTermValues._Entries.mapToKeyAndValue(\entry -> entry.Id, \entry -> entry))

    for (keyValuePair in coverageTerms.entrySet()){
      for(cellMapKey in cellMap.Keys){
        if(setValueOnRowCell(cellMap.get(cellMapKey), keyValuePair.Key, keyValuePair.Value)){
          cellMap.remove(cellMapKey)
          break
        }
      }
    }
  }

  private function setValueOnRowCell(field : PCFElement, key : String, value : String) : Boolean{
    if(field typeis ScheduleInputSet_true.ScheduledItemsIterator.entry.PropertyValues.entry2){
      return setValueOnRowCell(field, key, value)
    }

    return setValueOnRowCell(field as ScheduleInputSet_true.ScheduledItemsIterator.entry.CovTermValues.entry2, key, value)
  }

  private function setValueOnRowCell(field : ScheduleInputSet_true.ScheduledItemsIterator.entry.PropertyValues.entry2, key : String, value : String) : Boolean {
    var success = true
    if(field.ScheduledItemColumnInput_String.StringValue.Visible and field.ScheduledItemColumnInput_String.StringValue.Label == key) {
      field.ScheduledItemColumnInput_String.StringValue.setValue(value)
      return success
    } else if (field.ScheduledItemColumnInput_TypeKey.RangeValue.Visible and field.ScheduledItemColumnInput_TypeKey.RangeValue.Label == key){
      field.ScheduledItemColumnInput_TypeKey.RangeValue.getOptionByLabel(value).click()
      return success
    }
    else if(field.ScheduledItemColumnInput_Date.DateValue.Visible and field.ScheduledItemColumnInput_Date.DateValue.Label == key) {
      field.ScheduledItemColumnInput_Date.DateValue.setValue(value)
    }

    return false
  }

  private function setValueOnRowCell(field : ScheduleInputSet_true.ScheduledItemsIterator.entry.CovTermValues.entry2, key : String,  value : String) : Boolean {
    var success = true
    if(field.ScheduledItemCovTermInput_Typekey.TermValue.Visible and field.ScheduledItemCovTermInput_Typekey.TermValue.Label == key) {
      field.ScheduledItemCovTermInput_Typekey.TermValue.getOptionByLabel(value).click()
      return success
    } else if (field.ScheduledItemCovTermInput_Direct.DirectTermInput.Visible and field.ScheduledItemCovTermInput_Direct.DirectTermInput.Label == key){
      field.ScheduledItemCovTermInput_Direct.DirectTermInput.setValue(value)
      return success
    }

    return false
  }

  property get HOPScheduledPersonalPropertyInput() : CoverageInputSet_default {
    return this.HOPOptionalCoveragesPanelSet.liabilityCoveragePatternIterator._Entries
        .firstWhere(\entry -> entry.CoverageInputSet_default.CovPatternDisplayName.Text == "Scheduled Personal Property")
        .CoverageInputSet_default
  }

  property get HOPScheduledPersonalPropertyCheckBox() : CheckboxValueElement {
    return HOPScheduledPersonalPropertyInput.CovPatternInputGroup._checkbox
  }
}