package gw.enhancement.desktop

uses entity.Contact
uses entity.RIAgreement
uses gw.policy.PolicyPeriodSearchCriteria
uses gw.smoketest.platform.web.IteratorEntriesWithPaging
uses gw.smoketest.platform.web.PCFLocation
uses gw.testharness.ISmokeTestHelper
uses org.junit.Assert
uses pcftest.*
uses typekey.Job

enhancement PCTabBarBaseEnhancement : pcftest.TabBar {

  /**
   * Navigate to the Account File for the Account with the given number
   *
   * @FROM any page with the standard TabBar
   * @TO the AccountFile_Summary
   */
  public function goToAccountFileSummary(accountNumber: String) : AccountFile_Summary {
    this.AccountTab.AccountTab_AccountNumberSearchItem.Value = accountNumber
    var page = this.AccountTab.AccountTab_AccountNumberSearchItem_Button.click()
    return page as AccountFile_Summary
  }

  /**
   * Navigate to the Submission with the given number
   *
   * @FROM any page with the standard TabBar
   * @TO the SubmissionWizard PreQual page
   */
  function goToSubmission(submissionNumber : String) : pcftest.SubmissionWizard {
    return searchForSubmissionNumberAndClickSearch(submissionNumber) as pcftest.SubmissionWizard
  }

  function goToSubmission(policyPeriod : PolicyPeriod) : pcftest.SubmissionWizard {
    return searchForSubmissionNumberAndClickSearch(policyPeriod.Submission.JobNumber) as pcftest.SubmissionWizard
  }

  function goToQuickSubmission(policyPeriod : PolicyPeriod) : pcftest.QuickSubmissionWizard {
    return searchForSubmissionNumberAndClickSearch(policyPeriod.Submission.JobNumber) as pcftest.QuickSubmissionWizard
  }

  function goToQuickSubmission(submissionNumber : String) : pcftest.QuickSubmissionWizard {
    return searchForSubmissionNumberAndClickSearch(submissionNumber) as pcftest.QuickSubmissionWizard
  }

  function goToAnySubmission(submissionNumber : String) : gw.smoketest.platform.web.PCFLocation {
    return searchForSubmissionNumberAndClickSearch(submissionNumber)
  }

  private function searchForSubmissionNumberAndClickSearch(submissionNumber : String) : gw.smoketest.platform.web.PCFLocation {
    this.PolicyTab.PolicyTab_SubmissionNumberSearchItem.Value = submissionNumber
    return this.PolicyTab.PolicyTab_SubmissionNumberSearchItem_Button.click()
  }

  function goToTransaction(jobNumber : String) : PCFLocation {
    this.PolicyTab.PolicyTab_SubmissionNumberSearchItem.Value = jobNumber
    return this.PolicyTab.PolicyTab_SubmissionNumberSearchItem_Button.click()
  }

  function clickRecentContactEntryInContactTab(contact : Contact) : PCFLocation {
    return this.ContactTab._Entries*.ContactMenuContact.singleWhere(\c -> c.Text == contact.DisplayName).click()
  }

  function clickRecentContactEntryInContactTabByIndex(i : int) : PCFLocation {
    return this.ContactTab._Entries[i].ContactMenuContact.click()
  }

  function clickRecentAccountEntryInAccountTab(accountDisplayName : String) : PCFLocation {
    return this.AccountTab._Entries*.accountItem.singleWhere(\ c -> c.Text.startsWith(accountDisplayName)).click()
  }

  function clickRecentPolicyEntryInPolicyTab(policyNumber : String) : PCFLocation {
    return this.PolicyTab._Entries*.PolicyMenuPolicy.singleWhere(\ c -> c.Text.startsWith(policyNumber)).click()
  }

  function goToPersonThroughSearchTab(firstName : String, lastName : String, ssn : String) : ContactFile_Details {
    var searchScreen = this.SearchTab.Search_ContactSearch.click()
    searchScreen.ContactSearchScreen.searchPersonFromNameAndSSN(firstName, lastName, ssn)
    return findDetails(searchScreen.ContactSearchScreen.ContactSearchResultsLV._Entries.first().Name.click())
  }

  private function findDetails(location : PCFLocation): ContactFile_Details {
    return location.getOrCreateProperty("_parent", pcftest.ContactFile).MenuLinks.ContactFile_ContactFile_Details.click()
  }

  function goToCompanyThroughSearchTab(companyName : String) : ContactFile_Details {
    var searchScreen = this.SearchTab.Search_ContactSearch.click()
    searchScreen.ContactSearchScreen.searchCompanyFromName(companyName)
    return findDetails(searchScreen.ContactSearchScreen.ContactSearchResultsLV._Entries.first().Name.click())
  }

  function goToCompanyThroughSearchTab(companyName : String, fein : String) : ContactFile_Details {
    var searchScreen = this.SearchTab.Search_ContactSearch.click()
    searchScreen.ContactSearchScreen.searchCompanyFromNameAndFEIN(companyName, fein)
    return findDetails(searchScreen.ContactSearchScreen.ContactSearchResultsLV._Entries.first().Name.click())
  }

  function newPerson(firstName : String, lastName : String) : NewContact {
    var newContactPage = this.ContactTab.NewContact.NewPerson.click()
    var nameInputSet = newContactPage.ContactPanelSet.ContactCV.ContactDV.ContactNameInputSet_person
    nameInputSet.DefaultFirstName.setValue(firstName)
    nameInputSet.DefaultLastName.setValue(lastName)
    return newContactPage
  }

  function newCompany(companyName : String) : NewContact {
    var newContactPage = this.ContactTab.NewContact.NewCompany.click()
    var newCompanyName = newContactPage.CompanyName
    newCompanyName.setValue(companyName)
    return newContactPage
  }

  function goToDesktop() : pcftest.Underwriter_MySummary {
    return this.DesktopTab.click() as pcftest.Underwriter_MySummary
  }

  function goToMyActivities() : pcftest.DesktopActivities {
    var desktopPage = this.DesktopTab.click()
    return desktopPage.getOrCreateProperty("_parent", pcftest.Desktop).MenuLinks.Desktop_DesktopActivities.click()
  }

  property get CurrentActivityEntries() : IteratorEntriesWithPaging<DesktopActivitiesLV.entry> {
    var activities = this.goToMyActivities()
    return activities.DesktopActivitiesScreen_default.DesktopActivitiesLV._Entries
  }

  function goToMyAccounts() : pcftest.DesktopAccounts {
    var desktopPage = this.DesktopTab.click()
    return desktopPage.getOrCreateProperty("_parent", pcftest.Desktop).MenuLinks.Desktop_DesktopAccounts.click()
  }

  function goToMySubmissions() : pcftest.DesktopSubmissions {
    var desktopPage = this.DesktopTab.click()
    return desktopPage.getOrCreateProperty("_parent", pcftest.Desktop).MenuLinks.Desktop_DesktopSubmissions.click()
  }

  function goToMyRenewals() : pcftest.DesktopRenewals {
    var desktopPage = this.DesktopTab.click()
    return desktopPage.getOrCreateProperty("_parent", pcftest.Desktop).MenuLinks.Desktop_DesktopRenewals.click()
  }

  function goToOtherWorkOrders() : pcftest.DesktopOtherWorkOrders {
    var desktopPage = this.DesktopTab.click()
    return desktopPage.getOrCreateProperty("_parent", pcftest.Desktop).MenuLinks.Desktop_DesktopOtherWorkOrders.click()
  }

  /**
   * Navigate to the given Policy Change
   *
   * @FROM any page with the standard TabBar
   * @TO the PolicyChangeWizard PolicyInfo page
   */
  function goToPolicyChange(job : PolicyChange) : pcftest.PolicyChangeWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.Periods[0].PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.PolicyChangeWizard
    return wizard
  }

  /**
   * Navigate to the given Audit
   *
   * @FROM any page with the standard TabBar
   * @TO the AuditWizard PolicyInfo page
   */
  function goToAudit(job : Audit) : pcftest.AuditWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.PolicyPeriod.PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.AuditWizard
    return wizard
  }

  function goToAudit(jobNumber : String) : AuditWizard {
    this.PolicyTab.PolicyTab_SubmissionNumberSearchItem.Value = jobNumber
    return this.PolicyTab.PolicyTab_SubmissionNumberSearchItem_Button.click() as pcftest.AuditWizard
  }


  /**
   * Navigate to the given Issuance
   *
   * @FROM any page with the standard TabBar
   * @TO the IssuanceWizard PolicyInfo page
   */
  function goToIssuance(job : Issuance) : pcftest.IssuanceWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.Periods[0].PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.IssuanceWizard
    return wizard
  }

  /**
   * Navigate to the given Cancellation using the argument job's PolicyNumber.
   * Assumes that there is at most one Cancellation for that PolicyNumber.
   *
   * @FROM any page with the standard TabBar
   * @TO the CancellationWizard Entry page
   */
  function goToCancellation(job : Cancellation) : pcftest.CancellationWizard {
    var policySearchPage = goToDatabasePolicySearch()
    policySearchPage.SearchFor.getOptionByLabel(PolicyPeriodSearchCriteria.PolicyPeriodSearchType.Cancellation.toString()).click()
    policySearchPage.PolicyNumber.Value = job.LatestPeriod.PolicyNumber
    policySearchPage.SearchButton.click()
    var resultsEntries = policySearchPage.CancellationResults._Entries
    if (resultsEntries.Count != 1) {
      throw "Expected exactly one open cancellation for policy \"" + job.LatestPeriod.PolicyNumber + "\""
    }
    return resultsEntries.first().PolicyNumber.click() as pcftest.CancellationWizard
  }

  /**
   * Navigate to the given open Cancellation using the argument job's PolicyNumber
   * and job number.
   */
  function goToOpenCancellation(job : Cancellation) : pcftest.CancellationWizard {
    var policyFileSummary = this.goToPolicyFileSummary(job.LatestPeriod.PolicyNumber)
    var workOrderEntry = policyFileSummary.PendingTransactionsLV._Entries.firstWhere(\p -> p.JobNumber.Text == job.JobNumber)
    var cancellationWizard = workOrderEntry.JobNumber.click() as pcftest.CancellationWizard
    return cancellationWizard
  }

  /**
   * Navigate to the given Rewrite
   *
   * @FROM any page with the standard TabBar
   * @TO the RewriteWizard PolicyInfo page
   */
  function goToRewrite(job : Rewrite) : pcftest.RewriteWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.Periods[0].PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.RewriteWizard
    return wizard
  }

  /**
   * Navigate to the given open RewriteNewAccount using the argument job's
   * and job number.
   */
  function goToOpenRewriteNewAccount(job : RewriteNewAccount) : pcftest.RewriteNewAccountWizard {
    var accountFile = goToAccountFileSummary(job.Policy.Account.AccountNumber)

    var jobEntry = accountFile.WorkOrdersLV._Entries.singleWhere(\e -> e.Transaction.Text == job.JobNumber and e.Type.Text == Job.TC_REWRITENEWACCOUNT.getDisplayName())
    var wizard = jobEntry.Transaction.click() as pcftest.RewriteNewAccountWizard
    return wizard
  }

  /**
   * Navigate to the given RewriteNewAccount
   *
   * @FROM any page with the standard TabBar
   * @TO the RewriteWizard PolicyInfo page
   */
  function goToRewriteNewAccount(job : RewriteNewAccount) : pcftest.RewriteNewAccountWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.PolicyPeriod.PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.RewriteNewAccountWizard
    return wizard
  }

  /*
  function goToSubmission(policyPeriod: PolicyPeriod):  pcftest.SubmissionWizard {
    this.PolicyTab.PolicyTab_SubmissionNumberSearchItem.Value = policyPeriod.Submission.JobNumber
    return this.PolicyTab.PolicyTab_SubmissionNumberSearchItem_Button.click() as pcftest.SubmissionWizard
  }
  */


  /**
   * Navigate to the given Reinstatement
   *
   * @FROM any page with the standard TabBar
   * @TO the ReinstatementWizard PolicyInfo page
   */
  function goToReinstatement(job : Reinstatement) : pcftest.ReinstatementWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.PolicyPeriod.PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.ReinstatementWizard
    return wizard
  }

  function goToRenewal(renewalNumber : String) : pcftest.RenewalWizard {
    return searchForSubmissionNumberAndClickSearch(renewalNumber) as pcftest.RenewalWizard
  }

  function goToRenewal(renewal : Renewal) : pcftest.RenewalWizard {
    var policySearchPage = goToDatabasePolicySearch()
    policySearchPage.SearchFor.getOptionByLabel(PolicyPeriodSearchCriteria.PolicyPeriodSearchType.Renewal.toString()).click()
    policySearchPage.PolicyNumber.Value = renewal.LatestPeriod.PolicyNumber
    policySearchPage.SearchButton.click()
    var resultsEntries = policySearchPage.RenewalResults._Entries
    if (resultsEntries.Count != 1) {
      throw "Expected exactly one renewal for policy \"" + renewal.LatestPeriod.PolicyNumber + "\""
    }
    return resultsEntries.first().PolicyNumber.click() as pcftest.RenewalWizard
  }

  /**
   * Navigate to the given open Renewal
   *
   * @FROM any page with the standard TabBar
   * @TO the RenewalWizard PolicyInfo page
   */
  function goToOpenRenewal(job : Renewal) : pcftest.RenewalWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.LatestPeriod.PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.RenewalWizard
    return wizard
  }

  /**
   * Navigate to the given open Reinstatement
   *
   * @FROM any page with the standard TabBar
   * @TO the ReinstatementWizard StartReinstatement page
   */
  function goToOpenReinstatement(job : Reinstatement) : pcftest.ReinstatementWizard {
    var policyFileSummaryPage = goToPolicyFileSummary(job.LatestPeriod.PolicyNumber)
    var wizard = policyFileSummaryPage.openWorkorder(job.JobNumber) as pcftest.ReinstatementWizard
    return wizard
  }

  /**
   * Go to the PolicyFile_Summary page by entering a given policy number into
   * the policy search widget in the "Policy" tab bar.
   */
  function goToPolicySummary(policyNumber: String) : pcftest.PolicyFile_Summary {
    this.PolicyTab.PolicyTab_PolicyRetrievalItem.Value = policyNumber
    var page = this.PolicyTab.PolicyTab_PolicyRetrievalItem_Button.click()
    Assert.assertTrue("Policy not found? " + policyNumber
        + " (Expected to be on page " + pcftest.PolicyFile_Summary.Type.RelativeName
        + ", but was on " + (page.SmokeTest as ISmokeTestHelper).CurrentPageName + ")",
        (typeof page == pcftest.PolicyFile_Summary))

    return page as pcftest.PolicyFile_Summary
  }

  /**
   * Go to the ArchivedPolicyPeriodPage page by entering a given policy number into
   * the policy search widget in the "Policy" tab bar.
   */
  function goToArchivedPolicySummary(policyNumber: String) : ArchivedPolicyPeriodPage {
    this.PolicyTab.PolicyTab_PolicyRetrievalItem.Value = policyNumber
    var page = this.PolicyTab.PolicyTab_PolicyRetrievalItem_Button.click()
    Assert.assertTrue("Policy not found? " + policyNumber
        + " (Expected to be on page " + pcftest.ArchivedPolicyPeriodPage.Type.RelativeName
        + ", but was on " + (page.SmokeTest as ISmokeTestHelper).CurrentPageName + ")",
        (typeof page == pcftest.ArchivedPolicyPeriodPage))

    return page as pcftest.ArchivedPolicyPeriodPage
  }

  /**
   * Navigate to the Account Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the AccountSearch page
   */
  function goToAccountSearch() : pcftest.AccountSearch {
    return this.SearchTab.Search_AccountSearch.click()
  }

  /**
   * Navigate to the Contact Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the AccountSearch page
   */
  function goToContactSearch() : pcftest.ContactSearch {
    return this.SearchTab.Search_ContactSearch.click()
  }

  function goToProgramSearch() : pcftest.ProgramSearchPage {
    return this.ReinsuranceTab.Reinsurance_ProgramSearchPage.click()
  }

  function goToProgram(program : RIProgram) : pcftest.EditProgramPage {
    var searchPage = this.ReinsuranceTab.Reinsurance_ProgramSearchPage.click()
    var result = searchPage.ProgramSearchScreen.searchProgram(program)
    return result.Name.click()
  }

  function goToAgreementSearch() : pcftest.AgreementSearchPage {
    return this.ReinsuranceTab.Reinsurance_AgreementSearchPage.click()
  }

  function goToAgreement(agreement : RIAgreement) : pcftest.EditAgreementPage {
    var searchPage = this.ReinsuranceTab.Reinsurance_AgreementSearchPage.click()
    var result = searchPage.searchByNumber(agreement.AgreementNumber)
    return result.AgreementNumber.click()
  }

  /**
   * Go to the PolicyFile_Summary page (by entering a given policy number into
   * the policy search widget in the "Policy" tab bar), but returns the
   * PolicyFile itself. This is useful if the caller needs to access objects
   * on the PolicyFile location group and not a particular page.
   */
  function goToPolicyFile(policyNumber : String) : pcftest.PolicyFile {
    return this.goToPolicySummary(policyNumber)._parent
  }

  function goToPolicyFile(policyPeriod : PolicyPeriod) : pcftest.PolicyFile {
    return this.goToPolicySummary(policyPeriod.PolicyNumber)._parent
  }

  /**
   * Go straight to the PolicyFile_Summary page.
   */
  function goToPolicyFileSummary(policyNumber : String) : pcftest.PolicyFile_Summary {
    return this.goToPolicyFile(policyNumber).MenuLinks.PolicyFile_PolicyFile_Summary.click()
  }

  /**
   * Navigate to the database Policy Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the PolicySearch page
   */
  function goToDatabasePolicySearch() : pcftest.PolicySearch {
    var page = this.SearchTab.click() as pcftest.PolicySearch

    if (page.PolicySearchScreen.SolrSearchTabActive) {
      page = page.PolicySearchScreen.dbSearchTab.click() as pcftest.PolicySearch
    }

    return page
  }

  /**
   * Navigate to the solr Policy Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the PolicySearch page
   */
  function goToSolrPolicySearch() : pcftest.PolicySearch {
    var page = this.SearchTab.click() as pcftest.PolicySearch

    if (page.PolicySearchScreen.DatabaseSearchTabActive) {
      page = page.PolicySearchScreen.solrSearchTab.click() as pcftest.PolicySearch
    }

    return page
  }

  /**
   * Navigate to the HVQ Policies Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the HVQPolicySearch page
   * @WHEN HVQEnabled is true
   */
  function goToHVQPoliciesSearch() : pcftest.HVQSearch {
    return this.SearchTab.Search_HVQSearch.click()
  }

  /**
   * Navigate to the producer code Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the ProducerCodeSearch page
   */
  function goToProducerCodeSearch() : pcftest.ProducerCodeSearch {
    return this.SearchTab.Search_ProducerCodeSearch.click()
  }

  /**
   * Navigate to the organization Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the OrganizationSearch page
   */
  function goToOrganizationSearch() : pcftest.OrganizationSearchPage {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_OrganizationSearchPage.click()
  }

  /**
   * Navigate to the group Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the GroupSearch page
   */
  function goToGroupSearch() : pcftest.AdminGroupSearchPage {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_AdminGroupSearchPage.click()
  }

  /**
   * Navigate to the admin user Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the AdminUserSearchPage page
   */
  function goToUserSearch() : pcftest.AdminUserSearchPage {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_AdminUserSearchPage.click()
  }

  function goToRoles() : pcftest.Roles {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_Roles.click()
  }


  /**
   * Navigate to the admin' producer code search page.
   *
   * @FROM any page with the standard TabBar
   * @TO the AdminProduceCodeSearch page
   */
  function goToAdminProducerCodeSearch() : pcftest.AdminProducerCodeSearch {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_AdminProducerCodeSearch.click()
  }

  /**
   * Navigate to the admin workflow Search page
   *
   * @FROM any page with the standard TabBar
   * @TO the WorkflowSearch page
   */
  function goToWorkflowSearch() : pcftest.WorkflowSearch {
    return this.AdminTab.Admin_Monitoring.Monitoring_WorkflowSearch.click()
  }

  function goToAttributes() : pcftest.Attributes {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_Attributes.click()
  }


  /**
   * Navigate to the admin page
   *
   * @FROM any page with the standard TabBar
   * @TO the admin page
   */
  function goToAdmin() : pcftest.AdminUserSearchPage {
    return this.AdminTab.click() as pcftest.AdminUserSearchPage
  }

  /**
   * Navigate to the admin page
   *
   * @FROM any page with the standard TabBar
   * @TO the admin page
   */
  function goToUWAuthorityProfiles() : pcftest.UWAuthorityProfiles {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_UWAuthorityProfiles.click()
  }

  function goToMessageSearch() : pcftest.MessageSearch.MessageSearchScreen {
    var eventMessagePage = this.AdminTab.Admin_Monitoring.Monitoring_MessageSearch.click()
    return eventMessagePage.MessageSearchScreen
  }

  function goToMessageQueues() : pcftest.MessagingDestinationControlList {
    var messageQueuePage = this.AdminTab.Admin_Monitoring.Monitoring_MessagingDestinationControlList.click()
    return messageQueuePage
  }

  function goToActivityPatterns() : pcftest.ActivityPatterns {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_ActivityPatterns.click()
  }

  function goToPolicyHolds() : pcftest.PolicyHolds {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_PolicyHolds.click()
  }

  function goToPolicyFormPatterns() : pcftest.FormPatterns {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_FormPatterns.click()
  }

  function goToHolidays() : pcftest.HolidaysPage {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_Holidays.click() as pcftest.HolidaysPage
  }

  function goToImportWizard() : ImportWizard {
    return this.AdminTab.Admin_Utilities.Utilities_ImportWizard.click() as pcftest.ImportWizard
  }

  function goToExportData() : ExportData {
    return this.AdminTab.Admin_Utilities.Utilities_ExportData.click()
  }

  function newOrganization() : pcftest.NewOrganization {
    var adminPage = this.AdminTab.click() as AdminUserSearchPage
    return adminPage._parent._parent.AdminMenuActions.AdminMenuActions_Create
        .AdminMenuActions_NewOrganization.click()
  }

  function goToRegions() : pcftest.RegionsPage {
    return this.AdminTab.Admin_UsersAndSecurity.UsersAndSecurity_Regions.click() as pcftest.RegionsPage
  }

  function goToScriptParameters() : pcftest.ScriptParametersPage {
    return this.AdminTab.Admin_Utilities.Utilities_ScriptParametersPage.click()
  }

  function goToSpreadsheetExportFormats() : pcftest.DataFlowMasks {
    return this.AdminTab.Admin_Utilities.Utilities_DataFlowMasks.click()
  }

  function goToTeam() : PCFLocation {
    return this.TeamTab.click()
  }

  function goToReinsurance() : pcftest.AgreementSearchPage {
    return this.ReinsuranceTab.click() as pcftest.AgreementSearchPage
  }

  function goToUWRules() : pcftest.UWRules {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_BizRules.BizRules_UWRules.click()
  }

  function goToManageDataLookupTables() : pcftest.LookupPage {
    return this.AdminTab.Admin_BusinessSettings.BusinessSettings_BizRules.BizRules_LookupPage.click()
  }

  property get CurrentActivities() : IteratorEntriesWithPaging<DesktopActivitiesLV.entry> {
    var desktopActivitiesPage = this.goToMyActivities()
    return desktopActivitiesPage.DesktopActivitiesScreen_default.DesktopActivitiesLV._Entries
  }

  function goToAccountSummary(account: Account): AccountFile_Summary {
    return goToAccountSummary(account.AccountNumber)
  }

  function goToAccountSummary(accountNumber: String): AccountFile_Summary {
    this.AccountTab.AccountTab_AccountNumberSearchItem.Value = accountNumber
    var page = this.AccountTab.AccountTab_AccountNumberSearchItem_Button.click()
    Assert.assertTrue("Account not found? ${accountNumber}. "
        + "Expected to be on page ${pcftest.AccountFile_Summary.Type.RelativeName}, but was on ${(page.SmokeTest as ISmokeTestHelper).CurrentPageName}",
        (typeof page == pcftest.AccountFile_Summary))

    return page as AccountFile_Summary
  }

}
