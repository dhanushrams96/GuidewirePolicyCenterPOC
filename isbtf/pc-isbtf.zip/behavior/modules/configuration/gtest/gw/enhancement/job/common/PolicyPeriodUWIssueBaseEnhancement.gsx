package gw.enhancement.job.common

enhancement PolicyPeriodUWIssueBaseEnhancement : PolicyPeriod {

  function approveUnderwritingIssuesBlockingBind() {
    this.UWIssuesActiveOnly
        .whereBlocking(UWIssueBlockingPoint.TC_BLOCKSBIND)
        .each(\issue -> {
          issue.createDefaultApproval()
          issue.Approval.ReferenceValue = issue.IssueType.ActiveVersion.calculateDefaultValue(issue.Approval.IssueValue)
        })
  }

}
