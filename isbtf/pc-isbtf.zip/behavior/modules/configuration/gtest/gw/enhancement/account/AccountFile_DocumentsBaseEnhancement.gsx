package gw.enhancement.account

uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement
uses pcftest.AccountNewDocumentMenuItemSet

enhancement AccountFile_DocumentsBaseEnhancement : pcftest.AccountFile_Documents {

  // list views

  property get DocumentsLV(): pcftest.DocumentsLV {
    return this.DocumentsScreen.DocumentsLV
  }

  // fields

  /**
   * Label: "Document Name"<br>
   * Type: String<br>
   */
  property get Name(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.Name
  }

  /**
   * Label: "Related To"<br>
   * Type: Object<br>
   */
  property get RelatedTo(): SelectElement {
    return this.DocumentsScreen.DocumentSearchDV.RelatedTo
  }

  /**
   * Label: "Status"<br>
   * Type: DocumentStatusType<br>
   */
  property get Status(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.Status
  }

  /**
   * Label: "Language"<br>
   * Type: LanguageType<br>
   */
  property get Language(): pcftest.DocumentSearchDV.Language {
    return this.DocumentsScreen.DocumentSearchDV.Language
  }

  /**
   * Label: "Date Range - From"<br>
   * Type: Date<br>
   */
  property get DateFrom(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.DateFrom
  }

  /**
   * Label: "Date Range - To"<br>
   * Type: Date<br>
   */
  property get DateTo(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.DateTo
  }

  /**
   * Label: "Author"<br>
   * Type: String<br>
   */
  property get Author(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.Author
  }

  /**
   * Label: "Include Hidden Documents"<br>
   * Type: Boolean<br>
   */
  property get IncludeObsoletes(): ValueElement {
    return this.DocumentsScreen.DocumentSearchDV.IncludeObsoletes
  }

  function search(): pcftest.PolicyFile_Documents {
    return this.DocumentsScreen.DocumentSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click() as pcftest.PolicyFile_Documents
  }

  function reset(): pcftest.PolicyFile_Documents {
    return this.DocumentsScreen.DocumentSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset.click() as pcftest.PolicyFile_Documents
  }

  function findByName(nameStr: String): pcftest.DocumentsLV.entry {
    return this.DocumentsLV._Entries.firstWhere(\item -> item.NameLink.Text == nameStr)
  }

  property get DocumentSearchDV(): pcftest.DocumentSearchDV {
    return this.DocumentsScreen.DocumentSearchDV
  }

  property get DocumentSearchLinkInputSet(): pcftest.SearchLinksInputSet {
    return this.DocumentSearchDV.SearchAndResetInputSet.SearchLinksInputSet
  }

  function localizedDocumentExists(nameStr: String, lang: LanguageType): Boolean {
    return getDocumentEntryByLanguage(nameStr, lang) != null
  }

  function getDocumentEntryByLanguage(nameStr: String, lang: LanguageType): pcftest.DocumentsLV.entry {
    var docsInLV = this.DocumentsLV
    var searchDV = this.DocumentSearchDV
    searchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
    searchDV.Name.Value = nameStr
    if (lang != null) {
      searchDV.Language.TypeKeyValue = lang
    }
    searchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()

    if (not docsInLV._Entries.Empty) {
      var docResults = docsInLV._Entries.where(\d -> d.NameLink.Text.containsIgnoreCase(nameStr)).toList()
      if (docResults.size() == 1) {
        return docResults.get(0)
      }
    }
    return null
  }

  property get NewDocumentMenu(): AccountNewDocumentMenuItemSet {
    return this.DocumentsScreen.DocumentsLV_tb
        .PolicyFile_Documents_NewDocumentButton
        .AccountNewDocumentMenuItemSet
  }

  function clickCreateNewDocFromTemplate<T extends PCFLocation>(expectedType: Class<T>): T {
    return this.NewDocumentMenu.AccountNewDocumentMenuItemSet_Template
        .clickThis(expectedType)
  }

  property get DocumentsCount(): int {
    return DocumentsLV._Entries.Count
  }

}
