package gw.enhancement.job.common

enhancement Job_RiskAnalysisScreenBaseEnhancement : pcftest.Job_RiskAnalysisScreen {

  property get IssueEntries(): gw.smoketest.platform.web.IteratorEntries<pcftest.RiskEvaluationPanelSet.entry> {
    return this.RiskAnalysisCV.RiskEvaluationPanelSet._Entries
  }

  property get EvaluationIssuesPanel(): pcftest.RiskEvaluationPanelSet {
    return this.RiskAnalysisCV.RiskEvaluationPanelSet
  }

  function clickEvaluationIssuesTab() {
    this.RiskAnalysisCV.EvaluationIssuesCardTab.click()
  }

  function clickIssueRowByShortDescription(shortDescription: String): pcftest.RiskApprovalDetailsPopup {
    return getIssueRowByShortDescription(shortDescription).ShortDescription.click()
  }

  function getIssueRowByShortDescription(shortDescription: String): pcftest.UWIssueRowSet_issue {
    return getIssueRowsByShortDescription(shortDescription).single()
  }

  function getIssueRowsByShortDescription(shortDescription: String): pcftest.UWIssueRowSet_issue[] {
    var panelSet = this.RiskAnalysisCV.RiskEvaluationPanelSet
    var issueRows = panelSet._Entries.where(\r -> (
        r.UWIssueRowSet_issue.ShortDescription.Visible
            and r.UWIssueRowSet_issue.ShortDescription.Value.contains(shortDescription))
    )*.UWIssueRowSet_issue
    return issueRows
  }

  function approveAllIssues() {
    var numberOfApprovals = IssueEntries.countWhere(\i -> i.UWIssueRowSet_issue.Approve.Visible and i.UWIssueRowSet_issue.Approve.Enabled)
    for (0..|numberOfApprovals) {
      var approvalPopup = IssueEntries.firstWhere(\issue -> issue.UWIssueRowSet_issue.Approve.Visible and issue.UWIssueRowSet_issue.Approve.Enabled).UWIssueRowSet_issue.Approve.click()
      approvalPopup.Update.click()
    }
  }

}
