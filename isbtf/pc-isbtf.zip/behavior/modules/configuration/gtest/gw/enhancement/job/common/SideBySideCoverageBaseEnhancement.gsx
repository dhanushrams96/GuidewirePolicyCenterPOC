package gw.enhancement.job.common

uses gw.smoketest.platform.web.SelectElement

enhancement SideBySideCoverageBaseEnhancement : pcftest.SideBySideTableLayoutDV.lineLevelCoverages.entry {

  property get LiabilityCoverage() : SelectElement {
    return this.lineCovRow._Entries[0].targetedCovTermId.SideBySideCovTermInputSet_range.SideBySideRangeCovTermValue
  }

}
