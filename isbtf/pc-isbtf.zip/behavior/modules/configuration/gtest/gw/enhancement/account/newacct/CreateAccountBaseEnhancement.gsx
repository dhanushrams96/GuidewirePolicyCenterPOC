package gw.enhancement.account.newacct

uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement
uses pcftest.CreateAccount

enhancement CreateAccountBaseEnhancement : CreateAccount {

  property get AddressLine1() : ValueElement {
    return this.CreateAccountScreen.CreateAccountDV.AddressInputSet.AddressLine1
  }

  property get City() : pcftest.GlobalAddressInputSet_default.City {
    return this.CreateAccountScreen.CreateAccountDV.AddressInputSet.City
  }

  property get State() : SelectElement {
    return this.CreateAccountScreen.CreateAccountDV.AddressInputSet.State
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return this.CreateAccountScreen.CreateAccountDV.AddressInputSet.PostalCode
  }

  property get AddressType() : pcftest.CreateAccountDV.AddressType {
    return this.CreateAccountScreen.CreateAccountDV.AddressType
  }

  property get Producer() : pcftest.CreateAccountDV.ProducerSelectionInputSet.Producer {
    return this.CreateAccountScreen.CreateAccountDV.ProducerSelectionInputSet.Producer
  }

  property get ProducerCode() : SelectElement {
    return this.CreateAccountScreen.CreateAccountDV.ProducerSelectionInputSet.ProducerCode
  }

  function update() : gw.smoketest.platform.web.PCFLocation{
    if (this.CreateAccountScreen.ForceDupCheckUpdate.Visible) {
      return this.CreateAccountScreen.ForceDupCheckUpdate.click()
    } else {
      return this.CreateAccountScreen.Update.click()
    }
  }
}
