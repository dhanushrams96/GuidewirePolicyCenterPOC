package gw.enhancement.job.cancellation

uses gw.smoketest.platform.web.PCFLocation

@Export
enhancement CancellationWizard_QuoteScreenTestEnhancement : pcftest.CancellationWizard_QuoteScreen {

  function clickScheduleCancellation() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Cancellation.BindOptions.SubmitCancellation.click()
  }

  function clickCancelNow() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Cancellation.BindOptions.CancelNow.click()
  }

  function clickRescindCancellation() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Cancellation.CloseOptions.RescindCancellation.click()
  }

}
