package gw.enhancement.account.newacct

uses gw.smoketest.platform.web.ValueElement
uses pcftest.NewAccount
uses org.junit.Assert


enhancement NewAccountBaseEnhancement : NewAccount {

  property get NewCompanyAccountButton() : pcftest.NewAccountScreen.NewAccountButton.NewAccount_Company {
    return this.NewAccountScreen.NewAccountButton.NewAccount_Company
  }

  property get NewPersonAccountButton() : pcftest.NewAccountScreen.NewAccountButton.NewAccount_Person {
    return this.NewAccountScreen.NewAccountButton.NewAccount_Person
  }

  function clickSearch() : gw.smoketest.platform.web.PCFLocation {
    return SearchButton.click()
  }

  property get SearchButton() : pcftest.SearchLinksInputSet.Search {
    return this.NewAccountScreen.NewAccountSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search
  }

  property get FirstName() : ValueElement {
    return this.NewAccountScreen.NewAccountSearchDV.GlobalPersonNameInputSet_default.FirstName
  }

  property get LastName() : ValueElement {
    return this.NewAccountScreen.NewAccountSearchDV.GlobalPersonNameInputSet_default.LastName
  }

  property get CompanyName() : ValueElement {
    return this.NewAccountScreen.NewAccountSearchDV.GlobalContactNameInputSet_default.Name
  }

  function clickCreatePersonAccount() : pcftest.CreateAccount{
    Assert.assertTrue("Create as New Account button not found", NewPersonAccountButton.Visible)
    return NewPersonAccountButton.click()
  }

  function clickCreateCompanyAccount() : pcftest.CreateAccount{
    Assert.assertTrue("Create as New Account button not found", this.NewCompanyAccountButton.Visible)
    return this.NewCompanyAccountButton.click()
  }
}
