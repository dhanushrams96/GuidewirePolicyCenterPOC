package gw.enhancement.job.policychange

uses pcftest.StartPolicyChange

enhancement StartPolicyChangeBaseEnhancement : StartPolicyChange {

  property get EffectiveDateTime() : Date {
    return this.StartPolicyChangeScreen.StartPolicyChangeDV.EffectiveDate.DateValue
  }

  property set EffectiveDateTime(d : Date) {
    if (d == null) {
      this.StartPolicyChangeScreen.StartPolicyChangeDV.EffectiveDate.Value = ""
    } else {
      this.StartPolicyChangeScreen.StartPolicyChangeDV.EffectiveDate.DateValue = d
    }
  }

}
