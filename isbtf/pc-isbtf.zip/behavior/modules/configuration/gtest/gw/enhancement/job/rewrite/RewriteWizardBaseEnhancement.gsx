package gw.enhancement.job.rewrite

uses gw.smoketest.pc.lob.gl.RewriteWizardGLMode
uses gw.smoketest.pc.lob.pa.RewriteWizardPAMode

// Enhances the Rewrite Wizard. Has some helper methods to navigate to and verify current screen
// Methods are grouped by product and order they appear on the UI navigation
enhancement RewriteWizardBaseEnhancement: pcftest.RewriteWizard {

  property get GLMode() : RewriteWizardGLMode {
    return new RewriteWizardGLMode(this)
  }

  property get PAMode() : RewriteWizardPAMode {
    return new RewriteWizardPAMode(this)
  }

  property get RiskAnalysisStep() : pcftest.RewriteWizard.RiskAnalysis {
    return this.RiskAnalysis
  }

  function goToRiskAnalysis() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    return screen
  }

  function goToQuoteStep() : pcftest.RewriteWizard_QuoteScreen {
    return this.ViewQuote.click()
  }

  property get SideBySidePage() : pcftest.JobWizardToolsMenuWizardStepSet.SideBySide {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide
  }

  function goToSideBySidePage(): pcftest.SideBySideScreen {
    return this.JobWizardToolsMenuWizardStepSet.SideBySide.click()
  }
}
