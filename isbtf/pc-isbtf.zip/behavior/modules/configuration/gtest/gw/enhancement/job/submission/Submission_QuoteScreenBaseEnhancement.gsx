package gw.enhancement.job.submission
uses gw.smoketest.platform.web.PCFLocation

enhancement Submission_QuoteScreenBaseEnhancement : pcftest.SubmissionWizard_QuoteScreen {
  
  /**
   * Clicks Issue Policy button on the screen. Most likely waitForAutoRefreshToComplete() will need to be called
   * as a next step in smoketest.
   */
  function clickBindAndIssue() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
  }

  /**
   * Clicks bind button on the screen. Most likely waitForAutoRefreshToComplete() will need to be called
   * as a next step in smoketest.
   */
  function clickBindOnly() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
  }

}
