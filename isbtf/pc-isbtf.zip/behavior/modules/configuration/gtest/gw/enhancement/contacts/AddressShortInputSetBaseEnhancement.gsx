package gw.enhancement.contacts

uses gw.smoketest.platform.web.ValueElement

// NOTE: Defaults to "default" mode
enhancement AddressShortInputSetBaseEnhancement : pcftest.AddressShortInputSet {

  property get Address() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressSummary
  }

  property get County() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.County
  }

  property get Country() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.Country
  }

}
