package gw.enhancement.job.submission

uses gw.smoketest.platform.web.IteratorEntries

enhancement SubmissionRejectLetterBaseEnhancement : pcftest.SubmissionRejectLetter {

  property get RejectionEntries() : IteratorEntries<pcftest.SubmissionRejectLetterDV.SubmissionRejectLetterLV.entry> {
    return this.SubmissionRejectLetterScreen.SubmissionRejectLetterDV.SubmissionRejectLetterLV._Entries
  }

}
