package gw.enhancement.lob.pa

uses gw.api.productmodel.ModifierPatternBaseLookup
uses gw.cucumber.util.lob.pa.VehicleIdentifier
uses gw.smoketest.platform.web.BooleanValueElement
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement
uses org.junit.Assert
uses pcftest.PAVehiclesPanelSet
uses pcftest.PersonalAuto_AssignDriversInputSet

enhancement PAVehiclesScreenBaseEnhancement : pcftest.PAVehiclesScreen {

  function SaveDraft() : PCFLocation {
    return this.JobWizardToolbarButtonSet_Submission.Draft.click()
  }

  property get AdditionalInterestLV() : pcftest.AdditionalInterestDetailsDV.AdditionalInterestLV {
    return this.AdditionalInterestRelationsDV.AdditionalInterestLV
  }

  property get PersonalAutoVehicleDV() : pcftest.PersonalAuto_VehicleDV {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV
  }

  property get VehicleDetail() : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV
  }

  property get ErrorMessages() : String[] { return this._msgs.getMessages() }

  public function clickCreateVehicle() {
    CreateVehicleButton.click()
  }

  public function clickRemoveVehicles() {
    RemoveVehicleButton.click()
  }

  public function removeVehicle(vehicleNumber : int) {
    VehiclesLV._Entries.firstWhere( \ v -> v.VehicleNumber.Value == (vehicleNumber as String) )._Checkbox.click()
    clickRemoveVehicles()
    this.SaveDraft()
  }

  function getPAVehicleEntry (vIdentifier : VehicleIdentifier) : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV.entry{
    return this.VehiclesLV._Entries.singleWhere(\vehicle -> {
      var vehicleEntry = new VehicleIdentifier(vehicle.Year.Text, vehicle.Make.Text, vehicle.Model.Text)
      return vIdentifier.equals(vehicleEntry)
    })
  }

  public function getVehicleWithNumber(number : int) : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV.entry {
    var vehicles = this.VehiclesLV._Entries.where(\vehicle -> vehicle.VehicleNumber.Text == number as String)
    Assert.assertEquals("Expected to get one vehicle with number " + number + " but got " + vehicles.Count, 1, vehicles.Count)
    return vehicles.first()
  }

  public function selectVehicleWithNumber(number : int) : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV.entry {
    var vehicle = getVehicleWithNumber(number)
    vehicle._Checkbox.click()
    return vehicle
  }

  public function viewVehicleWithNumber(number : int) : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV.entry {
    var vehicle = getVehicleWithNumber(number)
    vehicle.viewDetail()
    return vehicle
  }

  property get VehiclesCount() : int { return this.VehiclesLV._Entries.Count }
  property get DriversCount() : int { return this.DriverLV._Entries.Count }

  // list views
  property get VehiclesLV() : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV
  }

  property get DriverLV() : PersonalAuto_AssignDriversInputSet.DriverPctLV {
    return this.DriversDV.DriverPctLV
  }

  property get DriverLVToolbar() : pcftest.PersonalAuto_AssignDriversInputSet.DriverPctLV_tb {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PersonalAuto_AssignDriversInputSet.DriverPctLV_tb
  }

  // buttons
  property get CreateVehicleButton() : PAVehiclesPanelSet.VehiclesListDetailPanel_tb.Add {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel_tb.Add
  }

  property get RemoveVehicleButton() : PAVehiclesPanelSet.VehiclesListDetailPanel_tb.Remove {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel_tb.Remove
  }

  // driver buttons
  property get RemoveDriverButton() : pcftest.PersonalAuto_AssignDriversInputSet.DriverPctLV_tb.Remove { return this.DriversDV.DriverPctLV_tb.Remove }

  /**
   * Label: "#"<br>
   * Type: Integer<br>
   */
  property get VehicleNumber_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.VehicleNumber_DV }

  /**
   * Label: "Vehicle Type"<br>
   * Type: VehicleType<br>
   */
  property get Type_DV() : pcftest.PersonalAuto_VehicleDV.Type_DV { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Type_DV }

  /**
   * Label: "Vin"<br>
   * Type: String<br>
   */
  property get Vin_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Vin_DV }

  /**
   * Label: "Model Year"<br>
   * Type: Integer<br>
   */
  property get Year_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Year_DV }

  /**
   * Label: "Make"<br>
   * Type: String<br>
   */
  property get Make_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Make_DV }

  /**
   * Label: "Model"<br>
   * Type: String<br>
   */
  property get Model_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Model_DV }

  /**
   * Label: "Unknown"<br>
   * Type: BodyType<br>
   */
  property get BodyType_DV() : pcftest.PersonalAuto_VehicleDV.BodyType_DV { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.BodyType_DV }

  /**
   * Label: "Color"<br>
   * Type: String<br>
   */
  property get Color_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.Color_DV }

  /**
   * Label: "License Plate"<br>
   * Type: String<br>
   */
  property get LicensePlate_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.LicensePlate_DV }

  /**
   * Label: "License State"<br>
   * Type: State<br>
   */
  property get LicenseState_DV() : SelectElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.LicenseState_DV }

  /**
   * Label: "Location Name"<br>
   * Type: PolicyLocation<br>
   */
  property get GarageLocationInput() : pcftest.PAGarageLocationInputSet.PAGarageLocationInput { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PAGarageLocationInputSet.PAGarageLocationInput }

  /**
   * Label: "Cost"<br>
   * Type: BigDecimal<br>
   */
  property get CostNew_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.CostNew_DV }

  /**
   * Label: "Stated Value"<br>
   * Type: BigDecimal<br>
   */
  property get StatedValue_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.StatedValue_DV }

  /**
   * Label: "Leased or Rented?"<br>
   * Type: Boolean<br>
   */
  property get LeaseOrRent_DV() : BooleanValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.LeaseOrRent_DV }

  /**
   * Label: "Length of Lease/Rental (months)"<br>
   * Type: LengthOfLease<br>
   */
  property get LengthOfLease_DV() : pcftest.PersonalAuto_VehicleDV.LengthOfLease_DV { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.LengthOfLease_DV }

  /**
   * Label: "Annual Mileage"<br>
   * Type: Integer<br>
   */
  property get annualmiles_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.annualmiles_DV }

  /**
   * Label: "Commuting Miles (one way)"<br>
   * Type: Integer<br>
   */
  property get commutemiles_DV() : ValueElement { return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.commutemiles_DV }

  /**
   * Label: "Primary Use"<br>
   * Type: VehiclePrimaryUse<br>
   */
  property get primaryuse_DV() : pcftest.PersonalAuto_VehicleDV.primaryuse_DV {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.primaryuse_DV
  }
  property get GarageLocation() : pcftest.PAGarageLocationInputSet.PAGarageLocationInput {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PAGarageLocationInputSet.PAGarageLocationInput
  }
  property get GarageLocation_ReadOnly() : ValueElement {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PAGarageLocationInputSet.PAGarageLocationReadonly
  }

  property get DriversDV() : pcftest.PersonalAuto_AssignDriversInputSet {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PersonalAuto_AssignDriversInputSet
  }
  property get AddExistingDriverLink():pcftest.PersonalAuto_AssignDriversInputSet.DriverPctLV_tb.AddDriver {
    return this.DriverLVToolbar.AddDriver
  }

  property get PAVehicleModifiers_DV() : pcftest.PAVehicleModifiersInputSet{
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PAVehicleModifiersInputSet
  }

  property get AdditionalInterestTab() : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.AdditionalInterestCardTab{
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.AdditionalInterestCardTab
  }

  property get VehicleDetailsTab() : PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.VehicleDetailCardTab{
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.VehicleDetailCardTab
  }

  property get PreferredCoverageCurrency() : pcftest.PreferredCoverageCurrencyPanelSet {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.PreferredCoverageCurrencySelectorRef.PreferredCoverageCurrencyPanelSet
  }

  property get PreferredCoverageCurrencyForFirstRowOfLocationsLV() : ValueElement {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesLV._Entries.first().VehicleCoverageCurrency
  }

  property get AdditionalInterestRelationsDV(): pcftest.AdditionalInterestDetailsDV{
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.AdditionalInterestDetailsDV
  }

  /**
   * Selects vehicle location by location number. Method cause test failure if location with given number is not found.
   */
  function selectGarageLocation(locationNumber : int) : String {
    var prefix : String = locationNumber + ": "
    var location = GarageLocation.OptionLabels.firstWhere( \ s -> s.startsWith(prefix) )
    if (location != null) {
      return GarageLocation.getOptionByLabel(location).click().Text
    }
    Assert.fail( "Location #" + locationNumber + " not found" )
    return null
  }

  function addExistingDriver() {
    var entry = AddExistingDriverLink._Entries
    if (entry.Count > 0){
      entry.get(0).Driver.click()
    } else {
      print("No existing drivers available to add")
    }
  }

  function addExistingDriver(driverName : String) {
    var entry = this.AddExistingDriverLink._Entries.firstWhere( \ row -> row.Driver.Text == driverName)
    Assert.assertNotNull("Can't find driver with name: " + driverName, entry)
    entry.Driver.click()
  }

  function openDriver(driverName : String) : pcftest.EditPolicyContactRolePopup {
    var entry = this.DriverLV._Entries.firstWhere( \ row -> row.Driver.Text == driverName)
    Assert.assertNotNull("Can't find driver with name: " + driverName, entry)
    return entry.Driver.click()
  }

  function removeDriver(driverName : String) {
    var entry = this.DriverLV._Entries.firstWhere( \ row -> row.Driver.Text == driverName)
    Assert.assertNotNull("Can't find driver with name: " + driverName, entry)
    entry._Checkbox.click()
    this.RemoveDriverButton.click()
  }

  /**
   * Selects vehicle location by location name. Method cause test failure if location with given name is not found or
   * is found more than once.
   */
  function selectGarageLocation(locationName : String) {
    var found = false
    var match = ": " + locationName
    for (var optionText in GarageLocation.OptionLabels) {
      if (optionText.endsWith(match)) {
        if (!found) {
          GarageLocation.getOptionByLabel( optionText ).click()
          found = true
        } else {
          Assert.fail( "Location name '" + locationName + "' is not unique in the vehicle location drop-down. Your test data is non-deterministic." )
        }
      }
    }
    Assert.assertTrue( "Location " + locationName + " not found", found )
  }

  function populateRequiredFields() {
    populateRequiredFieldsWithLocation(1)
  }

  function populateRequiredFieldsWithLocation(locationIndex : int) {
    Type_DV.getOptionByLabel("Other").click()
    if (PreferredCoverageCurrency.PreferredCoverageCurrencySelectorDropDown.Visible) {
      PreferredCoverageCurrency.PreferredCoverageCurrencySelectorDropDown.selectFirstValidOption()
    }
    Vin_DV.Value = "1"
    CostNew_DV.Value = "123456"
    LicenseState_DV.Value = "CA"
    if (GarageLocation.Value == null) {
      GarageLocation.getOption(locationIndex).click()
    }
    addExistingDriver()
  }

  function setPercentageForDriver(driver: String, percentage: String){
    this.getDriverEntry(driver).Percentage.Value = percentage
  }

  function getDriverEntry(driver: String) : PersonalAuto_AssignDriversInputSet.DriverPctLV.entry{
    return this.DriverLV._Entries.firstWhere( \ p -> p.Driver.Value == driver  )
  }

  function getAdditionalInterest(name: String): pcftest.AdditionalInterestDetailsDV.AdditionalInterestLV.entry{
    return this.AdditionalInterestRelationsDV.AdditionalInterestLV._Entries.firstWhere( \ a -> a.Name.Value == name )
  }

  function openNewLocationPopup() : pcftest.LocationPopup {
    return this.PAVehiclesPanelSet.VehiclesListDetailPanel.VehiclesDetailsCV.PersonalAuto_VehicleDV.PAGarageLocationInputSet.PAGarageLocationInput.NewGarageLocation.click()
  }

  function getModifierEntry(modifierPatternCode : String) : pcftest.PAVehicleModifiersInputSet.entry {
    var modifierName = ModifierPatternBaseLookup.getByPublicID(modifierPatternCode).Name
    return this.PAVehicleModifiers_DV._Entries.firstWhere(\ e -> e.ModifierName.Value == modifierName)
  }

}
