package gw.enhancement.lob.common

uses gw.api.locale.DisplayKey
uses gw.cucumber.util.common.UIFieldsProviderBase
uses gw.cucumber.util.common.UIHelper
uses pcftest.LocationPopup
uses pcftest.TerritoryCodeInputSet

enhancement LocationsScreenBaseEnhancement : LocationPopup.LocationScreen {
  property get AutoFillTerritoryCode() : TerritoryCodeInputSet.AutofillLink {
    return this.LocationDetailPanelSet.LocationDetailCV.LocationDetailDV.LocationDetailInputSet.TerritoryCodeInputSet.AutofillLink
  }

  property get TerritoryCode() : TerritoryCodeInputSet.entry.TerritoryCode {
    return this.LocationDetailPanelSet.LocationDetailCV.LocationDetailDV.LocationDetailInputSet.TerritoryCodeInputSet._Entries.first().TerritoryCode
  }

  /**
   * This method will fill the fields related to the new lcoation and ensure the
   * button is clicked to autofill to corresponding territory code associated
   * with the address.
   *
   * @param newPolicyLocation - Address to be used for the new location
   */
  function fillLocationInfo(newPolicyLocation : Map<String, String>){
    UIHelper.setFieldValues(this, new UIFieldsProviderBase(newPolicyLocation) {

      override property get RequiredFields() : Set<String> {
        return {DisplayKey.get("Web.AddressBook.AddressInputSet.Address1"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.City"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.County"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.State"),
            DisplayKey.get("Web.AddressBook.AddressInputSet.ZIP")}
      }

      override property get DefaultFields() : Map<String, String> {
        return {
        }
      }
    })

    AutoFillTerritoryCode.click()
  }
}