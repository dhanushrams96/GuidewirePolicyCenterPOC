package gw.enhancement.contacts
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.ValueElement

enhancement NewContactBaseEnhancement : pcftest.NewContact {

  function update() : PCFLocation {
    if (this.ForceDupCheckUpdate.Visible) {
      return this.ForceDupCheckUpdate.click()
    } else {
      return this.Update.click()
    }
  }

  property get CompanyName() : ValueElement {
    return this.ContactPanelSet.ContactCV.ContactDV.ContactNameInputSet_company.DefaultCompanyName
  }

  property get ContactDV() : pcftest.ContactPanelSet.ContactCV.ContactDV {
    return this.ContactPanelSet.ContactCV.ContactDV
  }

  property get PreferredSettlementCurrency() : pcftest.ContactCurrencyInputSet.PreferredSettlementCurrency {
    return ContactDV.ContactCurrency.ContactCurrencyInputSet.PreferredSettlementCurrency
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return ContactDV.AddressInputSet.Country
  }

}
