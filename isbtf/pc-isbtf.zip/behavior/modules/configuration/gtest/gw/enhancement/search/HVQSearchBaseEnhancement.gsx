package gw.enhancement.search

uses pcftest.HVQPolicySearchPanelSet
uses pcftest.HVQSearch
uses pcftest.HVQSearch_ResultsLV


enhancement HVQSearchBaseEnhancement : HVQSearch {

  property get SearchDV() : HVQPolicySearchPanelSet.HVQPolicySearchDV { return this.HVQSearchScreen.HVQPolicySearchPanelSet.HVQPolicySearchDV }

  property get SearchResults() : HVQSearch_ResultsLV { return this.HVQSearchScreen.HVQPolicySearchPanelSet.getHVQSearch_ResultsLV() }

}
