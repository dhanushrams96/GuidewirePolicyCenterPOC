package gw.enhancement.job.common

uses entity.Address
uses org.junit.Assert
uses pcftest.AddressesPanelSet

enhancement AddressesPanelSetBaseEnhancement : AddressesPanelSet {

  function addAddress() {
    this.AddressesLV_tb.Add.click()
  }

   function markAsPrimaryAddress(address : Address) {
    markAsPrimaryAddress(address.addressString(",", false, false))
  }

  function markAsPrimaryAddress(addrName : String) {
    getMatchingAddressRow(addrName).Primary.click()
  }

  function removeAddress(address : Address) {
    removeAddress(address.addressString(",", false, false))
  }

  function removeAddress(addrName : String) {
    getMatchingAddressRow(addrName)._Checkbox.click()
    this.AddressesLV_tb.Remove.click()
  }

  function selectAddress(address : Address) {
    selectAddress(address.addressString(",", false, false))
  }

  function selectAddress(addrName : String) {
    getMatchingAddressRow(addrName)._Select.click()
  }

  function viewAddressDetail(address : Address) {
    viewAddressDetail(address.addressString(",", false, false))
  }

  function viewAddressDetail(addrName : String) {
    getMatchingAddressRow(addrName).viewDetail()
  }

  property get MergeAddressButtonSafely() : AddressesPanelSet.MergeAddresses {
    try {
      this.AddressToolsCardTab.click()
    } catch (t : Throwable) {print("Caught throwable: " + t.Message)}
    return this.MergeAddresses
  }

  function getMatchingAddressRow(addrName : String) : AddressesPanelSet.AddressesLV.entry {
    var addresses = getMatchingAddressRows(addrName)
    Assert.assertTrue("Found " + addresses.Count + " address with DisplayName \"" + addrName + "\"", addresses.Count == 1)
    return addresses.first()
  }

  function getMatchingAddressRows(addrName : String) : List<AddressesPanelSet.AddressesLV.entry> {
    return this.AddressesLV._Entries.where(\ a -> a.DisplayedName.Value == addrName)
  }

}
