package gw.enhancement.job.policychange

uses gw.cucumber.util.lob.pa.VehicleIdentifier
uses gw.smoketest.platform.web.PCFLocation
uses pcftest.PolicyChangeWizard_QuoteScreen

@Export
enhancement PolicyChangeWizard_QuoteScreenBaseEnhancement : PolicyChangeWizard_QuoteScreen {

  function clickBind() : PCFLocation {
    return this.BindPolicyChangeButton.click()
  }

  /**
   * Label: "Bind"<br>
   */
  property get BindPolicyChangeButton() : pcftest.JobWizardToolbarButtonSet_PolicyChange.BindPolicyChange {
    return this.JobWizardToolbarButtonSet_PolicyChange.BindPolicyChange
  }

  function getPAVehicleEntry(vIdentifier : VehicleIdentifier) : pcftest.RatingTxDetailsPanelSet_PersonalAutoLine.vehicleIterator.entry{
    return this.RatingTxDetailsPanelSet_PersonalAutoLine.vehicleIterator._Entries
        .singleWhere(\vehiclePanel -> {
          var vehicleEntry = new VehicleIdentifier(vehiclePanel.Year.Text, vehiclePanel.Make.Text, vehiclePanel.Model.Text)
          return vIdentifier.equals(vehicleEntry)
        })
  }
}