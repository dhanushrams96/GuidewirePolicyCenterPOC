package gw.enhancement.account
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.ValueElement
uses gw.smoketest.platform.web.CheckboxValueElement

enhancement AccountFile_AccountSearchBaseEnhancement : pcftest.AccountFile_AccountSearch {
  
  property get AccountNumber () : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AccountNumber
  }  
  
  property get TaxID () : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.TaxID
  }  
  
  property get CompanyName () : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.GlobalContactNameInputSet_default.Name
  }  
  
  property get FirstName () : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.GlobalPersonNameInputSet_default.FirstName
  }  
  
  property get LastName () : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.GlobalPersonNameInputSet_default.LastName
  }

  property get CityUS() : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.City
  }
  
  property get CountyUS() : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.County
  }

  property get StateUS() : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.State
  }
  
  property get PostalCodeUS() : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.PostalCode
  }
  
  property get CountryUS() : ValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.Country
  }
  
  property get SearchRelatedAccountsOnly() : CheckboxValueElement {
    return this.OtherAccountSearchScreen.AccountSearchDV.SearchRelatedAccountsOnly
  }
  
  property get SearchButton() : pcftest.SearchLinksInputSet.Search {
    return this.OtherAccountSearchScreen.AccountSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search
  }
  
  property get ResetButton() : pcftest.SearchLinksInputSet.Reset {
    return this.OtherAccountSearchScreen.AccountSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset
  }
  
  function searchByAccountNumber(acctNumber : String){
    AccountNumber.Value = acctNumber
    SearchButton.click()
  }  
  
  function searchAndSelectAccountByNumber(acctNumber : String) :  PCFLocation {
    AccountNumber.Value = acctNumber
    SearchButton.click()
    var entry = this.OtherAccountSearchScreen.OtherAccountSearchResultsLV._Entries.single()
    return entry.Select.click()
  }   
  
  //----------------------------------------------------------------- Search Results
  
  property get AccountSearchResults () : gw.smoketest.platform.web.IteratorEntriesWithPaging<pcftest.OtherAccountSearchResultsLV.entry>{
    return this.OtherAccountSearchScreen.OtherAccountSearchResultsLV._Entries
  }

}
