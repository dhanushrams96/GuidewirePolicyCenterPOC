package gw.enhancement.contacts
uses gw.api.databuilder.UniqueKeyGenerator
uses gw.smoketest.platform.web.ValueElement

enhancement ContactNameInputSet_companyBaseEnhancement : pcftest.ContactNameInputSet_company {

  function withName(name : String) : pcftest.ContactNameInputSet_company{
    this.DefaultCompanyName.Value = name
    return this
  }

  function withEmailAddress1(address1 : String) : pcftest.ContactNameInputSet_company{
    this.EmailAddress1.Value = address1
    return this
  }

  function withWorkPhone(workPhone : String) : pcftest.ContactNameInputSet_company{
    this.WorkPhoneNumber.Value = workPhone
    return this
  }

  function fillDefaults() : pcftest.ContactNameInputSet_company {
    var key = UniqueKeyGenerator.get().nextKey()
    this.DefaultCompanyName.Value = key
    this.EmailAddress1.Value = "${key}1@${key}.com"
    this.EmailAddress2.Value = "${key}2@${key}.com"
    this.FaxPhoneNumber.Value = "510-455-4566"
    this.WorkPhoneNumber.Value = "420-345-2344"
    return this
  }

  property get DefaultCompanyName(): ValueElement {
    return this.GlobalContactNameInputSet_default.Name
  }

  property get WorkPhoneNumber() : ValueElement{
    return this.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneNumber() : ValueElement{
    return this.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

}
