package gw.enhancement.account

uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.IteratorEntriesWithPaging

uses java.lang.IllegalStateException
uses java.lang.IllegalArgumentException
uses java.util.Map
uses java.lang.RuntimeException
uses gw.api.upgrade.Coercions

enhancement ContactSearchScreenBaseEnhancement : pcftest.ContactSearchScreen
{
  function searchContact(contact : Contact){
    search(contact)
  }

  function setContactTypeToPerson() {
    if (this.ContactType.Text.toLowerCase() != "person") {
      this.ContactType.clickFirstOptionWithMatchingValue(\string -> string == typekey.Contact.TC_PERSON.Code)
    }
  }

  function setContactTypeToCompany() {
    if (this.ContactType.Text.toLowerCase() != "company") {
      this.ContactType.clickFirstOptionWithMatchingValue(\string -> string == typekey.Contact.TC_COMPANY.Code)
    }
  }

  function searchByAddress(contactType : ContactType,
                           city : String,
                           county : String,
                           state : String,
                           country : String,
                           postalCode : String) {

    if (contactType == TC_PERSON) {
      setContactTypeToPerson()
    } else if (contactType == TC_COMPANY) {
      setContactTypeToCompany()
    } else {
      throw new IllegalArgumentException("Search called with unsupported contact type")
    }
    if (null != city) {
      this.AddressOwnerAddressInputSet.City.Value = city
    }
    if (null != county) {
      this.AddressOwnerAddressInputSet.County.Value = county
    }
    if (null != state) {
      this.AddressOwnerAddressInputSet.State.Value = state
    }
    if (null != country) {
      this.AddressOwnerAddressInputSet.Country.Value = country
    }
    if (null != postalCode) {
      this.AddressOwnerAddressInputSet.PostalCode.Value = postalCode
    }

    search()
  }

  property set SSN(taxId : String) {
    this.BasicContactInfoInputSet_person.TaxID.Value = taxId
  }

  function searchPersonByTaxID(taxId : String) {
    setContactTypeToPerson()
    SSN = taxId
    search()
  }

  function setPersonSearchFields(firstName : String, lastName : String, zip : String) {
    setContactTypeToPerson()
    this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.FirstName.Value = firstName
    this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.LastName.Value = lastName
    this.AddressOwnerAddressInputSet.PostalCode.Value = zip
  }

  function searchPersonFromName(firstName : String, lastName : String) {
    setPersonSearchFields(firstName, lastName, "94403")
    search()
  }

  function searchPersonFromName(firstName : String, lastName : String, zip : String) {
    setPersonSearchFields(firstName, lastName, zip)
    search()
  }

  function searchPersonFromNameAndSSN(firstName : String, lastName : String, taxId : String) {
    setContactTypeToPerson()
    this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.FirstName.Value = firstName
    this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.LastName.Value = lastName
    SSN = taxId
    search()
  }

  function setCompanySearchFields(companyName : String) {
    setContactTypeToCompany()
    this.BasicContactInfoInputSet_company.GlobalContactNameInputSet_default.Name.Value = companyName
  }

  property set FEIN(taxId : String) {
    this.BasicContactInfoInputSet_company.TaxID.Value = taxId
  }

  function searchCompanyFromName(companyName : String) {
    setCompanySearchFields(companyName)
    search()
  }

  function searchCompanyFromNameAndFEIN(companyName : String, taxId: String) {
    setCompanySearchFields(companyName)
    FEIN = taxId
    search()
  }

  function searchCompanyByTaxId(taxId : String) {
    setContactTypeToCompany()
    FEIN = taxId
    search()
  }

  private function clickNameOrSelect(row : pcftest.ContactSearchScreen.ContactSearchResultsLV.entry) : PCFLocation {
    if( row._Select.Visible ) {
      return row.select()
    } else {
      return row.Name.click()
    }
  }

  function searchAndSelectContact(contact : Contact) : PCFLocation {
    searchContact(contact)
    return clickNameOrSelect(this.ContactSearchResultsLV._Entries.first())
  }

  function searchAndSelectFirstPersonFromName(firstName : String, lastName : String, zip : String) : PCFLocation {
    searchPersonFromName(firstName, lastName, zip)
    return clickNameOrSelect(this.ContactSearchResultsLV._Entries.first())
  }

  function searchAndSelectFirstCompanyFromName(companyName : String) : PCFLocation {
    searchCompanyFromName(companyName)
    return clickNameOrSelect(this.ContactSearchResultsLV._Entries.first())
  }

  function searchAndSelectPersonFromName(firstName : String, lastName : String) : PCFLocation {
    return searchAndSelectPersonFromName(firstName,lastName,"94403")
  }

  function searchAndSelectPersonFromName(firstName : String, lastName : String, zip : String) : PCFLocation {
    searchPersonFromName(firstName, lastName, zip)
    var row = this.Results.firstWhere(\ contSearchRes -> contSearchRes.Name.Value == firstName + " " + lastName)
    if(row == null){
      throw new IllegalStateException("Could not find contact: ${firstName} ${lastName}")
    }
    return clickNameOrSelect(row)
  }

  function searchAndSelectCompanyFromName(companyName : String) : PCFLocation {
    searchCompanyFromName(companyName)
    var row = this.Results.firstWhere(\ contSearchRes -> contSearchRes.Name.Text == companyName)
    return clickNameOrSelect(row)
  }

  function search(contact : Contact) {
    if(contact typeis Person){
      this.ContactType.Value = "Person"
      this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.FirstName.Value = contact.FirstName
      this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.LastName.Value = contact.LastName
      this.BasicContactInfoInputSet_person.TaxID.Value = contact.TaxID
    }else{
      this.ContactType.Value = "Company"
      this.BasicContactInfoInputSet_company.GlobalContactNameInputSet_default.Name.Value = (contact as Company).Name
      this.BasicContactInfoInputSet_company.TaxID.Value = (contact as Company).TaxID
    }
    search()
  }

  function verifyContactIsExcluded(contact : Contact) {
    search(contact)
    if(this.Results.hasMatch(\ c -> c.Name.Text == contact.DisplayName)){
      throw new IllegalStateException("Should not found contact " + contact.DisplayName)
    }
  }

  function reset() {
    this.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
  }

  function search() {
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  property get Results() : IteratorEntriesWithPaging<pcftest.ContactSearchScreen.ContactSearchResultsLV.entry> {
    return this.ContactSearchResultsLV._Entries
  }

  private function setAddressCriteria(k : String, value : String) : boolean {
    if (k == "City") this.AddressOwnerAddressInputSet.City.Value = value
    else if (k == "State") this.AddressOwnerAddressInputSet.State.Value = value
    else if (k == "PostalCode") this.AddressOwnerAddressInputSet.PostalCode.Value = value
    else return false
    return true
  }

  function setCompanyCriteria(criteria : Map<String,String>) {
    this.BasicContactInfoInputSet_company.CompanyNameExact.BoolValue = false
    this.ContactType.clickFirstOptionWithMatchingLabel(\ string -> string == "Company")
    for (k in criteria.Keys) {
      if (k == "Name") this.BasicContactInfoInputSet_company.GlobalContactNameInputSet_default.Name.Value = criteria[k]
      else if (k == "TaxID") this.BasicContactInfoInputSet_company.TaxID.Value = criteria[k]
      else if (k == "Phone") this.BasicContactInfoInputSet_company.PhoneNumber.Value = criteria[k]
      else if (k == "NameExact") this.BasicContactInfoInputSet_company.CompanyNameExact.BoolValue = Coercions.makeBooleanFrom(criteria[k])
      else if (setAddressCriteria(k,criteria[k])) {/* NOOP. Address criteria was correctly set */}
      else throw new RuntimeException("Invalid search criteria in test, " + k)
    }
  }

  function setPersonCriteria(criteria : Map<String,String>) {
    this.ContactType.clickFirstOptionWithMatchingLabel(\ string -> string == "Person")
    this.BasicContactInfoInputSet_person.FirstNameExact.BoolValue = false
    this.BasicContactInfoInputSet_person.LastNameExact.BoolValue = false
    for (k in criteria.Keys) {
      if (k == "FirstName") this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.FirstName.Value = criteria[k]
      else if (k == "FirstNameExact") this.BasicContactInfoInputSet_person.FirstNameExact.BoolValue = Coercions.makeBooleanFrom(criteria[k])
      else if (k == "LastName") this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_default.LastName.Value = criteria[k]
      else if (k == "LastNameExact") this.BasicContactInfoInputSet_person.LastNameExact.BoolValue = Coercions.makeBooleanFrom(criteria[k])
      else if (k == "TaxID") this.BasicContactInfoInputSet_person.TaxID.Value = criteria[k]
      else if (k == "Phone") this.BasicContactInfoInputSet_person.Phone.Value = criteria[k]
      else if (setAddressCriteria(k,criteria[k])) {/* NOOP. Address criteria was correctly set */}
      else throw new RuntimeException("Invalid search criteria in test, " + k)
    }
  }

  function getLVResults() : Map<String,String>[] {
    var resultSet = this.ContactSearchResultsLV._Entries.map(\ c -> {return {
        "name" -> c.Name.Text,
        "phone" -> c.Phone.Text,
        "address" -> c.Address.Text,
        "email" -> c.Email.Text
    }}).toTypedArray()
    return resultSet
  }

  function searchPersonByCriteria(criteria : Map<String,String>) : Map<String,String>[]{
    this.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
    setPersonCriteria(criteria);
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
    return getLVResults()
  }

  function searchCompanyByCriteria(criteria : Map<String,String>) : Map<String,String>[]{
    this.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()
    setCompanyCriteria(criteria);
    this.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
    return getLVResults()
  }

  // Returns the name fields displayed when the user is in the Japan locale
  property get KanjiNameFields() : pcftest.GlobalPersonNameInputSet_Japan {
    return this.BasicContactInfoInputSet_person.GlobalPersonNameInputSet_Japan
  }

}
