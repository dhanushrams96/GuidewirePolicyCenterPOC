package gw.enhancement.job.cancellation

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses org.junit.Assert
uses pcftest.CancellationWizard
uses pcftest.JobWizardToolsMenuWizardStepSet
uses pcftest.Job_RiskAnalysisScreen

enhancement CancellationWizardBaseEnhancement : CancellationWizard {

  function clickCancelNow() : PCFLocation {
    return this.ViewQuote.CancellationWizard_QuoteScreen.JobWizardToolbarButtonSet_Cancellation.BindOptions.CancelNow.click()
  }

}
