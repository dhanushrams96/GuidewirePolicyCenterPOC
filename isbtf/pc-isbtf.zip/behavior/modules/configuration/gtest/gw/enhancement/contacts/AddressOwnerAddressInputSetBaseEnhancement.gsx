package gw.enhancement.contacts

uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement

enhancement AddressOwnerAddressInputSetBaseEnhancement : pcftest.AddressOwnerAddressInputSet {

  property get AddressLine1() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine1
  }

  property get AddressLine2() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine2
  }

  property get AddressLine3() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.AddressLine3
  }

  property get City() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.City
  }

  property get County() : ValueElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.County
  }

  property get State() : SelectElement {
    return this.globalAddressContainer.GlobalAddressInputSet_default.State
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return this.globalAddressContainer.GlobalAddressInputSet_default.Country
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return this.globalAddressContainer.GlobalAddressInputSet_default.PostalCode
  }

}
