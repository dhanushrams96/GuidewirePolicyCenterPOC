package gw.enhancement.job.submission

uses pcftest.QuickSubmission_QuoteScreen

enhancement QuickSubmission_QuoteScreenTestEnhancement : QuickSubmission_QuoteScreen {

  function quote() {
    this.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
  }

}