package gw.enhancement.search

uses gw.smoketest.platform.web.CheckboxValueElement
uses gw.smoketest.platform.web.ValueElement
uses pcftest.AccountSearch

enhancement AccountSearchBaseEnhancement : AccountSearch {

  property get FirstName() : ValueElement {
    return this.AccountSearchScreen.AccountSearchDV.GlobalPersonNameInputSet_default.FirstName
  }

  property get LastName() : ValueElement {
    return this.AccountSearchScreen.AccountSearchDV.GlobalPersonNameInputSet_default.LastName
  }

  property get FirstNameExact() : CheckboxValueElement {
    return this.AccountSearchScreen.AccountSearchDV.FirstNameExact
  }

  property get LastNameExact() : CheckboxValueElement {
    return this.AccountSearchScreen.AccountSearchDV.LastNameExact
  }

  function clickSearchButton() : gw.smoketest.platform.web.PCFLocation {
    return SearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()
  }

  property get SearchDV() : pcftest.AccountSearchDV {
    return this.AccountSearchScreen.AccountSearchDV
  }

  property get Zip() : ValueElement {
    return this.AccountSearchScreen.AccountSearchDV.AddressOwnerAddressInputSet.PostalCode
  }

  property get CompanyName() : ValueElement {
    return this.AccountSearchScreen.AccountSearchDV.GlobalContactNameInputSet_default.Name
  }

  property get CompanyNameExact() : CheckboxValueElement {
    return this.AccountSearchScreen.AccountSearchDV.CompanyNameExact
  }

  property get AccountNumber() : ValueElement {
    return this.AccountSearchScreen.AccountSearchDV.AccountNumber
  }

  property get AccountSearchResultsLV() : pcftest.AccountSearchResultsLV {
    return this.AccountSearchScreen.AccountSearchResultsLV
  }

  property get PrintExportPopup() : pcftest.PrintOptionPopup {
    return this.AccountSearchScreen.AccountSearchResultsLV_tb.PrintMe.click() as pcftest.PrintOptionPopup
  }

}
