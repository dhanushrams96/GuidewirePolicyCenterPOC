package gw.enhancement.policy

@Export
enhancement Policy_NotesScreenEnhancement : pcftest.Policy_NotesScreen {

  function verifyNoteExists(subject : String, bodyText : String) : Boolean {
    return verifyLocalizedNoteExists(subject, bodyText, null)
  }

  function verifyLocalizedNoteExists(subject : String, bodyText : String, locale : LanguageType) : Boolean {
    return getNoteEntryByLanguage(subject, bodyText, locale) == null ? false : true
  }

  function getNoteEntryByLanguage(subject : String, bodyText : String, locale : LanguageType) : pcftest.NotesLV.entry {
    var noteSearchDV = this.NoteSearchDV
    noteSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Reset.click()

    noteSearchDV.TextSearch.Value = subject
    if (locale != null) {
      noteSearchDV.Language.TypeKeyValue = locale
    }
    noteSearchDV.SearchAndResetInputSet.SearchLinksInputSet.Search.click()

    var notesInLV = this.NotesLV
    return notesInLV._Entries.firstWhere(\ d ->
        d.NoteRowSet.Body.Text.containsIgnoreCase(bodyText)
            and d.NoteRowSet.Subject.Text.containsIgnoreCase(subject))
  }

}
