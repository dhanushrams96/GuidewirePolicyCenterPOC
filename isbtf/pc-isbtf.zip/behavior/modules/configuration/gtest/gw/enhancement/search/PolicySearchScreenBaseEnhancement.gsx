package gw.enhancement.search

enhancement PolicySearchScreenBaseEnhancement : pcftest.PolicySearchScreen {

  property get DataBaseSearchDV() : pcftest.DatabasePolicySearchPanelSet.PolicySearchDV {
    return this.DatabasePolicySearchPanelSet.PolicySearchDV
  }

  property get DatabaseSearchTabActive() : boolean {
    return this.DatabasePolicySearchPanelSet.PolicySearch_ResultsLV_Policy.PolicyNumberHeader.Visible
  }

  property get SolrSearchTabActive() : boolean {
    return this.SolrPolicySearchPanelSet.solrResultsLV.rankHeader.Visible
  }

}
