package gw.enhancement.job.common

uses pcftest.MultiQuoteAcceleratedMenuActions

enhancement PolicyPeriodSelectorBaseEnhancement : MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {

  property get Optionlabels() : List<String> {
    return this.PolicyPeriodSelector_Arg.OptionLabels.toList()
  }

}
