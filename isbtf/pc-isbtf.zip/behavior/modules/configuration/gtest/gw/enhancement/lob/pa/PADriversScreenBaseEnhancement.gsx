package gw.enhancement.lob.pa

uses gw.api.locale.DisplayKey
uses gw.smoketest.platform.web.ValueElement
uses pcftest.PADriversScreen

enhancement PADriversScreenBaseEnhancement : PADriversScreen {

  property get PAVehicleAddlInterest() : pcftest.PolicyAddlInterestPanelSet_PAVhcleAddlInterest {
    return this.PolicyAddlInterest._Entries.firstWhere(\ p -> p.PolicyAddlInterestPanelSet_PAVhcleAddlInterest._Entries.Count > 0).PolicyAddlInterestPanelSet_PAVhcleAddlInterest
  }

  property get PolicyAddlInterest() : pcftest.PolicyContactRolePanelSet_PolicyAddlInterest{
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV._Entries.firstWhere(\ p -> p.PolicyContactRolePanelSet_PolicyAddlInterest._Entries.Count > 0).PolicyContactRolePanelSet_PolicyAddlInterest
  }

  property get PolicyDriver() : pcftest.PolicyContactRolePanelSet_PolicyDriver {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV._Entries.firstWhere(\ p -> p.PolicyContactRolePanelSet_PolicyDriver.PolicyDriverInfoDV.gooddriverdiscount.Visible == true).PolicyContactRolePanelSet_PolicyDriver
  }

  property get PolicyContactRoleNameInputSet_person() : pcftest.PolicyContactRoleNameInputSet_person {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.PolicyContactRoleNameInputSet_person
  }

  property get DriversLV(): pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV {
    return this.PADriversPanelSet.DriversListDetailPanel.DriversLV
  }

  property get DriverDetails(): pcftest.LicenseInputSet_PolicyDriver {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.LicenseInputSet_PolicyDriver
  }

  property get AddressDetails() : pcftest.AddressInputSet {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.AddressInputSet
  }

  property get AddressType() : pcftest.PolicyContactDetailsDV.AddressType {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.AddressType
  }

  property get PreferredSettlementCurrency() : pcftest.ContactCurrencyInputSet.PreferredSettlementCurrency {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.ContactCurrency.ContactCurrencyInputSet.PreferredSettlementCurrency
  }

  property get AddressDescription() : ValueElement {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV.AddressDescription
  }

  property get DriverLVToolbar() : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb {
    return this.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb
  }

  property get AddExistingDriverLink():pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.AddExistingContact {
    return this.DriverLVToolbar.AddDriver.AddExistingContact
  }

  property get AddNewPersonButton() : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.entry.ContactType {
    return this.DriverLVToolbar.AddDriver._Entries.firstWhere(\ p -> p.ContactType.Text == DisplayKey.get("Web.Contact.AddNewOfType", ContactType.TC_PERSON)).ContactType
  }

  property get AddFromSearchContactButton() : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.AddFromSearch {
    return this.DriverLVToolbar.AddDriver.AddFromSearch
  }

  property get UnassignedDrivers() : gw.smoketest.platform.web.IteratorEntries<pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.AddExistingContact.entry> {
    return this.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.AddExistingContact._Entries
  }

  property get ContactAddresses() : pcftest.AddressesPanelSet.AddressDetailDV {
    this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.AddressDetailCardTab.click()
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.AddressesPanelSet.AddressDetailDV
  }

  property get PolicyContactDetailsDV() : pcftest.PolicyContactDetailsDV {
    return this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailsDV
  }

  function addExistingDriver() {
    var entry = AddExistingDriverLink._Entries
    if (entry.Count > 0) {
      entry.get(0).UnassignedDriver.click()
      defaultYearLicensedAndIncidents()
    }
  }

  function addExistingDriver(driverName : String) {
    getAddExistingDriverWithName(driverName).click()
    defaultYearLicensedAndIncidents()
  }

  function getAddExistingDriverWithName(name : String) : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV_tb.AddDriver.AddExistingContact.entry.UnassignedDriver {
    return AddExistingDriverLink._Entries.firstWhere(\ p -> p.UnassignedDriver.Text == name).UnassignedDriver
  }

  public function getDriverWithName(name : String) : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV.entry {
    var drivers = this.DriversLV._Entries.where(\driver -> driver.Name.Value == name)
    return drivers.first()
  }

  public function selectDriverWithName(name : String) : pcftest.PADriversPanelSet.DriversListDetailPanel.DriversLV.entry {
    var driver = getDriverWithName(name)
    driver.viewDetail()
    return driver
  }

  public function removeDriverWithName(name : String) {
    var driver = getDriverWithName(name)
    driver._Checkbox.click()
    this.DriverLVToolbar.Remove.click()
  }

  // required field
  function defaultYearLicensedAndIncidents() {
    var inRoles = true
    if (PolicyDriver == null) {
      inRoles = false
      this.goToRolesTab()
    }
    PolicyDriver.PolicyDriverInfoDV.yearlicensed.Value = "1988"
    PolicyDriver.PolicyDriverNumberOfAccidents.TypeKeyValue = NumberOfAccidents.TC_0
    PolicyDriver.PolicyDriverNumberOfViolations.TypeKeyValue = NumberOfAccidents.TC_0
    PolicyDriver.DriverNumberOfAccidents.TypeKeyValue = NumberOfAccidents.TC_0
    PolicyDriver.DriverNumberOfViolations.TypeKeyValue = NumberOfAccidents.TC_0
    if (not inRoles) {
      this.goToContactDetailsTab()
    }
  }


  function setPolicyMVRDataFromMVR() {
    this.goToRolesTab()

    for (driverEntry in this.DriversLV._Entries.listIterator()) {
      driverEntry.viewDetail()
      if (this.PolicyDriver.MVRNumberofAccidents != null) {
        this.PolicyDriver.PolicyDriverNumberOfAccidents.Value = this.PolicyDriver.MVRNumberofAccidents.Value
        this.PolicyDriver.PolicyDriverNumberOfViolations.Value = this.PolicyDriver.MVRNumberofViolations.Value
      }
    }
  }

  property set DoNotOrderMVR(doNotOrder: boolean) {
    if (this.PolicyDriver == null) {
      this.goToRolesTab()
    }
    this.PolicyDriver.PolicyDriverInfoDV.DoNotOrderMVR.BoolValue = doNotOrder
  }

  property get DoNotOrderMVR(): boolean{
    if (this.PolicyDriver == null) {
      this.goToRolesTab()
    }
    return this.PolicyDriver.PolicyDriverInfoDV.DoNotOrderMVR.BoolValue
  }

  function goToContactDetailsTab() {
    var tab = this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.PolicyContactDetailCardTab
    if (tab.Visible and tab.Enabled) {
      tab.click()
    }
  }

  function goToRolesTab() {
    var tab = this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.RolesCardTab
    if (tab.Visible and tab.Enabled) {
      tab.click()
    }
  }

  function goToAddressDetailTab() {
    var tab = this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.AddressDetailCardTab
    if (tab.Visible and tab.Enabled) {
      tab.click()
    }
  }

  function goToMotorVehicleRecordTab() {
    var tab = this.PADriversPanelSet.DriversListDetailPanel.DriverDetailsCV.MVRDetailCardTab
    if (tab.Visible and tab.Enabled) {
      tab.click()
    }
  }

}
