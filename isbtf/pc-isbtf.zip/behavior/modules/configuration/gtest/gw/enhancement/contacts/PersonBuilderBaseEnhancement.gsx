package gw.enhancement.contacts

uses gw.api.builder.AddressBuilder
uses gw.api.builder.PersonBuilder
uses gw.api.databuilder.UniqueKeyGenerator

enhancement PersonBuilderBaseEnhancement : PersonBuilder {

  function asDriver(age : int) : PersonBuilder {
    this.withPrimaryAddress(new AddressBuilder())
        .withDateOfBirth(Date.CurrentDate.addYears(-age))
        .withLicenseState(Jurisdiction.TC_CA)
        .withLicenseNumber(UniqueKeyGenerator.get().nextKey())
    return this
  }
}