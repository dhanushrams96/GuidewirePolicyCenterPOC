package gw.enhancement.job.rewritenewaccount

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.pc.lob.pa.RewriteNewAccountWizardPAMode
uses gw.smoketest.platform.web.WizardMenuLinkElement

enhancement RewriteNewAccountWizardBaseEnhancement: pcftest.RewriteNewAccountWizard {

  property get PAMode() : RewriteNewAccountWizardPAMode {
    return new RewriteNewAccountWizardPAMode(this)
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage(this)
    AssertUtil.assertOnScreen(step)
  }

}
