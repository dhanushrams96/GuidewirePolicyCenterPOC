package gw.suites

uses cucumber.api.CucumberOptions
uses cucumber.api.SnippetType
uses cucumber.api.junit.Cucumber
uses org.junit.runner.RunWith

@Export
@RunWith(Cucumber)
@CucumberOptions(
    :dryRun = false,
    :plugin = {"pretty",
        "html:build/test-results/PCBehaviorCucumberSuite/CucumberHTMLReport",
        "junit:build/test-results/PCBehaviorCucumberSuite/CucumberResults.xml"},
    :monochrome = true,
    :glue = {"gw.cucumber"},
    :snippets = SnippetType.CAMELCASE,
    :strict = true,
    :features = {"res/cucumber"}
)
class PCBehaviorCucumberSuite {}
