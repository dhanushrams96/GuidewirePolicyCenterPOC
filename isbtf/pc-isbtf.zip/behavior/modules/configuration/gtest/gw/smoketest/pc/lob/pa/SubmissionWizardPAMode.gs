package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.SubmissionWizardWrapper
uses org.junit.Assert

class SubmissionWizardPAMode extends SubmissionWizardWrapper {

  construct(wizard : pcftest.SubmissionWizard) {
    super(wizard)
  }

  property get PAStep() : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPAStep() : pcftest.PersonalAutoScreen {
    if (not PAStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = PAStep.click()
    assertOnStep(PAStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    if (not VehiclesStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    if (not DriversStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

  function goToSideBySidePage() : pcftest.SideBySideScreen {
    return _wizard.goToSideBySidePage()
  }

  override function saveDraft() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (PolicyReviewStep.Current) {
       PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (QuoteStep.Current) {
       QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if ( OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else {
      Assert.fail("Unable to save draft")
    }
  }

  override function asyncQuote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (QuoteStep.Current) {
      QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      Assert.fail("Unable to quote asynchronously")
    }
  }

  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (PolicyReviewStep.Current) {
       PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (QuoteStep.Current) {
       QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else {
      Assert.fail("Unable to quote")
    }
  }

}
