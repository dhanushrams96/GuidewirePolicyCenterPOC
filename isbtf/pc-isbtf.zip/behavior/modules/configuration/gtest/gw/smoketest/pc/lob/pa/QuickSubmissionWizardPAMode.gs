package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.QuickQuoteSubmissionWizardWrapper
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses gw.smoketest.pc.commons.AssertUtil

class QuickSubmissionWizardPAMode extends QuickQuoteSubmissionWizardWrapper {

  construct(wizard : pcftest.QuickSubmissionWizard) {
    super(wizard)
  }

  property get InfoStep() : pcftest.LineQuickWizardStepSet_PersonalAuto.PAQuickSubmission_Info {
    return _wizard.LOBWizardStepGroup.LineQuickWizardStepSet_PersonalAuto.PAQuickSubmission_Info
  }
  
  property get QuoteStep() : pcftest.QuickSubmissionWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  function goToInfoStep() : pcftest.PAQuickSubmission_InfoScreen {
    var screen = InfoStep.click()
    assertOnStep(InfoStep)
    return screen
  }
  
  function goToQuoteStep() : pcftest.QuickSubmission_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  function quote() : pcftest.QuickSubmission_QuoteScreen {
    var quoteScreen = this.goToQuoteStep()
    quoteScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_QuickQuote.Quote.click()
    return quoteScreen
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage(_wizard)
    AssertUtil.assertOnScreen(step)  
  }

}
