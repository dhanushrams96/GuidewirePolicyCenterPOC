package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.IssuanceWizardWrapper

class IssuanceWizardPAMode extends IssuanceWizardWrapper {

  construct(wizard : pcftest.IssuanceWizard) {
    super(wizard)
  }

  property get PAStep() : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPAStep() : pcftest.PersonalAutoScreen {
    var screen = PAStep.click()
    assertOnStep(PAStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

}
