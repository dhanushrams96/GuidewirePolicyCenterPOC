package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses org.junit.Assert

class RenewalWizardWrapper {

  protected var _wizard : pcftest.RenewalWizard

  construct(wizard : pcftest.RenewalWizard) {
    _wizard = wizard
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  property get Next() : pcftest.RenewalWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.RenewalWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  property get OfferingStep() : pcftest.RenewalWizard.Offering {
    return _wizard.Offering
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  function selectMultiQuoteVersion(branchName : String) {
    MultiQuoteSelector.PolicyPeriodSelector_Arg.clickByLabelSubstr(branchName)
  }

  property get PolicyInfoStep() : pcftest.RenewalWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  function goToPolicyInfoStep() : pcftest.RenewalWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  property get FormsStep() : pcftest.RenewalWizard.PostQuoteWizardStepSet.Forms {
    return _wizard.PostQuoteWizardStepSet.Forms
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  property get RiskAnalysisStep() : pcftest.RenewalWizard.LOBWizardStepGroup.RiskAnalysis {
    return _wizard.LOBWizardStepGroup.RiskAnalysis
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  property get PolicyReviewStep() : pcftest.RenewalWizard.LOBWizardStepGroup.PolicyReview {
    return _wizard.LOBWizardStepGroup.PolicyReview
  }

  function goToPolicyReviewStep() : pcftest.RenewalWizard_DifferencesScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  property get QuoteStep() : pcftest.RenewalWizard.PostQuoteWizardStepSet.ViewQuote {
    return _wizard.PostQuoteWizardStepSet.ViewQuote
  }

  function goToQuoteStep() : pcftest.RenewalWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  property get PaymentStep() : pcftest.RenewalWizard.PostQuoteWizardStepSet.BillingInfo {
    return _wizard.PostQuoteWizardStepSet.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get MenuActions_Renewal () : pcftest.WizardActionsMenuItemSet_default {
    return _wizard.WizardMenuActions.WizardMenuActions_Goto.WizardActionsMenuItemSet_default
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  property get MultiQuoteSelector(): pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return _wizard.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get MultiQuoteSelectorText() : String {
    return MultiQuoteSelector.PolicyPeriodSelector_Arg.Text
  }

  function goToPaymentStep() : pcftest.RenewalWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  function quote() {}

  function asyncRate() {}

  function asyncQuote() {}

  function renew() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.SendToRenewal.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RenewalWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.SendToRenewal.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.SendToRenewal.click()
    } else if (QuoteStep.Current) {
      QuoteStep.RenewalWizard_QuoteScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.SendToRenewal.click()
    } else {
      Assert.fail("Unable to renew renewal")
    }
  }

  function issue() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.IssueNow.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RenewalWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.IssueNow.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.IssueNow.click()
    } else if (QuoteStep.Current) {
      QuoteStep.RenewalWizard_QuoteScreen.JobWizardToolbarButtonSet_Renewal.BindOptions.IssueNow.click()    
    } else if (PaymentStep.Current) {
      PaymentStep.RenewalWizard_PaymentScreen.JobWizardBillingToolbarButtonSet_Renewal.BindOptions.IssueNow.click()
    } else {
      Assert.fail("Unable to issue renewal")
    }
  }

  function editRenewal() {
    var buttonSet : pcftest.JobWizardToolbarButtonSet_Renewal
    if (OfferingStep.Current) {
      buttonSet = OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Renewal
    } else if (PolicyInfoStep.Current) {
      buttonSet = PolicyInfoStep.RenewalWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Renewal
    } else if (FormsStep.Current) {
      buttonSet = FormsStep.FormsScreen.JobWizardToolbarButtonSet_Renewal
    } else if (QuoteStep.Current) {
      buttonSet = QuoteStep.RenewalWizard_QuoteScreen.JobWizardToolbarButtonSet_Renewal
    } else if (RiskAnalysisStep.Current) {
      buttonSet = RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Renewal
    } else {
      Assert.fail("Unable to edit renewal")
    }

    if (buttonSet.EditPolicy.Visible) {
      buttonSet.EditPolicy.click()
    } else {
      buttonSet.EditPolicyWorkflow.click()
    }
  }

}
