package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses org.junit.Assert
uses pcftest.JobWizardToolbarButtonSet_PolicyChange

class PolicyChangeWizardWrapper {

  protected var _wizard : pcftest.PolicyChangeWizard

  construct(wizard : pcftest.PolicyChangeWizard) {
    _wizard = wizard
  }

  /**
   * Assert on named step.
   *
   * The step name is that of the property that returns the step from this
   * change wizard wrapper.  This method can be used when the step should not
   * be missing (i.e., null), and will report that assertion failure explicitly
   * instead of through a NullPointerException.
   */
  function assertOnStep(stepName : String) {
    /* validate step name as property... */
    if ( PolicyChangeWizardWrapper.Type.TypeInfo.getProperty(stepName) == null ) {
      throw new IllegalArgumentException(
          "PolicyChangeWizardWrapper:  Unknown step name "
              + stepName + "(unknown property)")
    }

    var step = this[stepName] as WizardMenuLinkElement
    if ( step == null ) {
      Assert.fail("Missing step in Policy Change: " + stepName)
    }
    assertOnStep(step)
  }

  /**
   * Assert on specified wizard step.
   *
   * Perhaps assertOnStep(stepName) should be used instead of this method if a
   * programming error in test code can result in a missing (i.e., null) step.
   */
  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  property get Next() : pcftest.PolicyChangeWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.PolicyChangeWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  property get OfferingStep() : pcftest.PolicyChangeWizard.Offering {
    return _wizard.Offering
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  property get PolicyInfoStep() : pcftest.PolicyChangeWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  function goToPolicyInfoStep() : pcftest.PolicyChangeWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  property get FormsStep() : pcftest.PolicyChangeWizard.Forms {
    return _wizard.Forms
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  property get PolicyReviewStep() : pcftest.PolicyChangeWizard.PolicyReview {
    return _wizard.PolicyReview
  }

  function goToPolicyReviewStep() : pcftest.PolicyChangeWizard_DifferencesScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  property get QuoteStep() : pcftest.PolicyChangeWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  function goToQuoteStep() : pcftest.PolicyChangeWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  function goToMultiLineQuoteStep_CPP() : pcftest.PolicyChangeWizard_MultiLine_QuoteScreen_CommercialPackage {
    MultiLineQuoteStep.click()
    var screen = MultiLineQuoteStep.PolicyChangeWizard_MultiLine_QuoteScreen_CommercialPackage
    assertOnStep(MultiLineQuoteStep)
    return screen
  }

  property get MultiLineQuoteStep() : pcftest.PolicyChangeWizard.ViewMultiLineQuote {
    return _wizard.ViewMultiLineQuote
  }

  property get RiskAnalysisStep() : pcftest.PolicyChangeWizard.RiskAnalysis {
    return _wizard.RiskAnalysis
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  property get PaymentStep() : pcftest.PolicyChangeWizard.BillingInfo {
    return _wizard.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get MenuActions_PolicyChange () : pcftest.WizardActionsMenuItemSet_default {
    return _wizard.WizardMenuActions.WizardMenuActions_Goto.WizardActionsMenuItemSet_default
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  function goToPaymentStep() : pcftest.PolicyChangeWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  property get MultiQuoteSelector(): pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return _wizard.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get MultiQuoteSelectorText() : String {
    return MultiQuoteSelector.PolicyPeriodSelector_Arg.Text
  }

  function selectMultiQuoteVersion(branchName : String) {
    MultiQuoteSelector.PolicyPeriodSelector_Arg.clickByLabelSubstr(branchName)
  }

  function quote() {}

  function asyncRate() {}

  function asyncQuote() {}

  /**
   * Saves Draft
   */
  function saveDraft() {
  }

  property get EditButton() : pcftest.JobWizardToolbarButtonSet_PolicyChange.EditPolicy {
    return QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange.EditPolicy
  }

  property get ReleaseLockButton() : JobWizardToolbarButtonSet_PolicyChange.Unlock {
    return QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange.Unlock
  }
  property get SaveDraftButton() : JobWizardToolbarButtonSet_PolicyChange.Draft {
    return QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange.Draft
  }

}
