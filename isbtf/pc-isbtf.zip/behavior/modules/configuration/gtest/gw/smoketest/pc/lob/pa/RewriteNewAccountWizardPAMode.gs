package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.RewriteNewAccountWizardWrapper

class RewriteNewAccountWizardPAMode extends RewriteNewAccountWizardWrapper {

  construct(wizard : pcftest.RewriteNewAccountWizard) {
    super(wizard)
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

  property get PAStep() : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPAStep() : pcftest.PersonalAutoScreen {
    var screen = PAStep.click()
    assertOnStep(PAStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  override function asyncQuote(){
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (QualificationStep.Current) {
      QualificationStep.RewriteNewAccountWizard_PreQualificationScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RewriteNewAccountWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyReviewStep.Current) {
      PolicyReviewStep.RewriteNewAccountWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_RewriteNewAccount.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      throw new IllegalStateException("Unable to quote asynchronously !")
    }
  }

}
