package gw.smoketest.pc.contacts

uses gw.smoketest.platform.web.ValueElement
uses gw.smoketest.platform.web.DateElement

class EditAccountPopupPersonMode extends EditAccountPopupBase {

  construct(editAccountPopup : pcftest.EditAccountPopup){
    super(editAccountPopup)
  }

  property get FirstName() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.DefaultFirstName
  }

  property get FirstNameKanji() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.GlobalPersonNameInputSet_Japan.FirstNameKanji
  }

  property get LastName() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.DefaultLastName
  }

  property get LastNameKanji() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.GlobalPersonNameInputSet_Japan.LastNameKanji
  }

  property get DateOfBirth() : DateElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.DateOfBirth
  }

  property get MaritalStatus() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.MaritalStatus
  }

  property get PrimaryPhone() : pcftest.ContactNameInputSet_person.PrimaryPhone {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.PrimaryPhone
  }

  property get HomePhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.HomePhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get HomePhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.HomePhone.GlobalPhoneInputSet.CountryCode
  }

  property get WorkPhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get WorkPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.WorkPhone.GlobalPhoneInputSet.CountryCode
  }

  property get CellPhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.CellPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get CellPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.CellPhone.GlobalPhoneInputSet.CountryCode
  }

  property get FaxPhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.FaxPhone.GlobalPhoneInputSet.CountryCode
  }

  property get PrimaryPhoneNumber() : ValueElement {
    switch (PrimaryPhone.TypeKeyValue) {
      case PrimaryPhoneType.TC_HOME:
        return HomePhone
      case PrimaryPhoneType.TC_MOBILE:
        return CellPhone
      case PrimaryPhoneType.TC_WORK:
        return WorkPhone
      default:
        throw new IllegalStateException()
    }
  }

  property get EmailAddress1() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.EmailAddress1
  }

  property get EmailAddress2() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_person.EmailAddress2
  }

  property get SSN() : ValueElement {
    return _editAccountPopup.EditAccountScreen.OfficialIDInputSet_person.OfficialIDDV_Input
  }


}
