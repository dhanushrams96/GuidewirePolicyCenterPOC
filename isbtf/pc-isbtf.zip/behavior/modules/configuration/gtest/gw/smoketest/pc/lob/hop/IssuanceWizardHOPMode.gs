package gw.smoketest.pc.lob.hop

uses gw.smoketest.pc.job.wizard.IssuanceWizardWrapper

class IssuanceWizardHOPMode extends IssuanceWizardWrapper {

  construct(wizard : pcftest.IssuanceWizard) {
    super(wizard)
  }
}