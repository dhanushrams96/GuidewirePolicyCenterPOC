package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.PolicyChangeWizardWrapper
uses gw.smoketest.platform.web.PCFLocation
uses org.junit.Assert
uses pcftest.JobWizardToolbarButtonSet_PolicyChange

class PolicyChangeWizardPAMode extends PolicyChangeWizardWrapper {

  construct(wizard_ : pcftest.PolicyChangeWizard) {
    super(wizard_)
  }

  property get PAStep() : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPAStep() : pcftest.PersonalAutoScreen {
    var screen = PAStep.click()
    assertOnStep(PAStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  function goToSideBySidePage() : pcftest.SideBySideScreen {
    return _wizard.goToSideBySidePage()
  }

  override function quote() {
    var toolbarButtonSet = PolicyChangeToolbarButtonSet
    if (toolbarButtonSet == null) {
      Assert.fail("Unable to quote")
    }
    toolbarButtonSet.QuoteTypeToolbarButtonSet_Quote.Quote.click()
  }

  function bind() : PCFLocation {
    var toolbarButtonSet = PolicyChangeToolbarButtonSet
    if (toolbarButtonSet == null) {
      throw "Unable to bind"
    }
    return toolbarButtonSet.BindPolicyChange.click()
  }

  function finishQuote() {
    var toolbarButtonSet = PolicyChangeToolbarButtonSet
    if (toolbarButtonSet == null) {
      throw "Unable to finish quote"
    }
    toolbarButtonSet.QuoteTypeToolbarButtonSet_FinishQuote.FinishQuote.click()
  }

  private property get PolicyChangeToolbarButtonSet(): JobWizardToolbarButtonSet_PolicyChange {
    var toolbarButtonSet: JobWizardToolbarButtonSet_PolicyChange
    if (PolicyInfoStep.Current) {
      toolbarButtonSet = PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange
    } else if (DriversStep.Current) {
      toolbarButtonSet = DriversStep.PADriversScreen.JobWizardToolbarButtonSet_PolicyChange
    } else if (VehiclesStep.Current) {
      toolbarButtonSet = VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_PolicyChange
    } else if (PAStep.Current) {
      toolbarButtonSet = PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_PolicyChange
    } else if (PolicyReviewStep.Current) {
      toolbarButtonSet = PolicyReviewStep.PolicyChangeWizard_DifferencesScreen.JobWizardToolbarButtonSet_PolicyChange
    } else if (QuoteStep.Current) {
      toolbarButtonSet = QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange
    }
    return toolbarButtonSet
  }

}
