package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement

class RewriteNewAccountWizardWrapper {

  protected var _wizard : pcftest.RewriteNewAccountWizard

  construct(wizard : pcftest.RewriteNewAccountWizard) {
    _wizard = wizard
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  property get Next() : pcftest.RewriteNewAccountWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.RewriteNewAccountWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  // ==================================================================================================================
  // Common methods
  // ==================================================================================================================

  property get OfferingStep() : pcftest.RewriteNewAccountWizard.Offering {
    return _wizard.Offering
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  property get QualificationStep() : pcftest.RewriteNewAccountWizard.Qualification {
    return _wizard.Qualification
  }

  function goToPolicyReviewStep() : pcftest.RewriteNewAccountWizard_PolicyReviewScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  function goToQualificationStep() : pcftest.RewriteNewAccountWizard_PreQualificationScreen {
    var screen = QualificationStep.click()
    assertOnStep( QualificationStep )
    return screen
  }

  property get PolicyInfoStep() : pcftest.RewriteNewAccountWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  function goToPolicyInfoStep() : pcftest.RewriteNewAccountWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  property get FormsStep() : pcftest.RewriteNewAccountWizard.Forms {
    return _wizard.Forms
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  property get RiskAnalysisStep() : pcftest.RewriteNewAccountWizard.RiskAnalysis {
    return _wizard.RiskAnalysis
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  property get PolicyReviewStep() : pcftest.RewriteNewAccountWizard.PolicyReview {
    return _wizard.PolicyReview
  }


  property get QuoteStep() : pcftest.RewriteNewAccountWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  function goToQuoteStep() : pcftest.RewriteNewAccountWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  property get MultiLineQuoteStep() : pcftest.RewriteNewAccountWizard.ViewMultiLineQuote {
    return _wizard.ViewMultiLineQuote
  }

  property get PaymentStep() : pcftest.RewriteNewAccountWizard.BillingInfo {
    return _wizard.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get MenuActions_Rewrite () : pcftest.WizardActionsMenuItemSet_default {
    return _wizard.WizardMenuActions.WizardMenuActions_Goto.WizardActionsMenuItemSet_default
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  function goToPaymentStep() : pcftest.RewriteNewAccountWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  function approveAllOpenUWIssues() {
    var riskAnalysisScreen = _wizard.RiskAnalysis.click()
    riskAnalysisScreen.approveAllIssues()
  }

  function asyncRate(){}

  function asyncQuote(){}

  function quote(){}

}
