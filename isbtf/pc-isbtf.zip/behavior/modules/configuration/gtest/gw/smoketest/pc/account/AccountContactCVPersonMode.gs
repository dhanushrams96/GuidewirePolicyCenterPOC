package gw.smoketest.pc.account

uses gw.smoketest.platform.web.DateElement
uses gw.smoketest.platform.web.ValueElement

class AccountContactCVPersonMode extends AccountContactCVBase {
  
  construct(detailsCV : pcftest.AccountContactCV) {
    super(detailsCV)
  }

  property get FirstName() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.DefaultFirstName
  }

  property get LastName() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.DefaultLastName
  }

  property get DateOfBirth() : DateElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.DateOfBirth
  }

  property get MaritalStatus() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.MaritalStatus
  }

  property get PrimaryPhone() : pcftest.ContactNameInputSet_person.PrimaryPhone {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.PrimaryPhone
  }

  property get HomePhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.HomePhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get HomePhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.HomePhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get WorkPhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get WorkPhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.WorkPhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get CellPhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.CellPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get CellPhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.CellPhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get FaxPhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.FaxPhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get EmailAddress1() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.EmailAddress1
  }

  property get EmailAddress2() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_person.EmailAddress2
  }
  
  // Note that this isn't valid for a user contact
  property get SSN() : ValueElement {
    return _detailsCV.AccountContactDVSafely.OfficialIDInputSet_person.OfficialIDDV_Input
  }
  
  override function setRequiredFields(seed : int) : String {
    super.setRequiredFields(seed)
    final var nonZeroOrBlank = nonZeroOrBlank(seed)
    final var fourDigit = fourDigit(seed)
    if (not FirstName.Value.HasContent) {
      FirstName.Value = "Trogdor" + nonZeroOrBlank
    }
    if (not LastName.Value.HasContent) {
      LastName.Value = "da Burninator" + nonZeroOrBlank
    }
    if (PrimaryPhone.Value == "home" and not HomePhone.Value.HasContent) {
      HomePhone.Value = "111-111-" + fourDigit
    }
    if (PrimaryPhone.Value == "work" and not WorkPhone.Value.HasContent) {
      WorkPhone.Value = "222-222-" + fourDigit
    }
    if (PrimaryPhone.Value == "mobile" and not CellPhone.Value.HasContent) {
      CellPhone.Value = "333-333-" + fourDigit
    }
    return FirstName.Value + " " + LastName.Value
  }
  
}
