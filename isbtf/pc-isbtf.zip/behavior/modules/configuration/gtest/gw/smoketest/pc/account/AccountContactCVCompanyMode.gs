package gw.smoketest.pc.account

uses gw.smoketest.platform.web.ValueElement

class AccountContactCVCompanyMode extends AccountContactCVBase {

  construct(detailsCV : pcftest.AccountContactCV) {
    super(detailsCV)
  }
  
  // fields

  property get CompanyName() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.DefaultCompanyName
  }

  property get WorkPhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get WorkPhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.WorkPhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get FaxPhone() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneDisplay() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.FaxPhone.GlobalPhoneInputSet.PhoneDisplay
  }

  property get EmailAddress1() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.EmailAddress1
  }

  property get EmailAddress2() : ValueElement {
    return _detailsCV.AccountContactDVSafely.ContactNameInputSet_company.EmailAddress2
  }

  property get FEIN() : ValueElement {
    return _detailsCV.AccountContactDVSafely.OfficialIDInputSet_company.OfficialIDDV_Input
  }

  override function setRequiredFields(seed : int) : String {
    super.setRequiredFields(seed)
    final var nonZeroOrBlank = nonZeroOrBlank(seed)
    if (not CompanyName.Value.HasContent) {
      CompanyName.Value = "Uncle Enzo's Cosa Nostra Pizza #" + nonZeroOrBlank
    }
    return CompanyName.Value
  }

}
