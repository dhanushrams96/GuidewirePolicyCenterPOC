package gw.smoketest.pc.commons

uses gw.smoketest.platform.web.PCFLocation
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses gw.testharness.ISmokeTest
uses org.fest.assertions.Assertions

class AssertUtil {

  private construct() { }

  static function assertSmaller(msg : String, c1 : Comparable, c2 : Comparable){
    Assertions.assertThat(c1.compareTo(c2) >= 0)
        .as("${msg}, Expected ${c1} < ${c2}")
        .isFalse()
  }

  static reified function assertException<T extends Throwable>(call : block(), exceptionType : Type<T>) : T{
    try {
      call()
    } catch(e : Throwable) {
      if ((typeof e) != exceptionType) {
        e.printStackTrace()
        throw new IllegalStateException("Wrong type of exception: ${e}")
      } else {
        print(e.Message)
      }
      return e as T
    }
    org.junit.Assert.fail("Expected exception to be thrown")
    return null
  }

  static function assertUpdateClosedPopup(popup : PCFLocation) {
    if (popup.OnPage) {
      var message = "Update failed to close the " + popup.Id + " popup as expected."

      org.junit.Assert.fail(message)
    }
  }

  static function assertOnPage(page : PCFLocation) {
    if (!page.OnPage) {
      var message = "Expected to be on page " + page.Id + " but was on page " + (page.SmokeTest.CurrentPage as PCFLocation).Id + "."

      org.junit.Assert.fail(message)
    }
  }

  static function assertOnPageByID(pageID : String, smokeTest : ISmokeTest) {
    if (pageID != (smokeTest.CurrentPage as PCFLocation).Id) {
      var message = "Expected to be on page " + pageID + " but was on page " + (smokeTest.CurrentPage as PCFLocation).Id + "."
      org.junit.Assert.fail(message)
    }
  }

  static function assertOnScreen(screen : WizardMenuLinkElement) {
    if (!screen.Current) {
      var idParts = screen.Id.split(ISmokeTest.ID_SEPARATOR)
      var message = "Expected to be on step " + idParts[idParts.length - 1] + " but on " + screen.getCurrentScreenName()

      org.junit.Assert.fail(message)
    }
  }

  /**
   * Asserts that the throwable "e" or a throwable that is reachable via e.Cause
   * has a message that exactly matches "text".
   */
  static function assertExceptionChainContainsExactMessage( e : Throwable, text : String ) {
    Assertions.assertThat(e)
        .as("Could not find expected exception message \"" + text + "\"")
        .isNotNull()
    if ( e.Message != text ) {
      assertExceptionChainContainsExactMessage( e.Cause, text )
    }
  }

  /**
   * Asserts that the throwable "e" or a throwable that is reachable via e.Cause
   * has a message that contains "text".
   */
  static function assertExceptionChainContains( e : Throwable, text : String ) {
    Assertions.assertThat(e)
        .as("Could not find expected exception message \"" + text + "\"")
        .isNotNull()

    if ( not e.Message.contains( text ) ) {
      assertExceptionChainContains( e.Cause, text )
    }
  }

}
