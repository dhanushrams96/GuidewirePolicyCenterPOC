package gw.smoketest.pc.lob.gl

uses gw.smoketest.pc.job.wizard.IssuanceWizardWrapper
uses org.junit.Assert

class IssuanceWizardGLMode extends IssuanceWizardWrapper {

  construct(wizard : pcftest.IssuanceWizard) {
    super(wizard)
  }

  property get GLStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }

  function goToGLStep() : pcftest.GeneralLiabilityScreen {
    var screen = GLStep.click()
    assertOnStep(GLStep)
    return screen
  }

  property get ExposureUnitStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLineEU {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLineEU
  }

  property get LocationsStep() : pcftest.LineWizardStepSet_GeneralLiability.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Locations
  }

  property get ModifiersStep() : pcftest.LineWizardStepSet_GeneralLiability.Modifiers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Modifiers
  }

  function goToModifiersStep() : pcftest.ModifiersScreen {
    if (not ModifiersStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = ModifiersStep.click()
    assertOnStep(ModifiersStep)
    return screen
  }

  override function asyncQuote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.IssuanceWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (GLStep.Current) {
      GLStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (ExposureUnitStep.Current) {
      ExposureUnitStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.ModifiersScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.IssuanceWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Issuance.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }

}
