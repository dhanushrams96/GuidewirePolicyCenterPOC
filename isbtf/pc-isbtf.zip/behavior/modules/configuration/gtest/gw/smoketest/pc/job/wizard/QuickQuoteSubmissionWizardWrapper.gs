package gw.smoketest.pc.job.wizard

class QuickQuoteSubmissionWizardWrapper {

  protected var _wizard : pcftest.QuickSubmissionWizard

  construct(wizard : pcftest.QuickSubmissionWizard) {
    _wizard = wizard
  }

  property get MultiQuoteSelector(): pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return _wizard.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  property get MenuActions() : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

}
