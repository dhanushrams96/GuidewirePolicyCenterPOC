package gw.smoketest.pc.lob.hop

uses gw.smoketest.pc.job.wizard.SubmissionWizardWrapper
uses org.junit.Assert
uses pcftest.HOPDwellingScreen
uses pcftest.LineWizardStepSet_HOPHomeowners
uses pcftest.HOPCoveragesScreen

class SubmissionWizardHOPMode extends SubmissionWizardWrapper {

  construct(wizard : pcftest.SubmissionWizard) {
    super(wizard)
  }

  //
  // HOP Properties
  //
  property get DwellingStep(): LineWizardStepSet_HOPHomeowners.HOPDwelling {
    return this._wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPDwelling
  }

  property get DwellingConstructionStep(): LineWizardStepSet_HOPHomeowners.HOPDwellingConstruction {
    return this._wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPDwellingConstruction
  }

  property get CoveragesStep(): LineWizardStepSet_HOPHomeowners.HOPCoverages {
    return this._wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPCoverages
  }

  property get ModifiersStep(): LineWizardStepSet_HOPHomeowners.Modifiers {
    return this._wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.Modifiers
  }

  function goToDwellingStep() : HOPDwellingScreen {
    if (not DwellingStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = DwellingStep.click()
    assertOnStep(DwellingStep)
    return screen
  }

  function goToDwellingConstruction() : pcftest.HOPDwellingConstructionScreen {
    var screen = DwellingConstructionStep.click()
    assertOnStep(DwellingConstructionStep)
    return screen
  }

  property get HOPCoveragesStep() : pcftest.LineWizardStepSet_HOPHomeowners.HOPCoverages {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPCoverages
  }

  function goToHOPCoveragesScreen() : pcftest.HOPCoveragesScreen {
    var screen = HOPCoveragesStep.click()
    assertOnStep(HOPCoveragesStep)
    return screen
  }

  function goToSideBySidePage() : pcftest.SideBySideScreen {
    return _wizard.goToSideBySidePage()
  }

  function goToCoveragesStep() : HOPCoveragesScreen {
    if (not CoveragesStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = CoveragesStep.click()
    assertOnStep(CoveragesStep)
    return screen
  }

  override function saveDraft() {
    if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (PolicyReviewStep.Current) {
       PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (QuoteStep.Current) {
       QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if ( OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.HOPModifiersScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else {
      Assert.fail("Unable to save draft")
    }
  }

  override function asyncQuote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (QuoteStep.Current) {
      QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      Assert.fail("Unable to quote asynchronously")
    }
  }

  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DwellingStep.Current) {
      DwellingStep.HOPDwellingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DwellingConstructionStep.Current) {
      DwellingConstructionStep.HOPDwellingConstructionScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (CoveragesStep.Current) {
      CoveragesStep.HOPCoveragesScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.HOPModifiersScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (QuoteStep.Current) {
      QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }
}
