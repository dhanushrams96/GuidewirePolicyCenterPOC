package gw.smoketest.pc.job.policychange

uses gw.smoketest.pc.job.wizard.PolicyChangeWizardWrapper
uses gw.smoketest.platform.web.PCFLocation
uses org.junit.Assert
uses pcftest.SplitPeriodPopup

class PolicyChangeWizardWCMode extends PolicyChangeWizardWrapper {

  construct(wizard_ : pcftest.PolicyChangeWizard) {
    super(wizard_)
  }

  property get LocationsStep() : pcftest.LineWizardStepSet_WorkersComp.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.Locations
  }

  function goToLocationsStep() : pcftest.LocationsScreen {
    var screen = LocationsStep.click()
    assertOnStep(LocationsStep)
    return screen
  }

  property get PolicyInfoInputSet() : pcftest.PolicyInfoInputSet {
    return PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.PolicyChangeWizard_PolicyInfoDV.PolicyInfoInputSet
  }

  property get AccountInfoInputSet() : pcftest.AccountInfoInputSet {
    return PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.PolicyChangeWizard_PolicyInfoDV.AccountInfoInputSet
  }

  property get PolicyInfoSaveButton() : pcftest.JobWizardToolbarButtonSet_PolicyChange.Draft {
    return PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.Draft
  }

  property get LocationsSaveButton() : pcftest.JobWizardToolbarButtonSet_PolicyChange.Draft {
    return LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_PolicyChange.Draft
  }

  property get CovOptionsSaveButton() : pcftest.JobWizardToolbarButtonSet_PolicyChange.Draft {
    return OptionsStep.CoverageOptionsScreen.JobWizardToolbarButtonSet_PolicyChange.Draft
  }

  property get OptionsStep() : pcftest.LineWizardStepSet_WorkersComp.WorkersCompOptions {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompOptions
  }

  function goToOptionsStep() : pcftest.CoverageOptionsScreen {
    var screen = OptionsStep.click()
    assertOnStep(OptionsStep)
    return screen
  }

  property get WCCoverageStep () : pcftest.LineWizardStepSet_WorkersComp.WorkersCompCoverageConfig {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompCoverageConfig
  }

  function goToWCCoverageStep() : pcftest.WorkersCompCoverageConfigScreen {
    var screen = WCCoverageStep.click()
    assertOnStep(WCCoverageStep)
    return screen
  }

  property get SupplementalStep() : pcftest.LineWizardStepSet_WorkersComp.WorkersCompSupplemental {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompSupplemental
  }

  function goToSupplementalStep() : pcftest.WorkersCompSupplementalScreen {
    var screen = SupplementalStep.click()
    assertOnStep(SupplementalStep)
    return screen
  }

  override function quote() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (OptionsStep.Current) {
      OptionsStep.CoverageOptionsScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (WCCoverageStep.Current) {
      WCCoverageStep.WorkersCompCoverageConfigScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (SupplementalStep.Current) {
      SupplementalStep.WorkersCompSupplementalScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (PolicyReviewStep.Current) {
      PolicyReviewStep.PolicyChangeWizard_DifferencesScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (QuoteStep.Current) {
      QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else {
      Assert.fail("Unable to quote")
    }
  }

  function splitPeriod(splitEffectiveDateStr: String, splitType: String){
    WCCoverageStep.WorkersCompCoverageConfigScreen.WorkersCompCoverageCV.PolicyLinePerStateConfig_LV._Entries.single()._Checkbox.click()
    var popup = WCCoverageStep.WorkersCompCoverageConfigScreen.WorkersCompCoverageCV.SplitPeriod.click() as SplitPeriodPopup
    popup.SplitDate.Value = splitEffectiveDateStr
    popup.splitType.getOptionByLabel(splitType).click()
    popup.Update.click()
  }
}