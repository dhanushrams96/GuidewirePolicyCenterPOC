package gw.smoketest.pc.contacts

uses gw.smoketest.platform.web.ValueElement

class EditAccountPopupCompanyMode extends EditAccountPopupBase {

  construct(editAccountPopup : pcftest.EditAccountPopup){
    super(editAccountPopup)
  }

  property get CompanyName() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.DefaultCompanyName
  }

  property get WorkPhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.WorkPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get WorkPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.WorkPhone.GlobalPhoneInputSet.CountryCode
  }

  property get FaxPhone() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.FaxPhone.GlobalPhoneInputSet.NationalSubscriberNumber
  }

  property get FaxPhoneRegion() : pcftest.GlobalPhoneInputSet.CountryCode {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.FaxPhone.GlobalPhoneInputSet.CountryCode
  }

  property get EmailAddress1() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.EmailAddress1
  }

  property get EmailAddress2() : ValueElement {
    return _editAccountPopup.EditAccountScreen.ContactNameInputSet_company.EmailAddress2
  }

  property get FEIN() : ValueElement {
    return _editAccountPopup.EditAccountScreen.OfficialIDInputSet_company.OfficialIDDV_Input
  }

  property get OrgType() : pcftest.EditAccountPopup.EditAccountScreen.OrgType {
    return _editAccountPopup.EditAccountScreen.OrgType
  }

  property get IndustryCode() : pcftest.EditAccountPopup.EditAccountScreen.IndustryCode {
    return _editAccountPopup.EditAccountScreen.IndustryCode
  }

  property get DescriptionOfBusiness() : ValueElement {
    return _editAccountPopup.EditAccountScreen.DescriptionOfBusiness
  }
  
}
