package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement

class RewriteWizardWrapper {

  protected var _wizard : pcftest.RewriteWizard

  construct(wizard : pcftest.RewriteWizard) {
    _wizard = wizard
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  property get Next() : pcftest.RewriteWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.RewriteWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  // ==================================================================================================================
  // Common methods
  // ==================================================================================================================

  property get OfferingStep() : pcftest.RewriteWizard.Offering {
    return _wizard.Offering
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  property get PolicyInfoStep() : pcftest.RewriteWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  function goToPolicyInfoStep() : pcftest.RewriteWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  property get FormsStep() : pcftest.RewriteWizard.Forms {
    return _wizard.Forms
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  property get PolicyReviewStep() : pcftest.RewriteWizard.PolicyReview {
    return _wizard.PolicyReview
  }

  function goToPolicyReviewStep() : pcftest.RewriteWizard_DifferencesScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  property get RiskAnalysisStep() : pcftest.RewriteWizard.RiskAnalysis {
    return _wizard.RiskAnalysis
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  property get QuoteStep() : pcftest.RewriteWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  function goToQuoteStep() : pcftest.RewriteWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  property get PaymentStep() : pcftest.RewriteWizard.BillingInfo {
    return _wizard.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get MenuActions_Rewrite () : pcftest.WizardActionsMenuItemSet_default {
    return _wizard.WizardMenuActions.WizardMenuActions_Goto.WizardActionsMenuItemSet_default
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  property get MultiQuoteSelector(): pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return _wizard.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get MultiQuoteSelectorText() : String {
    return MultiQuoteSelector.PolicyPeriodSelector_Arg.Text
  }

  function selectMultiQuoteVersion(branchName : String) {
    MultiQuoteSelector.PolicyPeriodSelector_Arg.clickByLabelSubstr(branchName)
  }

  function goToPaymentStep() : pcftest.RewriteWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  function approveAllOpenUWIssues() {
    var riskAnalysisScreen = goToRiskAnalysisStep()
    riskAnalysisScreen.approveAllIssues()
  }

  function quote() {}

  function asyncRate() {}

  function asyncQuote() {}

}