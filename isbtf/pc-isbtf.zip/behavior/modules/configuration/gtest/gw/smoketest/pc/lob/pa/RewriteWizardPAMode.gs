package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.RewriteWizardWrapper
uses org.junit.Assert

class RewriteWizardPAMode extends RewriteWizardWrapper {
  construct(wizard : pcftest.RewriteWizard) {
    super(wizard)
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

  property get PAStep() : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPAStep() : pcftest.PersonalAutoScreen {
    var screen = PAStep.click()
    assertOnStep(PAStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RewriteWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.RewriteWizard_DifferencesScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }

  function bind() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.RewriteWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else if (PAStep.Current) {
      PAStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.RewriteWizard_DifferencesScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else if (QuoteStep.Current) {
      QuoteStep.RewriteWizard_QuoteScreen.JobWizardToolbarButtonSet_Rewrite.BindRewrite.click()
    } else {
      Assert.fail("Unable to bind")
    }
  }
}
