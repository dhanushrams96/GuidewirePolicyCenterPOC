package gw.smoketest.pc.lob.gl

uses gw.smoketest.pc.job.wizard.RewriteWizardWrapper
uses pcftest.LineWizardStepSet_GeneralLiability

class RewriteWizardGLMode extends RewriteWizardWrapper {

  construct(wizard : pcftest.RewriteWizard) {
    super(wizard)
  }

  property get GLStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }

  function goToGLStep() : pcftest.GeneralLiabilityScreen {
    var screen = GLStep.click()
    assertOnStep(GLStep)
    return screen
  }

  property get ExposuresStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLineEU {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLineEU
  }

  function goToExposureStep() : pcftest.GeneralLiabilityEUScreen{
    var screen  = ExposuresStep.click()
    assertOnStep(ExposuresStep)
    return screen
  }

  property get LocationsStep (): LineWizardStepSet_GeneralLiability.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Locations
  }

  property get CoveragesStep(): LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }

  override function asyncQuote(){
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RewriteWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (CoveragesStep.Current) {
      CoveragesStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (ExposuresStep.Current) {
      ExposuresStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_Rewrite.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      throw new IllegalStateException("Unable to quote asynchronously !")
    }
  }

}
