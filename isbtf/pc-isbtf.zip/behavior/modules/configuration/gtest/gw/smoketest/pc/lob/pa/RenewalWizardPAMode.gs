package gw.smoketest.pc.lob.pa

uses gw.smoketest.pc.job.wizard.RenewalWizardWrapper
uses org.junit.Assert

class RenewalWizardPAMode extends RenewalWizardWrapper {

  construct(wizard : pcftest.RenewalWizard) {
    super(wizard)
  }

  property get PACoveragesStep () : pcftest.LineWizardStepSet_PersonalAuto.PALine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PALine
  }

  function goToPACoveragesStep() : pcftest.PersonalAutoScreen  {
    var screen = PACoveragesStep.click()
    assertOnStep(PACoveragesStep)
    return screen
  }

  property get VehiclesStep() : pcftest.LineWizardStepSet_PersonalAuto.PersonalVehicles {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PersonalVehicles
  }

  function goToVehiclesStep() : pcftest.PAVehiclesScreen {
    var screen = VehiclesStep.click()
    assertOnStep(VehiclesStep)
    return screen
  }

  property get DriversStep() : pcftest.LineWizardStepSet_PersonalAuto.PADrivers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_PersonalAuto.PADrivers
  }

  function goToDriversStep() : pcftest.PADriversScreen {
    var screen = DriversStep.click()
    assertOnStep(DriversStep)
    return screen
  }

  function goToSideBySidePage() : pcftest.SideBySideScreen {
    return _wizard.goToSideBySidePage()
  }

  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.RenewalWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PACoveragesStep.Current) {
      PACoveragesStep.PersonalAutoScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (VehiclesStep.Current) {
      VehiclesStep.PAVehiclesScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DriversStep.Current) {
      DriversStep.PADriversScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }

}
