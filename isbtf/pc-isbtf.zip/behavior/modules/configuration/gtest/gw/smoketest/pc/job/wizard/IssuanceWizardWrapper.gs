package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement

class IssuanceWizardWrapper {
  protected var _wizard : pcftest.IssuanceWizard

  construct(wizard : pcftest.IssuanceWizard) {
    _wizard = wizard
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  property get Next() : pcftest.IssuanceWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.IssuanceWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  // ==================================================================================================================
  // Common methods
  // ==================================================================================================================

  property get OfferingStep() : pcftest.IssuanceWizard.Offering {
    return _wizard.Offering
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  property get PolicyInfoStep() : pcftest.IssuanceWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  function goToPolicyInfoStep() : pcftest.IssuanceWizard_PolicyInfoScreen {
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  property get RiskAnalysisStep() : pcftest.IssuanceWizard.RiskAnalysis {
    return _wizard.RiskAnalysis
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  property get PolicyReviewStep() : pcftest.IssuanceWizard.PolicyReview {
    return _wizard.PolicyReview
  }

  function goToPolicyReviewStep() : pcftest.IssuanceWizard_PolicyReviewScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  property get QuoteStep() : pcftest.IssuanceWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  function goToQuoteStep() : pcftest.IssuanceWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  function goToMultiLineQuoteStep_CPP() : pcftest.IssuanceWizard_MultiLine_QuoteScreen_CommercialPackage {
    MultiLineQuoteStep.click()
    var screen = MultiLineQuoteStep.IssuanceWizard_MultiLine_QuoteScreen_CommercialPackage
    assertOnStep(MultiLineQuoteStep)
    return screen
  }

  property get MultiLineQuoteStep() : pcftest.IssuanceWizard.ViewMultiLineQuote {
    return _wizard.ViewMultiLineQuote
  }

  property get FormsStep() : pcftest.IssuanceWizard.Forms {
    return _wizard.Forms
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  property get PaymentStep() : pcftest.IssuanceWizard.BillingInfo {
    return _wizard.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  function goToPaymentStep() : pcftest.IssuanceWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  function asyncRate() {}

  function asyncQuote() {}

  function quote() {}

}
