package gw.smoketest.pc.lob.gl

uses gw.smoketest.pc.job.wizard.PolicyChangeWizardWrapper
uses pcftest.GeneralLiabilityEUScreen

class PolicyChangeWizardGLMode extends PolicyChangeWizardWrapper {

  construct(wizard : pcftest.PolicyChangeWizard) {
    super(wizard)
  }

  property get CoveragesStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }

  property get ExposuresStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLineEU {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLineEU
  }

  property get LocationsStep() : pcftest.LineWizardStepSet_GeneralLiability.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Locations
  }

  property get ModifiersStep () : pcftest.LineWizardStepSet_GeneralLiability.Modifiers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Modifiers
  }

  function goToGLStep() : pcftest.GeneralLiabilityScreen {
    return CoveragesStep.click()
  }

  function gotoExposuresStep() : GeneralLiabilityEUScreen {
    return ExposuresStep.click()
  }

  override function quote(){
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (CoveragesStep.Current) {
      CoveragesStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else if (ExposuresStep.Current) {
      ExposuresStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    }
    else {
      throw new IllegalStateException("Unable to quote, implement me!")
    }
  }

  override function asyncQuote(){
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyInfoStep.Current) {
      PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (CoveragesStep.Current) {
      CoveragesStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (ExposuresStep.Current) {
      ExposuresStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      throw new IllegalStateException("Unable to quote, implement me!")
    }
  }

}
