package gw.smoketest.pc.lob.wc.submission

uses gw.smoketest.pc.job.wizard.SubmissionWizardWrapper
uses org.junit.*

class SubmissionWizardWCMode extends SubmissionWizardWrapper {
  
  construct(wizard : pcftest.SubmissionWizard) {
    super(wizard)
  }
  
  property get LocationsStep() : pcftest.LineWizardStepSet_WorkersComp.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.Locations
  }
  
  function goToLocationsStep() : pcftest.LocationsScreen {
    if (not LocationsStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = LocationsStep.click()
    assertOnStep(LocationsStep)
    return screen
  }
  
  property get PolicyInfoInputSet() : pcftest.PolicyInfoInputSet {
    return PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.SubmissionWizard_PolicyInfoDV.PolicyInfoInputSet
  }
  
  property get AccountInfoInputSet() : pcftest.AccountInfoInputSet {
    return PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
  }
  
  property get PolicyInfoSaveButton() : pcftest.JobWizardToolbarButtonSet_Submission.Draft {
    return PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.Draft 
  }
  
  property get LocationsSaveButton() : pcftest.JobWizardToolbarButtonSet_Submission.Draft {
    return LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.Draft 
  }
  
  property get CovOptionsSaveButton() : pcftest.JobWizardToolbarButtonSet_Submission.Draft {
    return OptionsStep.CoverageOptionsScreen.JobWizardToolbarButtonSet_Submission.Draft 
  }
  
  property get OptionsStep() : pcftest.LineWizardStepSet_WorkersComp.WorkersCompOptions {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompOptions
  }
  
  function goToOptionsStep() : pcftest.CoverageOptionsScreen {
    if (not OptionsStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = OptionsStep.click()
    assertOnStep(OptionsStep)
    return screen
  }
  
  property get WCCoverageStep() : pcftest.LineWizardStepSet_WorkersComp.WorkersCompCoverageConfig {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompCoverageConfig
  }
  
  function goToWCCoverageStep() : pcftest.WorkersCompCoverageConfigScreen {
    if (not WCCoverageStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = WCCoverageStep.click()
    assertOnStep(WCCoverageStep)
    return screen
  }
  
  property get SupplementalStep() : pcftest.LineWizardStepSet_WorkersComp.WorkersCompSupplemental {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_WorkersComp.WorkersCompSupplemental
  }
  
  function goToSupplementalStep() : pcftest.WorkersCompSupplementalScreen {
    if (not SupplementalStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = SupplementalStep.click()
    assertOnStep(SupplementalStep)
    return screen
  }
  
  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (WCCoverageStep.Current) {
      WCCoverageStep.WorkersCompCoverageConfigScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (OptionsStep.Current) {
      OptionsStep.CoverageOptionsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }    
  }

  function bindAndIssue() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else if (QuoteStep.Current) {
      QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else if (PaymentStep.Current) {
      PaymentStep.SubmissionWizard_PaymentScreen.JobWizardBillingToolbarButtonSet_Submission.BindOptions.BindAndIssue.click()
    } else {
      Assert.fail("Unable to bind")
    }    
  }

  function bindOnly() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else if (QuoteStep.Current) {
      QuoteStep.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else if (PaymentStep.Current) {
      PaymentStep.SubmissionWizard_PaymentScreen.JobWizardBillingToolbarButtonSet_Submission.BindOptions.BindOnly.click()
    } else {
      Assert.fail("Unable to bind")
    }    
  }

  override function saveDraft() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (WCCoverageStep.Current) {
      WCCoverageStep.WorkersCompCoverageConfigScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (OptionsStep.Current) {
      OptionsStep.CoverageOptionsScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.Draft.click()
    } else {
      Assert.fail("Unable to save draft")
    }        
  }
}
