package gw.smoketest.pc.lob.gl

uses gw.smoketest.pc.job.wizard.RenewalWizardWrapper
uses org.junit.Assert

class RenewalWizardGLMode extends RenewalWizardWrapper {

  construct(wizard : pcftest.RenewalWizard) {
    super(wizard)
  }

  property get GLStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }

  function goToGLStep() : pcftest.GeneralLiabilityScreen {
    var screen = GLStep.click()
    assertOnStep(GLStep)
    return screen
  }

  property get ExposuresStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLineEU {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLineEU
  }

  function goToExposureStep() : pcftest.GeneralLiabilityEUScreen{
    var screen  = ExposuresStep.click()
    assertOnStep(ExposuresStep)
    return screen
  }

  function asyncQuote() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.RenewalWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (PolicyReviewStep.Current) {
      PolicyReviewStep.RenewalWizard_DifferencesScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else if (QuoteStep.Current) {
      QuoteStep.RenewalWizard_QuoteScreen.JobWizardToolbarButtonSet_Renewal.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    }
    else {
      Assert.fail("Unable to quote asynchronously")
    }
  }

}
