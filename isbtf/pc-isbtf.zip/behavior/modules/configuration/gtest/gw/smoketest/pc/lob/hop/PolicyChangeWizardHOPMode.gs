package gw.smoketest.pc.lob.hop

uses gw.smoketest.pc.job.wizard.PolicyChangeWizardWrapper
uses pcftest.HOPDwellingScreen
uses pcftest.LineWizardStepSet_HOPHomeowners
uses org.junit.Assert

class PolicyChangeWizardHOPMode extends PolicyChangeWizardWrapper {

  construct(wizard : pcftest.PolicyChangeWizard) {
    super(wizard)
  }

  property get DwellingStep() : LineWizardStepSet_HOPHomeowners.HOPDwelling {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPDwelling
  }

  function goToDwellingStep() : HOPDwellingScreen {
    if (not DwellingStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = DwellingStep.click()
    assertOnStep(DwellingStep)
    return screen
  }

  property get DwellingConstructionStep() : LineWizardStepSet_HOPHomeowners.HOPDwellingConstruction {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPDwellingConstruction
  }

  property get CoveragesStep() : LineWizardStepSet_HOPHomeowners.HOPCoverages {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.HOPCoverages
  }

  property get ModifiersStep() : LineWizardStepSet_HOPHomeowners.Modifiers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_HOPHomeowners.Modifiers
  }

  //
  // Common Functions
  //
  override function quote() {
    if (PolicyInfoStep.Current) {
      PolicyInfoStep.PolicyChangeWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.PolicyChangeWizard_DifferencesScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DwellingStep.Current) {
      DwellingStep.HOPDwellingScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (DwellingConstructionStep.Current) {
      DwellingConstructionStep.HOPDwellingConstructionScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (CoveragesStep.Current) {
      CoveragesStep.HOPCoveragesScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.HOPModifiersScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (QuoteStep.Current) {
      QuoteStep.PolicyChangeWizard_QuoteScreen.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }
}