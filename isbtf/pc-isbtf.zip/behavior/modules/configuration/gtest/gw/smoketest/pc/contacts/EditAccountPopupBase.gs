package gw.smoketest.pc.contacts

uses gw.smoketest.platform.web.ValueElement
uses gw.smoketest.platform.web.SelectElement

abstract class EditAccountPopupBase {

  protected var _editAccountPopup : pcftest.EditAccountPopup
  
  construct(editAccountPopup : pcftest.EditAccountPopup){
    _editAccountPopup = editAccountPopup
  }
  
  property get AddressLine1() : ValueElement {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.AddressLine1
  }

  property get AddressLine2() : ValueElement {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.AddressLine2
  }

  property get City() : pcftest.GlobalAddressInputSet_default.City {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.City
  }

  property get State() : SelectElement {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.State
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.PostalCode
  }

  property get County() : ValueElement {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.County
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return _editAccountPopup.EditAccountScreen.AddressInputSet.Country
  }

  property get AddressType() : ValueElement {
    return _editAccountPopup.EditAccountScreen.AddressType
  }

  property get AddressDescription() : ValueElement {
    return _editAccountPopup.EditAccountScreen.AddressDescription
  }

}
