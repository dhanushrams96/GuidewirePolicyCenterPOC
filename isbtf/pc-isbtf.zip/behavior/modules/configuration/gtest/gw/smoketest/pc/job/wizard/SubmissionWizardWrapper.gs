package gw.smoketest.pc.job.wizard

uses gw.smoketest.pc.commons.AssertUtil
uses gw.smoketest.platform.web.WizardMenuLinkElement
uses org.junit.Assert

class SubmissionWizardWrapper {

  protected var _wizard : pcftest.SubmissionWizard

  construct(wizard_ : pcftest.SubmissionWizard) {
    _wizard = wizard_
  }

  property get Next() : pcftest.SubmissionWizard.Next {
    return _wizard.Next
  }

  property get Prev() : pcftest.SubmissionWizard.Prev {
    return _wizard.Prev
  }

  property get InfoBar() : pcftest.JobWizardInfoBar {
    return _wizard.JobWizardInfoBar
  }

  property get OfferingStep() : pcftest.SubmissionWizard.Offering {
    return _wizard.Offering
  }

  property get PreQualStep() : pcftest.SubmissionWizard.PreQualification {
    return _wizard.PreQualification
  }

  property get PolicyInfoStep() : pcftest.SubmissionWizard.LOBWizardStepGroup.PolicyInfo {
    return _wizard.LOBWizardStepGroup.PolicyInfo
  }

  property get FormsStep() : pcftest.SubmissionWizard.Forms {
    return _wizard.Forms
  }

  property get PolicyReviewStep() : pcftest.SubmissionWizard.PolicyReview {
    return _wizard.PolicyReview
  }

  property get RiskAnalysisStep() : pcftest.SubmissionWizard.RiskAnalysis {
    return _wizard.RiskAnalysis
  }

  property get QuoteStep() : pcftest.SubmissionWizard.ViewQuote {
    return _wizard.ViewQuote
  }

  property get MultiLineQuoteStep() : pcftest.SubmissionWizard.ViewMultiLineQuote {
    return _wizard.ViewMultiLineQuote
  }

  property get PaymentStep() : pcftest.SubmissionWizard.BillingInfo {
    return _wizard.BillingInfo
  }

  property get MenuActions () : pcftest.WizardMenuActions {
    return _wizard.WizardMenuActions
  }

  property get MenuActions_Submission () : pcftest.WizardActionsMenuItemSet_Submission {
    return _wizard.WizardMenuActions.WizardMenuActions_Goto.WizardActionsMenuItemSet_Submission
  }

  property get WizardTools () : pcftest.JobWizardToolsMenuWizardStepSet {
    return _wizard.JobWizardToolsMenuWizardStepSet
  }

  property get MultiQuoteSelector(): pcftest.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector {
    return _wizard.MultiQuoteAcceleratedMenuActions.PolicyPeriodSelector
  }

  property get MultiQuoteSelectorText() : String {
    return MultiQuoteSelector.PolicyPeriodSelector_Arg.Text
  }

  function selectMultiQuoteVersion(branchName : String) {
    MultiQuoteSelector.PolicyPeriodSelector_Arg.clickByLabelSubstr(branchName)
  }

  function assertOnStep(step : WizardMenuLinkElement) {
    AssertUtil.assertOnPage( _wizard )
    AssertUtil.assertOnScreen( step )
  }

  /**
   * Asserts that test is on the pre-qualification page and attempts to advance the UI past it without answering any questions.
   */
  function skipPreQual(): pcftest.SubmissionWizard_PolicyInfoScreen {
    skipOffering()
    Assert.assertTrue( "Not on pre-qual page", _wizard.PreQualification.Current )
    _wizard.Next.click()
    var policyInfo = _wizard.LOBWizardStepGroup.PolicyInfo
    Assert.assertTrue( "Could not pre-qualify submission", policyInfo.Current)
    return policyInfo.SubmissionWizard_PolicyInfoScreen
  }

  function skipOffering() {
    if (_wizard.Offering.Current) {
      _wizard.Next.click()
    }
  }

  function goToPolicyInfoScreenFromOffering() : pcftest.SubmissionWizard_PolicyInfoScreen {
    return skipPreQual()
  }

  function newVersion() : pcftest.SubmissionWizard {
    return _wizard.ViewQuote.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.Versions.NewVersion.click() as pcftest.SubmissionWizard
  }

  function notTaken() : pcftest.NotTakenReasonPopup {
    return _wizard.PreQualification.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.CloseOptions.NotTakenJob.click() as pcftest.NotTakenReasonPopup
  }

  function goToPolicyInfoStep() : pcftest.SubmissionWizard_PolicyInfoScreen {
    if (not PolicyInfoStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = PolicyInfoStep.click()
    assertOnStep( PolicyInfoStep )
    return screen
  }

  function goToOfferingStep() : pcftest.OfferingScreen {
    var screen = OfferingStep.click()
    assertOnStep( OfferingStep )
    return screen
  }

  function goToPreQualStep(): pcftest.SubmissionWizard_PreQualificationScreen {
    var screen = PreQualStep.click()
    assertOnStep( PreQualStep )
    return screen
  }

  function goToFormsStep() : pcftest.FormsScreen {
    var screen = FormsStep.click()
    assertOnStep( FormsStep )
    return screen
  }

  function goToPolicyReviewStep() : pcftest.SubmissionWizard_PolicyReviewScreen {
    var screen = PolicyReviewStep.click()
    assertOnStep(PolicyReviewStep)
    return screen
  }

  function goToRiskAnalysisStep() : pcftest.Job_RiskAnalysisScreen {
    var screen = RiskAnalysisStep.click()
    assertOnStep(RiskAnalysisStep)
    return screen
  }

  function goToQuoteStep() : pcftest.SubmissionWizard_QuoteScreen {
    var screen = QuoteStep.click()
    assertOnStep(QuoteStep)
    return screen
  }

  function goToMultiLineQuoteStep_CPP() : pcftest.SubmissionWizard_MultiLine_QuoteScreen_CommercialPackage {
    MultiLineQuoteStep.click()
    var screen = MultiLineQuoteStep.SubmissionWizard_MultiLine_QuoteScreen_CommercialPackage
    assertOnStep(MultiLineQuoteStep)
    return screen
  }

  function goToPaymentStep() : pcftest.SubmissionWizard_PaymentScreen {
    var screen = PaymentStep.click()
    assertOnStep(PaymentStep)
    return screen
  }

  function convertToFullApp() {
    var button = _wizard.ViewQuote.SubmissionWizard_QuoteScreen.JobWizardToolbarButtonSet_Submission.ConvertToFullApp
    Assert.assertNotNull( "Button not found. You cannot convert to full app from this screen.", button )
    button.click()
  }

  function copySubmission(): pcftest.SubmissionWizard {
    return this.MenuActions.WizardMenuActions_Create.WizardMenuActions_CopySubmission.click() as pcftest.SubmissionWizard
  }

  function quote() {}

  function asyncRate() {}

  function asyncQuote() {}

  /**
   * Saves Draft
   */
  function saveDraft() {}

}
