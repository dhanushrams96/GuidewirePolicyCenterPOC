package gw.smoketest.pc.lob.gl

uses gw.smoketest.pc.job.wizard.SubmissionWizardWrapper
uses org.junit.Assert

class SubmissionWizardGLMode extends SubmissionWizardWrapper {
  
  construct(wizard : pcftest.SubmissionWizard) {
    super(wizard)
  }
  
  property get LocationsStep() : pcftest.LineWizardStepSet_GeneralLiability.Locations {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Locations
  }
  
  function goToLocationsStep() : pcftest.LocationsScreen {
    if (not LocationsStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = LocationsStep.click()
    assertOnStep(LocationsStep)
    return screen
  }
  
  property get GLStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLine {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLine
  }
  
  function goToGLStep() : pcftest.GeneralLiabilityScreen {
    if (not GLStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = GLStep.click()
    assertOnStep(GLStep)
    return screen
  }

  property get ExposureUnitStep() : pcftest.LineWizardStepSet_GeneralLiability.GLLineEU {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.GLLineEU
  }
  
  function goToExposureUnitStep() : pcftest.GeneralLiabilityEUScreen {
    if (not ExposureUnitStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = ExposureUnitStep.click()
    assertOnStep(ExposureUnitStep)
    return screen
  }
    
  property get ModifiersStep() : pcftest.LineWizardStepSet_GeneralLiability.Modifiers {
    return _wizard.LOBWizardStepGroup.LineWizardStepSet_GeneralLiability.Modifiers
  }
  
  function goToModifiersStep() : pcftest.ModifiersScreen {
    if (not ModifiersStep.Visible) {
      _wizard.LOBWizardStepGroup.click()
    }
    var screen = ModifiersStep.click()
    assertOnStep(ModifiersStep)
    return screen
  }

  override function quote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (GLStep.Current) {
      GLStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (ExposureUnitStep.Current) {
      ExposureUnitStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.ModifiersScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }

  override function asyncQuote() {
    if (OfferingStep.Current) {
      OfferingStep.OfferingScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (PreQualStep.Current) {
      PreQualStep.SubmissionWizard_PreQualificationScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (PolicyInfoStep.Current) {
      PolicyInfoStep.SubmissionWizard_PolicyInfoScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (LocationsStep.Current) {
      LocationsStep.LocationsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (GLStep.Current) {
      GLStep.GeneralLiabilityScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (ExposureUnitStep.Current) {
      ExposureUnitStep.GeneralLiabilityEUScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (FormsStep.Current) {
      FormsStep.FormsScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (ModifiersStep.Current) {
      ModifiersStep.ModifiersScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (PolicyReviewStep.Current) {
      PolicyReviewStep.SubmissionWizard_PolicyReviewScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else if (RiskAnalysisStep.Current) {
      RiskAnalysisStep.Job_RiskAnalysisScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_AsyncQuote.AsyncQuote.click()
    } else {
      Assert.fail("Unable to quote")
    }
  }
  
}
