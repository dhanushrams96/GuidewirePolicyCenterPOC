package gw.smoketest.pc.account

uses gw.api.util.StringUtil
uses gw.smoketest.platform.web.SelectElement
uses gw.smoketest.platform.web.ValueElement

abstract class AccountContactCVBase {
  
  protected var _detailsCV : pcftest.AccountContactCV
  
  construct(detailsCV : pcftest.AccountContactCV){
    _detailsCV = detailsCV
  }

  // fields
  property get AddressSummary() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.AddressSummary
  }

  property get AddressLine1() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.AddressLine1
  }

  property get AddressLine2() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.AddressLine2
  }

  property get AddressLine3() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.AddressLine3
  }

  property get City() : pcftest.GlobalAddressInputSet_default.City {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.City
  }

  property get State() : SelectElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.State
  }

  property get PostalCode() : pcftest.GlobalAddressInputSet_default.PostalCode {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.PostalCode
  }

  property get County() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.County
  }

  property get Country() : pcftest.GlobalAddressInputSet_default.Country {
    return _detailsCV.AccountContactDVSafely.AddressInputSet.Country
  }

  property get AddressType() : pcftest.AccountContactDV.AddressType {
    return _detailsCV.AccountContactDVSafely.AddressType
  }

  property get AddressDescription() : ValueElement {
    return _detailsCV.AccountContactDVSafely.AddressDescription
  }

  /**
   * Set the required fields and then return the contact's name.
   */
  function setRequiredFields() : String {
    return setRequiredFields(0)
  }
  
  /**
   * Set the required fields and then return the contact's name.
   */
  function setRequiredFields(seed : int) : String {
    if (not AddressLine1.Value.HasContent) {
      AddressLine1.Value = seed + " Gemini Way"
    }
    if (not City.Value.HasContent) {
      City.Value = "Capicorn City"
    }
    if (not State.Value.HasContent) {
      State.Value = "CA"
    }
    if (not PostalCode.Value.HasContent) {
      PostalCode.Value = StringUtil.formatNumber(seed, "00000")
    }
    if (not AddressType.Value.HasContent) {
      AddressType.Value = "home"
    }
    
    // set required fields for roles here
    
    return null  // see subtypes for actual returns
  }
  
  protected function nonZeroOrBlank(seed : int) : String {
    return seed == 0 ? "" : java.lang.Integer.toString(seed)
  }
  
  protected function fourDigit(seed : int) : String {
    return StringUtil.formatNumber(seed, "0000")
  }
  
}
