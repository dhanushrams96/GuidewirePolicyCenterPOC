package gw.util

/**
 * A row on the RiskAnalysisScreen which represents a UW issue
 */
class IssueRow {
  var _title : String as Title
  var _shortDescription : String as ShortDescription
  var _isApproveVisible : Boolean as ApproveVisible
  var _isRejectVisible : Boolean as RejectVisible
  var _isReopenVisible : Boolean as ReopenVisible

  override function toString() : String {
    return _title + ", " + _shortDescription
  }

  override function hashCode() : int {
    return Objects.hash({_title, _shortDescription})
  }

  override function equals(o : Object) : boolean {
    if (o typeis IssueRow) {
      return this.hashCode() == o.hashCode()
    } else {
      return false
    }
  }
}