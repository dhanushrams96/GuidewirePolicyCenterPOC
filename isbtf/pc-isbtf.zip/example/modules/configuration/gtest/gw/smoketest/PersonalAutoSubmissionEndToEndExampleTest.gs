package gw.smoketest

uses gw.api.builder.AccountBuilder
uses gw.api.builder.SubmissionBuilder
uses gw.api.test.PCSmokeTestClassBase
uses gw.plugin.policyperiod.IPolicyEvaluationPlugin
uses gw.smoketest.pc.lob.pa.SubmissionWizardPAMode
uses gw.suites.PCExampleSmokeSuite
uses gw.testharness.v3.Suites

@Export
@Suites(PCExampleSmokeSuite.NAME)
class PersonalAutoSubmissionEndToEndExampleTest extends PCSmokeTestClassBase {

  var _wizard : SubmissionWizardPAMode as Wizard
  var _period: PolicyPeriod as Period

  // Walk through most of the submission wizard steps, from draft through quote and issuance.
  function testSubmission() {
    // suppress evaluations, so that we don't end up with UWIssues that prevent binding
    registerPlugin(IPolicyEvaluationPlugin, new IPolicyEvaluationPlugin() {
      override function evaluatePeriod(period: PolicyPeriod, _checkingSet: UWIssueCheckingSet) {
        // do nothing
      }
    })

    Period = goToPASubmission()
    fillInDriverInfo(Period)
    fillInVehicle()
    visitPACoveragesStep()
    var policyReviewScreen = visitReviewStep()
    getQuote(policyReviewScreen)
    visitFormsStep()
    setPaymentOptionsAndBind()
  }

  function goToPASubmission() : PolicyPeriod {
    // This creates a mostly-empty submission, as opposed to PASubmissionBuilder(), which will fill a lot of it in.
    var policyPeriod = new SubmissionBuilder()
        .withAccount(new AccountBuilder())
        .withProduct("PersonalAuto")
        .isDraft()
        .createAndCommit()

    loginDefaultUser()
    Wizard = TabBar.goToSubmission( policyPeriod.Job.JobNumber ).PAMode

    return policyPeriod
  }

  function fillInDriverInfo(policyPeriod : PolicyPeriod) {
    // fill in driver info
    var driversScreen = Wizard.goToDriversStep()
    driversScreen.addExistingDriver()
    driversScreen.DriverDetails.LicenseNumber.Value = "12345"
    driversScreen.DriverDetails.LicenseState.getOptionByValue( policyPeriod.BaseState.Code ).click()
  }

  function fillInVehicle() {
    // add a vehicle with a driver
    var vehiclesScreen = Wizard.goToVehiclesStep()
    vehiclesScreen.clickCreateVehicle()
    vehiclesScreen.populateRequiredFieldsWithLocation(1)
    vehiclesScreen.CostNew_DV.Value = "22561"
    Wizard.assertOnStep( Wizard.VehiclesStep )
  }

  function visitPACoveragesStep() : pcftest.PersonalAutoScreen {
    // PA Coverages step
    var covStep = Wizard.goToPAStep()

    // find underinsured motorist and add it
    var uim = covStep.PersonalAuto_AllVehicleCoveragesDV.PALiabCategoryIterator._Entries
      .singleWhere(\ e -> e.CoverageInputSet_PALiabilityCov.CovPatternDisplayName.Value.contains("Underinsured"))

    uim.CoverageInputSet_PALiabilityCov.CovPatternInputGroup._checkbox.click()

    return covStep
  }

  function visitReviewStep() : pcftest.SubmissionWizard_PolicyReviewScreen {
    var step = Wizard.goToPolicyReviewStep()
    _wizard.assertOnStep(Wizard.PolicyReviewStep)
    return step
  }

  function getQuote(revScreen : pcftest.SubmissionWizard_PolicyReviewScreen) {
    // get quote
    revScreen.JobWizardToolbarButtonSet_Submission.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    Wizard.assertOnStep( Wizard.QuoteStep )
    var quoteScreen = Wizard.QuoteStep.SubmissionWizard_QuoteScreen
    assertThat(quoteScreen.Quote_SummaryDV.TotalPremium.Text)
        .as("No premium amount on quote")
        .isNotNull()
  }

  function visitFormsStep() {
    Wizard.goToFormsStep()
    var forms = Wizard.FormsStep.FormsScreen.FormsDV.FormsLV._Entries
    assertThat(forms.singleWhere(\f -> f.FormNumber.Text == "PF 01")).isNotNull()
    assertThat(forms.hasMatch(\f -> f.FormNumber.Text == "CPP 01")).isFalse()
  }

  function setPaymentOptionsAndBind() {
    // set the payment options and bind
    var paymentScreen = Wizard.goToPaymentStep()
    paymentScreen.setDirectBillWithDeposit("101")
    paymentScreen.issue()

    // Check to make sure it is bound...
    Period = Period.refresh() as PolicyPeriod
    assertThat(Period.Status)
        .as("The policy period should be bound.")
        .isEqualTo(PolicyPeriodStatus.TC_BOUND)

    /// ... and the policy is issued. In both cases we need to
    // refresh() the bean, because the Wizard committed in its own bundle.
    var policy = Period.Policy.refresh() as Policy
    assertThat(policy.Issued)
        .as("The policy should be issued.")
        .isTrue()
  }

}
