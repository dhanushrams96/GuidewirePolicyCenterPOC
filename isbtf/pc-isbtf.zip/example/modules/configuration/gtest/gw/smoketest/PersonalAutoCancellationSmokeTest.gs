package gw.smoketest

uses gw.api.builder.CancellationBuilder
uses gw.api.test.PCSmokeTestClassBase
uses gw.sampledata.SampleData
uses gw.suites.PCExampleSmokeSuite
uses gw.testharness.v3.Suites

@Export
@Suites(PCExampleSmokeSuite.NAME)
class PersonalAutoCancellationSmokeTest extends PCSmokeTestClassBase {

  override function beforeMethod() {
    super.beforeMethod()
    try {
      SampleData.loadSampleDataSet(SampleDataSet.TC_SMALL)
    } catch (e : Exception) {
      e.printStackTrace()
    }
    loginAsUser("aapplegate")
  }

  function testCancelNowSetsCancelProcessDate() {
    // Creating Personal Auto cancellation job
    var period = new CancellationBuilder()
        .withProduct("PersonalAuto")
        .withEffectiveDate(Date.Tomorrow)
        .isQuoted()
        .createAndCommit()
    assertThat(period.Cancellation.CancelProcessDate)
        .as("Precondition: Cancellation should not be processed.")
        .isNull()
    TabBar.goToCancellation(period.Cancellation).clickCancelNow()

    // Refreshing the PolicyPeriod bean after being cancelled
    period = period.refresh() as PolicyPeriod
    var cancellation = period.Cancellation.refresh() as Cancellation
    assertThat(cancellation.CancelProcessDate.trimToMidnight()).as("Cancellation should be processed.")
        .isEqualTo(Date.Today.trimToMidnight())
   }

}
