package gw.smoketest

uses gw.api.builder.AccountBuilder
uses gw.api.builder.AccountContactBuilder
uses gw.api.builder.AddressBuilder
uses gw.api.builder.DriverBuilder
uses gw.api.builder.NamedInsuredBuilder
uses gw.api.builder.PersonBuilder
uses gw.api.builder.PolicyPriNamedInsuredBuilder
uses gw.api.builder.SubmissionBuilder
uses gw.api.databuilder.gl.GLSubmissionBuilder
uses gw.api.databuilder.pa.PASubmissionBuilder
uses gw.api.databuilder.pa.PAVehicleBuilder
uses gw.api.databuilder.pa.PersonalAutoLineBuilder
uses gw.api.databuilder.pa.PolicyDriverBuilder
uses gw.api.databuilder.pa.VehicleDriverBuilder
uses gw.api.test.PCSmokeTestClassBase
uses gw.sampledata.SampleData
uses gw.suites.PCExampleSmokeSuite
uses gw.testharness.v3.Suites
uses gw.transaction.Transaction

@Export
@Suites(PCExampleSmokeSuite.NAME)
class PolicyAddressSyncEndToEndExampleTest extends PCSmokeTestClassBase {

  static final var NEW_ADDRESS_LINE_1 = "newLine1"
  static final var DIRECT_BILL_DEPOSIT_AMOUNT = "125"
  static final var FIRST_STREET = "1st St."
  static final var SECOND_STREET = "2nd St."
  static final var THIRD_STREET = "3rd St."
  static final var LICENSE_NUMBER = "ABC123"

  override function beforeClass() {
    try {
      SampleData.loadSampleDataSet(SampleDataSet.TC_SMALL)
    } catch (e : Exception) {
      e.printStackTrace()
    }
  }

  function testPolicyAddressFieldsAreSharedOnNonPromotedJobsPA() {
    var period = new PASubmissionBuilder(false).isDraft().createAndCommit()

    loginDefaultUser()

    // change at AccountContact
    var contactsPage = TabBar.goToAccountFileSummary(period.Policy.Account.AccountNumber).goToContacts()
    var editContactPopup = contactsPage.editAccountContact(period.PrimaryNamedInsured.DisplayName)
    var addressLine1 = editContactPopup.AccountContactDVSafely.AddressInputSet.AddressLine1
    var oldLine1 = addressLine1.Value
    addressLine1.Value = NEW_ADDRESS_LINE_1
    editContactPopup.ContactDetailScreen.Update.click()

    // verify PolicyAddress changed
    var submissionWizard = TabBar.goToSubmission(period.Job.JobNumber).PAMode
    var polInfoPage = submissionWizard.goToPolicyInfoStep()
    var acctInfoInputSet = polInfoPage.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).doesNotContain(oldLine1)
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).contains(NEW_ADDRESS_LINE_1)
  }

  function testPolicyAddressFieldsAreSharedOnNonPromotedJobsGL() {
    var period = new GLSubmissionBuilder().isDraft().createAndCommit()

    loginDefaultUser()

    // change at AccountContact
    var contactsPage = TabBar.goToAccountFileSummary(period.Policy.Account.AccountNumber).goToContacts()
    var editContactPopup = contactsPage.editAccountContact(period.PrimaryNamedInsured.DisplayName)
    var addrInputSet = editContactPopup.AccountContactDVSafely.AddressInputSet
    var oldLine1 = addrInputSet.AddressLine1.Value
    addrInputSet.AddressLine1.Value = NEW_ADDRESS_LINE_1
    editContactPopup.ContactDetailScreen.Update.click()

    // verify PolicyAddress changed
    var submissionWizard = TabBar.goToSubmission(period.Job.JobNumber).GLMode
    var polInfoPage = submissionWizard.goToPolicyInfoStep()
    var acctInfoInputSet = polInfoPage.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).doesNotContain(oldLine1)
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).contains(NEW_ADDRESS_LINE_1)
  }

  function testPolicyAddressFieldsAreNotSharedOnPromotedJobsPA() {
    var period = new PASubmissionBuilder(false).isQuoted().createAndCommit()

    loginDefaultUser()

    var submissionWizard = TabBar.goToSubmission(period.Job.JobNumber).PAMode
    var paymentPage = submissionWizard.goToPaymentStep()
    paymentPage.setDirectBillWithDeposit(DIRECT_BILL_DEPOSIT_AMOUNT)

    paymentPage.issue()
    dismissIfNecessary()

    var reloadedPeriod : PolicyPeriod
    Transaction.runWithNewBundle(\bundle -> {
      reloadedPeriod = bundle.loadBean(period.ID) as PolicyPeriod
    })

    // change at AccountContact
    var contactsPage = TabBar.goToAccountFileSummary(reloadedPeriod.Policy.Account.AccountNumber).goToContacts()
    var editContactPopup = contactsPage.editAccountContact(reloadedPeriod.PrimaryNamedInsured.DisplayName)
    var addrInputSet = editContactPopup.AccountContactDVSafely.AddressInputSet
    var oldLine1 = addrInputSet.AddressLine1.Value
    addrInputSet.AddressLine1.Value = NEW_ADDRESS_LINE_1
    editContactPopup.ContactDetailScreen.Update.click()

    // verify PolicyAddress not changed
    submissionWizard = TabBar.goToSubmission(reloadedPeriod.Job.JobNumber).PAMode
    var polInfoPage = submissionWizard.goToPolicyInfoStep()
    var acctInfoInputSet = polInfoPage.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).contains(oldLine1)
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).doesNotContain(NEW_ADDRESS_LINE_1)
  }

  function testPolicyAddressFieldsAreNotSharedOnPromotedJobsGL() {
    var period = new GLSubmissionBuilder().isQuoted().createAndCommit()

    loginDefaultUser()

    var submissionWizard = TabBar.goToSubmission(period.Job.JobNumber).GLMode
    var paymentPage = submissionWizard.goToPaymentStep()
    paymentPage.setDirectBillWithDeposit(DIRECT_BILL_DEPOSIT_AMOUNT)
    paymentPage.issue()
    dismissIfNecessary()

    var reloadedPeriod : PolicyPeriod
    Transaction.runWithNewBundle(\bundle -> {
      reloadedPeriod = bundle.loadBean(period.ID) as PolicyPeriod
    })

    // change at AccountContact
    var contactsPage = TabBar.goToAccountFileSummary(reloadedPeriod.Policy.Account.AccountNumber).goToContacts()
    var editContactPopup = contactsPage.editAccountContact(reloadedPeriod.PrimaryNamedInsured.DisplayName)
    var addrInputSet = editContactPopup.AccountContactDVSafely.AddressInputSet
    var oldLine1 = addrInputSet.AddressLine1.Value
    addrInputSet.AddressLine1.Value = NEW_ADDRESS_LINE_1
    editContactPopup.ContactDetailScreen.Update.click()

    // verify PolicyAddress not changed
    submissionWizard = TabBar.goToSubmission(reloadedPeriod.Job.JobNumber).GLMode
    var polInfoPage = submissionWizard.goToPolicyInfoStep()
    var acctInfoInputSet = polInfoPage.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).contains(oldLine1)
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).doesNotContain(NEW_ADDRESS_LINE_1)
  }

  function testPolicyAddressIsUsedInsteadOfPrimaryNamedInsuredsPrimaryAddressPALine() {
    var addrBldr1 = new AddressBuilder().withAddressLine1(FIRST_STREET) // initially the Primary Address
    var addrBldr2 = new AddressBuilder().withAddressLine1(SECOND_STREET)
    var addrBldr3 = new AddressBuilder().withAddressLine1(THIRD_STREET)
    var contactBldr = new PersonBuilder(2)
        .withPrimaryAddress(addrBldr1)
        .withContactAddress(addrBldr2)
        .withContactAddress(addrBldr3)
    var contactDriverBldr = new PersonBuilder(3).withLicenseState(Jurisdiction.TC_CA).withLicenseNumber(LICENSE_NUMBER)
    var vehicleDriverBldr = new VehicleDriverBuilder()
    var vehicleBldr = new PAVehicleBuilder().withVehicleDriver(vehicleDriverBldr)
    var driverBldr = new DriverBuilder()
    var namedInsuredBldr = new NamedInsuredBuilder()
    var accountContactBldr = new AccountContactBuilder().withRole(namedInsuredBldr).withContact(contactBldr)
    var accountContactDriverBldr = new AccountContactBuilder().withRole(driverBldr).withContact(contactDriverBldr)
    var primaryNamedInsured = new PolicyPriNamedInsuredBuilder().withAccountContactRole(namedInsuredBldr)
    var policyDriverBldr = new PolicyDriverBuilder().withAccountContactRole(driverBldr).withVehicleDriver(vehicleDriverBldr)
    var period = new SubmissionBuilder().withProduct("PersonalAuto").isDraft()
        .withAccount(new AccountBuilder().withAccountContact(accountContactBldr).withAccountContact(accountContactDriverBldr))
        .withPrimaryNamedInsured(primaryNamedInsured)
        .withPolicyContactRole(policyDriverBldr)
        .withPolicyLine(new PersonalAutoLineBuilder().withPolicyDriver(policyDriverBldr).withVehicle(vehicleBldr))
        .createAndCommit()

    loginDefaultUser()

    // Make the Primary Address of PrimaryNamedInsured point to a different address (2nd St.) at the Account
    var contactsPage = TabBar.goToAccountFileSummary(period.Policy.Account.AccountNumber).goToContacts()
    var editContactPopup = contactsPage.editAccountContact(period.PrimaryNamedInsured.DisplayName)
    var entryOf2ndStAddress = editContactPopup.AddressesLVSafely
        ._Entries.firstWhere(\a -> a.DisplayedName.Value.contains(SECOND_STREET))
    entryOf2ndStAddress.Primary.click() // clicks "Primary" column radio button
    editContactPopup.ContactDetailScreen.Update.click()

    var reloadedPeriod : PolicyPeriod
    Transaction.runWithNewBundle( \ bundle -> {reloadedPeriod = bundle.loadBean(period.ID) as PolicyPeriod})

    // the PolicyAddress on PolicyInfo page has not been updated
    var submissionWizard = TabBar.goToSubmission(reloadedPeriod.Job.JobNumber).PAMode
    var polInfoPage = submissionWizard.goToPolicyInfoStep()
    var acctInfoInputSet = polInfoPage.SubmissionWizard_PolicyInfoDV.AccountInfoInputSet
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).contains(FIRST_STREET)
    assertThat(acctInfoInputSet.PolicyAddressDisplayInputSet.Address.Value).doesNotContain(SECOND_STREET)

    // Quote
    submissionWizard.quote()
    dismissIfNecessary()

    // the PolicyAddress on Quote page has not been updated
    var quotePage = submissionWizard.goToQuoteStep()
    var policyAddress = quotePage.Quote_SummaryDV.PolicyAddress.PolicyAddressDisplayInputSet.Address
    assertThat(policyAddress.Value).contains(FIRST_STREET)
    assertThat(policyAddress.Value).doesNotContain(SECOND_STREET)

    // Issue
    var paymentPage = submissionWizard.goToPaymentStep()
    paymentPage.setDirectBillWithDeposit(DIRECT_BILL_DEPOSIT_AMOUNT)
    paymentPage.issue()
    dismissIfNecessary()

    Transaction.runWithNewBundle( \ bundle -> {reloadedPeriod = bundle.loadBean(period.ID) as PolicyPeriod})

    // the PolicyAddress on PolicyReview page has not been updated
    submissionWizard = TabBar.goToSubmission(reloadedPeriod.Job.JobNumber).PAMode
    var polReviewPage = submissionWizard.goToPolicyReviewStep()
    policyAddress = polReviewPage.SubmissionWizard_ReviewSummaryDV.PolicyAddress.PolicyAddressDisplayInputSet.Address
    assertThat(policyAddress.Value).contains(FIRST_STREET)
    assertThat(policyAddress.Value).doesNotContain(SECOND_STREET)

    // the PolicyAddress on PolicySummary page has not been updated
    var policyInfo = TabBar.goToPolicyFile(reloadedPeriod.PolicyNumber).PolicyFileAcceleratedMenuActions.PolicyMenuItemSet_PersonalAuto.PolicyMenuItemSet_PolicyInfo.click()
    policyAddress = policyInfo.PolicyFile_PolicyInfoScreen.PolicyFile_PolicyInfoDV.AccountInfoInputSet.PolicyAddressDisplayInputSet.Address
    assertThat(policyAddress.Value).contains(FIRST_STREET)
    assertThat(policyAddress.Value).doesNotContain(SECOND_STREET)
  }

  private function dismissIfNecessary() {
    if (this.isConfirmationShowing()) {
      dismissAndGetConfirmation()
    }
  }

}
