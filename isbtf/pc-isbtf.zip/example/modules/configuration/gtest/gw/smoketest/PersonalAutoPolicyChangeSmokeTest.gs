package gw.smoketest

uses gw.api.builder.*
uses gw.api.databuilder.pa.PAVehicleBuilder
uses gw.api.databuilder.pa.PersonalAutoLineBuilder
uses gw.api.databuilder.pa.PolicyDriverBuilder
uses gw.api.databuilder.pa.VehicleDriverBuilder
uses gw.api.test.PCSmokeTestClassBase
uses gw.sampledata.SampleData
uses gw.suites.PCExampleSmokeSuite
uses gw.testharness.v3.Suites
uses pcftest.PolicyFile_Summary

@Export
@Suites(PCExampleSmokeSuite.NAME)
class PersonalAutoPolicyChangeSmokeTest extends PCSmokeTestClassBase {

  override function beforeMethod() {
    super.beforeMethod()
    try {
      SampleData.loadSampleDataSet(SampleDataSet.TC_SMALL)
    } catch (e : Exception) {
      e.printStackTrace()
    }
    loginAsUser("aapplegate")
  }

  function testPAPolicyChangeEndToEnd() {
    // Create test data
    // First describe the account and then generate it
    var driverBldr = new DriverBuilder().withGoodDriverDiscount(false)
    var accountLocation = new AccountLocationBuilder()
    var account = new AccountBuilder()
        .withAccountLocation(accountLocation)
        .withAccountContact(new AccountContactBuilder().withRole(driverBldr)
            .withContact(new PersonBuilder()
                .withFirstName("Adam").withLastName("Smith")
                .withLicenseNumber("6XYZ789")
                .withLicenseState(Jurisdiction.TC_CA))).create()

    // Describe the policy and generate it
    var policyLocation = new PolicyLocationBuilder()
        .withAccountLocation(accountLocation)

    var vehicleDriver1 = new VehicleDriverBuilder()
    var vehicleDriver2 = new VehicleDriverBuilder()

    var car1 = new PAVehicleBuilder()
        .withLocation(policyLocation)
        .withVIN("CAR1")
        .withVehicleDriver(vehicleDriver1)

    var car2 = new PAVehicleBuilder()
        .withLocation(policyLocation)
        .withVIN("CAR2")
        .withVehicleDriver(vehicleDriver2)
    var driver2 = new PolicyDriverBuilder().withAccountContactRole(driverBldr)

    var policyPeriod = new SubmissionBuilder()
        .withAccount(account)
        .withProduct("PersonalAuto")
        .withPolicyLocation(policyLocation)
        .withPolicyLine(new PersonalAutoLineBuilder()
            .withVehicle(car1)
            .withVehicle(car2)
        )
        .withPolicyContactRole(driver2.withVehicleDriver(vehicleDriver1)
            .withVehicleDriver(vehicleDriver2))
        .createAndCommit()

    assertThat(policyPeriod.PersonalAutoLine.Vehicles).as("The policy period should have the two vehicles.")
        .hasSize(2)
    // Navigate to the Policy File
    var policyFileSummary = TabBar.goToPolicySummary(policyPeriod.PolicyNumber)

    // Check whether this is the Summary Page of the Policy File for the right policy
    policyFileSummary.assertOnPage()

    assertThat(policyFileSummary.PolicyNumber.Text)
        .as("The policy file summary should have the correct policy number.")
        .isEqualTo(policyPeriod.PolicyNumber)

    // Start a Policy Change
    var effDate = Date.Today.addDays(2)
    var wizard = policyFileSummary._parent.startPolicyChange(effDate).PAMode

    // Go to line coverages step
    var lineCovsPage = wizard.goToPAStep()

    // Get the liability limit (as type CovTermInput)
    var liabilityCoverageLimit = lineCovsPage.AutoLiabCovTerm
    assertThat(liabilityCoverageLimit)
        .as("The PA Coverages step should have the main liability limit package coverage term.")
        .isNotNull()

    // Pick the third coverage option
    liabilityCoverageLimit.getOption(3).click()

    // Try to quote
    lineCovsPage.JobWizardToolbarButtonSet_PolicyChange.QuoteTypeToolbarButtonSet_Quote.Quote.click()
    wizard.assertOnStep(wizard.QuoteStep)


    // Try to bind
    var jobComplete = wizard.QuoteStep.PolicyChangeWizard_QuoteScreen.clickBind()
    jobComplete.assertOnPage()
    var boundPage = CurrentPage as pcftest.JobComplete

    // Go to the policy file
    policyFileSummary = boundPage.goToPolicyFile()
    policyFileSummary.assertOnPage()
    policyFileSummary = this.CurrentPage as PolicyFile_Summary


    var boundRow = policyFileSummary.CompletedTransactionsLV._Entries
        .firstWhere(\t -> t.EffectiveDate.DateValue.compareIgnoreTime(effDate) == 0)
    if (boundRow == null) {
      var issuingRow = policyFileSummary.PendingTransactionsLV._Entries
          .firstWhere(\t -> t.EffectiveDate.DateValue.compareIgnoreTime(effDate) == 0 and
              t.Status.Text.equalsIgnoreCase("Binding"))
      assertThat(issuingRow)
          .as("Didn't find policy change as bound transaction or in process of issuing in Policy File Summary")
          .isNotNull()
    }

  }

}
