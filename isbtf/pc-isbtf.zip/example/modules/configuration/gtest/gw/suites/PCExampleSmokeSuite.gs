package gw.suites

uses gw.api.test.PCSmokeTestClassBase
uses gw.api.test.SuiteBuilder
uses junit.framework.Test

@Export
class PCExampleSmokeSuite {

  public static final var NAME : String = "PCExampleSmokeSuite"

  static function suite() : Test {
    return new SuiteBuilder(PCSmokeTestClassBase)
        .withSuiteName(NAME)
        .build()
  }

}
