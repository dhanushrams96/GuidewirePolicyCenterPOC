package gw.api.test

uses gw.testharness.v3.PLAssertions
uses org.fest.assertions.BooleanAssert
uses org.fest.assertions.ObjectArrayAssert
uses org.fest.assertions.ObjectAssert
uses org.fest.assertions.StringAssert

@ReadOnly
class PCSmokeTestClassBase extends PCSmokeTestJavaClassBase {

  /**
   * Any point in the application can be access starting from the tab bar.
   */
  var _tabBar : pcftest.TabBar as TabBar

  construct() {
    super("PC Customer Smoke Test")
  }

  construct( testname : String ) {
    super( testname )
  }

  /**
   * Logs in as the default user, and initializes the TabBar property.
   */
  final function loginDefaultUser() {
    login("aapplegate", "gw")
  }

  /**
   * Equivalent to calling login(username, password) using the default password
   */
  function loginAsUser(username: String) {
    login(username, "gw")
  }

  function logout() : gw.smoketest.platform.web.PCFLocation {
    if (TabBar.LogoutTabBarLink.Visible) {
      return TabBar.LogoutTabBarLink.click();
    }
    throw new IllegalStateException("logout link is not visible")
  }

  /**
   * Logs in using the given username and password, and initializes the TabBar property.
   */
  function login(username : String, password : String) {
    var startPage = (this.goToEntryPoint( "Login" ) as pcftest.Login).login(username, password)
    var desktop = startPage.getOrCreateProperty("_parent", pcftest.Desktop)
    TabBar = desktop.MenuLinks.Desktop_DesktopActivities.click()._parent.TabBar
  }

  function assertThat(actual : Boolean) : BooleanAssert {
    return PLAssertions.assertThat(actual)
  }

  function assertThat(actual : boolean) : BooleanAssert {
    return PLAssertions.assertThat(actual)
  }

  function assertThat(actual : String) : StringAssert {
    return PLAssertions.assertThat(actual)
  }

  function assertThat(actual : Object) : ObjectAssert {
    return PLAssertions.assertThat(actual)
  }

  function assertThat(actual : Object[]) : ObjectArrayAssert {
    return PLAssertions.assertThat(actual)
  }

}