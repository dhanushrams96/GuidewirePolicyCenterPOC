package gw.cucumber.transformer

uses gw.pl.currency.MonetaryAmount

/**
 * Helper class which defines methods for converting an object to {@link MonetaryAmount}
 */
@Export
class MonetaryAmountTransformer {

  /**
   * Transforms the given string into a MonetaryAmount type. The expected string is <amount>SPACE<currency>.
   * For example: 100 USD, 50 EUR, etc
   *
   * @param amountStr - the String representation of the amount.
   * @return - a MonetaryAmount object
   */
  function transform(amountStr : String) : MonetaryAmount {
    try {
      return new MonetaryAmount(amountStr)
    } catch (e: Exception) {
      throw new IllegalArgumentException("Unsupported MonetaryAmount format: ${amountStr}" +
          e.getMessage() != null ? " - error: ${e.getMessage()}" : "" )
    }
  }
}