package gw.cucumber.transformer

uses com.google.common.collect.ImmutableSet
uses gw.api.locale.DisplayKey

class CancelOptionTransformer {

  static var _cancelOptions : Set<String> as CancelOptions = ImmutableSet.copyOf({
      DisplayKey.get('Job.Operation.CancelNow'),
      DisplayKey.get('Job.Operation.CancelPolicy')})

  internal function findValue(value : String) : String {
    return CancelOptions.firstWhere(\option -> option == value)
  }

  function transform(value : String) : String {
    var option =  findValue(value)
    if (option == null) {
      throw new IllegalArgumentException("No valid cancellation method found for " + value)
    }
    return option
  }

}