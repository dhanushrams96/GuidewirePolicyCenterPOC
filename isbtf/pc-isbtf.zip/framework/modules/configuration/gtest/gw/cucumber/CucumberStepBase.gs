package gw.cucumber

uses com.google.inject.Inject
uses gw.api.upgrade.Coercions
uses gw.pl.currency.MonetaryAmount
uses gw.plugin.InitializablePlugin
uses gw.plugin.policyperiod.IRatingPlugin
uses gw.plugin.policyperiod.impl.PCRatingPlugin
uses gw.sampledata.small.SmallSampleRatingData
uses gw.smoketest.pc.commons.QPlexorTestUtil
uses gw.testharness.v3.PLAssertions
uses gw.transaction.Transaction
uses org.fest.assertions.*
uses org.slf4j.Logger
uses pcftest.TabBar

uses java.math.BigDecimal

@ReadOnly
class CucumberStepBase {

  @Inject
  protected var _proxy : PCCucumberSmokeTestProxy


  protected var _defaultUser : String = "aapplegate"

  function loginAsUser(username: String) : TabBar {
    return login(username, "gw")
  }

  function login(username : String, password : String) : TabBar {
    _proxy.login(username, password)
    return _proxy.TabBar
  }

  /**
   * Attempts to wait until the progress widget goes away. Useful when waiting for a quote or a policy to
   * go through binding.
   */
  function waitForAutoRefreshToComplete() {
    try {
      _proxy.dismissAndGetConfirmation()
    } catch (e : Throwable) {
      print("Ignoring this: " + e) // ignore exception
    }

    if (typeof _proxy.CurrentPage == pcftest.PleaseBePatientPopup) {
      var popup = _proxy.CurrentPage as pcftest.PleaseBePatientPopup
      if (popup.OnPage) {
        //1s * 300 = 300s = 5 minutes to timeout
        for (wait in 0..|300) {
          sleep(1000)
          print("Slept 1 more second.  Flush #: " + (wait + 1))
          QPlexorTestUtil.flush()
          _proxy.refreshPage()

          if (!popup.OnPage) {
            // action completed
            return
          }
          if (Coercions.makePIntFrom(popup.PleaseBePatientPopupScreen.JobWizardPatiences.Value) >= 100) {
            popup.PleaseBePatientPopupScreen.JobWizardPatiences.click()
            return
          }
        }
        // timeout
        _proxy.fail("Waited too long for PleaseBePatientPopup page to complete")
      }
    }
  }

  /**
   * If logged out, login as the given user and return the TabBar. If already logged in - as any user - return the
   * TabBar of the current login session.
   * @param username if logged out, the login username
   * @return the TabBar of the current login or of the new login
   */
  function loginIfLoggedOut(username : String) : TabBar {
    return LoggedIn
        ? _proxy.TabBar
        : loginAsUser(username)
  }

  /**
   * Logs out the user who is currently logged in, landing on the login screen
   * If no user is logged in, do nothing
   */
  function logout() {
    if (LoggedIn) {
      _proxy.TabBar.LogoutTabBarLink.click()
    }
  }

  /**
   * @return true if a user is currently logged in. Otherwise, return false.
   */
  property get LoggedIn() : boolean {
    if (_proxy.TabBar == null) {
      _proxy.Logger.debug("No user has yet logged in.")
      return false
    }
    var logoutLink = _proxy.TabBar.LogoutTabBarLink
    if (not logoutLink.Visible) {
      _proxy.Logger.debug("No user is currently logged in.")
      return false
    }
    return true
  }

  public function sleep(millis : long) : void {
    try {
      Thread.sleep(millis)
    } catch (e : InterruptedException) {
      // Ignoring sleep interruptions
    }
  }

  property get Logger() : Logger {
    return _proxy.Logger
  }

  protected static function assertThat(actual: Object): ObjectAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: String): StringAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: Object[]): ObjectArrayAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: Collection<Object>): CollectionAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: Boolean): BooleanAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: int): IntAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: long): LongAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function assertThat(actual: BigDecimal): BigDecimalAssert {
    return PLAssertions.assertThat(actual)
  }

  protected static function fail(message : String) {
    PLAssertions.fail(message)
  }

  protected static function assertMonetaryAmountEquals(description : String, expected : MonetaryAmount, actual : MonetaryAmount, marginOfError : BigDecimal = null) {
    assertThat(actual.Currency)
        .as(description)
        .isEqualTo(expected.Currency)
    var condition = marginOfError == null
        ? new BigDecimalTestCondition(expected.Amount)
        : new BigDecimalTestCondition(expected.Amount, marginOfError)
    assertThat(actual.Amount)
        .as(description + "\n" + actual + " is not equal to " + expected + " within margin of error " + marginOfError)
        .satisfies(condition)
  }

  private static class BigDecimalTestCondition extends Condition<BigDecimal> {
    var _marginOfError : BigDecimal
    var _expectedValue : BigDecimal

    construct(expectedValue : BigDecimal) {
      this(expectedValue, BigDecimal.ZERO)
    }

    construct(expectedValue : BigDecimal, marginOfError : BigDecimal) {
      super("The values should be equal within margin of error:" + marginOfError)
      _expectedValue = expectedValue
      _marginOfError = marginOfError
    }

    override function matches(value : BigDecimal) : boolean {
      var difference = value.subtract(_expectedValue)
      return difference <= _marginOfError
    }
  }

}
