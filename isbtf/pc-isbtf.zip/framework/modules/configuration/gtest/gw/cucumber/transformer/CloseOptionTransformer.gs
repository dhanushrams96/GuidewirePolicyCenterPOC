package gw.cucumber.transformer

uses com.google.common.collect.ImmutableSet
uses gw.api.locale.DisplayKey

class CloseOptionTransformer {

  static var _closeOptions : Set<String> as CloseOptions = ImmutableSet.copyOf({
      DisplayKey.get('Job.Operation.NotTaking'),
      DisplayKey.get('Job.Operation.Declining'),
      DisplayKey.get('Job.Operation.Withdraw')})

  internal function findValue(value : String) : String {
    return CloseOptions.firstWhere(\option -> option == value)
  }

  function transform(value : String) : String {
    var option = findValue(value)
    if (option == null) {
      throw new IllegalArgumentException("No valid close option found for " + value)
    }
    return option
  }

}