package gw.cucumber.transformer

uses com.google.common.collect.ImmutableSet
uses gw.api.locale.DisplayKey

class ConflictOverrideTransformer {

  static var _overrideOptions : ImmutableSet<String> as OverrideOptions = ImmutableSet.copyOf({
      DisplayKey.get("Web.Job.Conflict.OverrideNone"),
      DisplayKey.get("Web.Job.Conflict.OverrideAll")})

  internal function findValue(value : String) : String {
    return OverrideOptions.firstWhere(\option -> option == value)
  }

  function transform(value : String) : String {
    var option = findValue(value)
    if (option == null) {
      throw new IllegalArgumentException("No valid conflict override option found for " + value)
    }
    return option
  }
}