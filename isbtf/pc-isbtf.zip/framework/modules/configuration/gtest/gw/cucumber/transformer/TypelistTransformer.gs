package gw.cucumber.transformer

uses gw.api.util.LocaleUtil
uses gw.entity.ITypeList
uses gw.entity.TypeKey
uses gw.lang.reflect.TypeSystem

/**
 * Helper class which defines methods for converting an object to {@link TypeKey}
 */
@Export
class TypelistTransformer<T extends TypeKey> {

  function transform(value : String) : T {
    var typelist = TypeSystem.getByFullNameIfValid(T.Name) as ITypeList<T>
    var typekeys = typelist.getTypeKeys(false)
    return typekeys.firstWhere(\typekey ->
        typekey.DisplayName.equalsIgnoreCase(value) || typekey.getDisplayName(LocaleUtil.toLanguage(LanguageType.getTypeKey("en_US"))).equalsIgnoreCase(value)
    )
  }
}